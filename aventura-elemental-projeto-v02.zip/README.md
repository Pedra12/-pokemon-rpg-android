# RPG 2D para Android

Projeto inicial jogável de RPG 2D vertical, com visual pixel-art desenhado por código, exploração por toque, encontros, batalha por turnos, progressão e salvamento local.

**Importante:** para evitar problemas de direitos autorais, esta implementação usa criaturas e nomes originais, sem artes, sprites, nomes ou outros recursos oficiais de Pokémon.

## Gerar o APK pelo GitHub (sem computador)
1. Crie um repositório vazio no GitHub pelo navegador do celular.
2. Envie os arquivos desta pasta para o repositório, mantendo a estrutura.
3. Abra **Actions** e habilite workflows, se o GitHub pedir.
4. Aguarde **Build Android APK** concluir.
5. Abra a execução concluída e baixe o artefato `rpg-debug-apk`.
6. Extraia o APK e instale no Android. Talvez seja necessário permitir a instalação pelo navegador/gerenciador de arquivos.

## Desenvolvimento
- Kotlin + Jetpack Compose
- Android SDK 35
- Gradle 8.9
- APK debug, sem assinatura de distribuição
