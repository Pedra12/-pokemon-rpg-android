/* ============ mapas por Gen ============ */
// Cada Gen é um mapa com 10 rotas (dados em dados-mapas.js, gerados da PokéAPI por ferramentas/gerar-mapas.ps1).
// As 9 primeiras têm um Alfa; a 10ª é a final: lutar contra os lendários da Gen fecha o mapa.
//   Roguelike: vencer a Gen encerra a run (vitória) e libera o mapa da Gen seguinte pras próximas runs.
//   Outros modos: vencer a Gen deixa escolher a próxima (S.gensVencidas); os níveis do mapa novo começam no seu nível
//   (escalaNivel) — S.nivelInicioGen guarda o nível em que você entrou nele.
// Pokédex da rota: quem você nunca enfrentou é "?"; depois de enfrentar vira silhueta; com REVELA_DERROTADOS
// derrotados (somando todas as jornadas) aparece colorido, com a taxa de aparição na rota.
// Puro (sem DOM): testado em tests/mapas.test.js.
// `GENS` sai de dados.js, não de dados-mapas.js: é lá que o Alfa trocado no editor de rotas (dados-rotas.js) é
// aplicado. Ler o mapa cru aqui faria a troca valer numa tela e não na outra.
import { GENS, REGIOES_INICIAIS, TRANCADA_POR_MISSAO } from './dados.js';
import { MEGAS } from './dados-megas.js';
import { clamp, fmt } from './util.js';

/* ---- iniciais não aparecem nas rotas ----
   O inicial é a escolha que abre a jornada; achar um solto no mato tira o peso dela. Então os 27 iniciais das 9
   regiões e as evoluções deles saem dos pools. Pikachu e Eevee (a região marcada `nasRotas` em REGIOES_INICIAIS)
   ficam: aparecem no mundo nos jogos, e o usuário pediu a exceção.
   Cada trio de uma região ocupa ids SEGUIDOS a partir do primeiro inicial (1–9, 152–160, 252–260, …), então a
   família inteira cabe numa faixa de 9. A limpeza roda uma vez, ao carregar: `rotasDaGen` é chamado o tempo todo. */
const BASES_INICIAIS = REGIOES_INICIAIS.filter(r => !r.nasRotas).flatMap(r => r.ids);
export const ehInicialDeRegiao = id => BASES_INICIAIS.some(b => id >= b && id <= b + 2);
export const MIN_POOL = 5;
/* Rota que ficou curta demais depois da limpeza empresta espécie das rotas vizinhas do MESMO mapa (as de nível mais
   parecido primeiro), entrando com o peso do bicho mais raro de lá — é o que o gerador já faz quando uma rota nasce
   magra. Sem isso, quatro rotas ficariam com 4 espécies e a exploração delas viraria repetição. */
function completarPool(g, z) {
  const tem = new Set(z.pool.map(p => p.id)), meio = (z.min + z.max) / 2;
  const peso = z.pool.length ? Math.min(...z.pool.map(p => p.p)) : 1;
  const vizinhos = g.rotas.filter(r => r !== z)
    .flatMap(r => r.pool.filter(p => !p.m).map(p => ({ p, d: Math.abs((r.min + r.max) / 2 - meio) })))
    .sort((a, b) => a.d - b.d);
  for (const { p } of vizinhos) {
    if (z.pool.length >= MIN_POOL) break;
    if (tem.has(p.id)) continue;
    tem.add(p.id); z.pool.push({ ...p, p: peso });
  }
}
export function tirarIniciais(gens) {
  // 1ª passada: limpa TODAS as rotas. Só depois uma rota empresta pra outra — senão uma rota ainda suja emprestaria
  // justamente o inicial que acabamos de tirar da vizinha.
  const curtas = [];
  for (const g of gens) for (const z of g.rotas) {
    if (z.posVitoria) continue; // o Santuário é justamente onde os iniciais vivem — ver `rotasDaGen`/zonaLiberada
    const limpo = z.pool.filter(p => !ehInicialDeRegiao(p.id));
    if (limpo.length && limpo.length < z.pool.length) { z.pool = limpo; curtas.push([g, z]); }
    // Alfa da rota também não pode ser inicial: vira o Pokémon mais raro do que sobrou, no mesmo nível de sempre.
    // O chefe é `{ id, nome, nivel }` — o `nome` é só o rótulo e o `id` é quem o jogo carrega de verdade (sprite,
    // tipos, golpes). Trocar um sem o outro cria um Alfa de nome "Delphox" com o corpo de outro bicho: foi bug real.
    if (z.chefe && ehInicialDeRegiao(z.chefe.id) && z.pool.length) {
      const raro = z.pool.reduce((a, p) => p.p < a.p ? p : a);
      z.chefe = { ...z.chefe, id: raro.id, nome: fmt(raro.n) };
    }
  }
  for (const [g, z] of curtas) if (z.pool.length < MIN_POOL) completarPool(g, z);
  return gens;
}
tirarIniciais(GENS);

export { GENS };
export const TOTAL_GENS = GENS.length;
export const REVELA_DERROTADOS = 10;
// nível do último lendário (o topo da progressão de um mapa): referência da escala de nível
export const NIVEL_TOPO = 75;

export const genDe = S => S?.gen || 1;
export const dadosDaGen = g => GENS.find(x => x.gen === g) || GENS[0];
export const rotasDaGen = g => dadosDaGen(g).rotas;
export const primeiraRota = g => rotasDaGen(g)[0];
/* A rota FINAL (a dos lendários) é a marcada com `final`, NÃO a última do array — desde o Santuário, a última é ele,
   e ele não tem `lendarios`. Ler `rotas.at(-1).lendarios` passou a devolver undefined e quebrava a tela de escolher
   a próxima Gen no meio da vitória ("Cannot read properties of undefined"), deixando o jogador sem conseguir abrir
   o save de novo — bug real, relatado por um testador ao fechar a Gen 2. Quem precisa dos lendários usa isto. */
export const rotaFinalDaGen = g => rotasDaGen(g).find(z => z.final) || rotasDaGen(g).at(-1);
export const lendariosDaGen = g => rotaFinalDaGen(g)?.lendarios || [];

/* Forma regional desta espécie NESTE mapa, se existir: { id, forma } (ex.: em Alola, 'exeggutor' → exeggutor-alola).
   Quem evolui em Alola vira a forma de Alola — é a regra dos jogos, e é o que faz a Exeggutor de lá (e a Raichu,
   a Marowak, a Muk…) existir de outro jeito que não "encontrar uma pronta no Santuário". Vale pra toda região:
   a fonte é o `f` do próprio mapa gerado, então região nova entra sozinha quando o mapa dela tiver formas.
   Procura no mapa INTEIRO (inclusive o Santuário), porque é lá que a maioria das formas regionais vive. */
export function formaRegionalDaGen(especie, gen) {
  for (const z of rotasDaGen(gen)) {
    const p = z.pool.find(x => x.n === especie && x.f);
    if (p) return { id: p.id, forma: p.f };
  }
  return null;
}

// Nível de um mapa quando você entra nele já forte (fora do Roguelike): o que ia de 2 a 75 passa a ir do seu nível
// até 100, mantendo a proporção. base ≤ 5 (começo de jornada) = níveis originais.
export function escalaNivel(n, base) {
  if (!base || base <= 5) return n;
  return clamp(Math.round(base + (n - 2) * (100 - base) / (NIVEL_TOPO - 2)), 1, 100);
}
/* ---- 🔒 Pokémon de missão fora do pool ----
   Espécie de `dados.ESPECIES_MISSAO` não existe no mundo até a conta cumprir a missão dela. O corte é AQUI porque
   esta é a porta única da rota na jornada (`estado.zone`/`rotasAtuais`): o sorteio, a taxa mostrada, a Pokédex da
   rota e a caça shiny todos leem a rota já filtrada, então nenhuma tela promete um bicho que não vai aparecer.
   `S.liberadas` é a foto tirada na criação da jornada (criacao.iniciarJornada) — save antigo não tem o campo, e
   aí tudo fica trancado até a próxima jornada. Devolve `null` quando não há nada a tirar, pra rota comum seguir
   sendo o MESMO objeto de sempre (isto roda a cada render). */
function poolDaJornada(z, S) {
  if (!z.pool?.some(p => TRANCADA_POR_MISSAO(p.n))) return null;
  const liberadas = S?.liberadas || [];
  const pool = z.pool.filter(p => !TRANCADA_POR_MISSAO(p.n) || liberadas.includes(p.n));
  return pool.length === z.pool.length ? null : pool;
}
// a rota com os níveis que valem nesta jornada (não muta a original). A 1ª rota do mapa continua sempre aberta.
export function rotaNaJornada(z, S) {
  if (!z) return z;
  const pool = poolDaJornada(z, S), b = S?.nivelInicioGen;
  if (!b || b <= 5) return pool ? { ...z, pool } : z;
  const e = n => escalaNivel(n, b);
  return { ...z, ...(pool && { pool }), min: e(z.min), max: e(z.max), libera: z.libera <= 1 ? 1 : e(z.libera),
    chefe: z.chefe && { ...z.chefe, nivel: e(z.chefe.nivel) },
    lendarios: z.lendarios?.map(l => ({ ...l, nivel: e(l.nivel) })) };
}

// sorteio ponderado pela taxa de aparição. `filtro(id)` (ex.: offline, só o que está no cache). null = nada sobrou.
/* `dobrar` = conjunto de nomes de espécie com peso em dobro (regras.especiesDobradas: item de evolução dela na
   mochila). Um peso só pra todo mundo: o sorteio e a taxa MOSTRADA leem a mesma função, senão a tela promete uma
   porcentagem que o sorteio não cumpre. */
export const MULT_ITEM_EVO = 2;
const pesoNaRota = (p, dobrar) => p.p * (dobrar?.has(p.n) ? MULT_ITEM_EVO : 1);
export function sortearDaRota(z, filtro = null, sorte = Math.random, dobrar = null) {
  const pool = filtro ? z.pool.filter(p => filtro(p.id)) : z.pool;
  const total = pool.reduce((a, p) => a + pesoNaRota(p, dobrar), 0);
  if (!total) return null;
  let r = sorte() * total;
  for (const p of pool) { r -= pesoNaRota(p, dobrar); if (r < 0) return p; }
  return pool[pool.length - 1];
}
/* ---- o id que representa uma espécie no registro (`registro.ids`) ----
   Bug relatado em jogo (#62, 26/09/2026): a tela de desbloqueios do Roguelike mostrava "Alakazam #10037" com o
   sprite da MEGA. `batalha.win()` gravava `E.id`, que vira o id da forma Mega enquanto ela está ativa, e o
   inimigo nunca passa por `desfazerMega`. Isso foi corrigido em 27/09 — mas só pra frente: quem já tinha o id
   errado na carreira continuava vendo a Mega pra sempre, porque o progresso da conta NUNCA ENCOLHE.
   A correção aqui é de LEITURA, não do dado: nada é apagado nem reescrito no save. Quem mostra o sprite pergunta
   qual id representa a espécie, e só quando o id guardado é EXATAMENTE uma forma Mega daquela espécie ele é
   trocado pelo id nacional.
   ⚠️ Por que casar contra `MEGAS` e não por faixa de id: as 57 FORMAS REGIONAIS do jogo são gravadas sob a
   espécie base com o id da forma (`{ id: 10100, n: 'raichu', f: 'raichu-alola' }`), e esse id é o CERTO — é o
   sprite do Raichu de Alola que tem de aparecer ali. Qualquer regra do tipo "id >= 10000 está errado" apagaria
   as 57 (o usuário vetou essa ideia justamente por isso). Nenhuma forma regional colide com um id de Mega da
   mesma espécie — as Megas do Raichu são 10304/10305 —, e tests/mapas.test.js trava isso pra sempre, porque os
   dois arquivos de dados são GERADOS e podem mudar. */
let idsBase = null;
function indiceDeIdBase() {
  if (idsBase) return idsBase;
  idsBase = new Map();
  // TODAS as rotas, inclusive o Santuário (`posVitoria`) e os míticos: aqui não se filtra conteúdo de jornada,
  // só se quer saber o id nacional de cada espécie — as 1025 estão nos pools.
  for (const g of GENS) for (const z of g.rotas || []) for (const p of z.pool || [])
    if (!p.f && !idsBase.has(p.n)) idsBase.set(p.n, p.id);
  return idsBase;
}
export const idBaseDaEspecie = nome => indiceDeIdBase().get(nome) ?? null;
export function idDaEspecieNoRegistro(especie, id) {
  if (!id || !MEGAS[especie]?.some(f => f.id === id)) return id || null;   // inclusive as formas regionais: passam intactas
  return idBaseDaEspecie(especie) ?? id;                                    // sem id base conhecido, fica como estava
}

/* Todas as espécies do mapa (qualquer rota da Gen), sem repetir e sem míticos. É de onde os treinadores tiram parte
   da equipe: um treinador ANDA — ele estar na Rota 3 não quer dizer que criou só bicho da Rota 3. A rota dá o nível,
   não a lista de espécies. */
export function especiesDaGen(gen) {
  const vistos = new Map();
  // fora o Santuário: lá moram iniciais, lendários e míticos, e treinador de rota não sai por aí com um Mewtwo.
  // Pokémon de missão também não: ele não é bicho de estimação de ninguém — nem depois de liberado.
  for (const z of rotasDaGen(gen)) if (!z.posVitoria) for (const p of z.pool) if (!p.m && !TRANCADA_POR_MISSAO(p.n) && !vistos.has(p.id)) vistos.set(p.id, p);
  return [...vistos.values()];
}
/* Nomes de todo lendário e mítico do jogo (badge 'ovos1000', ovos.js): saem das MARCAS `l`/`m` dos pools, as mesmas
   que `cacaveisDaRota` usa pra excluir os dois. Derivado, não uma lista nova à mão — mapa novo entra sozinho. Aqui o
   Santuário CONTA (é justamente onde eles moram), ao contrário de `especiesDaGen`. */
export function especiesLendarias() {
  const out = new Set();
  for (const g of GENS) for (const z of g.rotas) for (const p of z.pool || []) if (p.l || p.m) out.add(p.n);
  return [...out];
}
// chance (0–100) de cada encontro selvagem na rota ser esta espécie
export function taxaNaRota(z, id, dobrar = null) {
  const total = z.pool.reduce((a, p) => a + pesoNaRota(p, dobrar), 0), e = z.pool.find(p => p.id === id);
  return e && total ? pesoNaRota(e, dobrar) / total * 100 : 0;
}
/* Texto da taxa: uma casa (raros, duas) e sempre TRUNCADO pra baixo.
   ⚠️ Bugs #74 e #75 (03/10/2026): a soma das taxas MOSTRADAS passava de 100% (101,8% na Estrada da Vitória da
   Gen 4) e o jogador concluiu, com razão, que não sobrava espaço pros míticos — que ficam ocultos na Pokédex da
   rota e valem ~0,4% cada. A conta nunca esteve errada (`taxaNaRota` divide pelo pool inteiro, míticos
   incluídos, e `sortearDaRota` sorteia sobre o mesmo pool): era o ARREDONDAMENTO do texto, que levava oito
   espécies de 11,63% pra "12%". Truncar garante que o que está na tela nunca promete mais do que 100%, então o
   que falta pra fechar é justamente o que está escondido. */
export const textoTaxa = t => {
  const casas = t >= 1 ? 1 : 2, p = 10 ** casas;
  // o epsilon é contra o binário: 3.3 * 10 dá 32.999…, e truncar isso mostraria 3,2%
  return `${(Math.floor(t * p + 1e-9) / p).toFixed(casas).replace(/\.0$/, '').replace('.', ',')}%`;
};

// soma vistos/derrotados de vários registros (jornadas da carreira + a atual): o que você já sabe de cada espécie
export function somarRegistros(registros) {
  const out = { vistos: {}, derrotados: {} };
  for (const r of registros) for (const l of ['vistos', 'derrotados'])
    for (const [e, n] of Object.entries(r?.[l] || {})) out[l][e] = (out[l][e] || 0) + n;
  return out;
}
// Pokédex da rota: estado de cada espécie do pool
//   oculto    = nunca enfrentou ("?")        silhueta = já enfrentou         revelado = REVELA_DERROTADOS derrotados (cor + taxa)
export function pokedexDaRota(z, saber, dobrar = null) {
  return z.pool.map(p => {
    const vistos = saber.vistos[p.n] || 0, derrotados = saber.derrotados[p.n] || 0;
    const estado = derrotados >= REVELA_DERROTADOS ? 'revelado' : vistos || derrotados ? 'silhueta' : 'oculto';
    // `f` = forma regional (raichu-alola): o nome mostrado é o da forma, mas o registro continua na espécie (p.n),
    // que é a chave que o jogo usa pra contar visto/derrotado desde sempre
    return { id: p.id, n: p.n, forma: p.f || null, nome: p.f || p.n, mitico: !!p.m, lendario: !!p.l, estado, derrotados, taxa: taxaNaRota(z, p.id, dobrar), dobrado: !!dobrar?.has(p.n) };
  });
}

/* ---- Caça Shiny (modo ligado na criação: S.cacaShiny) ----
   Quando TODA espécie da rota estiver revelada (REVELA_DERROTADOS derrotados de cada uma), a rota libera a caça:
   você escolhe uma espécie e só ela aparece ali. Míticos ficam de fora da conta — derrotar 10 Mew não é razoável.
   ⚠️ Bug real corrigido (28/09/2026, relatado pelo usuário: "a rota nunca libera a opção de escolher quem
   caçar"): lendários tinham a MESMA razão de ficar de fora (raríssimos no pool, exigir 10 derrotas nunca fecha
   de verdade) mas o filtro só excluía `mitico`, não `lendario` — só importa na prática pro Santuário (11ª rota,
   `posVitoria`), a única que mistura lendários no pool normal (rotas 1–10 nunca têm `l` no pool: os lendários
   delas vivem em `z.lendarios`, fora do sorteio selvagem). Sem essa exclusão, caçar no Santuário travava pra
   sempre num "quase lá" que nunca fechava. */
export const cacaveisDaRota = (z, saber) => pokedexDaRota(z, saber).filter(p => !p.mitico && !p.lendario);
export const rotaLiberaCaca = (z, saber) => { const l = cacaveisDaRota(z, saber); return l.length > 0 && l.every(p => p.estado === 'revelado'); };
// quanto falta pra liberar: { reveladas, total }
export function progressoCaca(z, saber) {
  const l = cacaveisDaRota(z, saber);
  return { reveladas: l.filter(p => p.estado === 'revelado').length, total: l.length };
}
// espécie caçada nesta rota (ou null). `S.caca` = { idDaRota: speciesName }
export const cacaDaRota = (S, z) => (S?.cacaShiny && S.caca?.[z?.id]) || null;

/* ---- Repelentes (itens da loja: `S.repelente = { tipo, passos, especie? }`) ----
   'total'    = nenhum selvagem aparece enquanto durar
   'seletivo' = só a espécie escolhida aparece (se ela vive nesta rota; se não, é como o total)
   Nem um nem outro mexem em treinador, item, dinheiro ou ambientação: só no encontro selvagem. Dura N explorações. */
export const repelenteAtivo = S => (S?.repelente?.passos > 0 ? S.repelente : null);
// quem aparece de verdade nesta rota: repelente seletivo na frente, depois a Caça Shiny; null = sorteio normal
export function especieForcada(S, z) {
  const r = repelenteAtivo(S);
  if (r?.tipo === 'seletivo' && z?.pool?.some(p => p.n === r.especie)) return r.especie;
  return cacaDaRota(S, z);
}
// true = nenhum selvagem aparece agora (repelente total, ou seletivo de uma espécie que não vive aqui)
export function semSelvagens(S, z) {
  const r = repelenteAtivo(S); if (!r) return false;
  return r.tipo === 'total' || !z?.pool?.some(p => p.n === r.especie);
}
// uma exploração passou: gasta um "passo" do repelente. Devolve o que sobrou, 'acabou' no último, ou null.
export function gastarRepelente(S) {
  const r = S?.repelente; if (!r?.passos) return null;
  r.passos--;
  if (r.passos <= 0) { delete S.repelente; return 'acabou'; }
  return r.passos;
}

// luta final: o principal (último da lista) + até 3 dos outros lendários (sorteados, na ordem da lista)
export function sequenciaLendaria(z, sorte = Math.random) {
  const todos = z.lendarios || [];
  if (!todos.length) return [];
  /* O lendário FINAL é sorteado a cada run entre os da Gen — antes era sempre o mais forte da lista, então quem
     fechava Kanto enfrentava Mewtwo toda vez. Sorteando, cada run tem uma luta final diferente e completar a
     Pokédex dos lendários exige voltar ao mapa várias vezes (pedido do usuário).
     Os NÍVEIS são das VAGAS, não dos Pokémon: quem cair na vaga final herda o nível dela (e o reforço de chefe),
     quem entrar como coadjuvante herda o nível dos outros. Sem isso o sorteio bagunçaria a dificuldade — e também
     perderia a escala de `rotaNaJornada`, que já ajustou esses níveis pro seu nível de entrada no mapa. */
  const nivelFinal = todos[todos.length - 1].nivel, nivelOutros = todos[0].nivel;
  const iPrincipal = Math.min(todos.length - 1, Math.floor(sorte() * todos.length));
  const principal = { ...todos[iPrincipal], nivel: nivelFinal };
  const resto = todos.filter((_, i) => i !== iPrincipal);
  const outros = resto.map((l, i) => ({ l, i, k: sorte() })).sort((a, b) => a.k - b.k).slice(0, 3)
    .sort((a, b) => a.i - b.i).map(x => ({ ...x.l, nivel: nivelOutros }));
  return [...outros, principal];
}

// Fora do Roguelike, depois de fechar uma Gen: muda pro mapa `g`, com os níveis a partir do seu (escalaNivel)
export function entrarNaGen(S, g) {
  S.gen = g; S.nivelInicioGen = S.player.level; S.zone = primeiraRota(g).id;
  delete S.escolhendoGen;
}

// Roguelike: mapas liberados = Gen 1 + a seguinte de cada Gen vencida (sempre em sequência) — pela carreira
export function gensLiberadasRoguelike(jornadas) {
  let max = 0;
  // genVencida conta mesmo que a run tenha acabado em derrota DEPOIS da vitória: quem fecha a Gen e escolhe seguir
  // no Santuário não perde o mapa seguinte se morrer lá (batalha.vencerGen grava S.genVencida na hora da vitória).
  for (const j of jornadas || []) if (j.dificuldade === 'roguelike' && (j.motivo === 'venceu' || j.genVencida)) max = Math.max(max, j.genVencida || 0);
  return Array.from({ length: Math.min(TOTAL_GENS, max + 1) }, (_, i) => i + 1);
}
