/* ============ render: criação ============ */
// Tela inicial: passo 1 dificuldade, passo 2 espécie (só os iniciais — REGIOES_INICIAIS — salvo modo com
// `especiesLivres`), prévia (habilidade, natureza, nível, apelido) e início do jogo.
import { G, save, nm, registrar } from './estado.js';
import { $, limparTopo, semAnimacao, log } from './ui.js';
import { badge, buildGame } from './render.js';
import { makeMon, IVS_MAX } from './pokemon.js';
import { IMPL } from './habilidades.js';
import { SPR, espelhar, STATS, STAT_PT, NATURES, DIFICULDADES, REGIOES_INICIAIS, INICIAIS, DESBLOQUEIO, ITEMS, PSEUDO_LENDARIOS, ESPECIES_MISSAO } from './dados.js';
import { GENS, rotasDaGen, dadosDaGen, gensLiberadasRoguelike , lendariosDaGen, especiesLendarias } from './mapas.js';
import { ovoDeBadge } from './ovos.js';
import { barraTelas } from './navegacao.js';
import { guardar } from './saves.js';
import { carregarCarreira, desbloqueadasDaConta, badgesDaCarreira, vantagensDaConta, especiesLiberadasDaConta } from './carreira.js';
import { pokedexDaConta } from './pokedex-conta.js';
import { vantagensDe } from './badges.js';
import { modoComEvento, eventoDaGen, agenda, agoraDoEvento, jaComecou, dataBR, INICIO, BETA_SEM_ESPERA, EVENTOS } from './evento.js';
import { htmlComoFuncionam } from './ajuda-chefes.js';
import { progressoRoguelike, desbloqueadas, textoProgresso } from './roguelike.js';
import { natureLabel, defaultMoves, zonaLiberada, maxAliados } from './regras.js';
import { oficioDe, OFICIOS } from './oficios.js';
import { FELICIDADE_ALIADO } from './evolucao.js';
import { syncGet, loadAbility, loadSpecies, loadGrowth, loadEvo, loadList, resolvePokemon, apiErr } from './api.js';
import { blocoAds, ativarSlots } from './ads.js';
import { aoMudarOnline, onlineAgora, contagemAnonimos } from './presenca.js';
import { ehAdmin, podeUsarModo } from './nuvem.js';
import { tocarMusica, tocarCry } from './som.js';

// "Ad slot" da tela inicial. Mora em config.js junto com os outros: vazio = blocoAds() não desenha nada.
import { AD_SLOT_INICIO } from './config.js';
import { rand, pick, esc, fmt, novoId } from './util.js';

const livres = () => DIFICULDADES[G.dif].especiesLivres;
/* Ids que dá pra escolher: iniciais + TODOS os desbloqueados na carreira. null = qualquer um (modo livre).
   O desbloqueio continua sendo conquistado só jogando Roguelike (roguelike.js), mas a espécie desbloqueada vale
   em QUALQUER modo — conquista de conta que só serve num modo é conquista pela metade (decisão do usuário). */
function permitidos() {
  if (livres()) return null;
  return [...new Set([...INICIAIS, ...desbloqueadasDaConta().map(p => p.id)])];
}

// Passo 1 = dificuldade (sempre visível no topo), passo 2 = escolher o Pokémon — ou, no Randomizer, um botão só.
export function showCreate() {
  G.mode = 'create'; limparTopo(); tocarMusica('menu');
  $('#app').innerHTML = `<main class="create">
    ${barraTelas('create')}
    <h1>Escolha quem você vai ser.</h1>
    <div id="online-agora"></div>
    <p class="lead">Stats, IVs, EVs, natureza, golpes, XP e evolução seguem as fórmulas dos jogos. Você não tem treinador: é você na grama alta. Os outros Pokémon você encontra pelo caminho.</p>
    <h3 class="passo"><span>1</span> Dificuldade</h3>
    <div id="difs" class="difs"></div>
    <h3 class="passo"><span>2</span> Mapa (Gen)</h3>
    <div id="gens"></div>
    <details class="opcoes-jornada" ${larguraLarga() ? 'open' : ''}>
      <summary><b>⚙ Opções da jornada</b> <span class="muted small">vantagens da conta · caça shiny · clima e terreno</span></summary>
      <div id="vantagens"></div>
      <label class="check caca-opcao"><input type="checkbox" id="pv-caca" ${G.cacaShiny ? 'checked' : ''}> 🎯 Modo Caça Shiny
        <small class="muted">Quando você revelar todas as espécies de uma rota (10 derrotados de cada), pode escolher UMA delas pra ser a única que aparece ali. Serve pra caçar shiny — ou o que você quiser — sem depender da sorte do sorteio. Só dá pra ligar agora, no começo da jornada.</small></label>
      <div id="clima-opcao"></div>
    </details>
    <div id="agenda-evento"></div>
    <h3 class="passo"><span>3</span> <span id="passo2-titulo">Escolha o Pokémon</span></h3>
    <div id="escolha"></div>
    <div id="rnd" hidden><button class="btn big" data-act="randomizer">🎲 Sortear tudo e começar</button></div>
    <div id="netwarn"></div>
    <div id="preview"></div>
    <div id="comitiva"></div>
    ${blocoAds(AD_SLOT_INICIO)}
    <p class="small muted rodape-creditos">© 2026 Jonas Sprocatti · <a href="https://github.com/JonasSprocatti/PokeRPG" target="_blank" rel="noopener">código-fonte no GitHub</a></p></main>`;
  renderDificuldade();
  ativarSlots();
  aoMudarOnline(renderOnline);
}
// passo 2: grade de iniciais por região (padrão) ou busca livre (modo com `especiesLivres`)
function renderEscolha() {
  if (!livres()) {
    $('#escolha').innerHTML = `<p class="small muted">Os iniciais de cada região, mais Pikachu e Eevee.</p>
      <div class="regioes">${REGIOES_INICIAIS.map(r => `<div class="regiao"><h4>${r.nome}</h4><div class="picks">${r.ids.map((id, i) =>
        `<button class="pick" data-act="pick" data-v="${id}"><img src="${SPR(id)}" alt="" loading="lazy">${r.nomes[i]}</button>`).join('')}</div></div>`).join('')}</div>
      ${secaoDesbloqueios()}
      <div class="subrow" style="margin-top:12px"><button class="btn ghost" data-act="random">Sortear entre os disponíveis</button></div>`;
    ligarBuscaDesbloqueados();
    return;
  }
  $('#escolha').innerHTML = `<div class="search">
      <input id="q" list="dex" placeholder="Nome em inglês ou número (ex.: eevee, 448)" autocomplete="off" aria-label="Buscar Pokémon">
      <button class="btn" data-act="search">Buscar</button>
      <button class="btn ghost" data-act="random">Sortear</button>
    </div><datalist id="dex"></datalist>`;
  loadList().then(list => { if ($('#dex')) $('#dex').innerHTML = list.map(n => `<option value="${n}">`).join(''); })
    .catch(e => { $('#netwarn').innerHTML = `<div class="notice">${apiErr(e)}</div>`; });
}
/* Espécies desbloqueadas: valem em TODOS os modos (decisão do usuário — conquista de conta que só serve num modo
   é conquista pela metade). O que continua sendo só do Roguelike é CONQUISTAR o desbloqueio, e o texto diz isso
   quando você está em outro modo: um jogador terminou uma jornada inteira no Difícil achando que estava liberando
   o que derrotava, e a decepção só apareceu no fim. */
// a partir de quantos desbloqueados vale a pena mostrar a busca (com poucos, o campo só atrapalha)
const MIN_PRA_BUSCAR = 12;

/* Filtra a grade de desbloqueados sem redesenhar nada: só liga/desliga `hidden` em cada botão. Redesenhar a
   cada tecla apagaria o que foi digitado e perderia o foco do campo.
   Casa por NOME e por NÚMERO da Pokédex — quem decorou o número procura por ele. */
function ligarBuscaDesbloqueados() {
  const campo = $('#busca-desbloq'), lista = $('#lista-desbloq');
  if (!campo || !lista) return;
  campo.oninput = () => {
    const q = campo.value.trim().toLowerCase();
    let achou = 0;
    for (const b of lista.children) {
      const bate = !q || (b.dataset.nome || '').includes(q) || (b.dataset.num || '').startsWith(q);
      b.hidden = !bate;
      if (bate) achou++;
    }
    const vazio = $('#busca-vazia'); if (vazio) vazio.hidden = !!achou;
  };
}

function secaoDesbloqueios() {
  const prog = progressoRoguelike(carregarCarreira().jornadas);
  /* Os desbloqueados vêm do progresso permanente (nunca somem); o `quase lá` continua vindo do histórico.
     **Ordem da Pokédex** (pedido do usuário): a lista vinha na ordem em que cada espécie foi desbloqueada, que
     não é ordem nenhuma pra quem procura um Pokémon específico. */
  const livresJa = [...desbloqueadasDaConta()].sort((a, b) => (a.id || 0) - (b.id || 0));
  const quase = prog.filter(p => !p.desbloqueada).slice(0, 6);
  const regra = `Pra desbloquear uma espécie, somando suas jornadas <b>Roguelike</b>: derrote ${DESBLOQUEIO.derrotados}, faça amizade com ${DESBLOQUEIO.amigos}, ou evolua pra ela ${DESBLOQUEIO.evolucaoMeio}× (forma do meio) / ${DESBLOQUEIO.evolucaoFinal}× (forma final). Depois de desbloqueada, ela vale em <b>qualquer modo</b>${DIFICULDADES[G.dif].desbloqueios ? '' : ' — inclusive neste, embora jogar aqui não conte pra desbloquear novas'}.`;
  return `<div class="regiao desbloq"><h4>🔓 Desbloqueados (${livresJa.length})</h4>
      ${livresJa.length ? `${livresJa.length >= MIN_PRA_BUSCAR ? `<label class="campo busca-desbloq">Procurar<input id="busca-desbloq" type="search" placeholder="Nome em inglês ou número (ex.: gengar, 94)" autocomplete="off"></label>` : ''}
      <div class="picks" id="lista-desbloq">${livresJa.map(p => `<button class="pick" data-act="pick" data-v="${p.id}" data-nome="${esc(p.especie)}" data-num="${p.id}" title="${esc(textoProgresso(p))}"><img src="${SPR(p.id)}" alt="" loading="lazy">${esc(fmt(p.especie))} <small class="muted">#${p.id}</small></button>`).join('')}</div>
      <p class="small muted" id="busca-vazia" hidden>Nenhum desbloqueado com esse nome.</p>` : ''}
      <p class="small muted">${regra}</p>
      ${quase.length ? `<h4>Quase lá</h4><ul class="quase">${quase.map(p => `<li>${p.id ? `<img src="${SPR(p.id)}" alt="">` : ''}<b>${esc(fmt(p.especie))}</b><div class="bar"><div class="fill" style="width:${p.fracao * 100}%"></div></div><small>${esc(textoProgresso(p))}</small></li>`).join('')}</ul>` : ''}
    </div>`;
}
/* Marcador "jogando agora" (presenca.js — canal Realtime global, sem config vira null e o bloco some). O número
   de visitantes sem conta ao lado é ADMIN-ONLY (pedido do usuário): só quem tem `perfis.admin` vê, e só na tela
   inicial — não é uma estatística que interessa a quem só está jogando. `anonimosCache` evita pedir a RPC de
   novo a cada re-render (undefined = nunca pediu, null = não pôde saber/não é admin, number = total). */
let anonimosCache;
function renderOnline() {
  const el = $('#online-agora'); if (!el || G.mode !== 'create') return;
  const n = onlineAgora();
  if (ehAdmin() && anonimosCache === undefined) {
    anonimosCache = null;
    contagemAnonimos().then(v => { anonimosCache = v; renderOnline(); });
  }
  const anon = ehAdmin() && anonimosCache != null
    ? ` <span class="muted small" title="Só admin vê isso">· ${anonimosCache} sem conta desde sempre</span>` : '';
  el.innerHTML = n === null ? '' : `<p class="online-marcador"><span class="dot-viva" aria-hidden="true">🟢</span> ${n} jogando agora${anon}</p>`;
}
/* Vantagens da conta (badges.js): o que as suas conquistas dão nesta jornada, e o interruptor pra jogar sem elas.
   Quem desliga ganha bônus de pontuação no ranking — a ideia é que o desafio puro continue valendo a pena. */
function renderVantagens() {
  const el = $('#vantagens'); if (!el) return;
  const ganhas = badgesDaCarreira().filter(b => b.completo);
  const v = vantagensDe(ganhas);
  const itens = Object.entries(v.itens).map(([k, n]) => `${esc(ITEMS[k]?.name || k)} ×${n}`);
  const ovoTexto = { pseudo: '🥚 um ovo de pseudo-lendário', lendario: '🥚 um ovo de lendário ou mítico' };
  const linhas = [...itens, v.dinheiro ? `₽${v.dinheiro.toLocaleString('pt-BR')} a mais` : '', v.lojaGratis ? 'loja de graça' : '', v.ivsPerfeitos ? '🧬 seus IVs em 31' : '', v.ivsSelvagens ? '🌿 IVs 31 em todo selvagem' : '',
    ...(v.ovos || []).map(t => ovoTexto[t] || '🥚 um ovo')].filter(Boolean);
  el.innerHTML = `<label class="check caca-opcao"><input type="checkbox" id="pv-sem-vantagens" data-act="sem-vantagens" ${G.semVantagens ? 'checked' : ''}>
      🎖 Jogar sem as vantagens da conta
      <small class="muted">${ganhas.length
        ? `Você conquistou <b>${ganhas.length}</b> badge${ganhas.length > 1 ? 's' : ''} e começaria com: ${esc(linhas.join(' · '))}.
           Desligar deixa a jornada mais dura e <b>rende mais pontos</b> no ranking.`
        : 'Você ainda não tem badges. Quando tiver, elas dão itens e dinheiro no começo de cada jornada — e aqui dá pra abrir mão deles por mais pontos.'}</small></label>`;
}
/* 🌦 Clima e terreno das rotas: no Roguelike e no Hardcore são SEMPRE ligados (a caixa aparece marcada e travada);
   nos outros modos é opção, desligada por padrão. Como a caixa é redesenhada a cada troca de dificuldade, ela sempre
   reflete o modo atual. */
function renderClimaOpcao() {
  const el = $('#clima-opcao'); if (!el) return;
  const fixo = !!DIFICULDADES[G.dif].climaRotasFixo;
  el.innerHTML = `<label class="check caca-opcao"><input type="checkbox" id="pv-clima" ${fixo || G.climaRotas ? 'checked' : ''} ${fixo ? 'disabled' : ''}> 🌦 Clima e terreno das rotas
      <small class="muted">Várias rotas começam a luta com o tempo da paisagem (neve, areia, chuva, sol) ou com um terreno (grama, elétrico…), valendo para os dois lados. Um golpe ou habilidade troca por 5 turnos e depois a rota volta ao padrão. ${fixo ? '<b>Neste modo é sempre ligado.</b>' : 'Desligado por padrão. Só dá pra ligar agora, no começo da jornada.'}</small></label>`;
}
/* ☄ Agenda dos chefes da semana (evento.js): o aviso do primeiro chefe enquanto o evento não começou, e os próximos 3 chefes com
   as datas. Só nos modos que jogam evento (Roguelike e Hardcore) — nos outros ela nem aparece, pra não prometer o que não vale. */
function renderAgendaEvento() {
  const el = $('#agenda-evento'); if (!el) return;
  if (!modoComEvento(G.dif)) { el.innerHTML = ''; return; }
  const agora = agoraDoEvento(), lista = agenda(agora, 3);
  /* Recolhida no celular: eram ~450 px de cartão roxo entre o mapa e a escolha do Pokémon, e quem veio jogar
     rolava tudo isso pra chegar nos iniciais. O resumo já diz quem é o chefe desta semana (e os cartões de mapa
     acima trazem o sprite dele com o selo ☄). Aberta no computador, onde sobra espaço. */
  const atual = lista.find(a => a.atual) || lista[0];
  el.innerHTML = `<details class="agenda-evento" aria-label="Agenda dos chefes da semana" ${larguraLarga() ? 'open' : ''}>
    <summary><b>☄ Chefes da semana</b> <span class="muted small">${jaComecou(agora) ? `· esta semana: ${esc(atual.evento.nome)}` : `· o primeiro chega em ${dataBR(INICIO)}`}</span></summary>
    ${jaComecou(agora) ? '' : `<p class="agenda-aviso" role="status">🚨 <b>O primeiro chefe chega em ${dataBR(INICIO)}</b> (segunda-feira, 00:00 de Brasília): <b>${esc(lista[0].evento.nome)}</b>. Prepare o seu time — é muito difícil.</p>`}
    <ol class="agenda-lista">${lista.map(a => `<li class="${a.atual ? 'atual' : ''}"><img src="${SPR(a.evento.formaId)}" alt="" loading="lazy">
      <div><b>${esc(a.evento.nome)}</b> <span class="muted small">Gen ${a.evento.gen} · ${esc(dadosDaGen(a.evento.gen).regiao)}</span>
      <small>${a.atual ? '<b>Esta semana</b> · ' : ''}${dataBR(a.inicio)} a ${dataBR(a.fim - 1)}</small></div></li>`).join('')}</ol>
    <details class="agenda-ano"><summary>📅 Calendário do ano inteiro (${EVENTOS.length} chefes; depois a lista recomeça)</summary>
      <ol>${agenda(agora, 52).map(a => `<li class="${a.atual ? 'atual' : ''}"><span class="muted">${dataBR(a.inicio)}</span> <b>${esc(a.evento.nome)}</b> <span class="muted small">Gen ${a.evento.gen}</span></li>`).join('')}</ol></details>
    <p class="small muted">O chefe muda toda segunda-feira à meia-noite (horário de Brasília). Ele aparece na rota final da Gen dele${BETA_SEM_ESPERA ? ' (🧪 modo beta: sem espera entre tentativas)' : ', uma tentativa a cada 8 horas'} — ou na <b>Arena</b>, com os Pokémon do seu Hall da Fama.</p>
    <div class="subrow"><button class="btn" data-act="arena">🏟 Arena do Chefe</button></div>
    ${htmlComoFuncionam()}</details>`;
}
// computador e tablet largo: tudo aberto; celular: grupos recolhidos (ver as `<details>` da criação)
const larguraLarga = () => typeof window !== 'undefined' && window.innerWidth > 720;
// mapas que dá pra escolher neste modo: no Roguelike (fimNaGen), só os liberados vencendo a Gen anterior; nos outros, todos
const gensLiberadas = () => DIFICULDADES[G.dif].fimNaGen ? gensLiberadasRoguelike(carregarCarreira().jornadas) : GENS.map(x => x.gen);
// passo 2: mapa (Gen). Full Randomizer sorteia o mapa também (não mostra escolha)
function renderGens() {
  const ok = gensLiberadas();
  if (!ok.includes(G.gen)) G.gen = ok[ok.length - 1];
  if (G.dif === 'randomizer') { $('#gens').innerHTML = '<p class="small muted">🎲 O mapa também é sorteado.</p>'; return; }
  // o rosto do mapa é o lendário principal — pega da rota FINAL (mapas.lendariosDaGen), nunca da última do array
  // Roguelike/Hardcore: o chefe da semana ocupa o lugar do rosto do mapa, com brilho (evento.js) — o boss final da Gen "mudou"
  const comEvento = modoComEvento(G.dif);
  $('#gens').innerHTML = `<div class="gens">${GENS.map(x => { const lib = ok.includes(x.gen), lend = lendariosDaGen(x.gen), ev = comEvento ? eventoDaGen(x.gen) : null;
    return `<button class="gen-card ${G.gen === x.gen ? 'on' : ''} ${lib ? '' : 'trancada'} ${ev ? 'evento' : ''}" data-act="gen" data-v="${x.gen}" ${lib ? '' : 'disabled'} aria-pressed="${G.gen === x.gen}" title="${lib ? (ev ? `Evento da semana: ${ev.nome}` : '') : `Vença a Gen ${x.gen - 1} no Roguelike pra liberar`}">
      ${ev ? `<img class="evento-sprite" src="${SPR(ev.formaId)}" alt="" loading="lazy"><small class="evento-tag">☄ Evento</small>` : lend.length ? `<img src="${SPR(lend.at(-1).id)}" alt="" loading="lazy">` : ''}<b>${lib ? '' : '🔒 '}Gen ${x.gen}</b><span>${x.regiao}</span></button>`; }).join('')}</div>
    <p class="small muted">${DIFICULDADES[G.dif].fimNaGen ? 'No Roguelike, vencer os lendários de um mapa encerra a run em vitória e libera o mapa da Gen seguinte.' : 'Cada mapa tem 10 rotas; vencer os lendários da última deixa você escolher o próximo mapa, com a mesma equipe.'} Os Pokémon selvagens são os daquela Gen.</p>`;
}
/* Modos em construção (`admin: true` em DIFICULDADES, hoje o ⚔ Saga) aparecem SÓ pra conta de manutenção —
   mesmo critério do 🗺 Editor de rotas e do painel de testes (`nuvem.ehAdmin`, que exige login e `perfis.admin`).
   Esconder o cartão não é a trava: `iniciarJornada` confere de novo, porque `data-v` vem de atributo do HTML. */
const modosVisiveis = () => Object.entries(DIFICULDADES).filter(([, x]) => podeUsarModo(x));

// cartões de dificuldade + monta os passos 2 e 3 conforme o modo (Randomizer não escolhe Pokémon nem mapa)
export function renderDificuldade() {
  if (!podeUsarModo(DIFICULDADES[G.dif])) G.dif = 'roguelike';   // deslogou (ou perdeu o acesso) com um modo em construção escolhido
  $('#difs').innerHTML = modosVisiveis().map(([k, x]) => `<button class="abil ${G.dif === k ? 'on' : ''}" data-act="dificuldade" data-v="${k}" aria-pressed="${G.dif === k}"><b>${k === 'randomizer' ? '🎲 ' : ''}${x.nome}</b>${x.admin ? `<em>${ehAdmin() ? '🔒 em construção · só admin' : '🧪 em construção · você é testador'}</em>` : ''}<small>${esc(x.desc)}</small></button>`).join('');
  renderGens();
  renderVantagens();
  renderClimaOpcao();
  renderAgendaEvento();
  const rnd = G.dif === 'randomizer';
  $('#escolha').hidden = rnd; $('#rnd').hidden = !rnd;
  $('#passo2-titulo').textContent = rnd ? 'Tudo sorteado' : 'Escolha o Pokémon';
  if (!rnd) renderEscolha();
  // prévia de uma espécie que este modo não permite (ex.: desbloqueada, mas trocou pra um modo sem desbloqueios) some
  const ok = permitidos();
  if (G.PV && ok && !ok.includes(G.PV.data.id)) G.PV = null;
  if (rnd || !G.PV) $('#preview').innerHTML = '';
  else renderPreview();
  renderComitiva();   // ⚔ Saga: o passo 4 só existe nesse modo (e o ofício mostrado depende da sua espécie)
}
// "Sortear": entre os iniciais, ou entre todos se o modo for livre
export const sortearEspecie = () => { const ok = permitidos(); return previewSearch(ok ? pick(ok) : rand(1, 1025)); };
export async function previewSearch(q) {
  q = String(q).trim().toLowerCase().replace(/\s+/g, '-'); if (!q) return;
  const box = $('#preview'); box.innerHTML = '<p class="loading">Consultando a PokéAPI…</p>';
  /* DUAS metades, com tratamentos DIFERENTES de propósito. Antes era um `try` só em volta de tudo, e qualquer
     erro virava a mensagem de rede — foi assim que um `ReferenceError` numa função que faltava (opcaoShiny) se
     disfarçou de "A conexão falhou ao buscar um dado da PokéAPI" e travou a criação de jornada inteira, com o
     jogador limpando cache e trocando de rede atrás de um problema que não estava lá.
     Regra: só o que fala com a rede pode reportar erro de rede. */
  let data;
  try {
    data = await resolvePokemon(q);
  } catch (e) {
    box.innerHTML = `<p class="err">${e.code === 404 ? `Nenhum Pokémon chamado “${esc(q)}”. Use o nome em inglês (ex.: mr-mime) ou o número da Pokédex.` : apiErr(e)}</p>`;
    return;
  }
  tocarCry(data.id);   // quem você escolheu se apresenta (pedido do usuário) — o clique no card já é o gesto que libera o áudio
  try {
    // garantia (a UI só oferece iniciais, mas `pick`/`search` vêm de atributo do HTML)
    const ok = permitidos();
    if (ok && !ok.includes(data.id)) { box.innerHTML = '<p class="err">Neste modo só dá pra começar com um inicial, Pikachu, Eevee ou uma espécie desbloqueada.</p>'; return; }
    // nível sobrevive a trocar de espécie na prévia; a dificuldade mora em G.dif (passo 1)
    G.PV = { data, ability: (data.abilities.find(a => !a.hidden) || data.abilities[0])?.name, nature: pick(Object.keys(NATURES)), level: G.PV?.level || 5, nick: '' };
    renderPreview();
    data.abilities.forEach(a => loadAbility(a).then(() => { if (G.PV?.data === data) renderPreview(); }).catch(() => {}));
    box.scrollIntoView({ behavior: semAnimacao() ? 'auto' : 'smooth', block: 'start' });
  } catch (e) {
    console.error('prévia:', e);
    box.innerHTML = `<p class="err">Não consegui montar a prévia de ${esc(fmt(data.name))}: ${esc(e.message)}.<br>
      <small>Isto é um problema do jogo, não da sua conexão — os dados chegaram normalmente.</small></p>`;
  }
}
// nível que vale de fato: a escolha do jogador só conta se a dificuldade deixar (senão 5)
const nivelInicial = PV => DIFICULDADES[G.dif].nivelLivre ? PV.level : 5;

/* Começar shiny: liberado pra espécie de que você JÁ recrutou um shiny em alguma jornada (decisão do usuário —
   "se você capturar um Shiny, desbloqueia ele e tem a opção de usar ele Shiny na Run"). Quem nunca recrutou não
   vê nada, e continua no sorteio normal de 1 em 4096.
   A conta sai da Pokédex da conta (`shiniesAmigos` por espécie), que soma a carreira inteira e não encolhe.
   ATENÇÃO — esta função ESTAVA FALTANDO: era chamada aqui e não existia em lugar nenhum do projeto, então
   `renderPreview()` lançava ReferenceError a cada clique numa espécie. Como a chamada mora dentro do `try` de
   `previewSearch`, o erro saía traduzido como "A conexão falhou ao buscar um dado da PokéAPI" e ninguém
   conseguia começar jornada nenhuma pela tela de criação (o Full Randomizer escapava por não desenhar a prévia).
   Se for mexer aqui, lembre: o que quebrar nesta função vira "erro de rede" na cara de quem joga. */
function opcaoShiny(d) {
  const dex = pokedexDaConta(carregarCarreira().jornadas, G.S?.registro);
  const tem = dex.porNome?.[d.speciesName]?.shiniesAmigos || 0;
  if (!tem) return '';
  return `<label class="check caca-opcao" style="margin-top:12px"><input type="checkbox" id="pv-shiny" ${G.PV?.shiny ? 'checked' : ''}>
    ✨ Começar shiny
    <small class="muted">Você já recrutou ${tem === 1 ? 'um' : tem} ${esc(fmt(d.name))} shiny, então pode ser um também. Só muda as cores — nada de status.</small></label>`;
}
/* ⚔ Saga: o ofício da espécie escolhida, na prévia. Só nesse modo — nos outros a palavra "ofício" não significa
   nada, e prometer função de RPG onde ela não existe é pior que não falar. `oficioDe` é puro e não vai à rede:
   `base` e `learnset` já vieram com a prévia. */
function blocoOficio(d) {
  if (G.dif !== 'saga') return '';
  const o = oficioDe(d);
  if (!o) return '';
  return `<p class="small" style="margin-top:6px">Ofício: <b>${o.emoji} ${esc(o.nome)}</b>
    <span class="muted">· ${esc(OFICIOS[o.maior].funcao)}. Lido dos stats base e do que a espécie aprende — não dá pra escolher.</span></p>`;
}
export function renderPreview() {
  const PV = G.PV, d = PV.data, total = STATS.reduce((a, s) => a + d.base[s], 0);
  const nickVal = $('#pv-nick')?.value ?? PV.nick; PV.nick = nickVal;
  const dif = DIFICULDADES[G.dif], livre = dif.escolhaLivre, nivel = nivelInicial(PV);
  const sorteada = '<small class="muted"> · sorteada ao começar</small>';
  $('#preview').innerHTML = `<section class="pv">
    <div class="pv-art"><img src="${espelhar(d.art || d.sprite)}" alt="${esc(fmt(d.name))}"></div>
    <div>
      <p class="dexno">Nº ${String(d.id).padStart(4, '0')}</p>
      <h2>${esc(fmt(d.name))}</h2>
      <div class="types">${d.types.map(badge).join('')}</div>
      <div class="basestats">${STATS.map(s => `<div class="bs"><span>${STAT_PT[s]}</span><b>${d.base[s]}</b><i style="width:${Math.min(100, d.base[s] / 255 * 100)}%"></i></div>`).join('')}
        <div class="bs total"><span>Total</span><b>${total}</b><i></i></div></div>
      <p class="small muted" style="margin-top:14px">Modo <b>${dif.nome}</b> (troque no passo 1, lá em cima).</p>
      ${blocoOficio(d)}
      <h3>Habilidade${livre ? '' : sorteada}</h3>
      <div class="abils">${d.abilities.map(a => `<button class="abil ${livre && PV.ability === a.name ? 'on' : ''}" data-act="ability" data-v="${a.name}" aria-pressed="${livre && PV.ability === a.name}" ${livre ? '' : 'disabled'}><b>${esc(fmt(a.name))}</b>${a.hidden ? '<em>oculta</em>' : ''}${IMPL.has(a.name) ? '<span class="impl">✓ ativa em batalha</span>' : '<span class="impl-futura">efeito em batalha: será ajustado em atualizações futuras</span>'}<small>${esc(syncGet('ab:' + a.name)?.effect || 'Carregando…')}</small></button>`).join('')}</div>
      <div class="row3">
        <label>Natureza${livre ? `<select id="pv-nature">${Object.keys(NATURES).map(n => `<option value="${n}" ${n === PV.nature ? 'selected' : ''}>${esc(natureLabel(n))}</option>`).join('')}</select>` : '<select disabled><option>Sorteada ao começar</option></select>'}</label>
        <label>Nível inicial${dif.nivelLivre ? `<select id="pv-level">${[5, 15, 30, 50].map(l => `<option ${l === PV.level ? 'selected' : ''}>${l}</option>`).join('')}</select>` : `<select disabled title="${dif.nome}: começa no nível 5"><option>5</option></select>`}</label>
        <label>Apelido<input id="pv-nick" maxlength="12" placeholder="${esc(fmt(d.name))}" value="${esc(PV.nick)}"></label>
      </div>
      ${opcaoShiny(d)}
      <p class="small muted" style="margin-top:14px">Golpes iniciais: ${defaultMoves(d.learnset.list, nivel).map(m => esc(fmt(m.name))).join(', ')}. Lista de golpes por nível vinda de ${esc(fmt(d.learnset.vg) || '—')}.</p>
      <div class="pv-comecar"><button class="btn big" data-act="start">Começar como ${esc(fmt(d.name))}</button></div>
    </div></section>`;
}
/* ============ ⚔ Saga: montar a comitiva na criação ============
   No Saga você escolhe quem vai com você (decisão do usuário, 02/10/2026) em vez de recrutar com petisco pelo
   caminho: a comitiva de ofícios complementares é o que a fase 1 existe pra avaliar, e esperar meia hora de jogo
   pra ter um Curandeiro inviabiliza testar.

   Um clique = UMA busca, de propósito: mostrar o ofício de todos os candidatos de uma vez custaria ~30
   requisições à PokéAPI ao abrir a tela (o ofício precisa de `base` e `learnset`, e a grade só tem id e sprite).
   É o mesmo desenho da prévia do passo 3 — você clica, ele busca, o ofício aparece.
   `G.comitiva` vive na tela (não no save): quem começa a jornada é `iniciarJornada`. */
const candidatosDaComitiva = () => permitidos() || INICIAIS;

export function renderComitiva() {
  const el = $('#comitiva'); if (!el) return;
  if (G.dif !== 'saga') { el.innerHTML = ''; return; }
  const teto = maxAliados('saga'), escolhidos = G.comitiva || [];
  const meu = G.PV ? oficioDe(G.PV.data) : null;
  el.innerHTML = `<h3 class="passo"><span>4</span> Comitiva <span class="muted small">(${escolhidos.length}/${teto})</span></h3>
    <p class="small muted">Quem vai com você. ${meu ? `Você é <b>${meu.emoji} ${esc(meu.nome)}</b> — ` : ''}a ideia é cobrir os ofícios que faltam: alguém que segure a linha, alguém que cure, alguém que machuque.
      Dá pra começar com menos e recrutar o resto no caminho, com petisco.</p>
    ${escolhidos.length ? `<div class="aliados">${escolhidos.map((c, i) => `<div class="ali-card">
        <img src="${espelhar(c.data.sprite)}" alt="" loading="lazy">
        <div><b>${esc(fmt(c.data.name))}</b><small class="muted">${c.oficio ? `${c.oficio.emoji} ${esc(c.oficio.nome)}` : 'ofício desconhecido'}</small></div>
        <button class="btn sm ghost" data-act="comitiva-tirar" data-v="${i}">✕ Tirar</button>
      </div>`).join('')}</div>` : ''}
    ${escolhidos.length < teto ? `<div class="picks" style="margin-top:10px">${candidatosDaComitiva().map(id =>
      `<button class="pick" data-act="comitiva-por" data-v="${id}"><img src="${SPR(id)}" alt="" loading="lazy">#${id}</button>`).join('')}</div>
      <p class="small muted" id="comitiva-aviso"></p>` : '<p class="small muted">Comitiva completa.</p>'}`;
}
/* Põe um candidato na comitiva. A busca pode falhar (rede): o aviso fica NO BLOCO da comitiva, não na prévia —
   erro de rede mostrado longe do botão que o causou faz o jogador procurar o problema no lugar errado. */
export async function porNaComitiva(id) {
  const teto = maxAliados('saga');
  // o aviso pode não estar mais na tela depois do `await` (trocou de modo no meio da busca): nunca assumir que está
  const aviso = html => { const el = $('#comitiva-aviso'); if (el) el.innerHTML = html; };
  G.comitiva ||= [];
  if (G.comitiva.length >= teto) return;
  if (G.comitiva.some(c => String(c.data.id) === String(id))) { aviso('Esse já está na comitiva.'); return; }
  aviso('Consultando a PokéAPI…');
  let data;
  try { data = await resolvePokemon(id); }
  catch (e) { aviso(apiErr(e)); return; }
  G.comitiva.push({ data, oficio: oficioDe(data) });
  renderComitiva();
}
export function tirarDaComitiva(i) {
  (G.comitiva || []).splice(Number(i), 1);
  renderComitiva();
}
/* Os companheiros escolhidos entram como aliados de verdade: mesmo caminho do recrutar com petisco
   (`amizade.oferecer`) — growth, exp do nível e `felicidade` de aliado, senão eles não sobem de nível nem evoluem.
   Falhar aqui NÃO pode impedir a jornada de começar: quem não vier é só um companheiro a menos (e o aviso diz
   isso), porque a esta altura o save já existe. */
async function montarComitiva(S, comitiva) {
  for (const { data } of comitiva) {
    try {
      const A = await makeMon(data, S.player.level);
      const sp = await loadSpecies(data.speciesUrl);
      A.growth = await loadGrowth(sp.growthUrl);
      A.exp = A.growth[A.level];
      A.felicidade = FELICIDADE_ALIADO;
      S.aliados.push(A);
      registrar(S, 'amigos', data.speciesName, data.id);
      if (A.shiny) registrar(S, 'shiniesAmigos', data.speciesName, data.id);
    } catch (e) {
      console.error('comitiva:', e);
      log(`${esc(fmt(data.name))} não pôde vir com você agora (${esc(e.message)}) — dá pra recrutar alguém no caminho, com petisco.`, 'muted');
    }
  }
}

// Monta o save e entra no jogo. `nature`/`ability` undefined = sorteadas pelo makeMon.
async function iniciarJornada({ data, level, nature, ability, nick = '', dificuldade, gen, shiny, comitiva }) {
  /* Modo em construção só pra admin — conferido AQUI, não só no cartão: `data-act="dificuldade"` carrega a chave
     num atributo do HTML, e regra que só existe na tela não é regra. Sem isso, dá pra começar uma jornada num
     modo pela metade e levar o save (e a pontuação) pra frente. */
  if (!podeUsarModo(DIFICULDADES[dificuldade])) throw new Error('Este modo ainda está em construção.');
  const sp = await loadSpecies(data.speciesUrl);
  const growth = await loadGrowth(sp.growthUrl);
  /* A árvore de evolução NÃO pode impedir você de começar a jogar. Ela só é consultada quando você sobe de
     nível, e `progressao.arvoreDe` já sabe buscá-la mais tarde (e `checkEvolution` marca `evoPendente` e tenta
     de novo sozinho quando a rede voltar). Deixá-la obrigatória aqui fazia a criação inteira morrer com
     "A conexão falhou ao buscar um dado da PokéAPI" — sem jornada nenhuma, por causa de um dado que o jogo só
     precisa daqui a vários minutos. `undefined` (não `null`) é o que faz `arvoreDe` tentar de novo depois;
     `null` significa "esta espécie não evolui" e encerraria o assunto. */
  let evo;
  if (sp.evoUrl) { try { evo = await loadEvo(sp.evoUrl); } catch (e) { console.warn('evolução vem depois:', e.message); } }
  else evo = null;
  /* Vantagens das badges (badges.js): itens, dinheiro, os 6 IVs em 31 com a badge "Potencial máximo" e os IVs 31
     do SELVAGEM de rota com a "Rotas em potencial máximo" (lida em `batalha.novoOponente` por `S.ivsSelvagens`).
     G.semVantagens desliga tudo: quem joga sem elas ganha bônus de pontuação no ranking (regras.pontuacao), e IVs
     perfeitos de graça junto com esse bônus seria o melhor dos dois mundos. */
  const v = G.semVantagens ? { itens: {}, dinheiro: 0, lojaGratis: false, ivsPerfeitos: false, ivsSelvagens: false, ovos: [] } : vantagensDaConta();
  const mon = await makeMon(data, level, { nature, ability, nick, shiny, ivs: v.ivsPerfeitos ? IVS_MAX : undefined });
  mon.exp = growth[mon.level];
  // começa na rota mais alta do mapa que já combina com o seu nível (nível 5 = a 1ª rota)
  const rotas = rotasDaGen(gen), startZone = [...rotas].reverse().find(z => !z.final && zonaLiberada(z, mon.level) && z.min <= mon.level) || rotas[0];
  // começar outra com uma jornada aberta (veio pelo 🏠 Início): a de antes vai pras guardadas, não some (saves.js)
  const anterior = G.S?.player ? (save(), guardar(G.S) ? G.S : null) : null;
  const bag = { potion: 3, 'full-heal': 1 };
  for (const [k, n] of Object.entries(v.itens)) bag[k] = (bag[k] || 0) + n;
  /* 🥚 Ovos das badges (ovos.js): a espécie é sorteada AQUI, porque é a criação que conhece o mapa — e fica guardada
     dentro do ovo sem aparecer em tela nenhuma até chocar. Nada de rede neste caminho: os ciclos de choco de cada
     tipo são fixos (CICLOS_PSEUDO/CICLOS_LENDARIO), então começar a jornada nunca espera por isso. */
  const ovosIniciais = (v.ovos || []).map(t => ovoDeBadge(t, t === 'lendario' ? especiesLendarias() : PSEUDO_LENDARIOS)).filter(Boolean);
  G.S = { player: mon, bag, aliados: [], ovos: ovosIniciais, money: 500 + v.dinheiro, lojaGratis: v.lojaGratis, ivsSelvagens: v.ivsSelvagens, semVantagens: !!G.semVantagens, gen, zone: startZone.id, meta: { growth, evo }, wins: 0, log: [], dificuldade,
    climaRotas: !!(DIFICULDADES[dificuldade].climaRotasFixo || G.climaRotas), // 🌦 clima/terreno das rotas: fixo no Roguelike/Hardcore, opção nos outros (regras.climaDasRotasAtivo)
    cacaShiny: !!G.cacaShiny, caca: {}, // 🎯 modo Caça Shiny: escolhido agora e vale pra jornada inteira (mapas.js)
    // 🔒 Pokémon de missão já liberados pela conta: a foto é tirada agora e vale pra jornada inteira (mapas.rotaNaJornada)
    liberadas: especiesLiberadasDaConta(),
    especieInicial: data.speciesName, criadoEm: new Date().toISOString(), tempoMs: 0, ultimoTick: Date.now(),
    id: novoId() }; // id da jornada: não contar em dobro na carreira e casar o save deste aparelho com o da nuvem
  // Segredo do brilho (regras.bonusShiny): registra NA HORA pra "✨ Começar shiny" (opcaoShiny) já valer nesta
  // espécie em jornadas futuras — bug corrigido em 27/09/2026, antes só recrutar um ALIADO shiny registrava isso.
  if (mon.shiny) registrar(G.S, 'shiniesAmigos', data.speciesName, data.id);
  // ⚔ Saga: os companheiros escolhidos no passo 4 entram agora, com o save já montado
  if (comitiva?.length) await montarComitiva(G.S, comitiva);
  G.mode = 'explore'; G.panel = 'main'; tocarMusica('explorar');
  buildGame();
  log(`Você abre os olhos em ${startZone.name}, em ${dadosDaGen(gen).regiao}. Não há treinador por perto: desta vez, o Pokémon é você, ${nm(mon)}.`);
  if (anterior) log(`💾 A jornada de ${esc(anterior.player.nick || fmt(anterior.player.name))} foi guardada: dá pra voltar nela em Jornadas salvas.`, 'muted');
  if (G.S.cacaShiny) log('🎯 Modo Caça Shiny ligado: revele todas as espécies de uma rota pra escolher qual vai aparecer nela.', 'muted');
  if (G.S.climaRotas) log('🌦 Clima e terreno das rotas ligados: várias rotas começam a luta com o tempo da paisagem.', 'muted');
  if (mon.shiny) log('✨ Suas cores brilham diferente. Você é um Pokémon shiny — 1 em 4096!', 'level');
  if (v.ivsPerfeitos) log('🧬 Potencial máximo: seus 6 IVs nasceram em 31, o teto. É a badge do milhão de dano fazendo efeito.', 'level');
  if (v.ivsSelvagens) log('🌿 Rotas em potencial máximo: todo selvagem destas rotas nasce com os 6 IVs em 31. Quem você recrutar vem perfeito — e quem te enfrentar também.', 'level');
  if (ovosIniciais.length) log(`🥚 Você carrega ${ovosIniciais.length === 1 ? 'um ovo' : `${ovosIniciais.length} ovos`} de presente das suas badges. Ninguém sabe o que tem dentro — explore pra chocar (veja no painel de Aliados).`, 'level');
  // 🔒 Pokémon de missão: as missões já cumpridas valem nesta jornada, e quem jogou pra isso merece saber que valeu
  if (G.S.liberadas?.length) log(`🔓 Missões cumpridas: ${G.S.liberadas.map(e => `${ESPECIES_MISSAO[e].icone} ${fmt(e)}`).join(', ')} ${G.S.liberadas.length === 1 ? 'aparece' : 'aparecem'} nas rotas desta jornada.`, 'level');
  const dif = DIFICULDADES[dificuldade];
  if (!dif.escolhaLivre) log(`${dif.nome}: natureza ${esc(natureLabel(mon.nature))}, habilidade ${esc(fmt(mon.ability))}.`, 'muted');
  log('Explore para encontrar Pokémon selvagens, itens e dinheiro. Cuidado com treinadores: eles querem te capturar. O jogo salva sozinho neste navegador.', 'muted');
  save();
}
export async function startGame(btn) {
  btn.disabled = true; btn.textContent = 'Preparando sua jornada…';
  const PV = G.PV, livre = DIFICULDADES[G.dif].escolhaLivre;
  try {
    PV.nick = ($('#pv-nick')?.value || '').trim();
    // ✨ começar shiny (opcaoShiny): só existe pra espécie de que você já recrutou um shiny. `undefined` quando
    // não marcado, pra `makeMon` cair no sorteio normal de 1 em 4096 em vez de forçar "não shiny".
    PV.shiny = !!$('#pv-shiny')?.checked;
    const gen = gensLiberadas().includes(G.gen) ? G.gen : 1; // garantia (o cartão trancado já vem desativado)
    await iniciarJornada({ data: PV.data, level: nivelInicial(PV), nature: livre ? PV.nature : undefined, ability: livre ? PV.ability : undefined, nick: PV.nick, dificuldade: G.dif, gen, shiny: PV.shiny || undefined, comitiva: G.dif === 'saga' ? G.comitiva : null });
  } catch (e) {
    btn.disabled = false; btn.textContent = 'Tentar de novo';
    $('#preview').insertAdjacentHTML('beforeend', `<p class="err">${apiErr(e)}</p>`);
  }
}
// Full Randomizer: sorteia a espécie também e começa direto, sem prévia
export async function fullRandomizer(btn) {
  btn.disabled = true; btn.textContent = '🎲 Sorteando…';
  try {
    const data = await resolvePokemon(livres() ? rand(1, 1025) : pick(INICIAIS));
    await iniciarJornada({ data, level: 5, dificuldade: 'randomizer', gen: pick(GENS).gen });
  } catch (e) {
    btn.disabled = false; btn.textContent = '🎲 Sortear tudo e começar';
    $('#netwarn').innerHTML = `<div class="notice">${apiErr(e)}</div>`;
  }
}
