/* ============ nuvem (Supabase: login + carreira + save da jornada) ============ */
// Login com Google ou link por e-mail. Com conta:
//   • carreira: jornadas terminadas sobem/descem (tabela `jornadas`), juntadas sem duplicar (mesclarJornadas)
//   • jornadas em andamento (tabela `saves`, uma linha por jornada: a atual e as guardadas de saves.js): a atual
//     sobe sozinha depois de cada save() (agendarEnvioSave, com espera) e ao sair da aba; em outro aparelho, a
//     sincronização oferece continuar, guardar ou excluir (sincronizarSaves).
// Sem config (js/config.js com marcadores) tudo aqui vira no-op e o jogo segue só local.
// O cliente do Supabase é carregado sob demanda (import dinâmico) — nada disso roda nos testes.
import { SUPABASE_URL, SUPABASE_ANON_KEY } from './config.js';
import { carregarCarreira, salvarCarreira, mesclarJornadas, carregarProgresso, mesclarProgressoLocal, atualizarProgresso } from './carreira.js';
import { reconciliarSaves, guardadas, excluidos, guardar, excluir, esquecerExcluido, GUARDADOS_KEY, MAX_GUARDADAS } from './saves.js';
import { offline, store } from './util.js';
import { semTeste } from './progresso-conta.js';
import { blobParaDataUrl, dataUrlParaBlob, cabeNaFila } from './imagens-relato.js';

export const nuvemConfigurada = () => !!SUPABASE_URL && !SUPABASE_URL.includes('SEU-PROJETO') && !!SUPABASE_ANON_KEY && !SUPABASE_ANON_KEY.includes('SUA-CHAVE');

let cliente = null, sessao = null;
// exportado: presenca.js precisa do MESMO cliente (canal Realtime global + as duas RPCs de visitante), em vez
// de abrir uma segunda conexão com o Supabase
export async function sb() {
  if (!nuvemConfigurada()) return null;
  if (!cliente) {
    const { createClient } = await import('https://esm.sh/@supabase/supabase-js@2');
    cliente = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  }
  return cliente;
}
export const usuario = () => sessao?.user || null;
// id do jogador: o da conta, ou um de visitante persistido neste navegador (não é PII, só serve pra contar
// presença de sala/global e, sem conta, pra `registrar_visitante_anonimo`). Era privado em multiplayer.js
// (`meuId`); exportado daqui pra não duplicar a mesma lógica em presenca.js.
const VISITANTE_KEY = 'pokerpg-visitante';
export function idJogador() {
  const u = usuario(); if (u) return u.id;
  let v = store.get(VISITANTE_KEY);
  if (!v) { v = 'v-' + Math.random().toString(36).slice(2, 10); store.set(VISITANTE_KEY, v); }
  return v;
}

// estado mostrado na tela de conta / no chip do topo
export const BADGE_EXIBIDA_KEY = 'pokerpg-badge-exibida';
export const nuvem = { status: 'ocioso', erro: null, naNuvem: 0, apelido: '', ultimaSync: null, icone: null, codigoAmigo: '', amigos: [], admin: false, beta: false, criadoEm: null,
  badgeExibida: store.get(BADGE_EXIBIDA_KEY) || null };   // qual insígnia de evento aparece ao lado do nome (id da badge)
/* A insígnia que aparece ao lado do nome. Fica neste navegador na hora e, com conta, sobe pro perfil (`perfis.badge_exibida`,
   supabase/migrations/20260925120000_badge_exibida.sql). Se a coluna ainda não existir o jogo segue só com o valor local. */
export async function salvarBadgeExibida(id) {
  nuvem.badgeExibida = id || null; store.set(BADGE_EXIBIDA_KEY, nuvem.badgeExibida); avisar();
  const c = await sb(), u = usuario(); if (!c || !u) return;
  const { error } = await c.from('perfis').update({ badge_exibida: nuvem.badgeExibida }).eq('id', u.id);
  if (error) console.warn('badge_exibida: rode a migração do banco pra os outros verem', error.message);
}

/* ---- modo tutorial (js/tutorial.js, js/tela-tutorial.js): "já visto" ---- */
// Mesmo padrão de salvarBadgeExibida: fica neste navegador na hora (funciona sem conta e antes de qualquer
// sincronização) e sobe pro perfil com conta (`perfis.tutorial_visto`, supabase/migrations/20260928130000_tutorial_visto.sql).
// Sem a coluna, o jogo segue só com o valor local — nunca trava o tutorial por causa disso.
export const TUTORIAL_KEY = 'pokerpg-tutorial-visto';
export const tutorialVistoLocal = () => !!store.get(TUTORIAL_KEY);
export async function salvarTutorialVisto() {
  if (tutorialVistoLocal()) return; // idempotente: nada a fazer (e nada a subir de novo) se já estava marcado
  store.set(TUTORIAL_KEY, true);
  const c = await sb(), u = usuario(); if (!c || !u) return;
  const { error } = await c.from('perfis').update({ tutorial_visto: true }).eq('id', u.id);
  if (error) console.warn('tutorial_visto: rode a migração do banco pra sincronizar entre aparelhos', error.message);
}
// conta de manutenção: libera o painel de testes em ⚙ Ajustes (dev.js). Sai de `perfis.admin`, nunca do navegador.
export const ehAdmin = () => !!nuvem.admin && !!usuario();
/* 🧪 Testador: conta que o admin escolheu pra jogar um modo em construção (`perfis.beta`). É só a chave do MODO —
   não abre editor, painel de testes nem o canal de teste do conteúdo. `podeUsarModo` é o ÚNICO ponto que decide
   se um modo de `DIFICULDADES` existe pra esta conta: a tela de criação (o cartão) e `iniciarJornada` (a trava)
   perguntam aqui, senão a regra existiria em dois lugares e um deles ficaria velho. */
export const ehBeta = () => !!nuvem.beta && !!usuario();
export const podeUsarModo = modo => !modo?.admin || ehAdmin() || (!!modo.beta && ehBeta());

/* ---- ícone do jogador: qualquer Pokémon, normal ou shiny. Sem conta fica só neste navegador. ---- */
const ICONE_KEY = 'pokerpg-icone';
export const iconeLocal = () => store.get(ICONE_KEY) || { id: 25, shiny: false };
export const meuIcone = () => nuvem.icone || iconeLocal();
export async function salvarIcone(id, shiny) {
  id = Math.min(1025, Math.max(1, Math.round(+id) || 25)); shiny = !!shiny;
  nuvem.icone = { id, shiny }; store.set(ICONE_KEY, nuvem.icone);
  const c = await sb(), u = usuario();
  if (c && u) { const { error } = await c.from('perfis').update({ icone_id: id, icone_shiny: shiny }).eq('id', u.id); if (error) throw error; }
  avisar();
}

/* ---- amigos (precisa de conta) ---- */
export async function carregarAmigos() {
  const c = await sb(); if (!c || !usuario()) { nuvem.amigos = []; return []; }
  const { data, error } = await c.rpc('meus_amigos'); if (error) throw error;
  nuvem.amigos = data || []; avisar();
  return nuvem.amigos;
}
// Perfil de um amigo (ou o meu): ícone, insígnias, números e últimas runs — `perfil_do_amigo` no banco só responde pra amigos
export async function perfilDoAmigo(idAmigo) {
  const c = await sb(); if (!c || !usuario()) throw new Error('entre na conta primeiro');
  const { data, error } = await c.rpc('perfil_do_amigo', { p_amigo: idAmigo }); if (error) throw error;
  return data;
}
// devolve 'pedido' (esperando o outro aceitar) ou 'aceita' (o outro já tinha pedido)
export async function pedirAmizade(codigo) {
  const c = await sb(); if (!c || !usuario()) throw new Error('entre na conta primeiro');
  const { data, error } = await c.rpc('pedir_amizade', { p_codigo: String(codigo || '').trim().toUpperCase() });
  if (error) throw error;
  await carregarAmigos(); return data;
}
export async function aceitarAmizade(id) {
  const c = await sb(); const { error } = await c.from('amizades').update({ status: 'aceita' }).eq('id', id); if (error) throw error;
  await carregarAmigos();
}
export async function removerAmizade(id) {
  const c = await sb(); const { error } = await c.from('amizades').delete().eq('id', id); if (error) throw error;
  await carregarAmigos();
}

/* ---- convites pra sala: cada conta ouve o próprio canal; o anfitrião manda pro canal do amigo ---- */
let canalConvites = null;
async function ouvirConvites() {
  const c = await sb(), u = usuario(); if (!c || !u) return;
  if (canalConvites) await c.removeChannel(canalConvites);
  canalConvites = c.channel('pokerpg-convites-' + u.id)
    .on('broadcast', { event: 'convite' }, ({ payload }) => {
      // só aceita convite de quem é amigo de verdade (a lista vem do banco, não do convite)
      if (nuvem.amigos.some(a => a.amigo === payload?.de && a.status === 'aceita')) ganchos.convite(payload);
    })
    .subscribe();
}
export async function convidarAmigo(amigoId, sala) {
  const c = await sb(), u = usuario(); if (!c || !u) throw new Error('entre na conta primeiro');
  const ch = c.channel('pokerpg-convites-' + amigoId);
  await new Promise((ok, erro) => { ch.subscribe(s => { if (s === 'SUBSCRIBED') ok(); else if (s === 'CHANNEL_ERROR' || s === 'TIMED_OUT') erro(new Error('não consegui avisar o amigo')); }); });
  await ch.send({ type: 'broadcast', event: 'convite', payload: { de: u.id, nome: nuvem.apelido || 'Um amigo', ...sala } });
  await c.removeChannel(ch);
}
const ouvintes = new Set();
const avisar = () => ouvintes.forEach(fn => { try { fn(); } catch (e) { console.error(e); } });
export const aoMudarNuvem = fn => { ouvintes.add(fn); fn(); };

// Ganchos que o jogo registra (main.js) — a nuvem não conhece a tela:
//   saveLocal()            → o save da jornada atual (ou null)
//   jornadaTerminada()     → descartar o save local da jornada atual (ela já acabou em outro aparelho)
//   oferecerSave(remoto, local) → jornada da nuvem que este aparelho não conhece (local = a atual daqui, ou null);
//                            devolve 'continuar' | 'guardar' | 'excluir'
//   carregarSave(remoto, { guardarAtual }) → trocar a jornada atual pela da nuvem (guardarAtual: a daqui vai pras guardadas)
//   convite(payload)       → um amigo chamou pra sala ({ de, nome, codigo, modo })
export const ganchos = { saveLocal: () => null, jornadaTerminada: () => {}, oferecerSave: async () => false, carregarSave: () => {}, convite: () => {} };

let iniciada = false, ouvindoRede = false;
export async function iniciarNuvem() {
  if (iniciada) return;
  if (!ouvindoRede) { // uma vez só, mesmo que iniciarNuvem seja tentada de novo depois de abrir offline
    ouvindoRede = true;
    // voltou a internet: termina de iniciar (se o jogo abriu offline) e manda tudo o que ficou pendente
    addEventListener('online', () => {
      avisar();
      if (!iniciada) iniciarNuvem().catch(e => console.error(e)); else if (usuario()) sincronizar();
      enviarFilaRelatos().catch(e => console.warn('relatos', e)); // bugs/sugestões escritos offline
    });
    addEventListener('offline', avisar);
  }
  let c;
  try { c = await sb(); }
  catch (e) { console.warn('nuvem: biblioteca indisponível (offline?)', e); avisar(); return; } // tenta de novo no 'online'
  if (!c) { avisar(); return; }
  iniciada = true;
  const { data } = await c.auth.getSession();
  sessao = data.session; avisar();
  c.auth.onAuthStateChange((evento, s) => {
    sessao = s; avisar();
    if (evento === 'SIGNED_IN') { sincronizar(); ouvirConvites(); }
    if (evento === 'SIGNED_OUT') {
      nuvem.apelido = ''; nuvem.criadoEm = null; nuvem.naNuvem = 0; nuvem.status = 'ocioso'; nuvem.icone = null; nuvem.codigoAmigo = ''; nuvem.amigos = [];
      if (canalConvites) { c.removeChannel(canalConvites); canalConvites = null; }
      avisar();
    }
  });
  if (sessao) { sincronizar(); ouvirConvites(); }
  enviarFilaRelatos().catch(e => console.warn('relatos', e));
  // sair da aba / fechar: manda o save pendente na hora, e mais uma tentativa se o progresso (Hall da Fama…) ainda não confirmou
  const aoSair = () => { enviarSaveAgora(); if (progressoPendente) sincronizar(); };
  addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') aoSair(); });
  addEventListener('pagehide', aoSair);
}

const voltarPraCa = () => location.origin + location.pathname;
export async function entrarGoogle() {
  const c = await sb(); if (!c) return;
  const { error } = await c.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: voltarPraCa() } });
  if (error) throw error;
}
export async function entrarEmail(email) {
  const c = await sb(); if (!c) return;
  const { error } = await c.auth.signInWithOtp({ email, options: { emailRedirectTo: voltarPraCa() } });
  if (error) throw error;
}
export async function sair() { await enviarSaveAgora(); const c = await sb(); if (c) await c.auth.signOut(); }

export async function salvarApelido(apelido) {
  const c = await sb(), u = usuario(); if (!c || !u) return;
  const { error } = await c.from('perfis').upsert({ id: u.id, apelido });
  if (error) throw error;
  nuvem.apelido = apelido; avisar();
}

const linhaJornada = j => ({ id: j.id, user_id: j.dono, especie: j.especie, dificuldade: j.dificuldade, pontuacao: j.pontuacao, nivel: j.nivel, resumo: j, terminou_em: j.data });

// Junta carreira local + nuvem e reconcilia o save da jornada em andamento. Chamada ao entrar, ao abrir o jogo
// logado e depois de toda jornada terminada.
/* UMA sincronização por vez. Ao abrir o jogo logado ela era chamada duas vezes juntas (o evento SIGNED_IN do Supabase
   e o `if (sessao)` de iniciarNuvem), e cada uma lia o mesmo estado: você respondia "Guardar"/"Excluir" e a segunda
   perguntava DE NOVO a mesma jornada — e, com o estado velho na mão, ainda sobrescrevia a lista de guardadas que a
   primeira acabara de gravar. Chamada durante uma em andamento não roda em paralelo: pede UMA repetição no fim (que
   já enxerga o que acabou de mudar, como uma jornada que terminou agora). */
/* Bug relatado (28/09/2026): jornada de Roguelike terminou (desmaiou, nível 66) e o Hall da Fama nunca chegou na
   nuvem — a jornada em si subiu (é outro caminho), só o progresso permanente (que leva o Hall) ficou pra trás.
   Causa provável: `sincronizar()` engole o próprio erro (vira `nuvem.status`/`nuvem.erro`, nunca uma exceção) e
   quem chama depois de `encerrarJornada` era um fire-and-forget de UMA tentativa só — uma rede instável bem na
   hora da tela de Game Over (o jogador fecha o app logo depois de perder) não tinha segunda chance nenhuma.
   `sincronizarComRetentativa` tenta de novo (mesmo espaçamento de `api.getJSON`: 400ms, 800ms) e `progressoPendente`
   segue o MESMO padrão do `pendente` do save: se ainda não confirmou, esconder/fechar a aba tenta mais uma vez. */
let progressoPendente = false;
export async function sincronizarComRetentativa(tentativas = 3, esperaMs = 400) {
  progressoPendente = true;
  for (let i = 1; i <= tentativas; i++) {
    await sincronizar();
    if (nuvem.status !== 'erro') { progressoPendente = false; return true; }
    if (i < tentativas) await new Promise(r => setTimeout(r, esperaMs * i));
  }
  return false;   // fica progressoPendente = true: visibilitychange/pagehide tentam de novo ao sair
}

let sincronizando = null, sincronizarDeNovo = false;
export function sincronizar() {
  if (sincronizando) { sincronizarDeNovo = true; return sincronizando; }
  sincronizando = (async () => {
    try { do { sincronizarDeNovo = false; await sincronizarAgora(); } while (sincronizarDeNovo); }
    finally { sincronizando = null; }
  })();
  return sincronizando;
}
async function sincronizarAgora() {
  const c = await sb(), u = usuario(); if (!c || !u) return;
  if (offline()) { nuvem.status = 'offline'; avisar(); return; } // o listener 'online' chama de novo
  nuvem.status = 'sincronizando'; nuvem.erro = null; avisar();
  try {
    // perfil (apelido padrão = começo do e-mail; ícone = o escolhido neste navegador antes de entrar)
    let { data: perfil, error: ep } = await c.from('perfis').select('apelido, icone_id, icone_shiny, codigo_amigo, admin, criado_em').eq('id', u.id).maybeSingle();
    if (ep?.code === '42703') ({ data: perfil, error: ep } = await c.from('perfis').select('apelido').eq('id', u.id).maybeSingle()); // schema.sql antigo
    if (ep) throw ep;
    if (!perfil) {
      const apelido = (u.user_metadata?.name || u.email || 'Treinador').split('@')[0].slice(0, 20);
      const { error } = await c.from('perfis').insert({ id: u.id, apelido }); if (error) throw error;
      nuvem.apelido = apelido;
      const local = iconeLocal(); if (local.id !== 25 || local.shiny) await salvarIcone(local.id, local.shiny).catch(() => {});
      ({ data: perfil } = await c.from('perfis').select('apelido, icone_id, icone_shiny, codigo_amigo').eq('id', u.id).maybeSingle());
    }
    nuvem.apelido = perfil?.apelido || nuvem.apelido || '';
    if (perfil?.icone_id) { nuvem.icone = { id: perfil.icone_id, shiny: !!perfil.icone_shiny }; store.set(ICONE_KEY, nuvem.icone); }
    nuvem.codigoAmigo = perfil?.codigo_amigo || '';
    /* `admin` é o que libera o painel de testes (dev.js). Vem do banco e SÓ do banco: um gatilho impede a API
       de mudar essa coluna (supabase/migrations), então ninguém se promove pelo jogo — a promoção é feita à mão
       no SQL Editor. Aqui do lado do cliente isso é só a chave do painel; o que protege dado é a RLS. */
    nuvem.admin = !!perfil?.admin;
    /* `beta` numa leitura À PARTE, e não junto das outras colunas: se a migration ainda não chegou, pedir a coluna
       derrubaria a leitura inteira do perfil (apelido, ícone e o próprio `admin` iriam junto). Aqui o erro só
       quer dizer "ninguém é testador ainda". */
    try {
      const { data: pb, error: eb2 } = await c.from('perfis').select('beta').eq('id', u.id).maybeSingle();
      nuvem.beta = !eb2 && !!pb?.beta;
    } catch { nuvem.beta = false; }
    nuvem.criadoEm = perfil?.criado_em || null; // insígnia Alpha (alpha.js): a data de criação da conta vem do servidor
    // insígnia de evento escolhida (coluna à parte: se a migração ainda não rodou, o erro é ignorado e vale a do navegador)
    try {
      const { data: be, error: eb } = await c.from('perfis').select('badge_exibida').eq('id', u.id).maybeSingle();
      if (!eb && be?.badge_exibida) { nuvem.badgeExibida = be.badge_exibida; store.set(BADGE_EXIBIDA_KEY, be.badge_exibida); }
    } catch (e) { console.warn('badge_exibida', e); }
    // "já viu o tutorial" (outra coluna à parte, mesmo motivo): true na conta marca aqui também; false não apaga
    // um "true" que só existe neste navegador (visto localmente antes de logar não pode "desver" ao entrar)
    try {
      const { data: tv, error: etv } = await c.from('perfis').select('tutorial_visto').eq('id', u.id).maybeSingle();
      if (!etv && tv?.tutorial_visto) store.set(TUTORIAL_KEY, true);
    } catch (e) { console.warn('tutorial_visto', e); }
    await carregarAmigos().catch(e => console.warn('amigos', e)); // sem a tabela ainda: segue sem amigos

    // carreira: sobe o que só existe aqui, baixa o que só existe lá
    const { data: linhas, error: ej } = await c.from('jornadas').select('resumo'); if (ej) throw ej;
    const remotas = linhas.map(l => l.resumo);
    const { todas, subir } = mesclarJornadas(carregarCarreira().jornadas, remotas, u.id);
    // uma por vez: se o servidor recusar uma (validar_jornada), as outras sobem mesmo assim
    let subiram = 0;
    for (const j of subir) {
      const { error } = await c.from('jornadas').upsert(linhaJornada(j), { onConflict: 'id', ignoreDuplicates: true });
      if (!error) { subiram++; continue; }
      if (error.code === 'P0001') { const x = todas.find(t => t.id === j.id); if (x) x.recusada = error.message; } // recusada: não reenvia
      else throw error; // rede/permissão: tenta tudo de novo na próxima
    }
    salvarCarreira({ jornadas: todas });
    nuvem.naNuvem = remotas.length + subiram;

    /* Progresso permanente (progresso-conta.js): o que foi CONQUISTADO não pode sumir porque uma jornada saiu do
       histórico. Desce, junta (união — nunca remove) e sobe de volta. Se a tabela ainda não existir no projeto,
       o jogo segue com o progresso local: é conteúdo novo, não pode quebrar quem não rodou a migração. */
    try {
      const { data: prog, error: ep } = await c.from('progresso').select('dados').eq('user_id', u.id).maybeSingle();
      if (ep) throw ep;
      atualizarProgresso(todas);                       // banca o que acabou de chegar da nuvem
      const junto = mesclarProgressoLocal(prog?.dados || null);
      /* `semTeste`: o que o painel de manutenção concedeu NÃO sobe. Como a fusão é união e nunca remove,
         progresso de teste que subisse voltaria em toda sincronização — e o botão "limpar o que foi de teste"
         viraria mentira, em todos os aparelhos. */
      await c.from('progresso').upsert({ user_id: u.id, dados: semTeste(junto), atualizado_em: new Date().toISOString() }, { onConflict: 'user_id' });
    } catch (e) { console.warn('progresso', e); }

    // jornadas em andamento (a atual + as guardadas — saves.js): uma linha por jornada na nuvem
    await sincronizarSaves(c, u, new Set(todas.map(j => j.id)));

    nuvem.status = 'ok'; nuvem.ultimaSync = new Date();
  } catch (e) {
    console.error(e); nuvem.status = 'erro'; nuvem.erro = e.message || String(e);
  }
  avisar();
}

// Ranking global (funções `ranking` e `especies_ranqueadas` do schema.sql). Funciona sem login (só pra ver).
// especie null = geral. Devolve linhas { posicao, apelido, especie, pontuacao, nivel, dificuldade, terminou_em, eu }.
export async function buscarRanking(especie = null, limite = 50) {
  const c = await sb(); if (!c) throw new Error('nuvem não configurada');
  if (offline()) throw new Error('sem internet');
  const { data, error } = await c.rpc('ranking', { p_especie: especie, p_limite: limite });
  if (error) throw error;
  return data;
}
export async function especiesRanqueadas() {
  const c = await sb(); if (!c) return [];
  const { data, error } = await c.rpc('especies_ranqueadas');
  if (error) throw error;
  return data;
}

// Bugs e sugestões (tabela `relatos`). Sem internet / sem config / falha: vai pra uma fila neste navegador e sobe
// sozinho depois (enviarFilaRelatos no sync e ao voltar a internet). Devolve 'enviado' ou 'na-fila'.
const FILA_RELATOS = 'pokerpg-relatos-fila';
export const relatosNaFila = () => (store.get(FILA_RELATOS) || []).length;
/* Devolve `{ estado, motivo }`. **`motivo` existe porque "foi pra fila" tem mais de uma causa** e dizer sempre
   "sem conexão" já enganou: com a tabela `relatos` ainda não criada no Supabase, o relato ia pra fila e a tela
   anunciava falta de internet — a pessoa ficava esperando a conexão "voltar" pra algo que nunca ia subir. */
/* Imagens do relato (até 2, já comprimidas — imagens-relato.js): vão pro bucket `relatos-imagens` do Storage e a linha do
   relato guarda só os CAMINHOS (`relatos.imagens`, supabase/migrations/20260925160000_relatos_imagens.sql). O campo só entra
   no insert quando há imagem: relato sem imagem continua funcionando mesmo se a migração ainda não foi aplicada. */
/* ANEXAR IMAGEM EXIGE CONTA (29/09/2026, auditoria de segurança — imagens-relato.MOTIVO_PRECISA_CONTA). Sem
   conta não há a quem amarrar o envio, e a política do bucket passou a recusar. Aqui a checagem é repetida por um
   motivo prático: a FILA OFFLINE pode ter um relato guardado com imagem de antes desta mudança, ou guardado com
   conta e enviado depois de sair dela. Se isso fosse simplesmente tentar e falhar, o relato ficaria preso na fila
   PRA SEMPRE, tentando de novo a cada abertura da tela — o texto da pessoa nunca chegaria. Então: sem conta, as
   imagens ficam de fora e o relato vai mesmo assim, com a tela avisando quantas caíram. */
const BUCKET_RELATOS = 'relatos-imagens';
async function subirImagensRelato(c, imagens) {
  if (!usuario()) return null;   // null ≠ []: quem chama precisa distinguir "não tinha imagem" de "não pude subir"
  const pasta = `${usuario().id}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const caminhos = [];
  for (const [i, im] of imagens.entries()) {
    const ext = im.tipo === 'image/png' ? 'png' : im.tipo === 'image/webp' ? 'webp' : 'jpg';
    const caminho = `${pasta}-${i + 1}.${ext}`;
    const { error } = await c.storage.from(BUCKET_RELATOS).upload(caminho, im.blob, { contentType: im.tipo, upsert: false });
    if (error) throw error;
    caminhos.push(caminho);
  }
  return caminhos;
}
// o que vai pra fila offline: texto + imagens em data URL (só se couberem no localStorage; senão o relato segue sem elas)
async function paraFila(relato, imagens) {
  if (!imagens.length || !cabeNaFila(imagens)) return { ...relato, semImagens: imagens.length || undefined };
  try { return { ...relato, imagensFila: await Promise.all(imagens.map(async i => ({ tipo: i.tipo, dataUrl: await blobParaDataUrl(i.blob) }))) }; }
  catch { return { ...relato, semImagens: imagens.length }; }
}
/* `imagens` = [{ blob, tipo }]. Devolve `{ estado, motivo, semImagens? }` — `semImagens` = quantas imagens NÃO foram guardadas
   na fila (offline e grandes demais pro localStorage): a tela avisa pra a pessoa reenviar. */
export async function enviarRelato(relato, imagens = []) {
  const c = await sb().catch(() => null);
  let motivo = 'sem-conexao';
  if (!c) motivo = 'sem-config';
  else if (!offline()) {
    try {
      const caminhos = imagens.length ? await subirImagensRelato(c, imagens) : [];
      const { error } = await c.from('relatos').insert({ ...relato, ...(caminhos?.length ? { imagens: caminhos } : {}), user_id: usuario()?.id ?? null });
      // sem conta as imagens não sobem (ver subirImagensRelato): o relato vai, e a tela diz quantas ficaram de fora
      if (!error) return { estado: 'enviado', semImagens: caminhos === null ? imagens.length : 0 };
      if (error.code === '23514') throw new Error('Título (3 a 120 letras) e descrição (5 a 4000) precisam estar preenchidos.'); // check do banco
      console.warn('relato: vai pra fila', error);
      motivo = error.message || 'erro no servidor';
    } catch (e) {
      if (/preenchidos/.test(e.message)) throw e;
      console.warn('relato: vai pra fila', e);
      motivo = e.message || 'erro no servidor';
    }
  }
  const item = await paraFila(relato, imagens);
  store.set(FILA_RELATOS, [...(store.get(FILA_RELATOS) || []), item]);
  return { estado: 'na-fila', motivo, semImagens: item.semImagens || 0 };
}
/* Tenta esvaziar a fila. Devolve `{ enviados, sobraram, motivo }` pra tela poder dizer o que aconteceu.
   Chamada ao abrir a tela de relatos, além do `online` e do início — o evento `online` não dispara quando o
   navegador já se considera conectado, então a fila podia ficar parada pra sempre sem ninguém saber por quê. */
export async function enviarFilaRelatos() {
  const fila = store.get(FILA_RELATOS) || [];
  if (!fila.length) return { enviados: 0, sobraram: 0 };
  if (offline()) return { enviados: 0, sobraram: fila.length, motivo: 'sem-conexao' };
  const c = await sb().catch(() => null);
  if (!c) return { enviados: 0, sobraram: fila.length, motivo: 'sem-config' };
  const sobra = [];
  let motivo, semImagem = 0;
  for (const r of fila) {
    const { imagensFila, semImagens, ...dados } = r;   // esses dois campos são só da fila, não existem na tabela
    try {
      const imagens = imagensFila?.length ? await Promise.all(imagensFila.map(async i => ({ tipo: i.tipo, blob: await dataUrlParaBlob(i.dataUrl) }))) : [];
      const caminhos = imagens.length ? await subirImagensRelato(c, imagens) : [];
      const { error } = await c.from('relatos').insert({ ...dados, ...(caminhos?.length ? { imagens: caminhos } : {}), user_id: usuario()?.id ?? null });
      if (error && error.code !== '23514') { sobra.push(r); motivo = error.message || 'erro no servidor'; }
      // relato da fila que trazia imagem e subiu sem ela (a pessoa não está na conta): conta pra tela avisar
      else if (caminhos === null) semImagem += imagens.length;
    } catch (e) { sobra.push(r); motivo = e.message || 'erro no servidor'; }
  }
  store.set(FILA_RELATOS, sobra);
  return { enviados: fila.length - sobra.length, sobraram: sobra.length, motivo, semImagem };
}
export async function meusRelatos() {
  const c = await sb(); if (!c || !usuario()) return [];
  // `resposta` é a nota curta de quem mantém o jogo ("corrigido na versão 4.3"), mostrada junto da situação
  const { data, error } = await c.from('relatos').select('id, tipo, titulo, status, resposta, criado_em').order('criado_em', { ascending: false }).limit(20);
  if (error) throw error;
  return data;
}

// Multiplayer: canal Realtime da sala (broadcast + presence). `chave` = id do jogador na presença.
// Não precisa de login: basta o Supabase configurado (visitante usa um id aleatório guardado no navegador).
export async function canalSala(codigo, chave) {
  const c = await sb(); if (!c) throw new Error('modo online não configurado');
  return c.channel('pokerpg-sala-' + codigo, { config: { broadcast: { self: false }, presence: { key: chave } } });
}
export async function fecharCanal(canal) { const c = await sb(); if (c && canal) await c.removeChannel(canal); }

// Jornadas em andamento: reconciliarSaves (saves.js) decide; aqui só executa. Jornada da nuvem que este aparelho
// não conhece → pergunta (ganchos.oferecerSave): 'continuar' (a atual daqui vai pras guardadas), 'guardar' (fica na
// lista, sem perguntar de novo) ou 'excluir' (apaga daqui e da nuvem). Nada some sem o jogador pedir.
let savesPorJornada = null; // null = ainda não sei; false = schema.sql antigo (uma jornada por conta)
async function sincronizarSaves(c, u, terminadas) {
  const { data: remotos, error } = await c.from('saves').select('jornada_id, dados').eq('user_id', u.id);
  if (error) throw error;
  const r = reconciliarSaves({ ativo: ganchos.saveLocal(), guardadas: guardadas(), remotos, terminadas, excluidos: excluidos() });
  if (r.ativoTerminou) ganchos.jornadaTerminada(); // acabou em outro aparelho
  store.set(GUARDADOS_KEY, r.guardadas);
  for (const id of r.apagarRemotos) { if (await apagarSaveNuvem(id)) esquecerExcluido(id); }
  for (const id of r.esquecer) esquecerExcluido(id);
  if (r.novoAtivo) ganchos.carregarSave(r.novoAtivo);
  for (const S of r.subir) await subirSave(c, u, S);
  for (const d of r.perguntar) {
    if (guardadas()[d.id] || excluidos().has(d.id)) continue; // já respondida (por outra pergunta ainda aberta): não pergunta de novo
    const escolha = await ganchos.oferecerSave(d, ganchos.saveLocal());
    if (escolha === 'continuar') ganchos.carregarSave(d, { guardarAtual: true });
    else if (escolha === 'excluir') { excluir(d.id); if (await apagarSaveNuvem(d.id)) esquecerExcluido(d.id); }
    else if (!guardar(d)) nuvem.erro = `Limite de ${MAX_GUARDADAS} jornadas guardadas: a de ${d.player?.nick || d.player?.name} continua só na nuvem.`;
  }
}
async function subirSave(c, u, S) {
  if (savesPorJornada === false && S.id !== ganchos.saveLocal()?.id) return null; // schema antigo: guardada não sobrescreve a atual
  const linha = { user_id: u.id, jornada_id: S.id, dados: S, atualizado_em: new Date().toISOString() };
  let { error } = await c.from('saves').upsert(linha, { onConflict: savesPorJornada === false ? 'user_id' : 'user_id,jornada_id' });
  // schema.sql antigo (chave só user_id): funciona como antes, uma jornada por conta — só a atual sobe
  if (error?.code === '42P10' && savesPorJornada !== false) { savesPorJornada = false; ({ error } = await c.from('saves').upsert(linha, { onConflict: 'user_id' })); }
  else if (!error) savesPorJornada ??= true;
  return error;
}

// Save da jornada: agendado depois de cada save() local (espera 5 s juntando vários), ou na hora ao sair da aba.
let timer = null, pendente = false;
export function agendarEnvioSave() {
  if (!usuario()) return;
  pendente = true; clearTimeout(timer);
  timer = setTimeout(() => enviarSaveAgora(), 5000);
}
// Offline ou falha de rede: o envio fica PENDENTE e sai no próximo save, ao voltar a internet ('online' →
// sincronizar, que sempre reenvia o save local) ou ao abrir o jogo de novo logado. Nada se perde: o save local
// continua sendo a fonte, a nuvem é cópia.
export async function enviarSaveAgora(forcar = false) {
  if (!forcar && !pendente) return;
  clearTimeout(timer);
  if (offline()) { pendente = true; nuvem.status = 'offline'; avisar(); return; }
  pendente = false;
  const c = await sb(), u = usuario(), S = ganchos.saveLocal();
  if (!c || !u || !S?.id) return;
  const error = await subirSave(c, u, S);
  if (error) { pendente = true; console.error(error); nuvem.status = 'erro'; nuvem.erro = 'Não consegui salvar a jornada na nuvem (tento de novo sozinho): ' + error.message; avisar(); }
}
/* ---- lembretes por push (js/notificacoes.js, js/lembretes.js) ----
   Duas tabelas, e as duas são do dono (RLS em supabase/migrations/20261008120000_lembretes_push.sql):
   `push_inscricoes` é por APARELHO (endpoint único) e `lembretes` é por motivo (chave única por jogador).
   Nada aqui é essencial: falha de rede só significa "este aparelho não vai receber lembrete desta vez". */
export async function salvarInscricaoPush(sub, { apagar = false } = {}) {
  const c = await sb(), u = usuario(); if (!c || !u || !sub?.endpoint) return false;
  if (apagar) { const { error } = await c.from('push_inscricoes').delete().eq('endpoint', sub.endpoint); if (error) throw error; return true; }
  const { error } = await c.from('push_inscricoes').upsert({
    user_id: u.id, endpoint: sub.endpoint, p256dh: sub.keys?.p256dh, auth: sub.keys?.auth
  }, { onConflict: 'endpoint' });
  if (error) throw error;
  return true;
}
/* `enviado_em: null` no upsert é o reset: o jogador voltou, então o lembrete que já saiu volta à fila com a hora
   nova. Motivo que deixou de valer (o ovo chocou, a badge saiu) é APAGADO — senão o push chegaria mentindo. */
export async function salvarLembretes(linhas = []) {
  const c = await sb(), u = usuario(); if (!c || !u) return false;
  const chaves = linhas.map(l => l.chave);
  if (linhas.length) {
    const { error } = await c.from('lembretes').upsert(linhas.map(l => ({ ...l, user_id: u.id, enviado_em: null })), { onConflict: 'user_id,chave' });
    if (error) throw error;
  }
  let q = c.from('lembretes').delete().eq('user_id', u.id);
  if (chaves.length) q = q.not('chave', 'in', `(${chaves.join(',')})`);
  const { error } = await q;
  if (error) throw error;
  return true;
}

/* Aviso GLOBAL (📜 novidades): o único lembrete que não nasce no aparelho de quem recebe. Vira uma linha `aviso`
   pra cada jogador com push ligado; quem barra pela segunda vez é a função no banco (só `perfis.admin`), porque
   regra que só existe na tela não é regra. Devolve quantas pessoas vão receber. */
/* 🧪 Testadores (só admin; o banco confere de novo — `definir_beta`/`listar_beta`). A pessoa é apontada pelo
   código de amigo, que ela vê em 👤 Conta. Erro sobe com a mensagem do banco: "código não encontrado" e "a
   função não existe" (migration que não chegou) são problemas diferentes, e a tela mostra qual foi. */
export async function listarBeta() {
  const c = await sb(); if (!c) throw new Error('A nuvem não está configurada.');
  const { data, error } = await c.rpc('listar_beta');
  if (error) throw error;
  return data || [];
}
export async function definirBeta(codigo, valor) {
  const c = await sb(); if (!c) throw new Error('A nuvem não está configurada.');
  const { data, error } = await c.rpc('definir_beta', { p_codigo: codigo, p_valor: !!valor });
  if (error) throw error;
  return data || '';
}
export async function publicarAviso(titulo, corpo) {
  const c = await sb(); if (!c) throw new Error('A nuvem não está configurada.');
  const { data, error } = await c.rpc('publicar_aviso', { p_titulo: titulo, p_corpo: corpo });
  if (error) throw error;
  return data || 0;
}

// Apaga UMA jornada em andamento da nuvem (terminou ou foi excluída). true = apagou (ou não havia o que apagar).
// Offline: não precisa fila — a próxima sincronizar() vê que ela terminou (carreira) ou foi excluída (saves.js) e apaga.
export async function apagarSaveNuvem(id) {
  const c = await sb(), u = usuario(); if (!c || !u || !id || offline()) return false;
  if (ganchos.saveLocal()?.id === id) { pendente = false; clearTimeout(timer); }
  const { error } = await c.from('saves').delete().eq('user_id', u.id).eq('jornada_id', id);
  if (error) { console.error(error); return false; }
  return true;
}
