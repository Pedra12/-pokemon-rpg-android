/* ============ regras ============ */
// Fórmulas puras (recebem dado, devolvem dado). Sem DOM, sem rede, sem estado global:
// importável direto no Node — é o que tests/regras.test.js cobre.
// A aleatoriedade usa Math.random/rand direto; os testes substituem Math.random quando precisam.
import { DONS } from './dados-saga.js';
import { API, STATS, STAT_PT, CHART, NATURES, ITEMS, DIFICULDADES, SELF_TARGETS, ALVOS_OPONENTES, ALVOS_TODOS, ITENS_DE_SELVAGEM } from './dados.js';
import { hab } from './habilidades.js';
import { especial, poderDoFling } from './especiais.js';
import { seg, multDanoDoItem, resisteDoItem, multEviolite, multStatDoItem } from './segurados.js';
import { rand, clamp, fmt } from './util.js';
import { GOLPE_FLAGS, GOLPE_AREA } from './dados-golpe-flags.js';
import { ESPECIE_DO_ITEM_EVO } from './dados-evolucao-restante.js';

export function typeEff(atk, defs) {
  const c = CHART[atk]; if (!c) return 1;
  return defs.reduce((f, d) => f * ((c.im || []).includes(d) ? 0 : c.se.includes(d) ? 2 : c.nv.includes(d) ? 0.5 : 1), 1);
}

/* ---- Terastalização (tera.js) ----
   Quem terastaliza passa a ter UM tipo só — o Tera — para RECEBER golpe. É a parte que muda a luta: um
   Charizard Tera Água deixa de morrer para Pedra.
   No ataque o STAB segue a regra dos jogos, que é generosa de propósito:
     golpe do tipo Tera que TAMBÉM era um tipo original → 2.0  (o prêmio por casar o Tera com o que você já é)
     golpe do tipo Tera que não era original            → 1.5
     golpe de um tipo original que não é o Tera         → 1.5  (você não perde o STAB que já tinha)
     qualquer outro                                     → 1
   `base` é o STAB da habilidade (Adaptability = 2), pra Adaptability continuar valendo em cima disso. */
/* ---- Z-Move (zmove.js) ----
   O Z-Move é o MESMO golpe com o poder convertido: uma vez por batalha, sem efeito secundário novo. A tabela é
   a dos jogos, achatada no topo de propósito — golpe fraco ganha muito, golpe que já é forte ganha pouco. É o
   que faz a escolha ser interessante: usar o Z no golpe de 60 rende mais do que no de 140.
   Fica aqui, e não em zmove.js, porque quem aplica é `calcDamage` — e é aqui que dá pra testar sem batalha. */
export function poderZ(poder) {
  const p = poder || 0;
  if (p <= 55) return 100;
  if (p <= 65) return 120;
  if (p <= 75) return 140;
  if (p <= 85) return 160;
  if (p <= 95) return 175;
  if (p <= 100) return 180;
  if (p <= 110) return 185;
  if (p <= 125) return 190;
  if (p <= 130) return 195;
  return 200;
}

/* ---- Gigantamax (dynamax.js) ----
   Enquanto está gigante, TODO golpe vira um golpe Max. A tabela é mais modesta que a do Z de propósito: o Z é
   um tiro único e pode ser absurdo; o Max vale por três turnos, e no mesmo patamar do Z deixaria a luta sem
   graça. A outra metade da força vem do HP dobrado (dynamax.js), não daqui. */
export function poderMax(poder) {
  const p = poder || 0;
  if (p <= 40) return 90;
  if (p <= 50) return 100;
  if (p <= 60) return 110;
  if (p <= 70) return 120;
  if (p <= 100) return 130;
  if (p <= 140) return 140;
  return 150;
}
// quanto o HP máximo cresce ao gigantamaxar (e por quantos turnos dura)
export const MULT_HP_DYNAMAX = 2;
export const TURNOS_DYNAMAX = 3;

/* ---- leitura de vantagem (a seta nos botões de golpe) ----
   Saber que Água é forte contra Fogo é óbvio pra quem jogou a vida toda e opaco pra quem está começando — e a
   tabela tem 18 tipos, dois tipos por Pokémon e multiplicadores que se multiplicam. Aqui a conta vira uma
   etiqueta e uma seta, que é o que dá pra ler no meio da luta.
   `nivel` vai de -3 a +2 e serve pra CSS/ordenação; `mult` é a conta de verdade, pra quem quiser o número.
   Golpe de status não tem vantagem: ele não usa a tabela de tipos pra nada, e inventar uma seta ali seria
   ensinar errado. */
export const VANTAGENS = [
  { min: 4, nivel: 2, seta: '⏫', rotulo: 'extremamente efetivo', classe: 'v-otimo' },
  { min: 2, nivel: 1, seta: '🔼', rotulo: 'super efetivo', classe: 'v-bom' },
  { min: 1, nivel: 0, seta: '▪', rotulo: 'dano normal', classe: 'v-neutro' },
  { min: 0.5, nivel: -1, seta: '🔽', rotulo: 'pouco efetivo', classe: 'v-ruim' },
  { min: 0.01, nivel: -2, seta: '⏬', rotulo: 'quase sem efeito', classe: 'v-pessimo' },
  { min: 0, nivel: -3, seta: '✖', rotulo: 'não afeta', classe: 'v-nulo' }
];
export function vantagemDoGolpe(golpe, alvo) {
  if (!golpe || !alvo || golpe.cls === 'status') return null;
  const mult = typeEff(golpe.type, tiposDefensivos(alvo));
  return { mult, ...VANTAGENS.find(v => mult >= v.min) };
}

/* O tipo ATUAL na batalha. `vol.tipos` é o tipo TROCADO por um golpe (Soak: o alvo vira Água pura) e mora no
   `vol` de propósito: `m.data` vem do cache e é COMPARTILHADO por todos da espécie — escrever tipo lá
   contaminaria todo Poliwag do jogo e ainda iria junto no save. Como todo `vol`, some no fim da batalha.
   Esta é a fonte ÚNICA pra regra: quem decide dano, imunidade, status, clima ou terreno lê DAQUI, nunca de
   `data.types`. Ficam de fora, de propósito, os leitores de IDENTIDADE da espécie (petisco por tipo em
   amizade.js, condição de evolução em evolucao.js, a ficha em render.js): quem levou Soak não mudou de espécie. */
export const tiposDe = m => m?.vol?.tipos || m?.data?.types || [];
export const tiposDefensivos = m => m?.tera ? [m.tera] : tiposDe(m);
/* O lado OFENSIVO não é o espelho do defensivo: terastalizar troca o tipo com que você DEFENDE (passa a ser um
   só), mas NÃO apaga o STAB dos tipos originais — quem vira Tera de um tipo novo ganha STAB no Tera e continua
   com o dos antigos (é o que `multStab` calcula). Esta lista serve ao julgamento grosso da IA (`melhorGolpe`),
   que só pergunta "esse golpe tem STAB?"; a conta de verdade do dano continua em `multStab`. */
export const tiposOfensivos = m => m?.tera ? [...new Set([m.tera, ...tiposDe(m)])] : tiposDe(m);
/* Eficácia do golpe contando a habilidade de QUEM ATACA. Hoje só `ignoraImunidade` (Scrappy, Mind's Eye: Normal e
   Lutador acertam Fantasma), e ela vale SÓ quando a eficácia é ZERO. Tirar o tipo da conta sempre seria outra
   coisa: um golpe Sombrio em Gengar (Fantasma/Venenoso) perderia o super efetivo sem motivo nenhum. Toda decisão
   de "esse golpe faz algo?" passa por aqui: o dano (calcDamage), o motor (golpe.executar, OHKO incluído) e a IA. */
export function eficacia(hu, tipo, alvo) {
  const tipos = tiposDefensivos(alvo);
  /* Posto NO CHÃO (Gravidade, Smack Down, Thousand Arrows): o Voador perde a imunidade a Terrestre. Fica aqui, e
     não em `typeEff`, porque a tabela de tipos é dado e isto é estado da luta — e porque esta já é a porta única
     de "esse golpe faz algo?" (dano, motor e IA leem daqui). A imunidade de HABILIDADE (Levitate) cai no mesmo
     caso, mas ela é checada em golpe.executar, que também pergunta pelo `noSolo`. */
  let defs = tipo === 'ground' && alvo?.vol?.noSolo ? tipos.filter(d => d !== 'flying') : tipos;
  /* 👁 `vol.semImunidade` = Foresight / Odor Sleuth (Fantasma deixa de ser imune a Normal e Lutador) e Miracle Eye
     (Sombrio deixa de ser imune a Psíquico). É o MESMO desenho do `noSolo` logo acima — tirar um tipo da conta
     defensiva —, e por isso mora no mesmo lugar: a porta única de "esse golpe faz algo?". */
  const sem = alvo?.vol?.semImunidade;
  if (sem && typeEff(tipo, defs) === 0) defs = defs.filter(d => !sem.includes(d));
  const e = typeEff(tipo, defs);
  if (e !== 0 || !hu?.ignoraImunidade) return e;
  return typeEff(tipo, defs.filter(d => !hu.ignoraImunidade.includes(d)));
}
/* Tipo Tera SORTEADO do inimigo: qualquer um dos 18, do tipo dele ou não, com a mesma chance. O fator surpresa é
   não dar pra prever pra onde ele vira. `rnd` injetável pros testes. */
export function sortearTipoTera(rnd = Math.random) {
  const tipos = Object.keys(CHART);
  return tipos[Math.floor(rnd() * tipos.length)];
}
export function multStab(m, tipoGolpe, base = 1.5) {
  const originais = tiposDe(m);   // quem virou Água por Soak ganha STAB em golpe de Água, como nos jogos
  if (!m?.tera) return originais.includes(tipoGolpe) ? base : 1;
  if (tipoGolpe === m.tera) return originais.includes(tipoGolpe) ? 2 : base;
  return originais.includes(tipoGolpe) ? base : 1;
}

export const natureMod = (n, s) => (NATURES[n] || [])[0] === s ? 1.1 : (NATURES[n] || [])[1] === s ? 0.9 : 1;
export const natureLabel = n => { const [u, d] = NATURES[n] || []; return fmt(n) + (u ? ` (+${STAT_PT[u]} −${STAT_PT[d]})` : ' (neutra)'); };

// golpes de dano fixo (ignoram ataque/defesa/tipo)
export const FIXED = {
  'seismic-toss': u => u.level, 'night-shade': u => u.level, 'dragon-rage': () => 40, 'sonic-boom': () => 20,
  'super-fang': (u, t) => Math.floor(t.hp / 2), psywave: u => Math.floor(u.level * rand(50, 150) / 100)
};

export function calcStats(m) {
  const out = {};
  for (const s of STATS) {
    const core = Math.floor((2 * m.data.base[s] + m.ivs[s] + Math.floor(m.evs[s] / 4)) * m.level / 100);
    out[s] = s === 'hp' ? (m.data.base.hp === 1 ? 1 : core + m.level + 10) : Math.floor((core + 5) * natureMod(m.nature, s));
  }
  return out;
}
/* `m.statsChefe` (batalha.js: Alfa e o lendário principal) marca quem recebeu statsDeChefe (HP ×2, resto ×1,3) na
   entrada — um bônus de UMA VEZ, fora do calcStats normal. Sem reaplicar aqui, um chefe que muda de forma no meio
   da luta (Mega, Castform, Aegislash…) perdia o bônus na recontagem: o teto de HP caía pela metade e o `clamp`
   embaixo zerava o HP atual — Alfa mega-evoluindo já saía desmaiado, antes até do aliado bater. Relatado em jogo. */
export function recalc(m) { const old = m.stats.hp; m.stats = m.statsChefe ? statsDeChefe(calcStats(m)) : calcStats(m); m.hp = clamp(m.hp + (m.stats.hp - old), 0, m.stats.hp); }
export const freshVol = () => ({ stages: { attack: 0, defense: 0, 'special-attack': 0, 'special-defense': 0, speed: 0, accuracy: 0, evasion: 0 }, conf: 0, flinch: false, flashFire: false, paixao: false });
export const stageMul = n => n >= 0 ? (2 + n) / 2 : 2 / (2 - n);
// maior atributo BASE de combate (sem HP), empate desfeito por Ataque > Defesa > At.Esp. > Def.Esp. > Velocidade
// (mesma ordem dos jogos) — Protosynthesis e Quark Drive reforçam esse, seja lá qual for, em vez de um fixo.
const STATS_COMBATE = ['attack', 'defense', 'special-attack', 'special-defense', 'speed'];
export const maiorStatBase = m => STATS_COMBATE.reduce((a, s) => m.data.base[s] > m.data.base[a] ? s : a);
// quanto o clima mexe num atributo deste Pokémon: habilidade (Swift Swim…) e o bônus do próprio clima (CLIMAS.defesaDe)
export function multStatClima(m, stat, clima) {
  if (!clima || !CLIMAS[clima]) return 1;
  const porTipo = CLIMAS[clima].defesaDe || {};
  const bonus = tiposDe(m).reduce((a, t) => a * (porTipo[t]?.[stat] || 1), 1);
  const h = hab(m);
  const maior = h.multMaiorStatClima?.[clima] && stat === maiorStatBase(m) ? multMaiorStat(stat) : 1;
  return (h.multStatClima?.[clima]?.[stat] || 1) * maior * bonus;
}
// Protosynthesis/Quark Drive: ×1,3 no maior atributo, ou ×1,5 se o maior for Velocidade — valor FIXO dos jogos
// (não é um número que a habilidade escolhe, por isso não mora na tabela de habilidades.js).
const multMaiorStat = stat => stat === 'speed' ? 1.5 : 1.3;
// quanto o terreno mexe num atributo (só pra quem está no chão) — Surge Surfer no Campo Elétrico, Quark Drive no Campo Elétrico
export function multStatTerreno(m, stat, terreno) {
  if (!terreno || !noChao(m)) return 1;
  const h = hab(m);
  const maior = h.multMaiorStatTerreno?.[terreno] && stat === maiorStatBase(m) ? multMaiorStat(stat) : 1;
  return (h.multStatTerreno?.[terreno]?.[stat] || 1) * maior;
}
// a habilidade de "força com status" vale pra este status? (Guts: qualquer; Toxic Boost: só veneno; Flare Boost: só queimadura)
export const statusVale = (h, ail) => !h.soStatus || h.soStatus.includes(ail);
/* Golpes por família, pras habilidades que reforçam um tipo de golpe pelo NOME (a PokéAPI não traz essa marca no golpe):
   Iron Fist = soco, Strong Jaw = mordida, Sharpness = corte. */
export const FAMILIAS_GOLPE = {
  soco: ['fire-punch', 'ice-punch', 'thunder-punch', 'mach-punch', 'bullet-punch', 'comet-punch', 'dizzy-punch', 'drain-punch', 'dynamic-punch',
    'focus-punch', 'hammer-arm', 'ice-hammer', 'mega-punch', 'meteor-mash', 'power-up-punch', 'shadow-punch', 'sky-uppercut', 'surging-strikes',
    'wicked-blow', 'plasma-fists', 'jet-punch', 'double-iron-bash', 'rage-fist', 'headlong-rush'],
  mordida: ['bite', 'crunch', 'fire-fang', 'ice-fang', 'thunder-fang', 'poison-fang', 'psychic-fangs', 'hyper-fang', 'jaw-lock', 'fishious-rend'],
  corte: ['slash', 'cut', 'night-slash', 'psycho-cut', 'leaf-blade', 'x-scissor', 'air-slash', 'aerial-ace', 'sacred-sword', 'razor-shell', 'cross-poison',
    'fury-cutter', 'solar-blade', 'stone-axe', 'ceaseless-edge', 'kowtow-cleave', 'secret-sword', 'behemoth-blade', 'bitter-blade', 'aqua-cutter',
    'air-cutter', 'razor-leaf', 'mighty-cleave', 'tachyon-cutter', 'psyblade']
};
export function multFamilia(h, nomeDoGolpe) {
  let mult = 1;
  for (const [fam, m] of Object.entries(h.golpesFamilia || {})) if (FAMILIAS_GOLPE[fam]?.includes(nomeDoGolpe)) mult *= m;
  return mult;
}
/* Flag de golpe de verdade (dados-golpe-flags.js, gerado do repositório-fonte da PokéAPI — a API pública não
   expõe isso). Golpe sem entrada na tabela (novo demais pro dado-fonte, ex. alguns golpes de Gen 9) devolve
   `false` pra qualquer flag — nunca lança, nunca inventa. */
export const temFlag = (move, flag) => !!GOLPE_FLAGS[move.name]?.includes(flag);
/* Faz contato de verdade? Antes disso existir, o jogo usava `move.cls === 'physical'` como PROXY (Earthquake é
   físico e NÃO faz contato, por exemplo) — com golpe MAPEADO na tabela, usa a flag `contact` de verdade; sem
   mapa (golpe fora do dado-fonte), cai pro proxy antigo em vez de dizer "sem contato" à toa. */
export const fazContato = move => GOLPE_FLAGS[move.name] ? temFlag(move, 'contact') : move.cls === 'physical';
// Sheer Force: o golpe tem ALGUM efeito secundário nativo? (estágio, status ou recuo por chance) — se sim, o
// golpe bate mais forte mas PERDE o efeito (golpe.executar guarda os três blocos de aplicação com `!hu.sheerForce`).
export const temSecundario = move => !!(move.stats?.length || (move.meta?.ailment && move.meta.ailment !== 'none' && move.meta?.ailChance > 0) || move.meta?.flinch > 0);
// `semEstagio`: ignora os degraus deste atributo (Unaware de QUEM ESTÁ do outro lado)
export function effStat(m, stat, crit = false, attacking = true, clima = null, terreno = null, semEstagio = false) {
  let st = semEstagio ? 0 : (m.vol?.stages[stat] || 0);
  if (crit) { if (attacking && st < 0) st = 0; if (!attacking && st > 0) st = 0; }
  const h = hab(m);
  let v = m.stats[stat] * stageMul(st) * (h.multStat?.[stat] || 1) * multStatDoItem(m, stat); // habilidade e item segurado (multStatDoItem respeita o `soEspecie`)
  v *= multStatClima(m, stat, clima) * multStatTerreno(m, stat, terreno);         // clima e terreno
  v *= multEviolite(m, stat);                                                     // Eviolite: só se a espécie ainda evolui
  if (h.inicioLento && (stat === 'attack' || stat === 'speed') && (m.vol?.turnosEmCampo || 0) < h.inicioLento) v *= 0.5;   // Slow Start: metade do Ataque e da Velocidade nos primeiros turnos
  if (h.abaixoDeMetade?.[stat] && m.hp <= m.stats.hp / 2) v *= h.abaixoDeMetade[stat]; // Defeatist
  if (m.status && h.comStatus?.[stat] && statusVale(h, m.status)) v *= h.comStatus[stat]; // Guts, Quick Feet, Marvel Scale, Toxic/Flare Boost
  else if (stat === 'speed' && m.status === 'paralysis') v *= 0.5;                 // (Quick Feet ignora a queda)
  return Math.max(1, Math.floor(v));
}
export function defaultMoves(list, level) {
  const avail = list.filter(m => m.level <= level), seen = new Set(), out = [];
  for (let i = avail.length - 1; i >= 0 && out.length < 4; i--) if (!seen.has(avail[i].name)) { seen.add(avail[i].name); out.push(avail[i]); }
  if (!out.length && list.length) out.push(list[0]);
  if (!out.length) out.push({ name: 'tackle', url: `${API}/move/33/`, level: 1 });
  return out.reverse();
}
/* Golpes que chegam JUNTO com a evolução. Duas fontes:
   - NÍVEL 0: é exatamente assim que a PokéAPI marca "aprende ao evoluir" (King's Shield do Aegislash, Stomp do
     Exeggutor). Só conta se a forma anterior não aprendia;
   - o golpe do nível atual, que já era o comportamento antigo.
   **Nível 1 NÃO entra**, e isso foi bug real: a primeira versão pegava `level <= 1`, mas nível 1 é a lista do que a
   espécie saberia se nascesse agora — o Exeggutor tem 17 golpes lá, então uma evolução reescrevia o moveset inteiro
   (relatado em jogo). O golpe de evolução de verdade é um só, e está no nível 0.
   Sem a primeira fonte, quem evoluía acima do nível 1 (ou seja, todo mundo) nunca aprendia o golpe assinatura da
   forma nova. Golpe que a forma antiga já aprendia não conta: seria repetir o que você já viu (ou já esqueceu). */
export function golpesDaEvolucao(antes = [], depois = [], nivel) {
  const tinha = new Set(antes.map(m => m.name)), out = [];
  for (const m of depois) {
    const vale = m.level === 0 ? !tinha.has(m.name) : m.level === nivel;
    if (vale && !out.some(x => x.name === m.name)) out.push(m);
  }
  return out;
}
// Dano de um golpe. Habilidades (habilidades.js) entram aqui: quem ataca (stab, técnico, crítico, pinch, pouco
// efetivo, queimadura ignorada) e quem recebe (resiste, super efetivo reduzido, HP cheio). Estágios/atributos em effStat.
// Poder de golpe que depende da situação (especiais.js → poder). null = usa o poder da tabela.
/* Peso em QUILOS. A PokéAPI manda em hectogramas (`data.weight`); quem baixou a espécie antes deste campo existir
   tem o registro sem ele (api.loadPokemon troca na primeira busca online), e aí não há peso: `null` faz a fórmula
   desistir e vale o poder da tabela, em vez de o golpe bater como se o bicho pesasse zero. */
const pesoKg = m => (typeof m.data?.weight === 'number' ? m.data.weight / 10 : null);
const estagiosPositivos = m => Object.values(m.vol?.stages || {}).reduce((s, n) => s + Math.max(0, n), 0);
export function poderEspecial(u, t, move) {
  const f = especial(move).poder; if (!f) return null;
  const base = move.power || 60, hpU = u.hp / u.stats.hp;
  switch (f) {
    case 'pesoDoAlvo': { const p = pesoKg(t); return p == null ? null : p >= 200 ? 120 : p >= 100 ? 100 : p >= 50 ? 80 : p >= 25 ? 60 : p >= 10 ? 40 : 20; } // Low Kick, Grass Knot
    case 'pesoRelativo': { // Heavy Slam, Heat Crash: quantas vezes você é mais pesado que o alvo
      const a = pesoKg(u), b = pesoKg(t); if (a == null || b == null) return null;
      const r = a / Math.max(0.1, b); return r >= 5 ? 120 : r >= 4 ? 100 : r >= 3 ? 80 : r >= 2 ? 60 : 40;
    }
    case 'estagios': return base + 20 * estagiosPositivos(u);                                           // Stored Power, Power Trip
    case 'estagiosDoAlvo': return Math.min(200, base + 20 * estagiosPositivos(t));                      // Punishment (teto 200 no jogo)
    case 'hpDoAlvo': return Math.max(1, Math.floor(120 * t.hp / t.stats.hp));                           // Wring Out, Crush Grip
    case 'hpBaixo': { const p = Math.floor(48 * u.hp / u.stats.hp); return p <= 1 ? 200 : p <= 4 ? 150 : p <= 9 ? 100 : p <= 16 ? 80 : p <= 32 ? 40 : 20; } // Flail, Reversal
    case 'hpAlto': return Math.max(1, Math.floor(150 * hpU));                                           // Eruption, Water Spout
    case 'giroscopio': return Math.min(150, Math.floor(25 * effStat(t, 'speed') / effStat(u, 'speed')) + 1); // Gyro Ball: mais lento = mais forte
    case 'eletro': { const r = effStat(u, 'speed') / effStat(t, 'speed'); return r >= 4 ? 150 : r >= 3 ? 120 : r >= 2 ? 80 : r >= 1 ? 60 : 40; } // Electro Ball
    case 'dobraAlvoComStatus': return t.status ? base * 2 : base;                                      // Hex
    case 'dobraComStatus': return u.status ? base * 2 : base;                                          // Facade
    case 'dobraAlvoEnvenenado': return t.status === 'poison' ? base * 2 : base;                       // Venoshock
    case 'dobraAlvoMetade': return t.hp <= t.stats.hp / 2 ? base * 2 : base;                           // Brine
    /* Return / Frustration: o poder sai da FELICIDADE, de 0 a 102 (felicidade/2,5), como nos jogos. Aqui a
       felicidade do seu Pokémon é a `m.felicidade` que o petisco e a amizade mexem (amizade.js), e a de um
       selvagem não existe — `?? 70` é o valor inicial dos jogos, que dá ~28 de poder. */
    case 'felicidade': return Math.max(1, Math.floor((u.felicidade ?? 70) / 2.5));
    case 'felicidadeInversa': return Math.max(1, Math.floor((255 - (u.felicidade ?? 70)) / 2.5));
    // Magnitude: o poder é sorteado na hora, com os mesmos pesos dos jogos (o 70 é o mais comum)
    case 'magnitude': return [[10, 5], [30, 10], [50, 20], [70, 30], [90, 20], [110, 10], [150, 5]]
      .reduce((a, [p, w]) => a.concat(Array(w).fill(p)), [])[rand(0, 99)];
    // Trump Card: quanto MENOS PP sobrou, mais forte — o último uso é o de 200
    case 'ppRestante': return [200, 80, 60, 50, 40][Math.min(4, Math.max(0, move.ppLeft ?? 4))];
    // Fling: o poder é o do item na mão (especiais.poderDoFling). Sem item o golpe falha antes de chegar aqui.
    case 'fling': return poderDoFling(u.item);
  }
  return null;
}
/* ⚔ **Contra-ataque** (Counter, Mirror Coat, Metal Burst): devolve o dano que você levou NESTE turno, vezes o
   multiplicador. `vol.ultimoDano` é escrito por `golpe.executar` e apagado em `fimDaRodada` — "neste turno" é
   literal, e é o que faz o golpe falhar quando ninguém te bateu antes de você agir.
   `classe` filtra físico × especial (Counter só devolve físico, Mirror Coat só especial); Metal Burst não filtra. */
export function danoDoContra(u, esp) {
  const c = esp?.contra, d = u?.vol?.ultimoDano;
  if (!c || !d?.valor) return null;
  if (c.classe && d.classe !== c.classe) return null;
  return Math.max(1, Math.floor(d.valor * c.mult));
}
/* 🎨 **Conversion 2**: o tipo de quem usa passa a ser um que RESISTE (ou é imune) ao último golpe que o acertou.
   Sorteia entre todos os que servem, como nos jogos — a tabela de tipos é a fonte, não uma lista nossa. */
export function tipoQueResiste(tipoDoGolpe, sorte = Math.random) {
  if (!CHART[tipoDoGolpe]) return null;
  const servem = Object.keys(CHART).filter(d => typeEff(tipoDoGolpe, [d]) < 1);
  return servem.length ? servem[Math.floor(sorte() * servem.length)] : null;
}
/* Golpes de dano FIXO: não passam pela fórmula de dano (nem tipo, nem atributo, nem crítico). Devolve o dano
   BRUTO ou null — quem chama (golpe.executar) ainda passa pelo chefe de evento, como o Endeavor já fazia:
   dano que fura a couraça do chefe seria um botão de vitória.
     número         sempre esse tanto (Sonic Boom 20, Dragon Rage 40)
     nivel          o nível de quem usou (Seismic Toss, Night Shade)
     nivelVariado   de 50% a 150% do nível (Psywave)
     metadeDoAlvo   metade do HP ATUAL do alvo (Super Fang, Nature's Madness)
     hpProprio      o HP que sobrou em quem usou, que desmaia depois (Final Gambit) */
export function danoFixoDe(u, t, esp, sorte = Math.random) {
  const f = esp?.danoFixo; if (f == null) return null;
  if (typeof f === 'number') return f;
  switch (f) {
    case 'nivel': return u.level;
    case 'nivelVariado': return Math.max(1, Math.floor(u.level * (0.5 + sorte())));
    case 'metadeDoAlvo': return Math.max(1, Math.floor(t.hp / 2));
    case 'hpProprio': return u.hp;
  }
  return null;
}
// OHKO (Fissure, Guillotine…): 30% + diferença de nível; alvo de nível maior nunca cai
export const chanceOhko = (u, t) => t.level > u.level ? 0 : Math.min(1, (30 + u.level - t.level) / 100);

/* ---- clima (campo da batalha) ----
   Vive em `campo.clima` (single player: G.B.campo; multiplayer: estado.campo) com `turnos` restantes. Sol e chuva
   mexem no dano de Fogo/Água; areia e granizo machucam quem não é do tipo certo no fim do turno; neve dá Defesa
   pros Gelo. Algumas habilidades ligam o clima ao entrar em campo e outras se aproveitam dele (habilidades.js). */
export const CLIMAS = {
  sol: { nome: 'Sol forte', icone: '☀', comeca: 'O sol fica forte!', acaba: 'O sol voltou ao normal.', sobe: { fire: 1.5 }, desce: { water: 0.5 } },
  chuva: { nome: 'Chuva', icone: '🌧', comeca: 'Começou a chover!', acaba: 'A chuva parou.', sobe: { water: 1.5 }, desce: { fire: 0.5 } },
  areia: { nome: 'Tempestade de areia', icone: '🏜', comeca: 'Uma tempestade de areia se levanta!', acaba: 'A areia baixou.', dano: 1 / 16, poupa: ['rock', 'ground', 'steel'], defesaDe: { rock: { 'special-defense': 1.5 } } },
  granizo: { nome: 'Granizo', icone: '🧊', comeca: 'Começou a cair granizo!', acaba: 'O granizo parou.', dano: 1 / 16, poupa: ['ice'] },
  neve: { nome: 'Neve', icone: '❄', comeca: 'Começou a nevar!', acaba: 'A neve parou.', poupa: ['ice'], defesaDe: { ice: { defense: 1.5 } } }
};
export const CLIMA_TURNOS = 5;

/* ---- lado do campo (telas, proteções e armadilhas) ----
   Cada lado da batalha tem o seu: `campo.lados = { jogador: {...}, inimigo: {...} }` (no multiplayer, A e B).
     reflect/luz/veu   turnos de Reflect, Light Screen e Aurora Veil — cortam dano pela metade
     salvaguarda       turnos sem pegar status
     neblina           turnos em que o inimigo não consegue baixar seus atributos (Mist)
     vento             turnos de Tailwind (velocidade × 2)
     pedras            Stealth Rock posto (true/false)
     espinhos/toxinas  camadas de Spikes e Toxic Spikes
   Armadilha só machuca quem ENTRA em campo — aqui isso acontece quando o treinador (ou a fila de lendários) manda
   o próximo Pokémon. Você nunca troca de Pokémon, então armadilha no seu lado não tem em quem pegar: os golpes
   dizem isso na hora de usar, em vez de fingir que funcionaram. */
// `resisteRaide` = { tipo, turnos }: Cinza Vulcânica/Escama Abissal (itens de raide, boss.js) — resiste um tipo por N turnos
/* As seis últimas são de 13/10/2026. `sorte` (Lucky Chant) dura 5 turnos como as telas; `wide`/`rapido`/`astuto`/
   `tapete` são as proteções de UM turno (Wide Guard, Quick Guard, Crafty Shield, Mat Block) e por isso nascem com
   1 — `passarLado` as zera no fim da própria rodada. `teia` é o Sticky Web, armadilha como as outras. */
export const LADO_VAZIO = () => ({ reflect: 0, luz: 0, veu: 0, salvaguarda: 0, neblina: 0, vento: 0, pedras: false, espinhos: 0, toxinas: 0, resisteRaide: null,
  sorte: 0, wide: 0, rapido: 0, astuto: 0, tapete: 0, teia: 0 });
export const TELA_TURNOS = 5, VENTO_TURNOS = 4;
export const MAX_ESPINHOS = 3, MAX_TOXINAS = 2;
/* Golpe de área (`target` = all-opponents / all-other-pokemon) que pega mais de um alvo bate 25% mais fraco em
   CADA um, como nas batalhas duplas dos jogos. Pegando só um (grupo de um, ou o resto já caiu) sai cheio.
   Quem aplica é golpe.executar; a lista de alvos sai de golpe.alvosDoGolpe. */
export const MULT_AREA = 0.75;
/* O que o golpe de área vale a mais na cabeça da IA (notaDoGolpe): a nota é "% do HP do alvo que o golpe vale",
   então um alvo extra vale menos que um alvo inteiro (sai ×MULT_AREA e nem sempre é o alvo que importa), e
   respingar no próprio aliado machuca mais do que o alvo extra compensa — senão o inimigo usa Earthquake com o
   bando dele em campo. */
export const BONUS_AREA = 25, PENA_AREA_ALIADO = 35;
/* Golpe de APOIO: golpe de status de alvo ESCOLHIDO cujo efeito é bom pra quem recebe (cura HP ou só sobe
   atributo) — Heal Pulse, Floral Healing, Purify, Decorate. Nos jogos quem usa aponta num companheiro; aqui o
   alvo escolhido é sempre o inimigo em foco, então Heal Pulse curava QUEM USOU e Decorate subia +2 Atk/At.Esp.
   do INIMIGO. Quem redireciona pro próprio lado é golpe.alvosDoGolpe; a IA lê isto em notaDoGolpe.
   Golpe com `target` de si/do lado (Recover, Swords Dance) nunca chega aqui: aquele caminho vem antes. */
export const golpeDeApoio = g => g?.cls === 'status' && !(g.meta?.ailment && g.meta.ailment !== 'none')
  && ((g.meta?.heal > 0) || (!!g.stats?.length && g.stats.every(s => s.change > 0)));
// dano cortado pelas telas do lado de quem DEFENDE (Aurora Veil vale pros dois tipos de golpe)
// `atravessa` = Infiltrator: pra quem tem, a tela do outro lado é como se não existisse (e a Salvaguarda também,
// em golpe.aplicarStatus — é a mesma habilidade, lida nos dois pontos)
export function multTelas(lado, move, atravessa = false) {
  if (!lado || atravessa) return 1;
  const fisico = move.cls === 'physical';
  if (lado.veu > 0 || (fisico ? lado.reflect > 0 : lado.luz > 0)) return 0.5;
  return 1;
}
export const temSalvaguarda = lado => !!lado && lado.salvaguarda > 0;
export const temNeblina = lado => !!lado && lado.neblina > 0;
export const multVento = lado => (lado?.vento > 0 ? 2 : 1);
// Cinza Vulcânica/Escama Abissal (item de raide): dano recebido daquele tipo, pela metade
export const multResisteRaide = (lado, tipo) => (lado?.resisteRaide?.tipo === tipo ? 0.5 : 1);
// Stealth Rock: 1/8 do HP máximo, corrigido pela eficácia de Pedra contra o tipo de quem entrou
export const danoPedras = m => Math.max(1, Math.floor(m.stats.hp / 8 * typeEff('rock', tiposDefensivos(m))));
// Spikes: só pega quem está no chão; 1/8, 1/6 ou 1/4 conforme as camadas
export const danoEspinhos = (m, camadas) => (!camadas || !noChao(m) ? 0 : Math.max(1, Math.floor(m.stats.hp * [0, 1 / 8, 1 / 6, 1 / 4][Math.min(camadas, MAX_ESPINHOS)])));
// Toxic Spikes: Venenoso no chão limpa o campo; Aço e quem voa não ligam; 2 camadas = veneno grave
export function efeitoToxinas(m, camadas) {
  if (!camadas || !noChao(m)) return null;
  if (tiposDe(m).includes('poison')) return 'limpa';
  if (imuneAoStatus(tiposDe(m), 'poison') || hab(m).imuneStatus?.includes('poison')) return null;
  return camadas >= MAX_TOXINAS ? 'grave' : 'veneno';
}
// fim da rodada: tudo que conta turno anda um. Devolve o que acabou agora, pra narrar.
export function passarLado(lado) {
  const acabou = [];
  for (const k of ['reflect', 'luz', 'veu', 'salvaguarda', 'neblina', 'vento', 'sorte', 'wide', 'rapido', 'astuto', 'tapete']) {
    if (lado?.[k] > 0 && --lado[k] === 0) acabou.push(k);
  }
  if (lado?.resisteRaide && --lado.resisteRaide.turnos <= 0) { lado.resisteRaide = null; acabou.push('resisteRaide'); }
  return acabou;
}
export const NOME_LADO = { reflect: 'Refletir', luz: 'Tela de Luz', veu: 'Véu da Aurora', salvaguarda: 'Salvaguarda', neblina: 'Névoa', vento: 'Vento de Cauda', resisteRaide: 'A proteção elemental',
  sorte: 'O Canto da Sorte', wide: 'A Guarda Ampla', rapido: 'A Guarda Rápida', astuto: 'O Escudo Astuto', tapete: 'O Tapete', teia: 'A teia' };
// as proteções de lado que valem UM turno: cada uma barra uma família de golpe (golpe.executar)
export const GUARDAS_DE_LADO = { wide: 'area', rapido: 'prioridade', astuto: 'status', tapete: 'dano' };

/* ---- terrenos ----
   Também vivem no campo (`campo.terreno` / `campo.terrenoTurnos`) e duram 5 turnos, mas só valem pra quem está NO
   CHÃO: Pokémon do tipo Voador e quem tem Levitate flutuam e ficam de fora de tudo (bônus, cura e proteção). */
export const TERRENOS = {
  eletrico: { nome: 'Campo Elétrico', icone: '⚡', comeca: 'O chão fica eletrizado!', acaba: 'A eletricidade do chão sumiu.', sobe: { electric: 1.3 }, semStatus: ['sleep'] },
  grama: { nome: 'Campo de Grama', icone: '🌿', comeca: 'Cresce grama alta pelo campo!', acaba: 'A grama do campo murchou.', sobe: { grass: 1.3 }, cura: 1 / 16 },
  psiquico: { nome: 'Campo Psíquico', icone: '🔮', comeca: 'O chão fica estranho, quase vivo!', acaba: 'A estranheza do chão passou.', sobe: { psychic: 1.3 }, semPrioridade: true },
  fada: { nome: 'Campo de Névoa', icone: '🌫', comeca: 'Uma névoa cobre o chão!', acaba: 'A névoa do chão se dissipou.', desce: { dragon: 0.5 }, semStatus: 'todos' }
};
export const TERRENO_TURNOS = 5;

/* ---- clima e terreno PADRÃO da rota ----
   Algumas rotas nascem com o tempo/chão da paisagem: neve em Caverna Gelada, areia no deserto, grama nos bosques.
   Vale pros dois lados e desde o 1º turno. É PERMANENTE (`climaFixo`/`terrenoFixo`: o contador não anda) até algum
   golpe ou habilidade trocar; a troca dura os 5 turnos de sempre e, quando acaba, a rota volta ao padrão dela
   (`campo.padrao`). Chave = id da rota (dados-mapas.js). Rota fora da tabela = campo limpo, como sempre foi. */
export const CLIMA_DA_ROTA = {
  // clima
  'k-ilhas': { clima: 'chuva' }, caverna: { clima: 'chuva' }, 'j-olivine': { clima: 'chuva' }, 'j-furia': { clima: 'chuva' }, 'j-gelo': { clima: 'granizo' },
  'h-deserto': { clima: 'areia' }, 'h-chimney': { clima: 'sol' }, 'h-mar': { clima: 'chuva' },
  's-eolico': { clima: 'sol' }, 's-pantano': { clima: 'chuva' }, 's-neve': { clima: 'neve' },
  'u-deserto': { clima: 'areia' }, 'u-gelada': { clima: 'neve' }, 'u-humilau': { clima: 'chuva' },
  'ka-frost': { clima: 'neve' }, 'ka-pantano': { clima: 'chuva' }, 'ka-azure': { clima: 'sol' },
  'a-wela': { clima: 'sol' }, 'a-hano': { clima: 'sol' }, 'a-lanakila': { clima: 'neve' }, 'a-poni': { clima: 'areia' },
  'g-rota8': { clima: 'neve' }, 'g-coroa': { clima: 'neve' }, 'g-miloc': { clima: 'chuva' },
  'p-glaseado': { clima: 'neve' }, 'p-asado': { clima: 'areia' }, 'p-casseroya': { clima: 'chuva' },
  // terreno
  'k-usina': { terreno: 'eletrico' }, floresta: { terreno: 'grama' }, 'j-ilex': { terreno: 'grama' }, 'j-ruinas': { terreno: 'psiquico' },
  'h-petalburgo': { terreno: 'grama' }, 'h-pilar': { terreno: 'psiquico' }, 's-eterna': { terreno: 'grama' },
  'u-chargestone': { terreno: 'eletrico' }, 'u-pinwheel': { terreno: 'grama' }, 'u-sonhos': { terreno: 'grama' }, 'u-celestial': { terreno: 'psiquico' },
  'ka-santalune': { terreno: 'grama' }, 'ka-usina': { terreno: 'eletrico' }, 'ka-riviere': { terreno: 'fada' },
  'a-selva': { terreno: 'grama' }, 'a-altar': { terreno: 'psiquico' },
  'g-hammerlocke': { terreno: 'eletrico' }, 'g-glimwood': { terreno: 'fada' },
  'p-tagtree': { terreno: 'grama' }, 'p-zero': { terreno: 'psiquico' }
};
// Esta jornada usa o clima/terreno das rotas? Roguelike e Hardcore: sempre (`climaRotasFixo`). Os outros modos: só se
// o jogador ligou na criação (`S.climaRotas`). Save antigo sem o campo cai na regra do modo.
export const climaDasRotasAtivo = S => !!(DIFICULDADES[S?.dificuldade]?.climaRotasFixo || S?.climaRotas);
// o campo de uma batalha nova naquela rota (sem rota, ou rota sem padrão, = campo limpo)
export function novoCampo(rotaId) {
  const p = CLIMA_DA_ROTA[rotaId] || {};
  return {
    clima: p.clima || null, turnos: p.clima ? CLIMA_TURNOS : 0, climaFixo: !!p.clima,
    terreno: p.terreno || null, terrenoTurnos: p.terreno ? TERRENO_TURNOS : 0, terrenoFixo: !!p.terreno,
    padrao: { clima: p.clima || null, terreno: p.terreno || null }, lados: {}
  };
}

/* Weather Ball: o tipo e o poder seguem o tempo (sol Fogo, chuva Água, areia Pedra, granizo/neve Gelo; poder ×2).
   Devolve uma CÓPIA do golpe — o gasto de PP e a lista de golpes seguem no original. Sem tempo, é o Normal de 50. */
export const TIPO_BOLA_DO_TEMPO = { sol: 'fire', chuva: 'water', areia: 'rock', granizo: 'ice', neve: 'ice' };
export function golpeDoClima(g, clima) {
  if (g?.name !== 'weather-ball' || !TIPO_BOLA_DO_TEMPO[clima]) return g;
  return { ...g, type: TIPO_BOLA_DO_TEMPO[clima], power: (g.power || 50) * 2 };
}
/* Tera Blast: o tipo segue o Tera de QUEM USA (não muda de categoria física/especial — simplificação; o poder já
   vem certo da PokéAPI). Sem terastalizar, continua Fogo/Normal do golpe original. Relatado em jogo: o golpe
   nunca mudava de tipo depois de terastalizar. */
export function golpeDoTera(g, u) {
  if (g?.name !== 'tera-blast' || !u?.tera) return g;
  return { ...g, type: u.tera };
}
/* Battle Bond (Ash-Greninja): Water Shuriken vira poder fixo 20 e SEMPRE 3 acertos (a versão normal é poder 15,
   2 a 5 acertos aleatórios). Texto oficial da habilidade na PokéAPI: "Water Shuriken's power is 20 and always
   hits three times." Sem virar Ash-Greninja, o golpe original continua valendo. */
export function golpeDoBattleBond(g, u) {
  if (g?.name !== 'water-shuriken' || !u?.ashGreninja) return g;
  return { ...g, power: 20, meta: { ...g.meta, minHits: 3, maxHits: 3 } };
}
/* Aerilate/Pixilate/Refrigerate/Galvanize (Normal vira Voador/Fada/Gelo/Elétrico, ×1,3) e Normalize (QUALQUER
   golpe vira Normal — `de: '*'`, sem reforço de poder): entra ANTES de calcDamage, igual golpeDoClima/golpeDoTera.
   De propósito ANTES do Tera/Battle Bond na ordem de `executar()`: Weather Ball sem clima ativo continua Normal
   (golpeDoClima não mexeu nele) e É convertido aqui — igual nos jogos de verdade (Pixilate + Weather Ball sem
   tempo vira golpe de Fada). Com o Tera ativo, o tipo do Tera já venceria de qualquer jeito (roda depois). */
export function golpeDaConversaoDeTipo(g, u) {
  const c = hab(u).converteTipo; if (!c || !g || (c.de !== '*' && g.type !== c.de) || g.type === c.para) return g;
  return { ...g, type: c.para, power: g.power ? Math.floor(g.power * (c.mult || 1)) : g.power };
}
export const terrenoDe = campo => (campo?.terrenoTurnos > 0 && TERRENOS[campo.terreno]) ? campo.terreno : null;
/* Quem está no chão sente o terreno; Voador e Levitate flutuam.
   🪨 `vol.noSolo` (Gravidade, Smack Down, Thousand Arrows) força PRA BAIXO e 🧲 `vol.voando` (Magnet Rise,
   Telekinesis) força PRA CIMA — nesta ordem, como nos jogos: a gravidade vence a flutuação, e é por isso que
   `mudarGravidade` apaga o `voando` de quem estava no ar. Um Pokémon posto no chão sente o terreno, pisa nos
   espinhos, pega as toxinas e passa a levar golpe Terrestre (`regras.eficacia`). */
export const noChao = m => m?.vol?.noSolo ? true : m?.vol?.voando > 0 ? false
  : !tiposDe(m).includes('flying') && hab(m).imuneTipo !== 'ground' && !m?.vol?.balao;
/* Turnos de cada coisa que mexe com o chão e com o aperto. `APERTO_MIN/MAX` são os 4–5 turnos dos jogos (Bind,
   Fire Spin, Whirlpool…), e `APERTO_FRACAO` o 1/8 do HP máximo por turno. */
export const GRAVIDADE_TURNOS = 5, APERTO_MIN = 4, APERTO_MAX = 5, APERTO_FRACAO = 1 / 8;
export function multTerreno(terreno, tipo, atacante) {
  const t = TERRENOS[terreno]; if (!t || !atacante || !noChao(atacante)) return 1;
  return t.sobe?.[tipo] || t.desce?.[tipo] || 1;
}
// o terreno impede este status neste Pokémon? (Campo Elétrico tira o sono; Campo de Névoa tira todos)
export function terrenoBloqueiaStatus(terreno, m, ail) {
  const t = TERRENOS[terreno];
  if (!t?.semStatus || !noChao(m)) return false;
  return t.semStatus === 'todos' || t.semStatus.includes(ail);
}
export const climaDe = campo => (campo?.turnos > 0 && CLIMAS[campo.clima]) ? campo.clima : null;
// multiplicador de dano do clima pro tipo do golpe
export function multClima(clima, tipo) {
  const c = CLIMAS[clima]; if (!c) return 1;
  return c.sobe?.[tipo] || c.desce?.[tipo] || 1;
}
// dano de fim de turno do clima (areia/granizo); 0 = não machuca este Pokémon
export function danoClima(clima, m) {
  const c = CLIMAS[clima];
  if (!c?.dano || (c.poupa || []).some(t => tiposDe(m).includes(t))) return 0;
  if (hab(m).imuneClima?.includes(clima)) return 0;                       // Sand Veil, Snow Cloak, Ice Body, Magic Guard…
  return Math.max(1, Math.floor(m.stats.hp * c.dano));
}
// precisão que muda com o clima: Thunder/Hurricane acertam sempre na chuva e ficam ruins no sol; Blizzard, no gelo
export const PRECISAO_CLIMA = { thunder: { chuva: 100, sol: 50 }, hurricane: { chuva: 100, sol: 50 }, blizzard: { granizo: 100, neve: 100 } };

// `ladoAlvo` = o lado do campo de quem defende (telas: Reflect, Light Screen, Aurora Veil)
/* `esperado` = a média, sem sorteio: sem crítico e com a rolagem no meio da faixa (92,5%). É pra IA do inimigo
   comparar golpes (notaDoGolpe) sem que um crítico ou uma rolagem baixa mude a escolha de um turno pro outro. */
/* Chance de crítico por DEGRAU acumulado (golpe de alto crítico, Focus Energy, Super Luck, Garra Afiada…), como
   nas Gens 6+. Exportada porque a 📈 tela de Taxas a mostra: a tabela e o sorteio têm de ser o mesmo número. */
export const DEGRAUS_CRITICO = [1 / 24, 1 / 8, 1 / 2, 1];
export function calcDamage(u, t, move, clima = null, terreno = null, ladoAlvo = null, esperado = false) {
  if (FIXED[move.name]) return { dmg: Math.max(1, FIXED[move.name](u, t)), crit: false };
  const hu = hab(u), ht = hab(t);
  let power = poderEspecial(u, t, move) ?? (move.power || 60);
  /* Z-Move: converte o poder ANTES de tudo (zmove.js liga `vol.zAtivo` só no turno do Z). Entra aqui, e não
     numa cópia do golpe, pra não haver dois objetos de golpe em jogo — a cópia quebraria o gasto de PP, que é
     feito no golpe de verdade. */
  if (u.vol?.zAtivo) power = poderZ(power);
  else if (u.dyna) power = poderMax(power);   // gigante: todo golpe é Max (o Z tem prioridade — é um tiro só)
  if (hu.tecnico && power <= 60) power = Math.floor(power * 1.5);                   // Technician
  const phys = move.cls === 'physical';
  // estágio de crítico: o do golpe + Focus Energy (u.vol.foco)
  // `semCritico` (Battle Armor, Shell Armor): o golpe nunca sai crítico contra quem tem. Vale inclusive sobre
  // Focus Energy e golpe de crítico garantido — é exatamente pra isso que a habilidade existe.
  // `focoBase` (Super Luck): a habilidade já nasce com um degrau de crítico, somado ao do golpe e ao Focus Energy
  // `critContraStatus` (Merciless): contra alvo com esse status o crítico é garantido (ainda respeitando o semCritico)
  // `vol.estocada` (⚔ Saga, perícia do Guerreiro): crítico garantido — e ainda assim respeitando `semCritico`,
  // que é exatamente pra isso que Battle Armor/Shell Armor existem.
  const crit = !esperado && !ht.semCritico && !(ladoAlvo?.sorte > 0)        // 🍀 Lucky Chant: nada de crítico naquele lado
    && (!!u.vol?.estocada || !!u.vol?.critoCerto                            // 🔦 Laser Focus: crítico garantido
      || (hu.critContraStatus && t.status === hu.critContraStatus)
      || Math.random() < DEGRAUS_CRITICO[Math.min(DEGRAUS_CRITICO.length - 1, (move.meta?.crit || 0) + (u.vol?.foco || 0) + (hu.focoBase || 0) + (seg(u).critExtra || 0))]);
  // Unaware: quem tem ignora os degraus do OUTRO lado (o Ataque de quem o ataca, a Defesa de quem ele ataca)
  /* O par de atributos sai do `cls` do golpe, MENOS quando a tabela de especiais diz outra coisa: Body Press
     ataca com a sua Defesa, Foul Play com o Ataque do alvo, e Psyshock/Psystrike/Secret Sword são especiais
     que batem na Defesa física. */
  const esp = especial(move);
  const A = effStat(esp.atkDoAlvo ? t : u, esp.atkDe || (phys ? 'attack' : 'special-attack'), crit, true, clima, terreno, !!ht.ignoraEstagios);
  /* 🏠 Wonder Room (`vol.salaMaravilhas`): Defesa e Def. Esp. trocam de papel. A marca mora no `vol` de quem está
     em campo — o mesmo desenho da Gravidade — porque `calcDamage` recebe o Pokémon mas não o campo. */
  let statD = esp.defDe || (phys ? 'defense' : 'special-defense');
  if (t.vol?.salaMaravilhas && !esp.defDe) statD = phys ? 'special-defense' : 'defense';
  const D = effStat(t, statD, crit, false, clima, terreno, !!hu.ignoraEstagios);
  const base = Math.floor(Math.floor(Math.floor(2 * u.level / 5 + 2) * power * A / D) / 50) + 2;
  let mod = (crit ? hu.critico || 1.5 : 1) * (esperado ? 92.5 : rand(85, 100)) / 100;
  mod *= multStab(u, move.type, hu.stab || 1.5);                                      // STAB (Adaptability = ×2; Tera muda a conta)
  const ef = eficacia(hu, move.type, t);                                              // Tera defende pelo tipo Tera; Scrappy ignora a imunidade
  mod *= ef;
  if (ef > 1 && ht.superEfetivo) mod *= ht.superEfetivo;                            // Filter, Solid Rock
  if (ef < 1 && hu.poucoEfetivo) mod *= hu.poucoEfetivo;                            // Tinted Lens
  if (ef > 1 && hu.superEfetivoCausado) mod *= hu.superEfetivoCausado;              // Neuroforce
  mod *= hu.danoTipo?.[move.type] || 1;                                              // Steelworker, Transistor, Water Bubble…
  if (hu.emboscada && t.vol?.recemEntrou) mod *= hu.emboscada;                       // Stakeout: dobra o dano em quem acabou de entrar em campo
  if (hu.sheerForce && temSecundario(move)) mod *= 1.3;                              // Sheer Force: mais forte, mas perde o efeito (golpe.js)
  const dc = hu.danoTipoClima?.[clima]; if (dc?.tipos.includes(move.type)) mod *= dc.mult; // Sand Force na areia
  mod *= multFamilia(hu, move.name);                                                 // Iron Fist, Strong Jaw, Sharpness
  if (hu.multFlag && temFlag(move, hu.multFlag.flag)) mod *= hu.multFlag.mult;       // Tough Claws (contato), Mega Launcher (pulse), Punk Rock (som)
  if (ht.resisteFlag && temFlag(move, ht.resisteFlag.flag)) mod *= ht.resisteFlag.mult; // Punk Rock: quem tem leva metade de golpe de som
  if (hu.recuo && move.meta?.drain < 0) mod *= hu.recuo;                             // Reckless: golpe com recuo
  if (phys && u.status === 'burn' && !(hu.comStatus?.attack && statusVale(hu, 'burn')) && move.name !== 'facade') mod *= 0.5; // Guts e Facade ignoram a queimadura
  if (hu.rivalidade) mod *= mesmoGenero(u, t) ? 1.25 : generoOposto(u, t) ? 0.75 : 1; // Rivalry: briga melhor com igual
  if (hu.pinch === move.type && u.hp <= u.stats.hp / 3) mod *= 1.5;                 // Overgrow, Blaze, Torrent, Swarm
  if (u.vol.flashFire && move.type === 'fire') mod *= 1.5;
  if (ht.resiste?.[move.type]) mod *= ht.resiste[move.type];                        // Thick Fat, Heatproof
  if (ht.hpCheio && t.hp >= t.stats.hp) mod *= ht.hpCheio;                          // Multiscale
  /* Os quatro Tesouros da Ruína (Chi-Yu e cia.): quem tem baixa 25% de um atributo de TODO MUNDO menos de si.
     Numa luta de 1 contra 1 isso é exatamente o mesmo que mexer no dano deste golpe, e é assim que entra aqui:
     o atributo caído é de QUEM ESTÁ DO OUTRO LADO. Ataque/At. Esp. caído em quem ataca (`ht.ruina`) = ×0,75;
     Defesa/Def. Esp. caída em quem defende (`hu.ruina`) = ×4/3, que é o 1/0,75 da divisão.
     Simplificação assumida: com ALIADO em campo, o aliado não sente a ruína (o motor só tem os dois do golpe). */
  if (ht.ruina === (phys ? 'attack' : 'special-attack')) mod *= 0.75;
  if (hu.ruina === (phys ? 'defense' : 'special-defense')) mod *= 4 / 3;
  /* Dark Aura / Fairy Aura: reforçam o tipo pra TODO MUNDO em campo, dos dois lados — então basta um dos dois do
     golpe ter a habilidade. Aura Break (de qualquer lado) inverte o reforço em enfraquecimento, como nos jogos. */
  const aura = hu.aura?.tipo === move.type ? hu.aura : ht.aura?.tipo === move.type ? ht.aura : null;
  if (aura) mod *= (hu.anulaAura || ht.anulaAura) ? 0.75 : aura.mult;
  mod *= resisteDoItem(t, move.type, ef);                                            // Escama do Céu, Cristal Psíquico/Gélido, frutas de aperto
  mod *= multDanoDoItem(u, { ef, fisico: phys, tipo: move.type });                    // item segurado (Orbe da Vida, Núcleo Eternamax…)
  mod *= multClima(clima, move.type);                                                // sol/chuva (regras.CLIMAS)
  mod *= multTerreno(terreno, move.type, u);                                         // terreno, pra quem está no chão
  mod *= multTelas(ladoAlvo, move, !!hu.atravessaTelas);                             // telas do lado de quem defende (Infiltrator passa)
  mod *= multResisteRaide(ladoAlvo, move.type);                                      // Cinza Vulcânica/Escama Abissal (raide)
  return { dmg: Math.max(1, Math.floor(base * mod)), crit };
}
export function confDamage(u) {
  const A = effStat(u, 'attack'), D = effStat(u, 'defense');
  return Math.max(1, Math.floor(Math.floor(Math.floor(2 * u.level / 5 + 2) * 40 * A / D) / 50) + 2);
}
/* `vol.semCura` = **Heal Block**: por 5 turnos nada cura este Pokémon. Fica AQUI porque `heal` é a porta única de
   toda cura do jogo (golpe, dreno, item, habilidade, fim de turno) — uma linha cobre as ~25 chamadas, e uma trava
   por chamada seria um remendo em cada uma. Mora no `vol`: morre sozinho e não encosta no save. */
export const heal = (m, h) => { if (m?.vol?.semCura > 0) return 0; m.hp = Math.min(m.stats.hp, m.hp + h); return h; };

/* ---- extraídas de dentro da batalha (antes eram contas inline em useMove/turn/win/inflict/residual) ---- */

// probabilidade de acertar: precisão do golpe × estágio de precisão de quem usa contra evasão do alvo
export function chanceAcerto(move, user, target, clima = null) {
  // ⚔ Saga, ⚔ Estocada (perícia do Guerreiro): o próximo golpe NÃO erra. A marca é consumida pelo golpe em
  // golpe.usarGolpe; fora da Saga ela nunca existe no `vol`, então nada muda.
  if (user?.vol?.estocada || user?.vol?.miraCerta) return 1;   // ⚔ Estocada (Saga) · 🎯 Mind Reader / Lock On
  const h = hab(user), ht = hab(target);
  // Unaware: quem ataca ignora a evasão do alvo; quem é atacado ignora a precisão de quem ataca
  const n = clamp((ht.ignoraEstagios ? 0 : user.vol.stages.accuracy || 0) - (h.ignoraEstagios ? 0 : target.vol.stages.evasion || 0), -6, 6);
  let acc = PRECISAO_CLIMA[move.name]?.[clima] ?? move.acc;                          // Thunder na chuva, Blizzard no gelo…
  if (acc != null && ht.limitaStatus && move.cls === 'status') acc = Math.min(acc, ht.limitaStatus); // Wonder Skin: golpe de status alheio, no máx. 50%
  const esconde = clima && ht.escondeNoClima?.includes(clima) ? 0.8 : 1;             // Sand Veil, Snow Cloak
  const confuso = ht.evasaoConfuso && target.vol?.conf > 0 ? 0.5 : 1;                // Tangled Feet: evasão em dobro confuso
  return acc / 100 * (n >= 0 ? (3 + n) / 3 : 3 / (3 - n)) * (h.precisao || 1) * (move.cls === 'physical' ? h.precisaoFisica || 1 : 1) * esconde * confuso;
}

// imunidades de tipo a status (Elétrico não paralisa, Fogo não queima, Gelo não congela, Venenoso/Aço não envenenam)
export function imuneAoStatus(tipos, ail) {
  return (ail === 'paralysis' && tipos.includes('electric')) || (ail === 'burn' && tipos.includes('fire')) || (ail === 'freeze' && tipos.includes('ice')) || (ail === 'poison' && (tipos.includes('poison') || tipos.includes('steel')));
}
// tipo OU habilidade (Immunity, Limber, Insomnia, Own Tempo…)
export const imuneAoStatusMon = (m, ail) => (ail !== 'confusion' && imuneAoStatus(tiposDe(m), ail)) || !!hab(m).imuneStatus?.includes(ail);

// dano de queimadura (1/16) e veneno (1/8) no fim do turno, mínimo 1 (como nos jogos); 0 = sem status que cause dano.
// Sem o mínimo, HP máximo < 16 (queimadura) ou < 8 (veneno) dava floor = 0 e o status nunca machucava.
// Veneno grave (Toxic, m.vol.toxico = n): n/16 do HP, n sobe a cada turno (golpe.js fimDeTurno).
// Reordena os golpes na ficha (pedido do usuário: run e Raid) — troca a posição i com a vizinha (i+dir). Devolve
// um array NOVO (nunca muta): quem chama faz `M.moves = moverGolpe(M.moves, i, dir)`. O PP usado mora dentro de
// cada objeto de golpe (`ppLeft`), então ele viaja junto com o golpe na troca, sem lógica extra.
export function moverGolpe(moves, i, dir) {
  const j = i + dir;
  if (j < 0 || j >= moves.length) return moves;
  const novo = [...moves];
  [novo[i], novo[j]] = [novo[j], novo[i]];
  return novo;
}
export function danoResidual(m) {
  if (m.status === 'poison' && m.vol?.toxico) return Math.max(1, Math.floor(m.stats.hp * m.vol.toxico / 16));
  const frac = m.status === 'burn' ? 16 : m.status === 'poison' ? 8 : 0;
  return frac ? Math.max(1, Math.floor(m.stats.hp / frac)) : 0;
}

/* Item de evolução na mochila DOBRA a chance de encontrar quem evolui com ele (pedido do usuário): achou a Maçã
   Doce, o Applin passa a aparecer duas vezes mais nessa rota. Devolve o conjunto de nomes de espécie; quem pesa o
   pool é `mapas.sortearDaRota`, e a MESMA lista vai pro `mapas.taxaNaRota` — a porcentagem na tela da rota tem de
   contar o dobro também, senão a soma mostrada mente (foi o bug #74/#75).
   Fora: o Cabo de Conexão, que evolui por TROCA e não nomeia espécie na tabela da PokéAPI (seriam 30+ de uma vez,
   e ele se compra na loja). O multiplicador em si é `mapas.MULT_ITEM_EVO`, onde o pool é pesado. */
export function especiesDobradas(bag = {}) {
  const dobram = new Set();
  for (const k in bag) if (bag[k] > 0) for (const e of ESPECIE_DO_ITEM_EVO[k] || []) dobram.add(e);
  return dobram;
}
/* Quem, do seu lado, evolui COM este item — a MESMA tabela do dobro de encontro, lida pelo outro lado. É o
   marcador da mochila: item de evolução sem ninguém pra usar é só um item guardado; com alguém, a mochila diz o
   nome dele. Síncrono de propósito: a árvore de evolução de verdade mora na API (e vale pro caso de ter mais de
   um caminho), mas pra MARCAR a linha da mochila não vale pedir rede nem esperar cache. */
export const quemEvoluiComItem = (item, mons = []) => {
  const alvos = ESPECIE_DO_ITEM_EVO[item];
  return alvos ? mons.filter(m => alvos.includes(m?.data?.speciesName)) : [];
};

/* Item na mão do SELVAGEM (relato #77/#70). Duas constantes, e são as duas que você mexe pra calibrar:
     CHANCE_ITEM_SELVAGEM  quantos selvagens aparecem segurando algo
     CHANCE_ESPOLIO_ITEM   dos que seguravam, quantos DEIXAM o item cair ao serem derrotados
   O caminho normal pra ficar com o item é o GOLPE (Thief, Covet) ou a HABILIDADE (Pickpocket, Magician) — o
   espólio é o acidente raro, não a torneira. Multiplicadas, as duas dão ~0,2% das vitórias contra selvagem:
   decisão do usuário em 06/10/2026, justamente pra não virar renda na 🤖 caçada automática, que faz centenas de
   lutas seguidas. Se um dia a ideia for "item de selvagem é fonte de renda", sobe a SEGUNDA, não a primeira.
   `sorte` entra por parâmetro (como em `ganhoAmizade`/`consegueFugir`) porque efeito de chance se testa fixando
   o sorteio, nunca por amostragem. */
export const CHANCE_ITEM_SELVAGEM = 0.08;
export const CHANCE_ESPOLIO_ITEM = 0.025;
export function itemDeSelvagem(sorte = Math.random(), sorteio = Math.random(), lista = ITENS_DE_SELVAGEM) {
  if (!(sorte < CHANCE_ITEM_SELVAGEM) || !lista.length) return null;
  const total = lista.reduce((s, e) => s + e.p, 0);
  let x = clamp(sorteio, 0, 0.999999) * total;
  return (lista.find(e => (x -= e.p) < 0) || lista[lista.length - 1]).id;
}
// o selvagem derrotado deixou o item cair? Só faz sentido chamar em quem ESTAVA segurando algo.
export const itemCaiComoEspolio = (sorte = Math.random()) => sorte < CHANCE_ESPOLIO_ITEM;

/* fuga: Run Away ou ser mais rápido garante; senão a chance sobe 30/256 a cada tentativa. `preso` = o oponente
   tem Magnet Pull e você é do tipo Aço (regras.js não sabe de habilidade — quem chama já resolveu isso em
   `hab(inimigo).prendeTipo`) — nem a velocidade ajuda, só Run Away escapa disso, como nos jogos. */
export function consegueFugir(velP, velE, tentativas, habilidade, sorte = Math.random(), preso = false) {
  if (habilidade === 'run-away') return true;
  if (preso) return false;
  return velP >= velE || sorte * 256 < Math.floor(velP * 128 / velE) + 30 * tentativas;
}

// true = o jogador age primeiro. Prioridade do golpe decide; empate de prioridade vai pela velocidade; empate total é moeda
export function jogadorAgePrimeiro(pm, em, velP, velE, sorte = Math.random()) {
  if ((pm.priority || 0) !== (em.priority || 0)) return (pm.priority || 0) > (em.priority || 0);
  return velP === velE ? sorte < 0.5 : velP > velE;
}

// Centro Pokémon: preço sobe com o nível pra cura não virar reflexo depois de toda luta.
// ₽50 + ₽15/nível ≈ 1–2 vitórias da faixa em que você está (vitória ≈ ₽11 × nível do inimigo).
/* Preço de um item AGORA. Quase todo item tem preço fixo (ITEMS[id].price); o Disco Técnico é a exceção — cada Disco
   USADO deixa o próximo mais caro. Sem isso bastava juntar dinheiro uma vez no fim da run e comprar quatro de uma
   vez, montando o moveset perfeito de graça. Conta pelo que foi USADO (S.discosUsados), não pelo que foi comprado:
   Disco parado na mochila não encarece nada. */
export const PRECO_DISCO = 8000, AUMENTO_DISCO = 4000;
export const precoItem = (id, S) => S?.lojaGratis ? 0 : id === 'tm-normal'
  ? PRECO_DISCO + AUMENTO_DISCO * (S?.discosUsados || 0)
  : (ITEMS[id]?.price || 0);
// Venda (itens.js venderItem, mochila): metade do preço de compra, igual à convenção dos jogos. Item sem preço
// (achado explorando, prêmio de Alfa…) devolve 0 — a mochila oferece "Jogar fora" nesse caso, não "Vender".
export const precoVenda = (id, S) => Math.floor(precoItem(id, S) / 2);

/* Itens rápidos (S.rapidos): até MAX_RAPIDOS atalhos que aparecem junto dos botões principais da tela, com as
   teclas 1 e 2 como hotkey. Marcar de novo desmarca; cheio e item novo devolve `null` (quem chama avisa que
   precisa tirar um antes, em vez de trocar por conta própria e derrubar a escolha de quem joga). */
export const MAX_RAPIDOS = 2;
export function alternarRapido(lista, id, max = MAX_RAPIDOS) {
  const atual = (Array.isArray(lista) ? lista : []).filter(Boolean);
  if (atual.includes(id)) return atual.filter(x => x !== id);
  return atual.length >= max ? null : [...atual, id];
}

/* O que um item de golpe (ITENS_GOLPE) oferece pra este Pokémon, sem repetir o que ele já sabe:
   'relembrar' (Escama do Coração) = golpes da lista POR NÍVEL até o nível atual — o que você deixou passar;
   'pokedex'   (Disco Técnico)     = golpes de MT/tutor/herança (learnset.extras, montado em api.buildLearnset).
   `null` = não dá pra saber agora: espécie sem cache, ou cache antigo, de antes dos extras existirem — quem chama
   avisa pra conectar uma vez, em vez de dizer que o Pokémon não aprende nada (que seria mentira). */
export function golpesParaEnsinar(tipo, M) {
  const L = M?.data?.learnset;
  if (!L) return null;
  const sabe = n => (M.moves || []).some(m => m.name === n);
  if (tipo === 'relembrar') return L.list.filter(m => m.level <= M.level && !sabe(m.name));
  return L.extras ? L.extras.filter(m => !sabe(m.name)) : null;
}

export const custoCentro = nivel => 50 + 15 * nivel;
// algo pra curar? (HP, status ou PP) — com tudo cheio o Centro não cobra nem cura
export const precisaCurar = m => m.hp < m.stats.hp || !!m.status || m.moves.some(mv => mv.ppLeft < mv.pp);

/* Item da mochila que substitui a passada no Centro pra ESTE Pokémon, ou null (🤖 auto-explorar, pedido do
   usuário: "indo sempre no Centro gasta muito"). O Centro cobra `custoCentro` de CADA um que tenha 1 HP ou 1 PP
   faltando (`precisaCurar` → `custoCentroEquipe`), então topar o aliado que raspou com uma Poção achada no mato
   tira ele da conta inteira.
   Dois crivos, e os dois importam:
   - **resolve o que falta** — Poção que não fecha o buraco de HP não entra (usar duas e ainda pagar o Centro é o
     pior dos dois mundos); pra PP e status basta o item servir.
   - **custa menos que o Centro cobraria por ele** (`precoVenda` x `custoCentro(nível)`) — queimar uma Hyper
     Potion de ₽600 de venda pra economizar ₽125 de Centro no Nv. 5 é o mesmo desperdício ao contrário.
   Entre os que passam, o mais barato. Item sem preço de loja (achado explorando) vale 0 e ganha sempre.
   HP primeiro: enquanto falta HP é ele que decide, porque é o que mantém a caçada viva. */
export function itemEmVezDoCentro(M, bag, S) {
  const teto = custoCentro(M.level), falta = M.stats.hp - M.hp;
  const serve = it => {
    if (it.battle || it.raide || it.segurado) return false;
    if (falta > 0) return !!(it.heal || it.healPct) && (it.healPct ? Math.ceil(M.stats.hp * it.healPct / 100) : it.heal) >= falta;
    if (M.status && it.cure) return it.cure === 'all' || it.cure.includes(M.status);
    return !!it.ether && M.moves.some(mv => mv.ppLeft < mv.pp);
  };
  return Object.keys(bag || {})
    .filter(id => bag[id] > 0 && ITEMS[id] && serve(ITEMS[id]) && precoVenda(id, S) <= teto)
    .sort((a, b) => precoVenda(a, S) - precoVenda(b, S))[0] || null;
}

/* `MULT_XP` estica a jornada: menos XP por vitória = mais batalhas por nível = run mais longa (pedido do
   usuário). Mexer aqui, e não na curva da PokéAPI, é de propósito — a curva vem da API e fica no cache de quem
   joga, então mudá-la exigiria invalidar o cache de todo mundo e quebraria comparação com jornadas antigas.
   0,6 ≈ jornada 1,65× mais longa. É UM número, fácil de girar: se ficar arrastado, suba; se ficar rápido, desça.
   Não mexe no equilíbrio relativo — treinador continua valendo 1,5× de um selvagem. */
export const MULT_XP = 0.6;
// Pokémon de treinador dá 1,5× XP (como nos jogos)
export const xpPorVitoria = (E, deTreinador = false) =>
  Math.max(1, Math.floor(E.data.baseExp * E.level / 7 * (deTreinador ? 1.5 : 1) * MULT_XP));

/* ---- batalha com vários Pokémon do mesmo lado (aliados agora, multiplayer depois) ---- */

// Garra Rápida (item, 20%) e Quick Draw (habilidade, 30%): chance, sorteada de novo a cada turno, de agir
// primeiro DENTRO da própria prioridade — não fura quem tem prioridade maior, só ganha de quem está na mesma
// faixa (mesmo sendo mais lento). Se dois lados ativarem, a velocidade ainda decide entre eles (`ordenarAcoes`).
export const CHANCE_QUICK_CLAW = 0.2, CHANCE_QUICK_DRAW = 0.3;
export function ativouQuickClaw(m, sorte = Math.random()) {
  if (seg(m).quickClaw) return sorte < CHANCE_QUICK_CLAW;
  if (hab(m).acaoRapida) return sorte < CHANCE_QUICK_DRAW;
  return false;
}
// Stall: sempre age por ÚLTIMO dentro da própria prioridade (o oposto da Garra Rápida/Quick Draw) — nunca sorteia,
// é sempre assim.
export const sempreUltimo = m => !!hab(m).sempreLento;
// Ordena as ações do turno: prioridade maior primeiro; dentro dela, quem ativou Garra Rápida/Quick Draw
// (`rapido`) primeiro e quem tem Stall (`lento`) por último; entre os do meio, velocidade maior; empate = moeda.
// Cada ação: { prio, vel, rapido?, lento?, ... } (o resto passa intacto). Não muta a lista recebida.
/* `invertido` = 🏠 **Trick Room**: dentro da mesma prioridade, quem é mais LENTO age primeiro. Entra como
   parâmetro (e não como marca no `vol` de cada um, que é como a Gravidade resolveu o problema dela) porque aqui
   o estado já chega até a função: os dois motores montam a fila e têm o `campo` na mão. Prioridade, Garra Rápida
   e Stall continuam valendo por cima — a sala inverte a VELOCIDADE, não a ordem toda, como nos jogos. */
export function ordenarAcoes(acoes, sorte = Math.random, invertido = false) {
  const v = invertido ? -1 : 1;
  return acoes.map(a => ({ a, k: sorte() }))
    .sort((x, y) => (y.a.prio - x.a.prio) || ((y.a.rapido ? 1 : 0) - (x.a.rapido ? 1 : 0)) || ((x.a.lento ? 1 : 0) - (y.a.lento ? 1 : 0)) || v * (y.a.vel - x.a.vel) || (x.k - y.k))
    .map(x => x.a);
}
export const SALA_TURNOS = 5;
// a sala está de pé? (Trick Room, Wonder Room, Magic Room guardam turnos no campo, como o clima)
export const salaAtiva = (campo, qual) => (campo?.[qual] || 0) > 0;
// Prankster (+1 golpe de status), Gale Wings (+1 golpe Voador com HP cheio), Triage (+3 golpe de cura)
export function prioridadeEfetiva(m, g) {
  let p = g.priority || 0;
  const h = hab(m);
  if (h.prankster && g.cls === 'status') p += 1;
  if (h.prioridadeVoador && g.type === 'flying' && m.hp >= m.stats.hp) p += 1;
  if (h.prioridadeCura && g.meta?.heal > 0) p += 3;
  return p;
}

// IA simples de aliado: o golpe com mais dano esperado (poder × eficácia × STAB) entre os que têm PP.
// Golpe de status vale pouco (poder 0) — só sai se não houver nada melhor. Sem PP nenhum → null (Struggle).
export function melhorGolpe(moves, tiposAtacante, tiposAlvo) {
  let melhor = null, nota = -1;
  for (const m of moves) {
    if (m.ppLeft <= 0) continue;
    const n = (m.cls === 'status' ? 0.1 : (m.power || 60)) * typeEff(m.type, tiposAlvo) * (tiposAtacante.includes(m.type) ? 1.5 : 1);
    if (n > nota) { nota = n; melhor = m; }
  }
  return melhor;
}

/* ---- golpes que TRAVAM o que dá pra escolher ----
   Choice (item), Colete de Assalto, Taunt, Encore, Disable e Torment restringem quais golpes um Pokémon pode usar.
   Antes só a trava do Choice existia, e a regra estava COPIADA em 4 lugares (as 3 telas de golpe + golpeDoAliado),
   com o motor confiando cegamente no que a tela mandava. Com mais quatro travas isso viraria 16 cópias — e a IA do
   inimigo, que precisa saber o que o ALVO pode fazer, não teria de onde ler. Aqui é a única fonte: telas, aliados,
   IA e o próprio motor (golpe.usarGolpe) perguntam à mesma função.
   O motor precisa conferir também porque a ORDEM do turno importa: se o inimigo é mais rápido e te provoca DEPOIS
   de você escolher um golpe de status, o seu golpe falha — filtrar só o menu não cobre isso.
   Estado guardado em `m.vol` (só dados simples, vai no save e pela rede):
     ultimo      nome do último golpe usado (Encore/Disable/Torment dependem dele)
     provocado   turnos que faltam de Taunt
     encore      { golpe, turnos } — só pode repetir esse
     desativado  { golpe, turnos } — esse não pode
     tormento    true — não pode repetir o golpe anterior (dura a batalha toda) */
export const TRAVAS = ['provocar', 'encore', 'disable', 'tormento'];
export const TURNOS_TRAVA = { provocar: 3, encore: 3, disable: 4 };
const SEM_ENCORE = new Set(['encore', 'mimic', 'transform', 'sketch', 'mirror-move', 'me-first', 'struggle']);
/* 🎭 Golpe que NÃO pode ser copiado nem sorteado por outro golpe de cópia. Dois motivos juntos: os jogos
   excluem a maioria deles de Metronome/Mimic/Copycat, e aqui eles são também a trava contra RECURSÃO — um
   Metronome que sorteia Metronome, ou um Mirror Move copiando o Mirror Move do outro, não tem fim.
   `struggle` entra porque não é golpe de verdade; os de dois turnos entram porque a cópia não carrega
   (`golpe.usarCopia` executa na hora — é a simplificação consciente do sistema de cópia). */
export const SEM_COPIA = new Set(['struggle', 'metronome', 'mimic', 'sketch', 'mirror-move', 'copycat',
  'sleep-talk', 'assist', 'me-first', 'instruct', 'nature-power', 'transform',
  'fly', 'dig', 'dive', 'bounce', 'phantom-force', 'shadow-force', 'sky-drop', 'solar-beam', 'solar-blade',
  'skull-bash', 'razor-wind', 'sky-attack', 'meteor-beam', 'freeze-shock', 'ice-burn', 'electro-shot']);
export const podeCopiar = nome => !!nome && !SEM_COPIA.has(nome);

// Por que `g` NÃO pode ser usado por `m` agora — { causa, texto } — ou null se pode. Struggle nunca é bloqueado.
export function motivoBloqueio(m, g) {
  if (!m || !g || g.name === 'struggle') return null;
  const v = m.vol || {}, s = seg(m), item = ITEMS[m.item]?.name || 'item';
  if (s.choice && v.escolha && g.name !== v.escolha) return { causa: 'escolha', texto: `está travado em ${fmt(v.escolha)} pelo ${item}` };
  // Encore só prende se o golpe repetido ainda tem PP — sem PP a trava fica suspensa, senão o Pokémon travaria sem nenhum golpe
  const enc = v.encore && m.moves?.find(x => x.name === v.encore.golpe);
  if (enc && enc.ppLeft > 0 && g.name !== enc.name) return { causa: 'encore', texto: `sob Encore, só pode repetir ${fmt(enc.name)}` };
  if (v.provocado > 0 && g.cls === 'status') return { causa: 'provocado', texto: 'provocado, só pode usar golpes de dano' };
  if (s.semStatus && g.cls === 'status') return { causa: 'colete', texto: `o ${item} não deixa usar golpes de status` };
  if (v.desativado && g.name === v.desativado.golpe) return { causa: 'disable', texto: `${fmt(g.name)} está desativado` };
  if (v.tormento && v.ultimo === g.name) return { causa: 'tormento', texto: 'atormentado, não pode repetir o golpe anterior' };
  /* 🪐 Gravidade: os golpes que saem do chão (Fly, Bounce, Magnet Rise, Telekinesis…) não funcionam. Quem diz
     QUAIS é a flag `gravity` da própria PokéAPI (dados-golpe-flags.js) — ela existe exatamente pra isto, então
     não há lista nossa pra manter. Entra aqui, e não numa trava do motor, pra as 3 telas de golpe e a IA já
     respeitarem de graça. `vol.gravidade` é posto e tirado por golpe.mudarGravidade/passarGravidade. */
  if (v.gravidade && temFlag(g, 'gravity')) return { causa: 'gravidade', texto: 'a gravidade não deixa sair do chão' };
  /* 🔇 Throat Chop (`vol.calado`): nada de golpe SONORO por 2 turnos. A flag `sound` é da PokéAPI.
     🔗 Imprison (`vol.proibidos`): os golpes que QUEM USOU também sabe ficam proibidos. A lista de nomes é
     copiada pro `vol` do alvo na hora do golpe — assim `motivoBloqueio` continua puro e recebendo um Pokémon só,
     que era o que faltava pra este golpe caber (ele precisaria ver o moveset do outro lado). */
  if (v.calado > 0 && temFlag(g, 'sound')) return { causa: 'calado', texto: 'está calado e não pode usar golpes de som' };
  if (v.proibidos?.includes(g.name)) return { causa: 'imprison', texto: `${fmt(g.name)} está selado` };
  return null;
}
export const golpePermitido = (m, g) => g.ppLeft > 0 && !motivoBloqueio(m, g);
// os golpes que `m` PODE escolher agora (com PP e sem trava). Lista vazia = Struggle.
export const golpesPermitidos = m => (m.moves || []).filter(g => golpePermitido(m, g));
// Encore: o golpe que a escolha vira, como nos jogos (a escolha é TROCADA, não recusada). null = sem Encore ativo
export function golpeForcado(m) {
  const e = m.vol?.encore;
  return e ? m.moves?.find(x => x.name === e.golpe && x.ppLeft > 0) || null : null;
}
// Por que o alvo não pode ser travado (null = pode). Chefe de evento é imune, como a status.
export function falhaDaTrava(alvo, tipo) {
  const v = alvo.vol || {};
  if (alvo.boss) return 'o chefe é imune';
  if (hab(alvo).imuneTrava?.includes(tipo)) return `${fmt(alvo.ability)} protege`;
  if (tipo === 'provocar' && v.provocado > 0) return 'já está provocado';
  if (tipo === 'tormento' && v.tormento) return 'já está atormentado';
  if (tipo === 'encore') {
    if (v.encore) return 'já está sob Encore';
    const g = v.ultimo && alvo.moves?.find(x => x.name === v.ultimo);
    if (!g || SEM_ENCORE.has(g.name)) return 'não tem golpe pra repetir';
    if (g.ppLeft <= 0) return 'o último golpe está sem PP';
  }
  if (tipo === 'disable') {
    if (v.desativado) return 'já tem um golpe desativado';
    if (!v.ultimo || !alvo.moves?.some(x => x.name === v.ultimo)) return 'ainda não usou golpe nenhum';
  }
  return null;
}
// Um turno passou: conta os prazos e devolve o que ACABOU (['provocado','encore','desativado']) pra quem narra avisar
export function passarTravas(m) {
  const v = m.vol; if (!v) return [];
  const fim = [];
  if (v.provocado > 0 && --v.provocado <= 0) { delete v.provocado; fim.push('provocado'); }
  for (const k of ['encore', 'desativado']) if (v[k] && --v[k].turnos <= 0) { delete v[k]; fim.push(k); }
  // 🧲 Magnet Rise / Telekinesis: a flutuação conta turnos igual às travas, no mesmo lugar
  if (v.voando > 0 && --v.voando <= 0) { delete v.voando; fim.push('voando'); }
  for (const k of ['calado', 'semCura', 'semItem']) if (v[k] > 0 && --v[k] <= 0) { delete v[k]; fim.push(k); }
  return fim;
}
// Linhas pra mostrar ao jogador o que está travando o Pokémon dele (as 3 telas de golpe usam a mesma)
export function resumoTravas(m) {
  const v = m.vol || {}, s = seg(m), item = ITEMS[m.item]?.name || 'item', l = [];
  if (s.choice && v.escolha) l.push(`🔒 Travado em ${fmt(v.escolha)} pelo ${item} até desmaiar ou ser revivido.`);
  if (s.semStatus) l.push(`🦺 O ${item} não deixa usar golpes de status.`);
  if (v.provocado > 0) l.push(`😤 Provocado por ${v.provocado} turno(s): só golpes de dano.`);
  if (v.encore) l.push(`🔁 Encore por ${v.encore.turnos} turno(s): só pode repetir ${fmt(v.encore.golpe)}.`);
  if (v.desativado) l.push(`⛔ ${fmt(v.desativado.golpe)} desativado por ${v.desativado.turnos} turno(s).`);
  if (v.tormento) l.push('😖 Atormentado: não pode repetir o golpe anterior.');
  return l;
}

/* ---- IA do inimigo ----
   Antes o inimigo sorteava qualquer golpe com PP — dava pra ganhar de Pokémon muito mais forte na sorte. Depois passou
   a acertar a escolha com a chance `esperteza` (selvagem erra bastante, treinador pensa melhor, Alfa e lendário quase
   sempre acertam), mas "acertar" era só o golpe de maior dano esperado (melhorGolpe: poder × eficácia × STAB) e
   golpe de status valia 0,1 pra qualquer um — então o inimigo só usava Toxic, Reflect ou Swords Dance por sorteio.
   Agora, com o CONTEXTO da luta (quem usa, quem apanha, o campo), cada golpe ganha uma nota (notaDoGolpe) e "pensar"
   é escolher a maior. A esperteza segue sendo a chance de pensar; o que muda com quem é o inimigo é QUANTO ele
   enxerga (nivelDaIA):
     simples   selvagem — como sempre foi: dano bruto (melhorGolpe), status quase nunca
     basico    treinador — dano de verdade (com dano esperado, precisão, imunidades e se derruba), status que pega
               (paralisar, queimar, dormir…) e cura quando está no fim; o resto é ruído
     completo  Alfa, lendário e chefe — tudo: buffs e debuffs, cura, clima, terreno, telas, Taunt/Encore/Disable,
               proteção, Leech Seed… e sabe que armadilha de entrada não pega no lado do jogador
   `sorte` injetável = testável. Devolve o golpe (ou null = Struggle). */
export const ESPERTEZA = { selvagem: 0.5, treinador: 0.75, chefe: 0.9 };
export const nivelDaIA = esperteza => esperteza >= ESPERTEZA.chefe ? 'completo' : esperteza >= ESPERTEZA.treinador ? 'basico' : 'simples';

// valor de infligir cada status (na mesma escala do dano: ≈ % do HP do alvo que o golpe "vale")
const VALOR_STATUS = { sleep: 55, paralysis: 40, burn: 40, freeze: 40, poison: 30, confusion: 25, infatuation: 15, trap: 15 };
// quanto vale +1 degrau em cada atributo (Ataque/Ataque Esp. são ajustados pelo que o Pokémon realmente usa)
const VALOR_ESTAGIO = { attack: 16, 'special-attack': 16, speed: 12, defense: 9, 'special-defense': 9, accuracy: 5, evasion: 8 };
const TETO_BUFF_IA = 2;            // não empilha mais que +2 (Swords Dance duas vezes já resolve)
const IGNORADO = 2;                // o que vale um golpe que o nível da IA nem considera
const IMPOSSIVEL = -100;           // não faz nada / é pior que não fazer nada: nunca escolhido "pensando"

// nota de UM golpe. c = { u: quem usa, alvo, campo, ladoU, ladoAlvo (os `campo.lados[...]` de cada um), nivel }
export function notaDoGolpe(g, c) {
  const { u, alvo, campo = null, ladoU = null, ladoAlvo = null } = c;
  const completo = (c.nivel || 'completo') === 'completo';
  const clima = campo ? climaDe(campo) : null, terreno = campo ? terrenoDe(campo) : null;
  const esp = especial(g), hu = hab(u), ht = hab(alvo);
  const acerto = g.acc == null ? 1 : clamp(chanceAcerto(g, u, alvo, clima), 0, 1);
  const frac = m => m.hp / Math.max(1, m.stats.hp);
  const usaFisico = u.moves.some(m => m.ppLeft > 0 && m.cls === 'physical'), usaEspecial = u.moves.some(m => m.ppLeft > 0 && m.cls === 'special');

  // ---- golpe de dano ----
  if (g.cls !== 'status') {
    const ef = eficacia(hu, g.type, alvo);                                                   // Scrappy: a IA sabe que Fantasma não é mais imune
    if (ef === 0 || ht.imuneTipo === g.type || ht.absorve === g.type) return IMPOSSIVEL;      // imune, ou ainda cura o alvo
    if (ht.imuneFlag && temFlag(g, ht.imuneFlag)) return IMPOSSIVEL;                          // Soundproof, Bulletproof
    if (esp.soDormindo && alvo.status !== 'sleep') return IMPOSSIVEL;
    if (esp.soNoSono && u.status !== 'sleep') return IMPOSSIVEL;      // Snore: só sai dormindo
    if (esp.soPrimeiroTurno && u.vol?.golpesDados) return IMPOSSIVEL;
    if (esp.ohko) return u.level < alvo.level ? IMPOSSIVEL : Math.min(90, 30 + u.level - alvo.level) * 0.9;
    /* 💥 Dano FIXO: `calcDamage` não sabe calcular estes (o poder é 0 ou mentira), então a nota sai do dano de
       verdade — senão a IA os trataria como golpe de poder nulo e nunca os usaria. Final Gambit leva o próprio
       dono junto, e por isso só vale a pena quando o troco derruba o alvo. */
    // Fling e Natural Gift falham sem o item/fruta na mão; Spit Up sem energia guardada; Beat Up/Present valem sempre
    if (esp.arremessa && !u.item) return IMPOSSIVEL;
    if (esp.presenteDaNatureza && !u.item?.endsWith('-berry')) return IMPOSSIVEL;
    if (esp.cuspir) return (u.vol?.estoque || 0) ? 30 * (u.vol.estoque / 3) + 20 : IMPOSSIVEL;
    const fixo = danoFixoDe(u, alvo, esp);
    if (fixo != null) {
      const nota = Math.min(1, fixo / Math.max(1, alvo.hp)) * 100 * acerto;
      return esp.autoDesmaio ? (fixo >= alvo.hp ? nota : nota - 60) : nota + (fixo >= alvo.hp ? 40 : 0);
    }
    const { dmg } = calcDamage(u, alvo, g, clima, terreno, ladoAlvo, true);
    let nota = Math.min(1, dmg / Math.max(1, alvo.hp)) * 100 * acerto;
    if (dmg >= alvo.hp && acerto > 0.6) nota += 40 + ((g.priority || 0) > 0 ? 30 : 0);      // derruba: vence qualquer outra ideia (e a prioridade garante)
    if (esp.soPrimeiroTurno) nota += 20;                                                     // Fake Out: o alvo perde a vez
    if (esp.autoDesmaio && dmg < alvo.hp) nota -= 60;                                        // só compensa se levar o alvo junto
    if (esp.recarga || esp.carga) nota *= esp.invulneravel ? 0.75 : 0.6;                     // gasta 2 turnos
    if (esp.furia) nota *= 0.9;
    if (esp.soSeAlvoAtaca) nota *= 0.7;
    // Thief/Covet (roubam) e Knock Off (derruba) valem um pouco mais quando há item na mão do alvo. São golpes de
    // DANO, então a nota base já vem de cima: isto é só o desempate contra outro golpe de poder parecido.
    if (alvo.item && ((esp.roubaItem && !u.item) || esp.derrubaItem)) nota += 8;
    /* 🐺 Golpe de ÁREA (dados.ALVOS_*): com grupo em campo ele pega vários, então vale mais — e Earthquake &
       cia. (`all-other-pokemon`) também respingam no PRÓPRIO aliado, o que a IA precisa saber antes de escolher.
       Sem contexto de quantos estão em campo (chamador antigo) vale o de sempre: a conta vira 0. */
    const outrosAlvos = Math.max(0, (c.oponentes || 1) - 1);
    const alcance = g.target || GOLPE_AREA[g.name];   // golpe sem `target` (save/cache velho): a tabela fixa responde, como em golpe.alvosDoGolpe
    if (ALVOS_OPONENTES.has(alcance) || ALVOS_TODOS.has(alcance)) nota += outrosAlvos * BONUS_AREA;
    if (ALVOS_TODOS.has(alcance)) nota -= (c.aliados || 0) * PENA_AREA_ALIADO;
    return nota;
  }

  // ---- golpe de status ----
  const ailmentDe = (ail, extra = 0) => {                                                     // infligir um status no alvo
    if (alvo.status && !['confusion', 'infatuation'].includes(ail)) return IMPOSSIVEL;
    if (ail === 'confusion' && alvo.vol?.conf > 0) return IMPOSSIVEL;
    // Attract só pega gênero OPOSTO, e uma vez só (golpe.aplicarStatus confere o mesmo)
    if (ail === 'infatuation' && (alvo.vol?.paixao || !generoOposto(alvo, u))) return IMPOSSIVEL;
    if (imuneAoStatusMon(alvo, ail) || ladoAlvo?.salvaguarda > 0) return IMPOSSIVEL;
    let v = (VALOR_STATUS[ail] ?? 4) + extra;
    if (ail === 'paralysis' && effStat(alvo, 'speed') > effStat(u, 'speed')) v += 15;        // tira a vez de quem é mais rápido
    if (ail === 'burn' && (alvo.data.base?.attack ?? 0) > (alvo.data.base?.['special-attack'] ?? 0)) v += 15;
    if (frac(alvo) < 0.25) v *= 0.3;                                                         // vai cair de qualquer jeito
    return v * acerto;
  };
  const curaDe = fracCura => {                                                               // recuperar o próprio HP
    const f = frac(u);
    if (f > 0.65) return IMPOSSIVEL;                                                         // com o HP alto, curar é desperdício
    return Math.min(fracCura, 1 - f) * 110;
  };
  /* 🤝 Golpe de companheiro (dados.ALVOS_ALIADOS): sem ninguém do lado em campo ele FALHA, então a IA não pode
     gastar o turno nele. Vale pro grupo selvagem e pro treinador com mais de um em campo — `c.aliados` é quem
     conta. Os de lado inteiro (Heal Bell, Howl) continuam valendo sozinho: quem usa também recebe. */
  if ((g.target === 'ally' || esp.soAliados || esp.ajudaAliado || esp.chamariz) && !(c.aliados || 0)) return IMPOSSIVEL;
  if (esp.ajudaAliado) return 14;                                                              // Helping Hand: só vale com companheiro pra ajudar
  if (esp.chamariz) return 16;                                                                 // Follow Me / Rage Powder: puxa o golpe pra si e poupa o companheiro
  if (esp.semEfeitoReal) return IMPOSSIVEL;                                                    // Hold Hands não faz nada
  if (esp.curaStatus) return u.status ? 45 : esp.cura && frac(u) < 0.6 ? 30 : IMPOSSIVEL;
  if (esp.statAleatorio) return frac(u) > 0.5 ? 12 : 3;                                        // Acupressure: atributo sorteado
  if (esp.generoOposto && !generoOposto(alvo, u)) return IMPOSSIVEL;                           // Captivate
  if (esp.toxico) return alvo.status || imuneAoStatusMon(alvo, 'poison') || ladoAlvo?.salvaguarda > 0 ? IMPOSSIVEL : 45 * acerto;
  if (esp.descanso) return frac(u) <= 0.4 && !imuneAoStatusMon(u, 'sleep') ? 60 : IMPOSSIVEL;
  // golpe de apoio (Heal Pulse, Floral Healing) cura o PRÓPRIO lado: a nota é a de curar, nunca a de atacar
  if (g.meta?.heal > 0 && (SELF_TARGETS.has(g.target) || golpeDeApoio(g))) return curaDe(g.meta.heal / 100);
  const ail = g.meta?.ailment;
  if (ail && ail !== 'none' && !SELF_TARGETS.has(g.target) && !esp.trava) return ailmentDe(ail);
  if (!completo) return IGNORADO;                                                            // treinador para por aqui

  // ---- só o nível "completo" (Alfa, lendário, chefe) ----
  if (esp.trava) {
    if (falhaDaTrava(alvo, esp.trava)) return IMPOSSIVEL;
    const ult = alvo.moves?.find(m => m.name === alvo.vol?.ultimo);
    if (esp.trava === 'provocar') {                                                          // vale contra quem depende de golpe de status; contra quem só bate, não tira nada
      const nStatus = alvo.moves.filter(m => m.ppLeft > 0 && m.cls === 'status').length;
      const v = nStatus === 0 ? 1 : 10 + Math.min(4, nStatus) * 12;
      return ult && ult.cls !== 'status' ? v * 0.4 : v;                                      // acabou de bater com dano: provocar não tira o que ele está fazendo
    }
    if (esp.trava === 'encore') return ult && (ult.cls === 'status' || (ult.power || 0) < 50) ? 45 : IMPOSSIVEL;                  // prender num golpe fraco/inútil
    if (esp.trava === 'disable') return (ult?.power || 0) >= 70 ? 35 : 12;
    return 15;                                                                                // Torment
  }
  if (esp.protege) return u.vol?.protSeguidas > 0 ? IMPOSSIVEL : alvo.vol?.carregando ? 55 : 5;   // esperar o golpe de 2 turnos passar; nunca duas seguidas
  if (esp.aguentaTurno) return frac(u) <= 0.35 ? 25 : IMPOSSIVEL;
  if (esp.foco) return u.vol?.foco ? IMPOSSIVEL : frac(u) > 0.6 ? 10 : 2;
  if (esp.semente) return tiposDefensivos(alvo).includes('grass') || alvo.vol?.semente != null ? IMPOSSIVEL : 32 * acerto;
  if (esp.armadilha) return IMPOSSIVEL;                                                     // do lado do jogador ninguém troca de Pokémon: não pega ninguém
  /* A leva de 09/2026 (gravidade, bocejo, raiz, trocas de atributo…). Sem uma linha aqui o golpe vale `IGNORADO`
     e o inimigo o usa de graça em cima de outro já ativo — era o que fazia um Hypno gastar 4 turnos bocejando. */
  if (esp.gravidade) return campo?.gravidade > 0 ? IMPOSSIVEL : noChao(alvo) ? 6 : 30;      // vale quando o alvo FLUTUA
  if (esp.voa) {
    const quem = esp.noAlvo ? alvo : u;
    if (campo?.gravidade > 0 || quem.vol?.voando > 0 || quem.vol?.noSolo) return IMPOSSIVEL;
    if (esp.noAlvo) return 6;                                                               // Telekinesis no inimigo: pouco proveito pra IA
    return alvo.moves?.some(m => m.ppLeft > 0 && m.type === 'ground') ? 28 : 4;              // Magnet Rise só serve contra golpe Terrestre
  }
  if (esp.poeNoChao) return noChao(alvo) ? IGNORADO : 24;
  if (esp.bocejo) return alvo.status || alvo.vol?.bocejo || imuneAoStatusMon(alvo, 'sleep') || ladoAlvo?.salvaguarda > 0 ? IMPOSSIVEL : 42 * acerto;
  if (esp.pesadeloGolpe) return alvo.status === 'sleep' && !alvo.vol?.pesadelo ? 40 : IMPOSSIVEL;
  if (esp.raiz) return u.vol?.raiz ? IMPOSSIVEL : frac(u) < 0.7 ? 18 : 6;
  if (esp.anel) return u.vol?.anel ? IMPOSSIVEL : frac(u) < 0.8 ? 20 : 8;
  if (esp.desejo) return u.vol?.desejo ? IMPOSSIVEL : frac(u) < 0.6 ? 34 : IMPOSSIVEL;
  if (esp.cancaoFinal) return u.vol?.cancaoFinal ? IMPOSSIVEL : frac(u) < 0.3 ? 40 : 8;      // caindo: leva o outro junto
  if (esp.tambor) return u.hp > u.stats.hp / 2 && (u.vol?.stages?.attack || 0) < 6 && frac(u) > 0.8 ? 55 : IMPOSSIVEL;
  if (esp.divideHp) return alvo.hp > u.hp * 1.5 ? 36 : IMPOSSIVEL;                           // só vale se o alvo tem MUITO mais HP
  if (esp.limpaEstagios) return estagiosPositivos(alvo) > estagiosPositivos(u) ? 30 : IMPOSSIVEL;
  if (esp.copiaEstagios) return estagiosPositivos(alvo) >= 2 ? 32 : IMPOSSIVEL;
  if (esp.inverteEstagios) return estagiosPositivos(alvo) >= 2 ? 34 : IMPOSSIVEL;
  if (esp.trocaEstagios || esp.trocaProprios || esp.trocaStat || esp.mediaStat) return 8;    // situacional demais pra IA julgar: usa pouco
  /* 🪆🎭🧠 A leva de cópia, substituto e habilidade. O cuidado aqui é o de sempre: a nota diz **quando o golpe
     não tem o que fazer** (`IMPOSSIVEL`), senão a IA gasta o turno pondo um segundo substituto ou copiando o
     nada. Nenhum deles vale mais que um bom golpe de dano — são jogadas de preparo. */
  if (esp.substituto) return u.vol?.substituto > 0 || u.hp <= u.stats.hp * esp.substituto ? IMPOSSIVEL : frac(u) > 0.8 ? 38 : 6;
  if (esp.transforma) return u.vol?.transformado || alvo.vol?.transformado ? IMPOSSIVEL : 26;
  if (esp.repete) return alvo.vol?.ultimo ? 10 : IMPOSSIVEL;                                 // Instruct faz o INIMIGO repetir: pra IA, pouco
  if (esp.anulaHabilidade) return alvo.vol?.semHabilidade ? IMPOSSIVEL : Object.keys(ht).length ? 22 : 3;
  if (esp.trocaHabilidade || esp.copiaHabilidade || esp.poeHabilidade) {
    // só vale se houver habilidade de verdade em jogo: trocar "nada" por "nada" é turno jogado fora
    const minha = Object.keys(hu).length, dele = Object.keys(ht).length;
    if (esp.poeHabilidade) return dele ? 20 : 2;
    if (esp.copiaHabilidade === 'proAlvo') return minha && !dele ? 14 : 2;                    // Entrainment: dar a sua pra ele
    return dele > minha ? 24 : 3;                                                            // Role Play / Skill Swap / Doodle
  }
  /* A cauda longa de 13/10/2026. O padrão continua o mesmo: a linha existe pra dizer quando o golpe NÃO tem o que
     fazer — a IA gastando turno em cima de um efeito já ativo é pior que ela nunca o usar. */
  if (esp.contra) return u.vol?.ultimoDano && (!esp.contra.classe || u.vol.ultimoDano.classe === esp.contra.classe) ? 50 : IMPOSSIVEL;
  if (esp.bide) return u.vol?.bide ? IGNORADO : frac(u) > 0.6 ? 12 : IMPOSSIVEL;
  if (esp.semImunidade) return esp.semImunidade.some(d => tiposDefensivos(alvo).includes(d)) && !alvo.vol?.semImunidade ? 26 : IMPOSSIVEL;
  if (esp.sala) return salaAtiva(campo, esp.sala) ? IMPOSSIVEL
    : esp.sala === 'salaInvertida' ? (effStat(u, 'speed') < effStat(alvo, 'speed') ? 36 : 2)   // só serve a quem é lento
    : esp.sala === 'salaMagica' ? (alvo.item ? 20 : 2) : 14;
  if (esp.sport) return campo?.sports?.includes(esp.sport) ? IMPOSSIVEL : alvo.moves?.some(m => m.ppLeft > 0 && m.type === esp.sport) ? 22 : 3;
  if (esp.ionizado || esp.travaFuga) return campo?.[esp.ionizado ? 'ionizado' : 'travaFuga'] ? IMPOSSIVEL : 8;
  if (esp.trocaLados) return Object.values(ladoAlvo || {}).some(v => v) || Object.values(ladoU || {}).some(v => v) ? 18 : IMPOSSIVEL;
  if (esp.desejoDeCura) return (c.aliados || 0) ? (frac(u) < 0.25 ? 30 : IMPOSSIVEL) : IMPOSSIVEL;   // só valendo pouco de HP
  if (esp.reviver) return (c.aliados || 0) ? 30 : IMPOSSIVEL;
  if (esp.reordena || esp.trocaLugar) return (c.aliados || 0) || esp.reordena ? 8 : IMPOSSIVEL;
  if (esp.maldicao) return tiposDefensivos(u).includes('ghost') ? (alvo.vol?.maldicao || frac(u) < 0.6 ? IMPOSSIVEL : 34) : 18;
  if (esp.laco || esp.rancor) return frac(u) < 0.3 ? 32 : 2;                                  // só faz sentido caindo
  if (esp.tiraPP) return alvo.vol?.ultimo ? 10 : IMPOSSIVEL;
  if (esp.selaGolpes) return (u.moves || []).some(x => alvo.moves?.some(y => y.name === x.name)) ? 24 : IMPOSSIVEL;
  if (esp.semCura) return alvo.vol?.semCura > 0 ? IMPOSSIVEL : 16;
  if (esp.semItem) return alvo.vol?.semItem > 0 || !alvo.item ? IMPOSSIVEL : 20;
  if (esp.calaPorTurnos) return alvo.vol?.calado > 0 ? IMPOSSIVEL : alvo.moves?.some(m => m.ppLeft > 0 && temFlag(m, 'sound')) ? 24 : 2;
  if (esp.manto || esp.furtar) return 6;                                                      // depende do que o outro fizer
  if (esp.passaStatus) return u.status && !alvo.status ? 36 : IMPOSSIVEL;
  if (esp.tipoDoTerreno || esp.tipoDoMeuGolpe || esp.tipoQueResiste || esp.tipoDoAlvo) {
    if (u.tera) return IMPOSSIVEL;
    if (esp.tipoQueResiste) return u.vol?.ultimoDano?.tipo ? 18 : IMPOSSIVEL;
    return 10;
  }
  if (esp.miraCerta) return u.vol?.miraCerta ? IMPOSSIVEL : acerto < 0.7 ? 24 : 3;            // vale contra golpe que erra
  if (esp.critoCerto) return u.vol?.critoCerto ? IMPOSSIVEL : 18;
  if (esp.holofote) return (c.aliados || 0) ? 12 : IMPOSSIVEL;
  if (esp.trancar) return alvo.vol?.octolock ? IMPOSSIVEL : 28;
  if (esp.poExplosivo) return alvo.moves?.some(m => m.ppLeft > 0 && m.type === 'fire') ? 26 : IMPOSSIVEL;
  if (esp.eletrifica) return alvo.vol?.eletrificado ? IMPOSSIVEL : 6;
  if (esp.estocar) return (u.vol?.estoque || 0) >= 3 ? IMPOSSIVEL : 20;
  if (esp.engolir) return (u.vol?.estoque || 0) && frac(u) < 0.6 ? 34 : IMPOSSIVEL;
  if (esp.trocaItem || esp.daItem) {
    if (ht.protegeItem) return IMPOSSIVEL;
    if (esp.daItem) return u.item && !alvo.item ? 10 : IMPOSSIVEL;
    return u.item || alvo.item ? 20 : IMPOSSIVEL;
  }
  if (esp.reciclar) return !u.item && u.vol?.itemGasto ? 24 : IMPOSSIVEL;
  if (esp.horaDoCha) return alvo.item?.endsWith('-berry') ? 6 : IMPOSSIVEL;
  if (esp.copia) {
    if (esp.soNoSono) return u.status === 'sleep' ? 40 : IMPOSSIVEL;                          // Sleep Talk só dormindo
    if (esp.copia === 'ultimoDoAlvo') return podeCopiar(alvo.vol?.ultimo) ? (esp.guardaNoSlot ? 16 : 30) : IMPOSSIVEL;
    if (esp.copia === 'ultimoDaLuta') return podeCopiar(campo?.ultimo) ? 28 : IMPOSSIVEL;
    if (esp.copia === 'escolhidoDoAlvo') return alvo.vol?.golpeEscolhido?.cls === 'status' ? IMPOSSIVEL : 34;
    if (esp.copia === 'dosAliados') return (c.aliados || 0) ? 20 : IMPOSSIVEL;
    return 22;                                                                               // Metronome, Nature Power: sempre têm algo
  }
  if (esp.autoDesmaio) return -60;
  if (esp.clima) {
    if (clima === esp.clima) return IMPOSSIVEL;
    return Math.max(5, 20 + (hu.multStatClima?.[esp.clima] ? 25 : 0) + (hu.curaClima?.[esp.clima] ? 20 : 0)
      - (ht.multStatClima?.[esp.clima] ? 25 : 0) - (ht.curaClima?.[esp.clima] ? 20 : 0));
  }
  if (esp.terreno) return terreno === esp.terreno ? IMPOSSIVEL : 14;
  if (esp.lado) {
    if (ladoU?.[esp.lado] > 0) return IMPOSSIVEL;                                            // já está de pé
    if (esp.soNoGelo && !['granizo', 'neve'].includes(clima)) return IMPOSSIVEL;
    const alvoFisico = (alvo.data.base?.attack ?? 0) >= (alvo.data.base?.['special-attack'] ?? 0);
    const v = { reflect: alvoFisico ? 34 : 14, luz: alvoFisico ? 14 : 34, veu: 30, salvaguarda: 12, neblina: 8,
      vento: effStat(u, 'speed') <= effStat(alvo, 'speed') ? 30 : 15 }[esp.lado] ?? 12;
    return frac(u) > 0.3 ? v : v * 0.4;                                                      // não monta tela pra quem está caindo
  }
  if (g.stats?.length) {
    // apoio (Decorate) e golpe de companheiro: o buff fica no PRÓPRIO lado, então vale como se fosse em quem usa
    const eu = SELF_TARGETS.has(g.target) || golpeDeApoio(g), estagios = (eu ? u : alvo).vol?.stages || {};
    let v = 0;
    for (const { stat, change } of g.stats) {
      const atual = estagios[stat] || 0, peso = VALOR_ESTAGIO[stat] ?? 6;
      if (eu) {
        if (change < 0) { v -= -change * peso * 0.5; continue; }                             // custo do próprio golpe (Curse, Shell Smash)
        const espaco = Math.min(change, TETO_BUFF_IA - atual);
        if (espaco <= 0) continue;
        let p = peso;
        if (stat === 'attack') p *= usaFisico ? 1 : 0.15;                                    // Ataque só serve a quem bate com golpe físico
        else if (stat === 'special-attack') p *= usaEspecial ? 1 : 0.15;
        else if (stat === 'speed') p *= effStat(u, 'speed') < effStat(alvo, 'speed') ? 1.5 : 0.5;
        v += espaco * p;
      } else {
        if (change > 0) continue;                                                            // golpe que SOBE o atributo do inimigo? não
        if (ht.semQueda === 'todas' || ht.semQueda?.includes?.(stat) || ladoAlvo?.neblina > 0) continue;
        const espaco = Math.min(-change, 2 + Math.min(0, atual));
        if (espaco > 0) v += espaco * peso * 0.7;
      }
    }
    if (eu) v *= frac(u) >= 0.7 ? 1 : frac(u) >= 0.5 ? 0.5 : 0.1;                            // setup só com folga de HP
    return v * acerto;
  }
  return IGNORADO;
}

export function escolhaIA(moves, tiposAtacante, tiposAlvo, esperteza = ESPERTEZA.selvagem, sorte = Math.random, contexto = null) {
  const comPP = moves.filter(m => m.ppLeft > 0);
  if (!comPP.length) return null;
  const nivel = contexto?.nivel || nivelDaIA(esperteza);
  if (contexto && nivel !== 'simples') {
    const notas = comPP.map(m => ({ m, n: notaDoGolpe(m, { ...contexto, nivel }) }));
    if (sorte() < esperteza) {                                       // pensa: a maior nota (empate = sorteio entre os empatados)
      const topo = Math.max(...notas.map(x => x.n));
      const top = notas.filter(x => x.n >= topo - 1e-9);
      return top[Math.floor(sorte() * top.length)].m;
    }
    const razoaveis = notas.filter(x => x.n > IMPOSSIVEL / 2);       // distraído: sorteia, mas não algo absurdo (imune, tela repetida…)
    const pool = razoaveis.length ? razoaveis : notas;
    return pool[Math.floor(sorte() * pool.length)].m;
  }
  if (sorte() < esperteza) return melhorGolpe(comPP, tiposAtacante, tiposAlvo) || comPP[0];
  return comPP[Math.floor(sorte() * comPP.length)];
}

/* ---- sair de campo sem desmaiar ----
   Nos jogos várias coisas dependem de TROCAR de Pokémon (Roar, Regenerator, Wimp Out…). Aqui você é o Pokémon e nunca
   troca, então cada uma foi ligada ao evento equivalente que já existe: o fim da luta vencida, a fuga, o próximo
   Pokémon do treinador. As contas ficam aqui (puras); quem tira o Pokémon de campo é batalha.forcarSaida. */
// Quem o treinador manda em seguida. `aleatorio` = arrastado à força (Roar…), senão o primeiro vivo da fila
// (desistência dele mesmo). -1 = ninguém sobrou. O atual nunca é candidato; quem já caiu (hp 0) também não.
export function proximoDoTreinador(equipe, atual, aleatorio = false, sorte = Math.random) {
  const vivos = equipe.map((m, i) => i).filter(i => i !== atual && equipe[i].hp > 0);
  if (!vivos.length) return -1;
  return aleatorio ? vivos[Math.floor(sorte() * vivos.length)] : vivos[0];
}

/* ---- O treinador trocando de Pokémon por ESCOLHA (pedido do usuário, 06/10/2026) ----
   "Os treinadores vão poder trocar de Pokémon a qualquer momento, quando for benéfico pra eles — isso dá uma
   noção de treinador mesmo fazendo isso." Até aqui a troca do lado de lá só acontecia EMPURRADA (Roar, Cartão
   Vermelho) ou quando um caía; agora ele recua sozinho de um confronto ruim, como qualquer jogador humano faria.

   `notaDeConfronto` é a conta: o que o Pokémon DEVOLVE menos o que ele TOMA, em multiplicadores de tipo. Lê os
   golpes de verdade dos dois lados (não os tipos do Pokémon) porque é o golpe que machuca — um Gyarados sem
   golpe de Água não ameaça um Pokémon de Fogo. Positivo = confronto favorável.

   O treinador "assistiu você lutar": ele enxerga os seus golpes. É a mesma licença que `escolhaIA` já toma, e sem
   ela a troca seria às cegas e pareceria aleatória — que é justamente o oposto de "noção de treinador".

   TETO DE 3 TROCAS POR LUTA (decisão do usuário, sem limite por Pokémon): sem teto, um treinador de 6 Pokémon
   consegue enrolar pra sempre trocando a cada turno que o confronto piora, e a luta deixa de ter ritmo. O teto é
   da luta inteira, então ele pode gastar as três em sequência se valer a pena — a tática é dele. */
export const MAX_TROCAS_TREINADOR = 3;
export const GANHO_PRA_TROCAR = 1.5;     // de quanto o confronto tem de melhorar pra valer gastar o turno
export const HP_PRA_TROCAR = 0.25;       // abaixo disso ele troca por qualquer confronto melhor, nem que seja pouco

export function notaDeConfronto(m, oponente) {
  const dano = x => (x?.moves || []).filter(g => g.cls !== 'status' && g.ppLeft > 0);
  const pior = (atacante, defensor) => {
    const gs = dano(atacante);
    // sem golpe de dano em PP, o melhor que ele faz é Struggle: eficácia neutra
    return gs.length ? Math.max(...gs.map(g => typeEff(g.type, tiposDefensivos(defensor)))) : 1;
  };
  return pior(m, oponente) - pior(oponente, m);
}

/* Devolve o índice de quem o treinador quer mandar no lugar do atual, ou -1 pra "fica quem está". Pura: quem
   troca de verdade é `batalha.forcarSaida({ para })`. `trocasFeitas` é o contador da luta (B.trocasTreinador). */
export function trocaDoTreinador(equipe, atual, oponente, trocasFeitas = 0, max = MAX_TROCAS_TREINADOR) {
  if (trocasFeitas >= max) return -1;
  const E = equipe?.[atual]; if (!E || E.hp <= 0 || !oponente || oponente.hp <= 0) return -1;
  const minha = notaDeConfronto(E, oponente);
  const apertado = E.hp / Math.max(1, E.stats.hp) < HP_PRA_TROCAR;
  // com o HP no fim, qualquer melhora serve: morrer em campo não guarda nada pra depois
  const precisa = apertado ? 0.0001 : GANHO_PRA_TROCAR;
  let escolhido = -1, melhor = minha + precisa;
  for (let i = 0; i < equipe.length; i++) {
    if (i === atual || equipe[i].hp <= 0) continue;
    const n = notaDeConfronto(equipe[i], oponente);
    if (n >= melhor) { melhor = n; escolhido = i; }
  }
  return escolhido;
}
// O que as habilidades de "saída" fazem quando a luta é vencida (o jogador nunca troca, então a saída é o fim da luta):
// Regenerator recupera parte do HP, Natural Cure tira o status. Devolve o que vai acontecer, sem mexer em nada.
export function efeitosAoVencer(m) {
  const h = hab(m), r = { cura: 0, limpaStatus: false };
  if (!m || m.hp <= 0) return r;
  if (h.curaAoVencer && m.hp < m.stats.hp) r.cura = Math.min(m.stats.hp - m.hp, Math.max(1, Math.floor(m.stats.hp * h.curaAoVencer)));
  if (h.limpaStatusAoVencer && m.status) r.limpaStatus = true;
  return r;
}

/* ⚔ Saga: o golpe que VOCÊ mandou o aliado usar neste turno (`B.planos`), já conferido.
   Devolve null quando o plano não vale mais — e aí quem chama cai na Ordem do aliado. Os três casos de null
   importam: índice que não existe mais (o aliado aprendeu/trocou golpe entre a escolha e o turno), e golpe que
   ficou PROIBIDO depois de escolhido. O terceiro é o que obriga esta função a existir: o inimigo mais rápido
   provoca (Taunt) no mesmo turno em que você planejou um golpe de status, e sem esta conferência o plano
   furaria `golpesPermitidos` — a regra que as 3 telas, a IA e o motor leem. Struggle sempre passa: é o que
   sobra quando nada é permitido. */
export function golpeDoPlano(plano, moves, permitidos, struggle) {
  if (!plano) return null;
  const g = plano.idx === -1 ? struggle : moves?.[plano.idx];
  if (!g) return null;
  return g === struggle || permitidos.includes(g) ? g : null;
}

// O que o aliado faz neste turno, pela ordem dele (ORDENS em dados.js):
//   { golpe }        → usa esse golpe (golpe null = sem PP em nada → Struggle, só no 'livre')
//   { parado: txt }  → não age neste turno (txt vai pro log)
export function golpeDoAliado(ordem, moves, tiposA, tiposAlvo, sorte = Math.random, travado = null) {
  if (ordem === 'parado' || ordem === 'fora') return { parado: 'fica de guarda, sem atacar.' };
  /* Faixa/Óculos/Lenço Escolha: aliado já travado num golpe — nem a IA de ordem escolhe outro (senão a trava se
     desfaria sozinha a cada turno). Sem PP no golpe travado, `golpe: null` vira Struggle (quem chama já trata). */
  if (travado) { const m = moves.find(x => x.name === travado); return { golpe: m?.ppLeft > 0 ? m : null }; }
  const comPP = moves.filter(m => m.ppLeft > 0);
  if (ordem === 'status') {
    const st = comPP.filter(m => m.cls === 'status');
    return st.length ? { golpe: st[Math.floor(sorte() * st.length)] } : { parado: 'não tem golpe de status com PP e espera.' };
  }
  if (ordem === 'fraco') {
    const dano = comPP.filter(m => m.cls !== 'status');
    if (!dano.length) return { parado: 'não tem golpe de dano com PP e espera.' };
    return { golpe: dano.reduce((a, m) => (m.power || 60) < (a.power || 60) ? m : a) };
  }
  return { golpe: melhorGolpe(moves, tiposA, tiposAlvo) };
}

/* ---- ⚔ Saga: ameaça (aggro) ----
   Até aqui o inimigo mirava um alvo ALEATÓRIO entre os do seu lado (`pick(vivos(emCampo()))` em batalha.js), e
   por isso "tanque" era impossível: não havia como atrair dano. A ameaça é o que faz ofício valer algo.

   Duas parcelas, de propósito:
   - `base × HP máximo` — ameaça por EXISTIR. Sem ela um Guardião, que bate pouco, teria sempre menos ameaça que
     o Arcano e nunca seguraria nada: aggro só por dano premia justamente quem não devia ser mirado.
   - `acumulada × peso` — o que você fez na luta (dano causado; cura e feitiço entram quando as perícias chegarem).
   O Curandeiro tem peso 1.5 porque curar chama atenção — é ele o segundo alvo, como em todo RPG de turno.

   `RUIDO` existe pra luta não virar xadrez: 10% das vezes o inimigo mira outro. Sem isso o jogador decora a
   regra e o combate fica resolvido.
   Fora de um modo com a flag `ameaca` nada disso roda — quem decide é batalha.js, e o padrão segue aleatório. */
export const AMEACA = {
  /* `base: 1` = o HP máximo inteiro vira ameaça. Calibrado contra o caso real: com 0.5, um Arcano roubava o
     alvo depois de ~100 de dano, ou seja, dois golpes — o Guardião segurava dois turnos e a mecânica não
     aparecia. Com 1, um Aggron de 200 de HP exige 200 de dano acumulado do Arcano pra perder o alvo: segura a
     luta comum inteira e começa a vazar nas longas (Alfa, chefe), que é onde a Provocação precisa existir. */
  guardiao:   { peso: 2,   base: 1 },
  curandeiro: { peso: 1.5, base: 0.2 },
  arcano:     { peso: 1,   base: 0.1 },
  guerreiro:  { peso: 1,   base: 0.1 },
  encantador: { peso: 1.2, base: 0.1 },
  bardo:      { peso: 1.2, base: 0.1 }
};
export const AMEACA_PADRAO = { peso: 1, base: 0.1 };   // sem ofício (save antigo, espécie sem dado)
export const RUIDO_AMEACA = 0.1;
export const ameacaDe = m => {
  const a = AMEACA[m?.oficio] || AMEACA_PADRAO;
  // `vol.provocou` é a Provocação do Guardião (perícia): multiplica a ameaça por alguns turnos
  return ((m?.vol?.ameaca || 0) * a.peso + a.base * (m?.stats?.hp || 0)) * (m?.vol?.provocou || 1);
};
/* Quem o inimigo ataca. Empate mantém a ordem de entrada (sort estável): o mesmo estado sempre dá o mesmo alvo,
   senão a luta mudaria de rumo entre dois F5. */
export function alvoPorAmeaca(candidatos, sorte = Math.random) {
  if (!candidatos?.length) return null;
  if (candidatos.length === 1) return candidatos[0];
  const ordem = [...candidatos].sort((a, b) => ameacaDe(b) - ameacaDe(a));
  if (sorte() < RUIDO_AMEACA) {
    const outros = ordem.slice(1);
    return outros[Math.floor(sorte() * outros.length)] || ordem[0];
  }
  return ordem[0];
}
/* ⚔ Saga: quantos inimigos aparecem num encontro. Cresce com o avanço da rota (`iRota` = índice 0-based dentro
   do mapa) — nas três primeiras a luta ainda pode ser 1×1, pra jornada nova não começar contra um grupo cheio
   no nível 5; da quarta em diante nunca é sozinho. Alfa e lendários montam o grupo por conta (batalha.js).
   `GRUPO_MAX` é teto da CENA, não de balanceamento: mais de 3 sprites do lado inimigo não cabe no celular. */
export const GRUPO_MAX = 3;
export function tamanhoDoGrupo(iRota, sorte = Math.random) {
  const piso = iRota <= 2 ? 1 : 2, teto = iRota <= 2 ? 2 : GRUPO_MAX;
  return piso + Math.floor(sorte() * (teto - piso + 1));
}

/* ---- 🐺 Matilhas e manadas: grupo selvagem em TODOS os modos (pedido do usuário, 06/10/2026) ----
   "Acho que é uma mecânica que aumenta a dificuldade, não será sempre, mas terá uma chance."
   Na ⚔ Saga o grupo é a regra (flag `grupos`, `tamanhoDoGrupo` acima). Fora dela passa a ser SORTE, e a chance
   cresce com o avanço do mapa: as três primeiras rotas nunca têm manada — uma jornada nova começa no Nv. 5,
   sozinha, e cair num grupo ali é game over sem decisão nenhuma. Da quarta em diante sobe até `CHANCE_GRUPO_MAX`
   na última. Mesma fronteira de `tamanhoDoGrupo`, de propósito: duas curvas diferentes pro mesmo conceito é o
   tipo de coisa que ninguém reconcilia depois. */
export const CHANCE_GRUPO_MAX = 0.35;
export const ROTAS_SEM_GRUPO = 3;          // índice 0-based: as rotas 1, 2 e 3 do mapa
export function chanceDeGrupo(iRota, rotasNoMapa = 10) {
  const i = Math.max(0, iRota);
  if (i < ROTAS_SEM_GRUPO) return 0;
  const ultima = Math.max(ROTAS_SEM_GRUPO, rotasNoMapa - 1);
  if (i >= ultima) return CHANCE_GRUPO_MAX;
  return CHANCE_GRUPO_MAX * (i - ROTAS_SEM_GRUPO + 1) / (ultima - ROTAS_SEM_GRUPO + 1);
}

/* O TETO do lado inimigo, pela decisão do usuário: "o grupo nunca passa de aliados + 1". Seu lado tem 1 + aliados
   em pé, então o inimigo pode ter no máximo um a mais que isso — sem aliado, 2 contra 1; com um aliado, 3.
   Não é gentileza: 3 contra 1 no começo da jornada não é dificuldade, é parede, e o jogador não tem o que
   DECIDIR. Do jeito que ficou, recrutar com petisco virou uma resposta concreta à manada. */
export const tetoDoGrupo = (aliadosEmPe = 0) => Math.min(GRUPO_MAX, Math.max(1, aliadosEmPe + 2));

/* Quantos inimigos neste encontro selvagem. `sempre` = modo com a flag `grupos` (a Saga), onde o grupo não é
   sorteado. Devolve 1 quando a sorte não deu — e 1 é o encontro de sempre, não um caso especial. */
export function tamanhoDoEncontro(iRota, aliadosEmPe = 0, { sempre = false, rotasNoMapa = 10, sorte = Math.random, sorteTamanho = Math.random } = {}) {
  const teto = tetoDoGrupo(aliadosEmPe);
  if (teto <= 1) return 1;
  if (!sempre && !(sorte() < chanceDeGrupo(iRota, rotasNoMapa))) return 1;
  return Math.min(teto, tamanhoDoGrupo(iRota, sorteTamanho));
}

/* Como o jogo CHAMA o grupo que apareceu. O usuário pediu "grupos de Pokémon, como matilhas, manadas e etc", e a
   palavra é metade da mecânica: "um grupo de 3 aparece" é relatório, "um enxame de 3 Weedle aparece" é um
   encontro. Lê o tipo em comum de todos; sem tipo em comum, cai em `bando`.
   Fica em `regras.js` porque é decisão sobre DADO (os tipos dos três), não desenho de tela. */
export const NOME_DO_GRUPO = {
  water: 'cardume', flying: 'revoada', bug: 'enxame', dark: 'alcateia', fighting: 'gangue',
  ghost: 'assombração', dragon: 'ninhada', rock: 'avalanche', ground: 'tropa', steel: 'batalhão',
  grass: 'moita', fire: 'fornalha', electric: 'tempestade', ice: 'nevasca', psychic: 'congregação',
  poison: 'praga', fairy: 'corte', normal: 'matilha'
};
export function nomeDoGrupo(lista = []) {
  if (lista.length < 2) return null;
  const tipos = lista.map(m => tiposDe(m) || []);
  const comuns = tipos[0].filter(t => tipos.every(ts => ts.includes(t)));
  return NOME_DO_GRUPO[comuns[0]] || 'bando';
}

/* ---- 🎒 Treinador: equipe de até 6 e CAMPO de 1 a 3 (pedido do usuário, 06/10/2026) ----
   "Treinadores podem ter 1, 2 ou até 3 Pokémon no campo também, assim aumentando o máximo para 6 nos
   treinadores. Treinadores com 6 Pokémon são raros e só eles podem jogar 3 Pokémon juntos, ou 2 juntos, ou 1
   Pokémon apenas, mas fazendo 6 lutas."

   Duas coisas independentes, e é essa separação que faz a mecânica render:
     EQUIPE  quantos ele tem (1 a 6). Sorteada por faixa de rota — 1 a 3 segue sendo o encontro comum, 4 e 5
             aparecem do meio do mapa pra frente, e 6 é raro e só em rota avançada.
     CAMPO   quantos ele põe ao mesmo tempo (1 a 3), e **só quem tem 6 pode pôr 3**. Um de 6 com campo 1 faz
             seis lutas de um; com campo 3, duas ondas de três. A escolha é dele, e muda a luta inteira.
   A tabela de pesos É o botão de calibragem: mexer num peso aqui muda a cara dos encontros do mapa todo. */
export const EQUIPE_TREINADOR = [
  { ate: 2, pesos: { 1: 60, 2: 40 } },                            // rotas 1–3: no máximo dois
  { ate: 5, pesos: { 1: 28, 2: 34, 3: 26, 4: 12 } },              // meio do mapa: o quarto começa a aparecer
  { ate: 8, pesos: { 2: 26, 3: 34, 4: 25, 5: 12, 6: 3 } },        // fim: o de 6 passa a ser possível
  { ate: 99, pesos: { 3: 28, 4: 30, 5: 27, 6: 15 } }              // rota final e Santuário
];
export function tamanhoDaEquipeDoTreinador(iRota, sorte = Math.random, tabela = EQUIPE_TREINADOR) {
  const faixa = tabela.find(f => Math.max(0, iRota) <= f.ate) || tabela[tabela.length - 1];
  const entradas = Object.entries(faixa.pesos).map(([n, p]) => [Number(n), p]);
  const total = entradas.reduce((s, [, p]) => s + p, 0);
  let x = clamp(sorte(), 0, 0.999999) * total;
  for (const [n, p] of entradas) if ((x -= p) < 0) return n;
  return entradas[entradas.length - 1][0];
}
/* Quantos ele põe em campo. `teto` é o do lado do jogador (`tetoDoGrupo`): um treinador de 6 contra você sozinho
   continua limitado a 2 em campo — o tamanho da EQUIPE dele não é desculpa pra uma parede. */
export function campoDoTreinador(tamanhoEquipe, teto = GRUPO_MAX, sorte = Math.random) {
  const maximo = Math.min(teto, tamanhoEquipe, tamanhoEquipe >= 6 ? 3 : 2);
  if (maximo <= 1) return 1;
  return 1 + Math.floor(clamp(sorte(), 0, 0.999999) * maximo);
}
/* Quem do banco pode entrar: de pé e fora de campo. `emCampo` = índices em `equipe` (o treinador deixou de ter um
   `atual` só, porque agora ele tem até 3 em campo ao mesmo tempo). Devolve índices, na ordem da fila. */
export const reservasDoTreinador = (equipe = [], emCampo = []) =>
  equipe.map((_, i) => i).filter(i => equipe[i]?.hp > 0 && !emCampo.includes(i));

/* ---- 🎒 O treinador EQUIPA os Pokémon dele (pedido do usuário, 06/10/2026) ----
   "Quanto mais alto o nível, melhores os itens são para os Pokémon."

   A curva de poder não foi inventada: é o **preço da loja**. Todo item segurado já tem `price` em `dados.js`, e
   esse número é exatamente "quão forte isso é" — a Fruta Oran custa ₽300, o Orbe da Vida ₽3.000. Então o nível do
   treinador vira um ORÇAMENTO e ele compra o que cabe. Uma tabela de faixas à mão seria uma segunda opinião sobre
   o mesmo balanceamento, e a segunda opinião é a que fica velha quando um item novo entra na loja.
   Efeito prático: Nv. 10 anda com fruta, Nv. 50 já tem Cinto do Perito e Restos, Nv. 80+ alcança Orbe da Vida,
   Faixa de Foco e os de Escolha. Item novo barato entra sozinho no começo; item novo caro, só no fim.

   A CHANCE também cresce, e isso é de propósito separado do orçamento: um treinador de rota 1 com a equipe toda
   equipada seria estranho, e um de nível 90 sem nada seria decepcionante. */
export const CHANCE_ITEM_TREINADOR = { min: 0.25, max: 0.8, nivelCheio: 70 };
export const orcamentoDoTreinador = nivel => 300 + Math.max(0, nivel) * 45;
export function chanceItemDoTreinador(nivel) {
  const { min, max, nivelCheio } = CHANCE_ITEM_TREINADOR;
  return min + (max - min) * clamp(Math.max(0, nivel) / nivelCheio, 0, 1);
}
/* Itens que o treinador NÃO dá pros Pokémon dele, com o motivo. Não é lista de proibição estética: cada um aqui
   atrapalharia o dono ou não faria nada, e item inerte na mão do inimigo é mentira na tela (o chip 🎁 promete
   algo que não acontece). */
export const ITENS_FORA_DO_TREINADOR = new Set([
  'iron-ball',        // −50% de Velocidade: presente pra VOCÊ, não pra ele
  'black-sludge',     // machuca quem não é Venenoso, e ele não escolhe a espécie
  'toxic-orb', 'flame-orb',   // se auto-infligem status; só valem com Guts e cia., que a IA não sabe explorar
  'eviolite'          // só vale em quem ainda evolui, e metade da equipe dele é forma final
]);
/* Devolve o id do item, ou null. `pool` = `[ [id, item] ]` (Object.entries de ITENS_SEGURADOS e companhia): quem
   chama passa a tabela, este módulo não importa `dados.js` inteiro pra isto. */
export const FRACAO_PISO_TREINADOR = 0.35;
export function itemDeTreinador(nivel, pool = [], sorte = Math.random, sorteio = Math.random) {
  if (!(sorte() < chanceItemDoTreinador(nivel))) return null;
  const teto = orcamentoDoTreinador(nivel);
  const serve = ([id, it]) => it?.segurado && it.price > 0 && it.price <= teto
    && !ITENS_FORA_DO_TREINADOR.has(id) && !it.soComMega && !it.soComZ && !it.soComVinculo;
  /* O PISO é o que faz o pedido se cumprir de verdade. Sem ele, as 17 frutas de aperto (₽1.200 cada) ficavam com
     31% dos casos até no Nv. 90 — um treinador de fim de mapa andando com fruta de tipo é o contrário de "quanto
     mais alto o nível, melhores os itens". Com o piso em 35% do orçamento, ele PARA de comprar o que ficou
     barato pra ele: no Nv. 90 a fruta de tipo sai da lista e o chão passa a ser Faixa Muscular.
     Se o piso não deixar nada (nível muito baixo), ele é ignorado — melhor um item barato que nenhum. */
  const piso = teto * FRACAO_PISO_TREINADOR;
  const todos = pool.filter(serve);
  const cabem = todos.filter(([, it]) => it.price >= piso);
  if (!cabem.length) return todos.length ? todos[Math.floor(clamp(sorteio(), 0, 0.999999) * todos.length)][0] : null;
  /* Peso pelo PREÇO: dentro do que ele pode pagar, o item melhor é o mais provável. Sem isso, as 17 frutas de
     aperto (₽1.200 cada) afogariam o Orbe da Vida por pura quantidade, e um treinador de Nv. 90 andaria com
     fruta — exatamente o contrário do que foi pedido. */
  const total = cabem.reduce((s, [, it]) => s + it.price, 0);
  let x = clamp(sorteio(), 0, 0.999999) * total;
  for (const [id, it] of cabem) if ((x -= it.price) < 0) return id;
  return cabem[cabem.length - 1][0];
}

// um golpe causou dano: quem bateu ganha ameaça. Chamado pelo motor único (golpe.js), nunca por uma tela.
export const somarAmeaca = (m, n) => { if (m?.vol && n > 0) m.vol.ameaca = (m.vol.ameaca || 0) + n; };

/* ---- ⚔ Saga: BRECHA e RUÍNA (o "break" de RPG japonês) ----

   Referências de verdade, pesquisadas pra desenhar isto (anotadas em `docs/features.md`):
   - **Octopath Traveler**, Break & Shield Points: cada inimigo tem N escudos e uma lista de fraquezas; acertar a
     fraqueza tira 1 escudo, zerar DERRUBA o inimigo — ele perde a ação, fica fraco a tudo e toma dano em dobro.
     É daqui que vem a forma inteira: Guarda = Shield Points, Brecha = o escudo que cai, Ruína = o Break.
   - **Final Fantasy VII Remake**, stagger: a barra de pressão fica VISÍVEL na placa do inimigo e o momento de
     "staggered" é a janela em que a festa despeja tudo. É daqui que vem a Guarda aparecer na CENA, embaixo do HP:
     um break invisível não é mecânica, é sorte.
   - **Persona**, crítico que concede "1 More": crítico também abre Brecha aqui. Sem isso o Guerreiro (que bate
     forte mas não escolhe tipo) não participaria da abertura, e a Brecha seria só do Arcano.

   Por que ESTA mecânica e não Brave/Default (Bravely Default) ou o CTB de FFX: as duas mexem na ECONOMIA DO
   TURNO (adiantar turnos, fila por contador de agilidade), e o turno aqui é o do Pokémon — prioridade, Quick
   Claw, velocidade efetiva com clima, lido pelos DOIS motores (`ordenarAcoes`). Trocar isso quebraria todos os
   modos por uma mecânica de um só. Brecha/Ruína mexe na RESOLUÇÃO do golpe, onde já havia gancho (`eficacia`),
   e é exatamente o que faltava pra a comitiva ser montada por TIPO em vez de por barra de dano.

   O que fica de fora de propósito: fraqueza por ARMA (Octopath tem espada/lança/arco…) — aqui o tipo do golpe já
   é a fraqueza, e é a tabela que o jogo inteiro usa; e o Boost (gastar pontos pra reforçar o golpe), porque
   "guardar recurso pra soltar junto" é o papel que a RECARGA das perícias já faz no modo.

   Só quem tem `vol.guardaMax` tem Guarda — e isso é posto por `batalha.js` nos inimigos de um modo com a flag
   `jrpg`. Fora dali tudo aqui é no-op: nenhum outro modo muda de comportamento. */
export const GUARDA = { selvagem: 3, alfa: 6, chefe: 10 };
/* `RUINA_TURNOS` = 2 por uma razão de leitura: a Ruína é marcada NO MEIO de uma rodada (o golpe que fecha a
   Guarda), então o primeiro turno que ela consome é o resto da rodada em que caiu — quem já agiu não perde nada.
   Com 1, derrubar a Guarda com o último a agir não custava NADA ao inimigo. Com 2 ele perde o resto da rodada e
   a rodada seguinte inteira, que é o "perde o próximo turno" do desenho. Afinar é mexer aqui. */
export const RUINA_TURNOS = 2;
/* ✨ Dons (dados-saga.DONS): habilidades que o MUNDO da Saga dá por escolha, guardadas no Pokémon (`m.dons`).
   O efeito é DADO, não código: cada dom pode trazer `dano` (o que você causa), `ruina` (o que você causa em
   inimigo em Ruína) e `defesa` (o que você recebe), e `multSaga` multiplica tudo — no mesmo ponto que o motor
   já lê uma vez no dano. Os limites de cada número são de `saga-validar.EFEITOS_DE_DOM`. */
export const MULT_RUINA = 1.5;      // em Ruína, tudo dói 50% mais
export const MULT_MURALHA = 0.5;    // 🧱 Muralha (perícia do Guardião): a comitiva toma metade
export const MULT_MARCA = 1.25;     // 🕯 Marca (perícia do Encantador): o marcado toma 25% mais
export const BRECHA_SUPER = 1;      // golpe super efetivo abre uma Brecha inteira
export const BRECHA_CRITICO = 1;    // crítico também (Persona: o crítico é tão bom quanto a fraqueza)
export const BRECHA_STATUS = 0.5;   // status e Marca abrem meia
export const BRECHA_SELO = 2;       // 🔮 Selo Arcano: +2 no golpe seguinte
export const MARCA_TURNOS = 2;
export const BRADO_TURNOS = 2;
export const BRADO_MULT = 3;        // 🛡 Brado de Ferro: ameaça ×3 (lido por `ameacaDe` via `vol.provocou`)

// quantos escudos o inimigo traz. Alfa e lendário aguentam o dobro; o chefe da semana, muito mais.
export const guardaInicial = ({ chefe = false, alfa = false } = {}) => chefe ? GUARDA.chefe : alfa ? GUARDA.alfa : GUARDA.selvagem;
export const temGuarda = m => (m?.vol?.guardaMax || 0) > 0;
export const emRuina = m => (m?.vol?.ruina || 0) > 0;
/* Tira `n` da Guarda. Devolve null quando não há o que fazer (sem Guarda, já em Ruína, `n` inútil) — quem chama
   usa isso pra decidir se narra. MUTA o `vol`, como `somarAmeaca`: é estado de luta, nunca do save.
   Ruir também APAGA os degraus positivos do inimigo: o Swords Dance que ele acumulou vai pro chão junto com a
   guarda, que é a outra metade do que torna a Brecha uma jogada e não só mais dano. */
export function abrirBrecha(m, n) {
  if (!temGuarda(m) || emRuina(m) || !(n > 0)) return null;
  const antes = m.vol.guarda ?? m.vol.guardaMax;
  m.vol.guarda = Math.max(0, antes - n);
  if (m.vol.guarda > 0) return { antes, agora: m.vol.guarda, max: m.vol.guardaMax, ruiu: false };
  m.vol.ruina = RUINA_TURNOS;
  for (const s of Object.keys(m.vol.stages || {})) if (m.vol.stages[s] > 0) m.vol.stages[s] = 0;
  return { antes, agora: 0, max: m.vol.guardaMax, ruiu: true };
}
/* O multiplicador de dano da Saga, num ponto só (lido pelo motor em `golpe.executar`): Ruína, Muralha e Marca.
   Fora da Saga nenhuma dessas marcas existe no `vol`, então devolve 1 e o dano é exatamente o de antes. */
const multDosDons = (m, campo) => (m?.dons || []).reduce((a, d) => a * (DONS[d]?.[campo] ?? 1), 1);
export const multSaga = (u, t) => (emRuina(t) ? MULT_RUINA * multDosDons(u, 'ruina') : 1)
  * (t?.vol?.muralha ? MULT_MURALHA : 1)
  * (t?.vol?.marca > 0 ? MULT_MARCA : 1)
  * multDosDons(u, 'dano')
  * multDosDons(t, 'defesa');
/* Fim de rodada da Saga: Ruína, Marca e Brado perdem um turno. Ruína que acaba DEVOLVE a Guarda cheia (como em
   Octopath: quebrou, aproveitou, e o escudo volta) — senão a segunda Brecha seria de graça pra sempre. */
export function passarSaga(m) {
  const v = m?.vol; if (!v) return;
  if (v.ruina > 0 && --v.ruina <= 0) { delete v.ruina; if (v.guardaMax) v.guarda = v.guardaMax; }
  if (v.marca > 0 && --v.marca <= 0) delete v.marca;
  if (v.provocouTurnos > 0 && --v.provocouTurnos <= 0) { delete v.provocouTurnos; delete v.provocou; }
}

/* ---- amizade (Etapa 3.2) ---- */
export const MAX_ALIADOS = 2;
/* Quantos aliados andam com você NESTE modo. O teto 2 é decisão fechada de balanceamento pros modos normais
   (o Esconderijo já resolve "guardar mais parceiros"); o ⚔ Saga sobe pra 3, porque a comitiva de quatro ofícios
   é a base do modo. Recebe a CHAVE da dificuldade (`dificuldadeDe(S)`) pra seguir pura — a regra de
   "save antigo = easy" mora em `estado.dificuldadeDe` e não deve existir em dois lugares. */
export const maxAliados = dif => DIFICULDADES[dif]?.aliadosEmCampo || MAX_ALIADOS;
// o mesmo teto, perguntado pelo save (o fallback `easy` é o de `estado.dificuldadeDe`: save antigo sem o campo)
export const tetoDaEquipe = S => maxAliados(S?.dificuldade || 'easy');
export const AMIZADE_MAX = 100;
// Item que o tipo gosta: +20–35 por oferta (3–5 ofertas pra encher). Item errado: 0–5 (quase nada).
export const DIVISOR_AMIZADE_LENDARIO = 4; // lendário/mítico: a amizade sobe ~4× mais devagar (ver ganhoAmizade)
export function ganhoAmizade(tiposDoItem, tiposDoAlvo, sorte = Math.random(), lendario = false) {
  const gosta = tiposDoAlvo.some(t => tiposDoItem.includes(t));
  const base = gosta ? 20 + Math.floor(sorte * 16) : Math.floor(sorte * 6);
  // Lendário e mítico aceitam petisco (é o que torna possível desbloquear eles pela amizade), mas confiam bem
  // devagar: onde um Pokémon comum vira aliado em 3–5 ofertas, eles levam mais de uma dezena. Nunca zera um ganho
  // que existia — ficar em 0 pra sempre pareceria que o petisco não funciona neles.
  return lendario && base > 0 ? Math.max(1, Math.floor(base / DIVISOR_AMIZADE_LENDARIO)) : base;
}
// só confia em quem não é muito mais fraco que ele — impede levar um Nv. 55 da Caverna Cerúlea sendo Nv. 5
export const podeFazerAmizade = (nivelAlvo, nivelJogador) => nivelAlvo <= nivelJogador + 5;

/* ---- 🍖 Oferecer petisco com UM toque (pedido do usuário, 14/10/2026) ----
   "um botão que já joga os petiscos que o pokémon gosta que tem na bolsa". Até aqui, fazer amizade era abrir a
   Mochila, achar a divisão certa e tocar no petisco — uma vez por oferta, três a cinco ofertas por Pokémon. O botão
   escolhe o petisco sozinho e repete a oferta enquanto for seguro.

   Duas escolhas de desenho, e as duas são de segurança, não de conforto:
   · **Só oferece o que ele GOSTA.** Petisco que ele não liga rende 0–5 de amizade: gastar o toque (e o turno, e o
     petisco) com isso é o erro que o botão existe pra evitar. Sem petisco que agrade, o botão diz por quê.
   · **Não oferece a quem é forte demais.** `oferecer` (amizade.js) GASTA o petisco e o turno e só então avisa que o
     alvo não confia em você — pelo botão isso seria um desperdício de um toque só, então o plano recusa antes.
   Cada oferta é um TURNO inteiro (o inimigo ataca, os aliados agem), então a repetição automática tem teto
   (`OFERTAS_POR_TOQUE`) e para quando o seu HP cai (`PISO_HP_OFERTA`) ou alguém do seu lado cai. */
/* 5 = 100 de amizade ÷ 20 (o MENOR ganho de um petisco que ele gosta, `ganhoAmizade`): com petisco que agrada, cinco
   ofertas enchem a barra de qualquer não-lendário. Lendário confia ~4× mais devagar e leva mais de um toque. */
export const OFERTAS_POR_TOQUE = 5;
export const PISO_HP_OFERTA = 0.5;   // acima disso a repetição segue; no meio da barra de HP ou abaixo, ela para e devolve a decisão
/* O que o botão faria AGORA. `bag` = { chave: quantidade }; `itens` = o catálogo (ITEMS, com `afinidade`);
   `tipos` = os tipos do alvo. Devolve { ok: true, id, estoque, total } ou { ok: false, motivo } com
   'sem-petisco' (a mochila não tem nenhum: o botão nem aparece) · 'forte-demais' (+ `ate`, o nível máximo que
   aceita) · 'nao-gosta' (tem petisco, mas nenhum do tipo dele). Entre vários que ele gosta vai o de MAIOR estoque
   (ganha o catálogo no empate): todos rendem o mesmo, e assim nenhum petisco raro acaba antes dos outros. */
export function planoDoPetisco({ bag = {}, itens = {}, tipos = [], nivelAlvo = 0, nivelJogador = 0 } = {}) {
  const ordem = Object.keys(itens);
  const todos = Object.entries(bag).filter(([k, n]) => n > 0 && itens[k]?.afinidade);
  if (!todos.length) return { ok: false, motivo: 'sem-petisco' };
  if (!podeFazerAmizade(nivelAlvo, nivelJogador)) return { ok: false, motivo: 'forte-demais', ate: nivelJogador + 5 };
  const gosta = todos.filter(([k]) => tipos.some(t => itens[k].afinidade.includes(t)));
  if (!gosta.length) return { ok: false, motivo: 'nao-gosta', tem: todos.length };
  gosta.sort((a, b) => b[1] - a[1] || ordem.indexOf(a[0]) - ordem.indexOf(b[0]));
  return { ok: true, id: gosta[0][0], estoque: gosta[0][1], total: gosta.reduce((s, [, n]) => s + n, 0) };
}
/* Depois de cada oferta: a repetição segue? `feitas` já conta a que acabou de sair. */
export const seguirOferecendo = ({ feitas = 0, hpFracao = 1, aliadoCaiu = false } = {}) =>
  feitas < OFERTAS_POR_TOQUE && hpFracao > PISO_HP_OFERTA && !aliadoCaiu;

// Centro com equipe: cada Pokémon que precisa de cura paga o preço do próprio nível
export const custoCentroEquipe = mons => mons.filter(precisaCurar).reduce((a, m) => a + custoCentro(m.level), 0);
// Desconto por vitória (modo Médio): cada vitória desde a última ida ao Centro tira `pct` do preço (10 × 10% = grátis)
export const custoComDesconto = (custo, vitorias, pct) => Math.round(custo * Math.max(0, 1 - vitorias * pct));

// O item faria efeito neste Pokémon agora? (desmaiado nunca — Potion não revive). `podeSubir` = tem curva de XP
// (o jogador sempre; o aliado se tiver `growth`) — sem ela o Rare Candy não tem como subir o nível.
export function itemTemEfeito(it, M, podeSubir = true) {
  if (it.revive) return M.hp <= 0; // o único que serve em desmaiado — e só nele
  if (M.hp <= 0) return false;
  if ((it.heal || it.healPct) && M.hp < M.stats.hp) return true;
  if (it.heal || (it.healPct && !it.cure)) return false;
  if (it.cure) return !!M.status && (it.cure === 'all' || it.cure.includes(M.status));
  if (it.ether) return M.moves.some(m => m.ppLeft < m.pp);
  if (it.stage) return true;
  if (it.treino === 'evs') return temEvs(M);
  if (it.treino === 'iv') return ivsParaMaximizar(M).length > 0;
  if (it.treino === 'habilidade') return habilidadesParaTrocar(M).length > 0;
  if (it.candy) return podeSubir && M.level < 100;
  return false;
}

/* ---- mundo e progressão (Etapa 2) ---- */

/* Rota liberada? Quase todas abrem por nível. O SANTUÁRIO (`posVitoria`, a 11ª de cada mapa) é a exceção: só abre
   depois que você vence os lendários daquela Gen (S.gensVencidas), porque é lá que vivem os iniciais e os lendários
   — é a garantia de que dá pra encontrar TODA a Gen, mas só depois de fechar o mapa.
   Sem o save (`S`), ela fica trancada: é o padrão seguro pra quem chama sem saber da regra (ex.: criação). */
/* Rota ESGOTADA (só no Roguelike): passou do DOBRO do teto de nível da rota, ela para de dar caçada. É anti-grind —
   farmar numa rota de nível 6 sendo nível 60 rendia XP fácil e sem risco. Você continua entrando na rota e vendo a
   Pokédex dela (quem vive ali, as taxas, o Alfa); o que some é o encontro selvagem. Fora do Roguelike, nada muda. */
/* `MARGEM_ESGOTADA` conserta um problema que só existia nas rotas do COMEÇO: dobrar um teto pequeno dá uma folga
   pequena. A Rota 1 tem teto 6, então o limite era 12 — e como se começa no nível 5, a rota se esgotava antes de
   dar pra completar as missões dela ("derrote 10 Pidgey", "derrote 10 Rattata"…), travando o progresso da run.
   Numa rota de teto 50 a folga era de 50 níveis; na de teto 6, de 6. O piso iguala isso: a folga nunca é menor
   que 15 níveis. Só muda rotas com teto abaixo de 15 — do meio do mapa pra frente, o dobro continua mandando. */
export const FATOR_ESGOTADA = 2;
export const MARGEM_ESGOTADA = 15;
export const limiteDaRota = z => Math.max((z?.max || 0) * FATOR_ESGOTADA, (z?.max || 0) + MARGEM_ESGOTADA);
export const rotaEsgotada = (z, nivel, dificuldade) =>
  dificuldade === 'roguelike' && !!z && nivel > limiteDaRota(z);

export const zonaLiberada = (z, nivel, S = null) => z?.posVitoria
  ? !!(S?.gensVencidas || []).includes(z.gen)
  : nivel >= (z?.libera || 1);

// Alfa: HP ×2 e demais stats ×1,3 (arredondado pra baixo). Não muta.
export const MULT_CHEFE = { hp: 2, outros: 1.3 };
export const statsDeChefe = stats => Object.fromEntries(Object.entries(stats).map(([s, v]) => [s, Math.floor(v * (s === 'hp' ? MULT_CHEFE.hp : MULT_CHEFE.outros))]));
export const premioChefe = nivel => nivel * 60;

// Progresso de uma condição de missão (formato em MISSOES, dados.js) sobre o save. Nunca passa do alvo.
export function progressoCondicao(cond, S) {
  const r = S.registro || {}, soma = o => Object.values(o || {}).reduce((a, n) => a + n, 0);
  const [atual, alvo] =
    'derrotar' in cond ? [r.derrotados?.[cond.derrotar] || 0, cond.qtd || 1]
    /* `alvos: [[especie, qtd]…]` = missão de espécie do editor de rotas (dados-rotas.js). Mais de uma espécie SOMA
       (8 Plusle + 8 Minun = 16/16), e cada uma tem o PRÓPRIO teto: 20 Plusle e 0 Minun dá 8/16, não 16/16 — senão a
       missão de duas espécies viraria a de uma só com o dobro da conta. `qualquer` = basta UMA chegar no alvo dela,
       e é o que o `libera` usa: ver um dos dois já revela a missão (exigir os dois deixaria a missão escondida
       por puro azar na ordem do sorteio da rota). */
    : 'alvos' in cond ? (cond.qualquer
      ? [cond.alvos.some(([n, q]) => (r.derrotados?.[n] || 0) >= (q || 1)) ? 1 : 0, 1]
      : [cond.alvos.reduce((s, [n, q]) => s + Math.min(r.derrotados?.[n] || 0, q || 1), 0), cond.alvos.reduce((s, [, q]) => s + (q || 1), 0)])
    : 'vitorias' in cond ? [S.wins || 0, cond.vitorias]
    : 'amigos' in cond ? [soma(r.amigos), cond.amigos]
    : 'nivel' in cond ? [S.player.level, cond.nivel]
    : 'chefe' in cond ? [S.chefes?.[cond.chefe] ? 1 : 0, 1]
    : 'treinadores' in cond ? [S.treinadoresVencidos || 0, cond.treinadores]
    : 'missao' in cond ? [(S.missoesFeitas || []).includes(cond.missao) ? 1 : 0, 1]
    : 'dinheiro' in cond ? [S.money || 0, cond.dinheiro]         // ter isso de uma vez (gastar faz cair)
    : 'gasto' in cond ? [S.gasto || 0, cond.gasto]               // total gasto na loja + Centro (S.gasto)
    : 'evolucoes' in cond ? [soma(r.evolucoes), cond.evolucoes]  // suas e dos aliados
    : [0, 1];
  return { atual: Math.min(atual, alvo), alvo, ok: atual >= alvo };
}
// Situação de todas as missões: visíveis e em andamento, prontas pra entregar, feitas e quantas ainda escondidas
export function situacaoMissoes(missoes, S) {
  const feitas = S.missoesFeitas || [], ativas = [], prontas = [];
  let escondidas = 0;
  for (const m of missoes) {
    if (feitas.includes(m.id)) continue;
    if (m.gen && m.gen !== (S.gen || 1)) continue;          // missão de outro mapa (ex.: Alfas de Kanto) nem conta
    if (m.libera && !progressoCondicao(m.libera, S).ok) { escondidas++; continue; }
    const p = progressoCondicao(m.objetivo, S);
    (p.ok ? prontas : ativas).push({ m, ...p });
  }
  return { ativas, prontas, feitas: feitas.length, escondidas };
}

// Desmaio número `n` (já contando este) precisa de Revive? `livres` null = modo sem limite (Fácil)
export const desmaioPrecisaRevive = (n, livres) => livres != null && n > livres;

/* ---- fim de jornada e recordes ---- */

const soma = o => Object.values(o || {}).reduce((a, n) => a + n, 0);
// Números da jornada, tirados do save. Espécie = a inicial (S.especieInicial; save antigo cai na atual).
/* XP que sobrou acima do nível 100. DERIVADO de `exp`, não acumulado num contador: `exp` nunca para de crescer
   (`progressao.gainExp` soma sempre; o que para no 100 é o laço de subir de nível), então a conta é exata, vale
   retroativamente pra quem já estava no teto antes desta regra existir e não precisa de campo novo no save.
   `growth` é a curva da espécie (`S.meta.growth`, da PokéAPI) — sem ela não dá pra saber onde o 100 começa, e
   devolver 0 é o certo: melhor não pontuar do que pontuar errado. */
export const xpExcedente = (exp, growth) => Math.max(0, Math.floor((exp || 0) - (growth?.[100] ?? Infinity)));

export function estatisticasDaJornada(S) {
  const r = S.registro || {};
  return {
    especie: S.especieInicial || S.player.data.speciesName, especieFinal: S.player.data.speciesName,
    nivel: S.player.level, xpExtra: xpExcedente(S.player.exp, S.meta?.growth), vitorias: S.wins || 0, derrotados: soma(r.derrotados), treinadores: S.treinadoresVencidos || 0,
    alfas: Object.keys(S.chefes || {}).length, amigos: soma(r.amigos), evolucoes: soma(r.evolucoes),
    missoes: (S.missoesFeitas || []).length, capturas: S.capturas || 0,
    ovosChocados: S.ovosChocados || 0,   // badges 'ovos100'/'ovos1000' (ovos.js): somadas do progresso permanente
    // mapa (Gen) em que a jornada estava e quantas Gens fechou (venceu os lendários)
    gen: S.gen || 1, gens: (S.gensVencidas || []).length, tempoMs: S.tempoMs || 0, shiny: !!S.player.shiny,
    // quantas vezes esta jornada seguiu pro mapa seguinte com o MESMO Pokémon (cada uma tira 20% da pontuação)
    continuacoes: S.continuacoes || 0, campeaoDe: S.gensVencidas || [],
    // badges: jogou sem as vantagens da conta? passou a jornada inteira sem Centro Pokémon?
    semVantagens: !!S.semVantagens, semCentro: !S.usouCentro,
    maxDinheiro: Math.max(S.maxDinheiro || 0, S.money || 0), gasto: S.gasto || 0,
    shiniesVistos: soma(r.shinies), shiniesAmigos: soma(r.shiniesAmigos),
    /* Cópia do registro por espécie: a Pokédex da carreira (vistos/amigos + sprite pelo id) sai daqui — e, desde as
       conquistas de conta, também os `abates` (conquistas.js), que alimentam as gimmicks.
       ATENÇÃO: esta cópia é uma LISTA BRANCA. Campo novo em `S.registro` que não for citado aqui existe durante a
       run e some quando a jornada termina. Foi exatamente o que aconteceu com `abates` na primeira versão: o
       contador subia jogando e zerava ao encerrar, porque a carreira nunca recebia o campo — e de novo com
       `shiniesAmigos` (bug corrigido em 27/09/2026): só o TOTAL sobrevivia aqui embaixo (`shiniesAmigos: soma(...)`),
       o mapa por espécie sumia ao fechar a jornada e `criacao.opcaoShiny` nunca via qual espécie exatamente
       tinha ficado shiny. `shinies` (o shiny ENCONTRADO, mesmo sem recrutar) entrou pelo mesmo motivo, em
       11/10/2026: é o que a ✨ Pokédex shiny acende, e sem ele só o total sobreviveria à jornada. */
    registro: JSON.parse(JSON.stringify({ vistos: r.vistos || {}, derrotados: r.derrotados || {}, amigos: r.amigos || {}, evolucoes: r.evolucoes || {}, formas: r.formas || {}, ids: r.ids || {}, abates: r.abates || {}, shinies: r.shinies || {}, shiniesAmigos: r.shiniesAmigos || {} }))
  };
}
// Pontuação = soma ponderada × multiplicador da dificuldade (Hardcore vale o dobro do Fácil)
/* `xpExtra` = XP ganho DEPOIS do nível 100 (pedido do usuário: no teto, o XP não podia mais virar nada e farmar
   deixava de valer). O peso é fracionário de propósito: 0,003 × os ~30 mil de XP que separam o nível 99 do 100
   na curva média dá ~89 pontos, ou seja, continuar farmando no teto rende quase o mesmo que ganhar um nível de
   verdade (100) — sem passar na frente de quem jogou a run inteira. */
export const PESOS_PONTOS = { nivel: 100, vitorias: 10, treinadores: 50, alfas: 300, amigos: 100, evolucoes: 150, missoes: 120, gens: 2000, xpExtra: 0.003 };
/* Continuar a mesma jornada no mapa seguinte (em vez de começar outra do zero) é mais fácil: você chega no mapa
   novo já em nível alto. Cada continuação tira 20% da pontuação, com piso de metade — o suficiente pra escolher
   recomeçar valer a pena no ranking, sem zerar quem prefere levar o veterano até o fim.
   **Mudou aqui, muda no SQL**: `validar_jornada` (supabase/schema.sql) recalcula a pontuação e recusa a jornada
   se o número não bater. */
export const PENAL_CONTINUACAO = 0.8, PENAL_MINIMO = 0.5;
// jogar sem as vantagens das badges (itens e dinheiro iniciais) rende 10% a mais: o desafio puro tem de valer algo
export const BONUS_SEM_VANTAGENS = 1.1;
// `Math.max(n||0, 0)` no EXPOENTE: com expoente negativo `0.8 ** -50` ≈ 70065 e a penalidade virava bônus de
// dezenas de milhares. O `Math.max` de fora é PISO, não teto, e não segurava isso. Ver a migration
// 20260930120000 — o furo de verdade era do lado do servidor; aqui é só manter os dois lados iguais.
export const multContinuacao = n => Math.max(PENAL_MINIMO, PENAL_CONTINUACAO ** Math.max(n || 0, 0));
export const pontuacao = (est, multDificuldade = 1) =>
  Math.round(Object.entries(PESOS_PONTOS).reduce((a, [k, p]) => a + (est[k] || 0) * p, 0)
    * multDificuldade * multContinuacao(est.continuacoes) * (est.semVantagens ? BONUS_SEM_VANTAGENS : 1));

export function formatarTempo(ms) {
  const min = Math.floor(ms / 60000);
  if (min < 1) return 'menos de 1 min';
  const h = Math.floor(min / 60), m = min % 60;
  return h ? `${h}h ${String(m).padStart(2, '0')}min` : `${m} min`;
}


/* ---- gênero ---- */
/* A PokéAPI dá `gender_rate` na ESPÉCIE (api.loadSpecies → `genderRate`): −1 = sem gênero, 0 = sempre macho,
   8 = sempre fêmea, 1–7 = chance de FÊMEA em oitavos. Sorteado uma vez no nascimento (pokemon.makeMon) e
   congelado no save — nada reescreve `m.genero` depois, nem a evolução.
   Forma presa a um gênero (meowstic-female, basculegion-male, oinkologne-male…): o NOME da forma manda, porque
   a espécie delas tem taxa 4 e o sorteio daria um Meowstic-Female macho. A forma padrão não traz sufixo, então
   o macho dessas espécies continua saindo do sorteio — fica certo nos dois casos. */
export function sortearGenero(taxa, nome = '', sorte = Math.random()) {
  if (/-female$/.test(nome)) return 'f';
  if (/-male$/.test(nome)) return 'm';
  if (!(taxa >= 0 && taxa <= 8)) return null;                 // −1 (sem gênero), ausente ou lixo
  return sorte < taxa / 8 ? 'f' : 'm';
}
// Rivalry, Attract, Captivate, Cute Charm. Sem gênero (Magnemite, lendários) e save antigo (`genero` ausente)
// nunca casam com nada: as duas respondem false, então o efeito falha em vez de chutar um gênero.
export const mesmoGenero = (a, b) => !!a?.genero && a.genero === b?.genero;
export const generoOposto = (a, b) => !!a?.genero && !!b?.genero && a.genero !== b.genero;

// shiny: 1 em 4096 (Gen 6+), sorteado pra todo Pokémon criado — você, selvagem ou de treinador, em qualquer modo
export const CHANCE_SHINY = 1 / 4096;
export const ehShiny = (sorte = Math.random()) => sorte < CHANCE_SHINY;
// Segredo do brilho: ser um Pokémon shiny (1 em 4096) dobra XP e dinheiro e deixa o Centro Pokémon de graça.
// Não está escrito em lugar nenhum da tela inicial — quem tirar um shiny descobre jogando.
export const MULT_SHINY = 2;
export const bonusShiny = S => !!S?.player?.shiny;
export const multShiny = S => bonusShiny(S) ? MULT_SHINY : 1;

/* Caminho (nomes de espécie) da raiz até `nome` numa árvore de evolução (api.slimEvo: {name, to:[...]}). `null`
   se a árvore não tiver o nó (save sem a árvore carregada ainda, ex. evoPendente). Usado pro desbloqueio
   retroativo do início-shiny (bug corrigido em 27/09/2026, ver `especiesShinyDoJogador`): sem isso não dava pra
   saber quais formas intermediárias um Pokémon shiny passou ao evoluir mais de uma vez. */
export function caminhoNaArvore(node, nome) {
  if (!node) return null;
  if (node.name === nome) return [node.name];
  for (const filho of node.to || []) {
    const resto = caminhoNaArvore(filho, nome);
    if (resto) return [node.name, ...resto];
  }
  return null;
}
/* Espécies que merecem o registro de "shiny recrutado" (registro.shiniesAmigos) pro PRÓPRIO Pokémon do jogador
   (bug: só era gravado ao recrutar um ALIADO shiny — o jogador shiny nunca desbloqueava a própria espécie pra
   começar de novo, nem propagava pras formas em que evoluiu). Com a árvore carregada (S.meta.evo), a espécie
   inicial E toda forma no caminho até a atual; sem ela (melhor esforço), só as duas pontas. */
export function especiesShinyDoJogador(S) {
  if (!S?.player?.shiny) return [];
  const atual = S.player.data?.speciesName;
  if (!atual) return [];
  const caminho = S.meta?.evo && caminhoNaArvore(S.meta.evo, atual);
  return caminho || [...new Set([S.especieInicial, atual].filter(Boolean))];
}

/* ---- treinadores caçadores (Etapa 3) ---- */

// prêmio ao derrotar a equipe inteira de um treinador (no lugar do dinheiro por Pokémon selvagem)
export const premioTreinador = equipe => equipe.reduce((a, m) => a + m.level, 0) * 20;

// bola que o treinador carrega, pela faixa de nível da equipe dele
export const bolaPorNivel = nivel => nivel < 20 ? 'poke-ball' : nivel < 40 ? 'great-ball' : 'ultra-ball';

// o treinador gasta a vez lançando bola só quando você está com metade do HP ou menos (60% de chance a cada turno)
export const treinadorLancaBola = (hp, hpMax, bolas, sorte = Math.random()) => bolas > 0 && hp <= hpMax / 2 && sorte < 0.6;

/* ---- 🥎 Em QUEM o treinador lança a bola (pedido do usuário, 06/10/2026) ----
   "Treinadores também vão poder tentar capturar Pokémon aliados, não só você."

   Até aqui a bola só existia pra você, e isso dizia uma coisa estranha do mundo do jogo: um caçador olhava um
   Pokémon selvagem lutando ao seu lado e não tinha interesse nenhum. Agora o lado dele escolhe — e escolhe BEM,
   pegando quem está mais perto de ser capturado (menor fração de HP), porque é o que um caçador faria.
   Devolve o Pokémon, ou null se ninguém está na faixa. `FRACAO_BOLA` é a mesma metade de `treinadorLancaBola`:
   duas condições diferentes pro mesmo "está fraco o bastante" é o tipo de coisa que ninguém reconcilia depois. */
export const FRACAO_BOLA = 0.5;
export function alvoDaBola(lado = [], jaPresos = []) {
  const candidatos = lado.filter(m => m && m.hp > 0 && !m.vol?.retirado && !jaPresos.includes(m)
    && m.hp <= m.stats.hp * FRACAO_BOLA);
  if (!candidatos.length) return null;
  return candidatos.reduce((pior, m) => (m.hp / m.stats.hp < pior.hp / pior.stats.hp ? m : pior));
}
/* Taxa de captura de um ALIADO. A do seu principal vem da espécie (`B.taxaCaptura`, buscada no começo da luta);
   a de um aliado exigiria uma busca de rede DENTRO do turno, e buscar no caminho crítico é a armadilha que o
   CLAUDE.md nomeia. Então vale a média da franquia — e ela é generosa com o jogador, porque 45 é mais baixo que
   a taxa da maioria dos Pokémon comuns que viram aliados. */
export const TAXA_CAPTURA_ALIADO = 45;

// Fórmula de captura da Gen 3/4. `a` ≥ 255 = captura garantida; senão cada um dos 4 balanços passa com chance b/65536.
export const BONUS_STATUS_CAPTURA = { sleep: 2, freeze: 2, paralysis: 1.5, burn: 1.5, poison: 1.5 };
export function valorCaptura(hp, hpMax, taxa, multBola, status) {
  return Math.floor(Math.floor((3 * hpMax - 2 * hp) * taxa * multBola / (3 * hpMax)) * (BONUS_STATUS_CAPTURA[status] || 1));
}
export function chancePorBalanco(a) {
  if (a >= 255) return 1;
  a = Math.max(1, a);
  return Math.floor(1048560 / Math.floor(Math.sqrt(Math.floor(Math.sqrt(Math.floor(16711680 / a)))))) / 65536;
}
// quantos balanços a bola dá (0–4); 4 = capturado
export function balancosDaCaptura(a, sorte = Math.random) {
  const p = chancePorBalanco(a);
  let n = 0;
  while (n < 4 && sorte() < p) n++;
  return n;
}

// EVs ganhos ao derrotar um Pokémon: teto de 252 por atributo e 510 no total. Devolve [[stat, qtd]], não muta `evs`
export function ganhoDeEVs(evs, effort) {
  let total = STATS.reduce((a, s) => a + evs[s], 0);
  const out = [];
  for (const [s, v] of Object.entries(effort)) {
    const add = Math.min(v, 252 - evs[s], 510 - total);
    if (add > 0) { out.push([s, add]); total += add; }
  }
  return out;
}
/* O que os itens de treino (dados.ITENS_TREINO) têm pra fazer neste Pokémon. Puros, e separados do sorteio de
   propósito: a MESMA conta diz se o item aparece como usável (itemTemEfeito) e de onde o IV é sorteado
   (itens.js) — senão a loja ofereceria uma Tampa de ₽250.000 pra quem já tem os 6 IVs em 31. */
export const temEvs = m => STATS.some(s => (m?.evs?.[s] || 0) > 0);
export const ivsParaMaximizar = m => STATS.filter(s => (m?.ivs?.[s] ?? 31) < 31);
// as outras habilidades da espécie (as normais e a oculta), do jeito que vêm de `api.slimPokemon`: [{name, url, hidden}]
export const habilidadesParaTrocar = m => (m?.data?.abilities || []).filter(a => a.name !== m.ability);

/* ---- 🤖 Auto-explorar (só admin, auto.js) ----
   A estatística da caçada: quantos de cada espécie o laço derrubou e quanto isso dá em porcentagem, pra comparar
   ao vivo com a taxa de aparição da rota (`mapas.taxaNaRota`). Puro porque é conta: a tela só desenha. */
export function resumoDeAbates(contagem = {}) {
  const linhas = Object.entries(contagem).map(([especie, n]) => ({ especie, n }));
  const total = linhas.reduce((a, l) => a + l.n, 0);
  for (const l of linhas) l.pct = total ? l.n / total * 100 : 0;
  return { total, linhas: linhas.sort((a, b) => b.n - a.n || a.especie.localeCompare(b.especie)) };
}
/* Hora de voltar ao Centro pra repor PP — ANTES do último golpe acabar (pedido do usuário). Quem chega no
   Struggle bate fraco, se machuca a cada golpe e transforma uma caçada tranquila em run perdida por teimosia.
   Dois gatilhos, porque um só erra metade dos casos: "nenhum golpe tem mais de 1 PP" pega quem está no
   finzinho, e a fração do PP total pega quem tem quatro golpes e está raspando em todos. Golpe de `pp` 0
   (Struggle) fica de fora da conta.
   A primeira regra já foi "sobrou UM golpe com PP" e era eager demais (2º pedido do usuário): quem tem três
   golpes zerados e um com 20 PP cheios ainda luta 20 turnos — mandar essa pessoa pro Centro é gastar dinheiro e
   cortar a caçada por nada. O gatilho é o golpe em 1 PP, que é quando o próximo turno pode ser o último. */
export function precisaReporPP(m, fracao = 0.25) {
  const moves = (m?.moves || []).filter(g => g.pp > 0);
  if (!moves.length) return false;
  const total = moves.reduce((a, g) => a + g.pp, 0), resta = moves.reduce((a, g) => a + (g.ppLeft || 0), 0);
  return !moves.some(g => (g.ppLeft || 0) > 1) || resta / total < fracao;
}
/* Por que o laço para. A ordem é a prioridade: achar o alvo ganha de tudo, e qualquer coisa que tire o jogo da
   rota (fim de jornada, outra tela, desmaio) para na hora — um laço que continua clicando depois do Game Over
   do Roguelike é exatamente o jeito de perder uma run sozinho. `teto` existe porque laço sem fim é bug, não
   funcionalidade. Devolve null quando é pra seguir. */
export function motivoDeParar({ achou = false, erro = false, modo, hp = 0, nivel = 0, nivelAlvo = 0, semPP = false, exploracoes = 0, teto = Infinity } = {}) {
  if (erro) return 'erro';
  if (achou) return 'achou';
  // chegar no nível pedido é objetivo cumprido, igual a achar a espécie — ganha de desmaio, teto e PP
  if (nivelAlvo && nivel >= nivelAlvo) return 'nivel';
  if (modo !== 'explore' && modo !== 'battle') return 'saiu';
  if (hp <= 0) return 'desmaiou';
  // sem PP e sem como repor (dinheiro curto): seguir daqui é moer Struggle, que machuca quem usa — para e conta
  if (semPP) return 'semPP';
  if (exploracoes >= teto) return 'teto';
  return null;
}
/* O que a caçada está procurando, em texto. São três objetivos (pedido do usuário): uma espécie, um nível do
   Pokémon principal, ou nada — e "nada" significa rodar até sair um shiny, que para o laço em qualquer caso.
   Mora aqui porque o painel (`render.blocoAuto`) e a narração (`auto.js`) precisam da MESMA frase, e render não
   pode importar auto (ciclo). */
export const objetivoAuto = a => a?.alvo ? fmt(a.alvo) : a?.especieRepel ? `um shiny de ${fmt(a.especieRepel)}` : a?.nivelAlvo ? `o nível ${a.nivelAlvo}` : 'um shiny';
