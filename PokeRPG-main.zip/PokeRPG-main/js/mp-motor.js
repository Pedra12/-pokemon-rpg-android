/* ============ motor de batalha multiplayer (puro) ============ */
// Batalha entre dois LADOS (A e B) com N Pokémon cada — co-op (jogadores em A contra a IA em B) e, depois, PvP
// (jogadores dos dois lados). Puro: recebe estado + ações, devolve estado NOVO + eventos de texto. Quem roda é o
// anfitrião da sala (multiplayer.js), que manda o resultado pros outros. Sem DOM, sem rede — tests/mp-motor.test.js.
// O GOLPE em si é o do motor único (golpe.js) — o mesmo do single player, com as habilidades. A narração é texto puro: quem exibe escapa.
//
// Estado: { turno, lados: { A: [mon], B: [mon] }, fugas, fim: null | 'A' | 'B' | 'fuga' }
// mon (fotoDoMon): { ref, dono, nome, level, stats, hp, status, sleep, moves[{…, ppLeft}], ability, data{types…}, vol }
// Ação: { ref, tipo: 'golpe', golpe: índice (-1 = Struggle), alvo: ref } | { ref, tipo: 'fugir' }
import { STRUGGLE, STATS, TYPE_PT, ITEMS } from './dados.js';
import { novoCampo, effStat, consegueFugir, ordenarAcoes, salaAtiva, ativouQuickClaw, sempreUltimo, prioridadeEfetiva, freshVol, calcStats, climaDe, terrenoDe, escolhaIA, golpesPermitidos, golpeForcado, ESPERTEZA, multVento, TURNOS_DYNAMAX, itemTemEfeito, heal, LADO_VAZIO, noChao, tiposDefensivos, tiposOfensivos } from './regras.js';
import { golpeCanhao, usarItemDeRaide } from './boss.js';
import { usarGolpe, golpeTravado, fimDeTurno, fimDaRodada, passarClima, passarTerreno, passarGravidade, passarLados, aoEntrarEmCampo, mudarEstagios } from './golpe.js';
import { aplicarForma, verboDaForma } from './mega.js';
import { megasDe } from './dados-megas.js';
import { teracristalizar } from './tera.js';
import { gigantamaxar, passarDynamax } from './dynamax.js';
import { inimigoTemZ, inimigoUsaZAgora } from './zmove.js';
import { rand, clamp, fmt } from './util.js';
import { hab } from './habilidades.js';

// Cópia enxuta de um Pokémon do jogo pra batalha multiplayer (sem descrições longas: vai pela rede).
// `slot` = 0 principal, 1..2 aliados (índice em S.aliados + 1) — é por ele que o resultado volta pro Pokémon certo.
// Leva base/IVs/EVs/natureza pra dar pra recalcular os stats em outro nível (balancear).
export function fotoDoMon(M, ref, dono, nome, slot = 0) {
  return {
    ref, dono, slot, nome: nome || M.nick || fmt(M.name), id: M.id, name: M.name, level: M.level, shiny: !!M.shiny, ability: M.ability,
    // gênero: Rivalry, Attract, Captivate e Cute Charm leem daqui (regras.mesmoGenero/generoOposto)
    genero: M.genero ?? null,
    // item segurado (pedido do usuário, 28/09/2026): antes NENHUM item segurado fazia efeito em luta de multiplayer
    // (Restos, Orbe da Vida, Faixa de Foco...) nem o Vínculo de Batalha virava Ash-Greninja — `seg(m)`/`m.item ===
    // ITEM_VINCULO` liam de `m.item`, e a "foto" simplesmente não tinha esse campo. golpe.js/regras.js são o MESMO
    // motor do single player, então só faltava mandar o dado: nenhuma lógica nova de dano/cura precisou mudar.
    item: M.item || null,
    nature: M.nature, ivs: { ...(M.ivs || {}) }, evs: { ...(M.evs || {}) },
    data: { types: [...M.data.types], sprite: M.data.sprite, back: M.data.back, speciesName: M.data.speciesName, baseExp: M.data.baseExp,
      effort: { ...(M.data.effort || {}) }, base: { ...(M.data.base || {}) } },
    stats: { ...M.stats }, hp: M.hp, status: M.status || null, sleep: M.sleep || 0,
    moves: M.moves.map(m => ({ name: m.name, type: m.type, cls: m.cls, power: m.power, acc: m.acc, pp: m.pp, ppLeft: m.ppLeft,
      priority: m.priority || 0, target: m.target, meta: m.meta || {}, stats: m.stats || [] })),
    vol: freshVol(),
    // chefe do evento semanal (boss.js): o estado das mecânicas vai junto pela rede e no estado da sala
    ...(M.boss ? { boss: structuredClone(M.boss), chefeEvento: true } : {})
  };
}
// pvp: ninguém foge (só dá pra desistir)
// `campo` = o que vale pros dois lados (hoje só o clima — regras.CLIMAS)
// `evento` = id do chefe semanal (boss.js) quando a luta é do evento; `revivesUsados` = quantos Revives cada jogador já gastou nela
// `alfa` = a luta é contra o Alfa da rota: ele pode carregar um Z-Move (zmove.inimigoTemZ, chance baixa, sorteada aqui uma vez)
export const novaBatalhaMP = (A, B, opcoes = {}) => ({ turno: 1, lados: { A, B }, fugas: 0, fim: null, pvp: !!opcoes.pvp, campo: novoCampo(opcoes.zona),
  evento: opcoes.evento || null, revivesUsados: {}, raideUsados: {},
  gimmicksUsados: {}, zIA: inimigoTemZ({ chefe: opcoes.alfa ? 'alfa' : null, evento: opcoes.evento }), zIAUsado: false });

/* ---- gimmicks no co-op (Mega, Tera, Gigantamax e Z-Move) ----
   Quem joga escolhe na tela e manda junto da ação de golpe: `acao.gimmicks = [{ tipo:'mega', forma, id, name, types, base,
   sprite, back, ability } | { tipo:'tera', valor } | { tipo:'gmax' } | { tipo:'z' }]`. Este motor é puro e não vê a conta
   de ninguém: a conquista e o item (Pedra Mega / Cristal Z) são conferidos NA TELA de quem joga, e aqui só entram as regras
   que dependem do estado da luta — e o anfitrião confia no que chega (é uma sala de amigos, como o resto da rede).
   Regras (as mesmas do single player): só o Pokémon PRINCIPAL (slot 0) de quem tem uma run (convidado não), só no co-op
   (PvP fica de fora), UMA de cada por luta e por jogador. Mega, Tera e Gigantamax não gastam o turno — entram antes de
   qualquer golpe; o Z é o próprio golpe do turno. Nada disso volta pra run: a foto do Pokémon é descartada no fim. */
const golpeDeDano = g => !!g && g.cls !== 'status' && g.power > 0 && g.name !== 'struggle';
function aplicarMegaMP(m, g) {
  const f = megasDe(m.data.speciesName).find(x => x.forma === g.forma);   // a forma tem que ser da espécie dele
  if (!f || m.mega || !Array.isArray(g.types) || !g.types.length || !STATS.every(s => Number.isFinite(g.base?.[s]))) return null;
  aplicarForma(m, f, { ...m.data, id: g.id ?? f.id, name: g.name || f.forma, types: g.types.map(String), base: Object.fromEntries(STATS.map(s => [s, g.base[s]])),
    sprite: g.sprite || m.data.sprite, back: g.back || m.data.back }, g.ability ? String(g.ability) : undefined);
  return f;
}
// devolve os `ref` cujo golpe deste turno é Z
async function aplicarGimmicksMP(s, acoes, ctx) {
  const say = ctx.say;
  const zRefs = new Set();
  if (s.pvp) return zRefs;
  for (const a of acoes) {
    if (a.tipo !== 'golpe' || !Array.isArray(a.gimmicks) || !a.gimmicks.length) continue;
    const m = monMP(s, a.ref);
    if (!m || m.hp <= 0 || m.dono === 'ia' || m.slot !== 0 || m.convidado || ladoDe(s, m.ref) !== 'A') continue;
    const usou = ((s.gimmicksUsados ||= {})[m.dono] ||= {});
    for (const g of a.gimmicks) {
      if (g?.tipo === 'mega' && !usou.mega) {
        const f = aplicarMegaMP(m, g);
        if (f) {
          usou.mega = true; say(`${m.nome} ${verboDaForma(f)}! ${f.nome} entra em campo.`, 'level');
          // a forma entra em campo de verdade: a habilidade dela dispara agora (Drought, Intimidate…)
          await aoEntrarEmCampo([m], x => vivosMP(s.lados[outro(ladoDe(s, x.ref))]), ctx);
        }
      } else if (g?.tipo === 'tera' && !usou.tera && !m.tera && TYPE_PT[g.valor]) {
        teracristalizar(m, g.valor); usou.tera = true;
        say(`${m.nome} TERASTALIZOU! Agora é do tipo ${TYPE_PT[g.valor]} — e só dele.`, 'level');
      } else if (g?.tipo === 'gmax' && !usou.gmax && !m.dyna) {
        gigantamaxar(m); usou.gmax = true;
        say(`${m.nome} GIGANTAMAXOU! O HP dobrou e os golpes viram Max por ${TURNOS_DYNAMAX} turnos.`, 'level');
      } else if (g?.tipo === 'z' && !usou.z && golpeDeDano(m.moves[a.golpe]) && m.moves[a.golpe].ppLeft > 0) {
        usou.z = true; zRefs.add(m.ref);
        say(`${m.nome} concentra a energia Z!`, 'level');
      }
    }
  }
  return zRefs;
}

/* Item comum (Potion, X Attack, curas de status, Éter...) no multiplayer (pedido do usuário, 28/09/2026): é uma
   ESCOLHA DE TURNO (como golpe/fugir, não uma ação livre) — ocupa a vez do Pokémon, igual no single player. Sempre
   no PRÓPRIO Pokémon que usou (sem "usar em qual aliado?": mantém simples numa sala, onde cada jogador só vê a
   própria mochila). `itemTemEfeito`/`heal` são as MESMAS regras puras do single player; `mudarEstagios` (golpe.js)
   é o motor único de estágio, então Clear Body/Simple/Contrary do alvo continuam valendo mesmo aqui. */
async function aplicarItemComum(m, it, ctx, say) {
  if (it.heal || it.healPct) {
    const base = it.healPct ? Math.ceil(m.stats.hp * it.healPct / 100) : it.heal;
    const h = Math.min(base, m.stats.hp - m.hp); heal(m, h);
    const curou = it.cure && m.status; if (curou) { m.status = null; m.sleep = 0; }
    say(`${m.nome} usou ${it.name} e recuperou ${h} HP${curou ? ', curado de status' : ''}.`, 'good');
  } else if (it.cure) {
    m.status = null; m.sleep = 0;
    say(`${m.nome} usou ${it.name} e está curado!`, 'good');
  } else if (it.ether) {
    m.moves.forEach(g => { g.ppLeft = Math.min(g.pp, g.ppLeft + it.ether); });
    say(`${m.nome} usou ${it.name}. PP restaurados.`, 'good');
  } else if (it.stage) {
    say(`${m.nome} usou ${it.name}.`);
    await mudarEstagios(m, [{ stat: it.stage, change: 2 }], ctx, m);
  }
}

/* Item de raide no co-op (boss.usarItemDeRaide): ação LIVRE de um jogador do grupo, um de cada tipo por luta pro GRUPO todo (a marca
   fica no `boss.raide` do chefe). Muta o estado — quem chama é o anfitrião. `raideUsados[dono][tipo]` viaja no estado: é por ele que
   cada cliente desconta o item da PRÓPRIA mochila. Devolve { ok, efeitos, motivo? }. */
export function usarRaideNoEvento(estado, dono, tipo) {
  if (!estado?.evento || estado.fim) return { ok: false, efeitos: [], motivo: 'Fora da luta do chefe.' };
  if (!estado.lados.A.some(m => m.dono === dono)) return { ok: false, efeitos: [], motivo: 'Você não está nesta luta.' };
  const E = estado.lados.B.find(m => m.boss && m.hp > 0);
  if (!E) return { ok: false, efeitos: [], motivo: 'O chefe já caiu.' };
  const ladoJogador = (estado.campo.lados ||= {}).A ||= LADO_VAZIO();
  const r = usarItemDeRaide(E, tipo, ladoJogador);
  if (r.ok) {
    const meu = ((estado.raideUsados ||= {})[dono] ||= {}); meu[tipo] = (meu[tipo] || 0) + 1;
    /* Relógio de Areia e Fragmento Tera: boss.js não sabe QUAL Pokémon é nem se o Tera já saiu — resolve aqui.
       Simplificação: muta o estágio direto (sem passar por golpe.mudarEstagios) porque esta ação livre não tem
       um `ctx` de narração como o resto do turno — Clear Body/Simple/Contrary não entram nesse +2 específico. */
    if (r.estagios) {
      const meuMon = estado.lados.A.find(m => m.dono === dono && m.slot === 0 && m.hp > 0) || estado.lados.A.find(m => m.dono === dono && m.hp > 0);
      if (meuMon) for (const [stat, change] of r.estagios) meuMon.vol.stages[stat] = Math.max(-6, Math.min(6, (meuMon.vol.stages[stat] || 0) + change));
    }
    if (r.recarregaTera) { const g = estado.gimmicksUsados?.[dono]; if (g) g.tera = false; }
  }
  return r;
}

/* Revive no meio da luta do chefe (só no evento): quem ficou com TODOS os Pokémon caídos enquanto o grupo ainda aguenta pode
   trazer um de volta com um Revive da mochila, com metade do HP. É o que faz valer a pena lutar em equipe: o grupo segura a
   luta e o amigo volta. Devolve o Pokémon revivido, ou null se não pôde (não é evento, não é dele, não está caído, o grupo
   já não aguenta, ou ele já gastou `MAX_REVIVES` nesta luta). Muta o estado — quem chama é o anfitrião. */
export const MAX_REVIVES = 3;
export function reviverNoEvento(estado, ref, dono) {
  if (!estado?.evento || estado.fim) return null;
  const m = monMP(estado, ref);
  if (!m || m.dono !== dono || m.hp > 0 || ladoDe(estado, m.ref) !== 'A') return null;
  if (!estado.lados.A.some(x => x.hp > 0)) return null;                                   // o grupo todo caiu: acabou
  if (estado.lados.A.some(x => x.dono === dono && x.hp > 0)) return null;                // ele ainda tem alguém de pé: não precisa
  const usados = estado.revivesUsados?.[dono] || 0; if (usados >= MAX_REVIVES) return null;
  m.hp = Math.max(1, Math.floor(m.stats.hp / 2)); m.status = null; m.sleep = 0; m.caido = false; m.vol = freshVol();
  (estado.revivesUsados ||= {})[dono] = usados + 1;
  return m;
}

/* Revive num companheiro caído SEM exigir que o time inteiro tenha caído (pedido do usuário, 28/09/2026, pra
   Arena): a Arena é sempre solo (um `dono` só em `lados.A`), então a condição "o resto do grupo aguenta" de
   `reviverNoEvento` nunca abre — pra ELE, "o time inteiro caiu" e "o dono não tem mais ninguém de pé" são a
   MESMA coisa, e o `estado.fim` já teria fechado a luta antes de dar chance de reviver. Esta versão é só a regra
   NORMAL de Revive de uma run de verdade (qualquer aliado caído, a qualquer momento, se você tem o item) —
   restaura a paridade, não inventa poder novo. Continua exigindo pelo menos um Pokémon do dono de pé (senão a
   luta já teria acabado) e o mesmo teto `MAX_REVIVES` por luta. */
export function reviverCompanheiro(estado, ref, dono, pct = 50) {
  if (!estado?.evento || estado.fim) return null;
  const m = monMP(estado, ref);
  if (!m || m.dono !== dono || m.hp > 0 || ladoDe(estado, m.ref) !== 'A') return null;
  if (!estado.lados.A.some(x => x.dono === dono && x.hp > 0)) return null;
  const usados = estado.revivesUsados?.[dono] || 0; if (usados >= MAX_REVIVES) return null;
  m.hp = Math.max(1, Math.floor(m.stats.hp * pct / 100)); m.status = null; m.sleep = 0; m.caido = false; m.vol = freshVol();
  (estado.revivesUsados ||= {})[dono] = usados + 1;
  // Sala de Raide (multiplayer.js consumirRevives): Revive x Max Revive descontam itens DIFERENTES do
  // inventário de conta — `revivesUsados` é só um contador, então a lista de tipos vai à parte, na MESMA ordem.
  ((estado.revivesTipos ||= {})[dono] ||= []).push(pct === 100 ? 'max-revive' : 'revive');
  return m;
}

/* ---- balancear ---- */
// mesmo Pokémon em outro nível: recalcula os stats (base/IVs/EVs/natureza) e mantém a FRAÇÃO de HP
// `nivelReal` guarda o nível de verdade (só quem lutou no nível real leva XP/itens de volta pra run — naNivelReal)
export function nivelarMon(m, nivel) {
  const n = structuredClone(m);
  n.nivelReal = m.nivelReal ?? m.level;
  n.level = clamp(Math.round(nivel), 1, 100);
  n.stats = calcStats({ data: { base: m.data.base }, ivs: m.ivs, evs: m.evs, nature: m.nature, level: n.level });
  n.hp = m.hp <= 0 ? 0 : Math.max(1, Math.round(n.stats.hp * m.hp / m.stats.hp));
  return n;
}
// HP máximo (e atual) × fator — pro lado em menor número aguentar a diferença
export function escalarHP(m, fator) {
  const n = structuredClone(m), max = Math.round(m.stats.hp * fator);
  n.hp = m.hp <= 0 ? 0 : Math.max(1, Math.round(max * m.hp / m.stats.hp));
  n.stats.hp = max;
  return n;
}
export const naNivelReal = m => (m.nivelReal ?? m.level) === m.level;
export const nivelMedio = mons => Math.round(mons.reduce((a, m) => a + m.level, 0) / mons.length);
// PvP balanceado: todo mundo no nível médio; o lado com menos Pokémon ganha HP × (maior / menor)
export function balancearPvP(A, B) {
  const nivel = nivelMedio([...A, ...B]);
  let a = A.map(m => nivelarMon(m, nivel)), b = B.map(m => nivelarMon(m, nivel));
  if (a.length < b.length) a = a.map(m => escalarHP(m, b.length / a.length));
  else if (b.length < a.length) b = b.map(m => escalarHP(m, a.length / b.length));
  return { A: a, B: b, nivel };
}
// co-op balanceado ("chamar alguém pra sua run"): o time inteiro no nível do anfitrião
export const balancearCoop = (A, nivel) => A.map(m => nivelarMon(m, nivel));

export const todosMP = e => [...e.lados.A, ...e.lados.B];
export const ladoDe = (e, ref) => e.lados.A.some(m => m.ref === ref) ? 'A' : 'B';
const outro = l => (l === 'A' ? 'B' : 'A');
const vivosMP = l => l.filter(m => m.hp > 0);
export const monMP = (e, ref) => todosMP(e).find(m => m.ref === ref);

/* O que uma "foto" de estado que chega significa pra quem está na sala. `turnoVisto` é o último turno JÁ processado
   (null = nenhuma luta em andamento); `turno` é o da foto que chegou.
   Existe como função pura por causa de um bug real (29/09/2026, Sala de Raide): a sala decidia "é turno novo?"
   comparando com `sala.batalha`, que o ANFITRIÃO já tinha sobrescrito com o turno novo antes de publicar — davam
   iguais, as escolhas do turno anterior nunca eram limpas e o jogador não conseguia mais atacar. Quem hospeda e quem
   é convidado passam pela MESMA regra, e ela é testável sem DOM.
   `limparEscolhas` é false na primeira foto de uma luta de propósito: a lista já nasce vazia, e limpar ali apagaria a
   escolha recém-feita (num convidado isso deixaria escolher duas vezes). */
/* Dois Pokémon de mesmo nome no mesmo lado (3 Swampert do Hall da Fama) deixavam o registro ilegível: "Swampert usou
   Earthquake!" três vezes, sem saber de quem era qual. Numera só os repetidos, na ordem em que entram. MUTA a lista
   (ela acabou de ser montada por quem chamou) e devolve ela mesma, pra encaixar no `return` de montarLado. */
export function numerarRepetidos(lista) {
  const quantos = {}, vistos = {};
  for (const m of lista) quantos[m.nome] = (quantos[m.nome] || 0) + 1;
  for (const m of lista) if (quantos[m.nome] > 1) m.nome = `${m.nome} ${vistos[m.nome] = (vistos[m.nome] || 0) + 1}`;
  return lista;
}

export const leituraDoEstado = (turnoVisto, turno) => ({
  novaLuta: turnoVisto == null,
  turnoNovo: turnoVisto !== turno,
  limparEscolhas: turnoVisto != null && turnoVisto !== turno
});

// IA do lado B (selvagem/Alfa): escolhe o golpe por regras.escolhaIA (acerta conforme a `esperteza`; sem PP = Struggle)
// num alvo vivo aleatório do outro lado
export function acaoDaIA(e, m, sorte = Math.random, esperteza = ESPERTEZA.selvagem) {
  const alvos = vivosMP(e.lados[outro(ladoDe(e, m.ref))]);
  const alvo = alvos[Math.floor(sorte() * alvos.length)];
  // pensa como no single player: só entre os golpes que as travas deixam, julgados com o contexto (quem apanha, o campo e os lados)
  const lados = e.campo?.lados;
  // `aliados`/`oponentes` = quantos em campo de cada lado: é com isso que a IA pesa golpe de área (notaDoGolpe)
  const contexto = alvo ? { u: m, alvo, campo: e.campo, ladoU: lados?.[ladoDe(e, m.ref)], ladoAlvo: lados?.[ladoDe(e, alvo.ref)],
    aliados: vivosMP(e.lados[ladoDe(e, m.ref)]).filter(x => x !== m).length, oponentes: alvos.length } : null;
  const g = escolhaIA(golpesPermitidos(m), tiposOfensivos(m), alvo ? tiposDefensivos(alvo) : [], esperteza, sorte, contexto);
  return { ref: m.ref, tipo: 'golpe', golpe: g ? m.moves.indexOf(g) : -1, alvo: alvo?.ref };
}

// async: a narração do motor único (golpe.js) é async (o single player espera entre mensagens); aqui ela só coleta texto.
export async function resolverTurnoMP(estado, acoes) {
  const s = structuredClone(estado), ev = [];
  /* `atuando` = de quem é a ação que está sendo narrada agora. Vai em cada evento (`ref`) pra quem desenha a sala
     poder destacar o cartão de quem age — sem isso o turno inteiro aparecia de uma vez, e com dois Pokémon de mesmo
     nome no time ("Swampert usou Earthquake!" três vezes) não dava pra saber quem tinha feito o quê. */
  let atuando = null;
  /* `tremer` pendurado na PRÓXIMA linha, não como evento próprio: o motor sempre chama `ctx.tremer(t, tipo)`
     imediatamente antes do `ctx.say` do dano ("X perdeu N HP"), e assim a lista de eventos continua com UMA forma
     só — todo evento tem `txt`. Um evento separado só de animação obrigaria o histórico da sala, a Arena e os
     testes a filtrarem pelo campo que faltava. */
  let tremendo = null;
  const say = (txt, cls = '') => {
    ev.push({ txt, cls, ...(atuando ? { ref: atuando } : {}), ...(tremendo || {}) });
    tremendo = null;
  };
  const porConta = async (ref, fn) => { atuando = ref; try { return await fn(); } finally { atuando = null; } };
  s.campo ||= { clima: null, turnos: 0, terreno: null, terrenoTurnos: 0, lados: {} }; // batalha de uma versão anterior, sem campo
  const ctx = { nome: m => m.nome, golpe: g => fmt(g.name), say, refDe: m => m.ref, monPorRef: r => monMP(s, r), campo: s.campo, ladoDe: m => ladoDe(s, m.ref),
    aliadosDe: m => vivosMP(s.lados[ladoDe(s, m.ref)]).filter(x => x !== m),     // Friend Guard
    oponentesDe: m => vivosMP(s.lados[outro(ladoDe(s, m.ref))]),                 // Bad Dreams
    /* `tremer` é o MESMO gancho do single player (`efeitos.CTX.tremer`), só que aqui ele não pode tocar no DOM:
       este motor é puro e roda SÓ no anfitrião — quem tem a tela é cada cliente, que recebe a lista de eventos.
       Então a tremida VIAJA na linha da narração (`tremer` = ref de quem apanhou, `tipo` = o do golpe) e
       `multiplayer.narrar` anima o cartão `[data-ref]` e toca o som do tipo. Sem isso a sala não tinha animação
       nem som de impacto nenhum, e a luta de chefe parecia parada (relato #81). */
    tremer: (m, tipo) => { tremendo = { tremer: m.ref, tipo: tipo || null }; } };
  // habilidades de entrada em campo, no 1º turno (Intimidate, Drizzle, Download…): a MESMA regra do single player
  if (s.turno === 1) await aoEntrarEmCampo(vivosMP(todosMP(s)), m => vivosMP(s.lados[outro(ladoDe(s, m.ref))]), ctx);
  if (s.fim) return { estado: s, eventos: ev };
  const valida = a => { const m = monMP(s, a.ref); return m && m.hp > 0; };

  /* 0) desistir: todos os Pokémon do dono daquela ação saem da luta. **Só PvP** — a trava de modo estava só na
     UI (`mp-telas.botoesPvP`) e o motor aceitava de qualquer modo, o que virou achado na 2ª auditoria: em co-op
     uma ação `desistir` com o `de` de outro jogador zerava a equipe dele, e no Roguelike isso desce por
     `mp-resultado.principalCaiu` → `encerrarJornada('desmaiou')`, acabando com a run de quem nem clicou. */
  for (const a of (s.pvp ? acoes.filter(x => x.tipo === 'desistir' && valida(x)) : [])) {
    const dono = monMP(s, a.ref).dono;
    const dele = todosMP(s).filter(m => m.dono === dono && m.hp > 0);
    for (const m of dele) { m.hp = 0; m.caido = true; }
    say(`${dele[0]?.nome || 'Alguém'} e a equipe desistiram da luta.`, 'hit');
  }

  // 0b) itens comuns: ocupam a vez (como nos jogos, antes de qualquer golpe), sempre no PRÓPRIO Pokémon.
  // `itensUsados[dono]` acumula pra cada cliente descontar da própria mochila depois (mesmo padrão de revive/raide).
  for (const a of acoes.filter(x => x.tipo === 'item' && valida(x))) {
    const m = monMP(s, a.ref), it = ITEMS[a.item];
    if (!it || !itemTemEfeito(it, m)) continue;
    await porConta(m.ref, () => aplicarItemComum(m, it, ctx, say));
    ((s.itensUsados ||= {})[m.dono] ||= []).push(a.item);
  }

  // 1) fuga (só o lado A, e nunca no PvP): o mais rápido de quem pediu tenta contra o mais rápido do outro lado
  // (pvp e chefe da semana: ninguém foge)
  const fugindo = s.pvp || s.evento ? [] : acoes.filter(a => a.tipo === 'fugir' && valida(a) && ladoDe(s, a.ref) === 'A').map(a => monMP(s, a.ref));
  if (fugindo.length) {
    s.fugas++;
    const quem = fugindo.reduce((a, b) => effStat(b, 'speed') > effStat(a, 'speed') ? b : a);
    const inimigoRapido = Math.max(...vivosMP(s.lados.B).map(m => effStat(m, 'speed')));
    // Magnet Pull (só Aço), Shadow Tag (todo mundo) e Arena Trap (só quem está no chão): qualquer inimigo vivo com a habilidade prende
    if (s.campo?.travaFuga > 0) { say('Um campo de força impede a fuga!', 'muted'); return { estado: s, eventos: ev }; }   // 🧚 Fairy Lock
    const preso = vivosMP(s.lados.B).some(m => hab(m).prendeTipo?.some(t => quem.data.types.includes(t))
      || hab(m).prendeQualquer === true || (hab(m).prendeQualquer === 'chao' && noChao(quem))) || !!quem.vol?.preso || !!quem.vol?.aperto;   // ou um golpe (Mean Look, Block, Spider Web, Bind & cia.)
    if (consegueFugir(effStat(quem, 'speed'), inimigoRapido, s.fugas, quem.ability, undefined, preso)) {
      say(`${quem.nome} achou uma saída e todo mundo fugiu!`, 'good');
      s.fim = 'fuga'; return { estado: s, eventos: ev };
    }
    say(`${quem.nome} tentou fugir, mas não conseguiu!`);
  }

  // 1b) gimmicks (Mega, Tera, Gigantamax entram antes de qualquer golpe; o Z marca o golpe do turno)
  const zRefs = await aplicarGimmicksMP(s, acoes, ctx);

  // 2) golpes na ordem de prioridade e velocidade
  const golpes = acoes.filter(a => a.tipo === 'golpe' && valida(a)).map(a => {
    const m = monMP(s, a.ref), g0 = a.golpe === -1 || !m.moves[a.golpe] ? STRUGGLE : m.moves[a.golpe];
    const g = g0 !== STRUGGLE && !golpeTravado(m) ? golpeForcado(m) || g0 : g0;   // Encore: a escolha vira o golpe repetido, já na ordem do turno
    return { ...a, m, g, prio: prioridadeEfetiva(m, g), vel: effStat(m, 'speed', false, true, climaDe(s.campo), terrenoDe(s.campo)) * multVento(s.campo.lados?.[ladoDe(s, m.ref)]), rapido: ativouQuickClaw(m), lento: sempreUltimo(m) }; // clima entra aqui (Swift Swim…)
  });
  // o que cada um vai usar neste turno (Sucker Punch: só funciona contra quem vai atacar); limpo em fimDaRodada
  for (const m of todosMP(s)) delete m.vol.golpeEscolhido;
  for (const a of golpes) a.m.vol.golpeEscolhido = golpeTravado(a.m) || a.g;
  // 🏠 Trick Room: o mais LENTO age primeiro (o mesmo `salaAtiva` do single player — o campo é compartilhado)
  const ordem = ordenarAcoes(golpes, undefined, salaAtiva(s.campo, 'salaInvertida')), pos = ref => ordem.findIndex(o => o.ref === ref);
  for (let i = 0; i < ordem.length; i++) {
    const a = ordem[i];
    if (a.m.hp <= 0) continue;
    // alvo caiu antes: mira outro vivo do mesmo lado; ninguém sobrou = batalha acabou
    let t = monMP(s, a.alvo);
    if (!t || t.hp <= 0 || ladoDe(s, t.ref) === ladoDe(s, a.ref)) {
      const vivos = vivosMP(s.lados[outro(ladoDe(s, a.ref))]);
      if (!vivos.length) break;
      t = vivos[rand(0, vivos.length - 1)];
    }
    /* Z-Move: a mesma marca do single player (`vol.zAtivo`, lida em regras.calcDamage), apagada logo depois do golpe.
       O Alfa da rota também pode (chance baixa, `s.zIA`); os demais inimigos nunca. */
    let ehZ = zRefs.has(a.ref);
    if (!ehZ && a.m.dono === 'ia' && inimigoUsaZAgora({ zInimigo: s.zIA, zInimigoUsado: s.zIAUsado }, a.g)) {
      ehZ = true; s.zIAUsado = true; say(`${a.m.nome} concentra a energia Z!`, 'hit');
    }
    if (ehZ) a.m.vol.zAtivo = true;
    try { await porConta(a.m.ref, () => usarGolpe(a.m, t, a.g, pos(t.ref) === -1 || i < pos(t.ref), ctx)); }
    finally { delete a.m.vol.zAtivo; }
    // o golpe carregado do chefe atinge o TIME INTEIRO (boss.antesDoChefeAgir → `todos`): os outros alvos levam o mesmo golpe
    if (a.m.boss?.soltouTodos) {
      a.m.boss.soltouTodos = false;
      const canhao = golpeCanhao(a.m.boss.id, a.m.boss.canhaoUltimoMult);   // o Escudo Astral (se usado) vale pro time inteiro
      for (const x of vivosMP(s.lados[outro(ladoDe(s, a.m.ref))])) if (x !== t) await porConta(a.m.ref, () => usarGolpe(a.m, x, canhao, true, ctx, { extra: true }));
    }
    if (!vivosMP(s.lados.A).length || !vivosMP(s.lados.B).length) break;
  }

  // 3) fim de turno: queimadura/veneno, desmaios, quem venceu
  if (vivosMP(s.lados.A).length && vivosMP(s.lados.B).length) { const todos = vivosMP(todosMP(s)); for (const m of todos) await porConta(m.ref, () => fimDeTurno(m, ctx)); await passarClima(s.campo, ctx); await passarTerreno(s.campo, ctx); await passarGravidade(s.campo, ctx, todos); await passarLados(s.campo, ctx); } // + Speed Boost, Shed Skin, clima
  for (const m of todosMP(s)) if (passarDynamax(m) === 'acabou') say(`${m.nome} voltou ao tamanho normal.`, 'status');   // o gigante encolhe no fim da rodada
  for (const m of todosMP(s)) { fimDaRodada(m); if (m.hp <= 0 && !m.caido) { m.caido = true; say(`${m.nome} desmaiou!`, 'hit'); } }
  if (!vivosMP(s.lados.B).length) s.fim = 'A';
  else if (!vivosMP(s.lados.A).length) s.fim = 'B';
  s.turno++;
  return { estado: s, eventos: ev };
}

