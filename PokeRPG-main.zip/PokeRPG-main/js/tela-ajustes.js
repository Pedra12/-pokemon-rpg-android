/* ============ tela: ⚙ ajustes ============ */
// Hoje só a fonte do jogo (ajustes.js). Cada opção é mostrada JÁ com a própria fonte, pra dar pra comparar antes de
// escolher; a escolha vale na hora e fica guardada neste navegador. O clique (data-act="fonte") está em main.js.
import { G } from './estado.js';
import { $, limparTopo } from './ui.js';
import { FONTES, fonteEscolhida, urlDaFonte, ESTILOS_SPRITE, estiloSpriteAtual, animacoesLigadas } from './ajustes.js';
import { barraTelas } from './navegacao.js';
import { GENS, genDe, dadosDaGen } from './mapas.js';
import { alvosDaGen, quantoFalta, precisaRebaixar, jaBaixado, semServiceWorker, baixarGen, baixarTudo, baixarImagens, imagensGuardadas, baixarImagens3D, imagensGuardadas3D, baixarImagensAnimadas, imagensGuardadasAnimadas, quantoFaltaTudo, totalDoJogo } from './offline.js';
import { espacoUsado, itensNoCache, limparCache } from './api.js';
import { devLigado, liberarMegas, liberarEspecies, liberarOutrasGimmicks, liberarIvsPerfeitos, limparTeste, temProgressoDeTeste, forjarJornada, NIVEIS_FORJA } from './dev.js';
import { TOTAL_GENS } from './mapas.js';
import { esc, offline } from './util.js';
import { adsConfigurado, consentimento } from './ads.js';
import { presencaLigada } from './presenca.js';
import { nuvemConfigurada } from './nuvem.js';
import { somLigado } from './som.js';
import { permissao, notificacoesLigadas, pushDisponivel } from './notificacoes.js';

export function telaAjustes() {
  G.mode = 'ajustes'; limparTopo();
  const atual = fonteEscolhida();
  const estiloAtual = estiloSpriteAtual();
  // carrega todas as fontes da lista pra amostra sair na fonte certa
  for (const f of FONTES) if (!document.querySelector(`link[data-fonte="${f.id}"]`)) {
    const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = urlDaFonte(f); l.dataset.fonte = f.id; document.head.appendChild(l);
  }
  $('#app').innerHTML = `<main class="create">
    ${barraTelas('ajustes')}
    <h1>Ajustes.</h1>
    <p class="lead">Escolha a fonte que você lê melhor. Vale para o jogo inteiro, em qualquer jornada, e fica salva neste navegador.</p>
    <h3 class="passo"><span>A</span> Fonte</h3>
    <div class="fontes">${FONTES.map(f => `
      <button class="fonte-card ${f.id === atual.id ? 'on' : ''}" data-act="fonte" data-v="${f.id}" aria-pressed="${f.id === atual.id}" style="--f-display:${f.display};--f-corpo:${f.corpo}${f.titulo ? `;--f-titulo:${f.titulo}` : ''}">
        <b class="fonte-nome">${esc(f.nome)}${f.id === atual.id ? ' ✓' : ''}</b>
        <span class="fonte-amostra">Pikachu · Nv. 25 · 2 5 8 · ₽1.250</span>
        <small>${esc(f.desc)}</small>
      </button>`).join('')}</div>
    <p class="small muted" style="margin-top:14px">As fontes vêm do Google Fonts e ficam guardadas para o modo offline depois do primeiro uso.</p>
    <h3 class="passo"><span>B</span> Sprites</h3>
    <div class="subrow">${ESTILOS_SPRITE.map(e => `<button class="btn ${e.id === estiloAtual ? '' : 'ghost'} sm" data-act="estilo-sprite" data-v="${e.id}" aria-pressed="${e.id === estiloAtual}">${esc(e.nome)}${e.id === estiloAtual ? ' ✓' : ''}</button>`).join('')}</div>
    <p class="small muted" style="margin-top:8px">${esc(ESTILOS_SPRITE.find(e => e.id === estiloAtual)?.desc || '')} Se a imagem não existir pra algum Pokémon, cai de volta pro clássico sozinho.</p>
    <h3 class="passo"><span>C</span> Som e animações</h3>
    <p class="small muted">O som vem desligado por padrão. Liga o grito de quem aparece na luta, uma música gerada na hora (nunca é arquivo pronto — o jogo não usa trilha de terceiros) e o som de cada golpe ao acertar: labareda no fogo, lufada no vento, estalo no elétrico.</p>
    <label class="check"><input type="checkbox" id="pv-som" ${somLigado() ? 'checked' : ''}> Som ligado</label>
    <p class="small muted" style="margin-top:10px">As animações de combate são a tremida de quem apanha, a piscada na cor do tipo do golpe e o pulo de quem ataca. Desligar deixa o combate mais rápido: sem animação pra ver, as mensagens também param de esperar.</p>
    <label class="check"><input type="checkbox" id="pv-animacoes" ${animacoesLigadas() ? 'checked' : ''}> Animações de combate</label>
    <h3 class="passo"><span>D</span> Jogar offline</h3>
    <div id="offline-box">${htmlOffline()}</div>
    ${htmlNotificacoes()}
    ${htmlPresenca()}
    ${htmlAds()}
    ${htmlDev()}
  </main>`;
  mostrarEspaco();
  mostrarImagens();     // conta as imagens guardadas (assíncrono: a linha se preenche sozinha)
  mostrarImagens3D();       // idem, pras imagens 3D (download opcional, à parte)
  mostrarImagensAnimadas(); // idem, pros sprites animados
}

// Baixar um mapa inteiro pra jogar sem internet (offline.js). Sem isso, offline só aparece quem você já encontrou —
// e Pokémon novo fica sem sprite.
function htmlOffline() {
  const gen = genDe(G.S), r = dadosDaGen(gen), falta = quantoFalta(gen), total = alvosDaGen(gen).length;
  const velho = precisaRebaixar(gen), pronto = !falta && !velho;
  return `<p class="lead">Baixe os Pokémon de um mapa (dados, golpes e sprites) pra jogar sem internet sem faltar nada.
      O jogo já guarda sozinho o que você encontra; isto adianta o resto de uma vez.</p>
    <p class="small ${pronto ? 'ok-offline' : 'muted'}">${pronto ? `✅ Gen ${gen} (${esc(r.regiao)}) já está inteira neste aparelho.`
      : velho ? `⚠ Gen ${gen} (${esc(r.regiao)}) foi baixada por uma versão antiga: os Pokémon estão aqui, mas faltam as curvas de XP e as árvores de evolução — sem elas não dá pra <b>começar uma jornada</b> nem evoluir offline. Baixe de novo (o que já está guardado não desce outra vez).`
      : `Gen ${gen} (${esc(r.regiao)}): <b>${total - falta}/${total}</b> Pokémon guardados — faltam ${falta}.`}</p>
    <div class="subrow">${GENS.map(g => `<button class="btn ${g.gen === gen ? '' : 'ghost'} sm" data-act="baixar-gen" data-v="${g.gen}">⬇ Gen ${g.gen} · ${esc(g.regiao)}${jaBaixado(g.gen) ? ' ✅' : ''}</button>`).join('')}</div>
    <div class="subrow" style="margin-top:10px"><button class="btn" data-act="baixar-tudo">⬇⬇ Baixar o jogo inteiro (${TOTAL_GENS} mapas)</button>
      <span class="small muted">${quantoFaltaTudo() ? `faltam ${quantoFaltaTudo()} de ${totalDoJogo()} Pokémon`
        : GENS.every(g => jaBaixado(g.gen)) ? '✅ tudo guardado' : '⚠ os Pokémon estão todos aqui, mas há mapas baixados por uma versão antiga'}</span></div>
    <div class="subrow" style="margin-top:10px"><button class="btn ghost sm" data-act="baixar-imagens">🖼 Baixar só as imagens (Gen ${gen})</button>
      <span class="small muted" id="offline-imagens">conferindo imagens guardadas…</span></div>
    <div class="subrow" style="margin-top:10px"><button class="btn ghost sm" data-act="baixar-imagens-3d">🧊 Baixar sprites 3D também (Gen ${gen})</button>
      <span class="small muted" id="offline-imagens-3d">conferindo sprites 3D guardados…</span></div>
    <div class="subrow" style="margin-top:10px"><button class="btn ghost sm" data-act="baixar-imagens-animadas">🎬 Baixar sprites animados também (Gen ${gen})</button>
      <span class="small muted" id="offline-imagens-animadas">conferindo sprites animados guardados…</span></div>
    <div class="subrow" style="margin-top:10px"><button class="btn ghost sm" data-act="limpar-baixar">🗑 Limpar tudo e baixar de novo (Gen ${gen})</button>
      <span class="small muted">apaga o que está guardado da PokéAPI e baixa do zero — use se algo ficou pela metade. Não mexe nos seus saves nem na carreira.</span></div>
    <div id="offline-progresso" class="small muted" style="margin-top:8px"></div>
    <p class="small muted">São cerca de ${total} Pokémon por mapa e ${totalDoJogo()} no jogo inteiro. O jogo inteiro ocupa cerca de <b>20 MB</b> — são dados e sprites pequenos —, mas leva alguns minutos porque são milhares de pedidos: use uma rede boa e deixe a tela aberta.<span id="offline-espaco"></span></p>`;
}
/* chamado por main.js no clique; mostra o progresso sem redesenhar a tela toda. `gen` null = o jogo inteiro.
   `limpar` = apaga o que já está guardado antes de baixar (botão 🗑): baixar por cima só busca o que FALTA, então
   registro guardado pela metade continuaria lá pra sempre. */
export async function baixarMapaOffline(gen, limpar = false) {
  const el = () => document.getElementById('offline-progresso');
  if (!el()) return;
  if (offline()) { el().innerHTML = '📴 Sem internet agora: conecte pra poder baixar.'; return; }
  // sem service worker no comando, as imagens não ficam guardadas (offline.semServiceWorker explica)
  if (semServiceWorker()) {
    el().innerHTML = '⚠ <b>Recarregue a página antes de baixar</b> (F5). Agora ela está fora do controle do service worker — os dados seriam guardados, mas <b>as imagens não</b>, e você só descobriria sem internet.';
    return;
  }
  if (limpar) { el().innerHTML = 'Limpando o que estava guardado…'; await limparCache(); }
  el().innerHTML = 'Baixando…';
  const andar = (feitos, total, oQue) => { const p = el(); if (p) p.innerHTML = `Baixando ${esc(oQue)}… <b>${feitos}/${total}</b>`; };
  const r = gen ? await baixarGen(+gen, andar) : await baixarTudo(andar);
  const p = el(); if (!p) return;
  const oQue = gen ? `Gen ${gen}` : 'O jogo inteiro';
  // dado e imagem são pendências diferentes (offline.baixarGen): sem o dado não dá pra jogar, sem a imagem dá
  p.innerHTML = r.dadosOk && !r.imagens ? `✅ Pronto! ${oQue} guardado neste aparelho (${r.total} Pokémon e ${r.golpes} golpes).`
    : r.dadosOk ? `✅ ${oQue} dá pra jogar offline (${r.total} Pokémon e ${r.golpes} golpes) — mas ${r.imagens} imagem(ns) não desceram. Dá pra baixar de novo pra tentar só elas; o jogo funciona mesmo assim.`
    : `Terminou com ${r.falhas} falha(s) nos dados${r.imagens ? ` e ${r.imagens} em imagens` : ''} — dá pra tentar de novo, o que já baixou fica guardado.`;
  const box = document.getElementById('offline-box'); if (box) { box.innerHTML = htmlOffline(); mostrarEspaco(); mostrarImagens(); mostrarImagens3D(); mostrarImagensAnimadas(); }
}

/* Só as imagens (botão 🖼). Serve pro caso em que os dados estão inteiros e as figuras não — que acontece quando
   o download roda sem service worker no comando (ver offline.baixarImagens). Não rebaixa dado nenhum. */
export async function baixarImagensOffline(gen) {
  const el = () => document.getElementById('offline-progresso');
  if (!el()) return;
  if (offline()) { el().innerHTML = '📴 Sem internet agora: conecte pra poder baixar.'; return; }
  if (semServiceWorker()) { el().innerHTML = '⚠ <b>Recarregue a página primeiro</b> (F5): sem o service worker no comando, imagem baixada não fica guardada em lugar nenhum.'; return; }
  el().innerHTML = 'Baixando imagens…';
  const r = await baixarImagens(+gen, (f, t) => { const p = el(); if (p) p.innerHTML = `Baixando imagens… <b>${f}/${t}</b>`; });
  const p = el(); if (!p) return;
  p.innerHTML = r.ok ? `✅ Imagens da Gen ${gen} guardadas (${r.total} Pokémon).`
    : `Terminou com ${r.falhas} imagem(ns) que não desceram — dá pra rodar de novo, o que já veio fica guardado.`;
  mostrarImagens();
}
// quantas imagens do mapa atual estão guardadas de verdade (pergunta ao cache do service worker)
async function mostrarImagens() {
  const el = document.getElementById('offline-imagens'); if (!el) return;
  const gen = genDe(G.S), total = alvosDaGen(gen).length, n = await imagensGuardadas(gen);
  if (!document.getElementById('offline-imagens')) return;   // trocou de tela enquanto contava
  el.innerHTML = n === null ? '' : n >= total ? `✅ ${n}/${total} imagens guardadas.`
    : `⚠ só <b>${n}/${total}</b> imagens guardadas — sem internet, o resto aparece como figura quebrada.`;
}
/* Sprites 3D (⚙ Ajustes → Sprites): baixar é sempre OPCIONAL e À PARTE — ligar o modo 3D sem ter baixado ainda
   funciona igual (cai no clássico pelo onerror da <img>, ver render.spriteFrente); isto só adianta pra quem
   quer jogar offline já vendo o 3D em vez do clássico enquanto o 3D não chega da rede. */
export async function baixarImagens3DOffline(gen) {
  const el = () => document.getElementById('offline-progresso');
  if (!el()) return;
  if (offline()) { el().innerHTML = '📴 Sem internet agora: conecte pra poder baixar.'; return; }
  if (semServiceWorker()) { el().innerHTML = '⚠ <b>Recarregue a página primeiro</b> (F5): sem o service worker no comando, imagem baixada não fica guardada em lugar nenhum.'; return; }
  el().innerHTML = 'Baixando sprites 3D…';
  const r = await baixarImagens3D(+gen, (f, t) => { const p = el(); if (p) p.innerHTML = `Baixando sprites 3D… <b>${f}/${t}</b>`; });
  const p = el(); if (!p) return;
  p.innerHTML = r.ok ? `✅ Sprites 3D da Gen ${gen} guardados (${r.total} Pokémon).`
    : `Terminou com ${r.falhas} sprite(s) 3D que não desceram — dá pra rodar de novo, o que já veio fica guardado.`;
  mostrarImagens3D();
}
async function mostrarImagens3D() {
  const el = document.getElementById('offline-imagens-3d'); if (!el) return;
  const gen = genDe(G.S), total = alvosDaGen(gen).length, n = await imagensGuardadas3D(gen);
  if (!document.getElementById('offline-imagens-3d')) return;
  el.innerHTML = n === null ? '' : n >= total ? `✅ ${n}/${total} sprites 3D guardados.`
    : n === 0 ? 'nenhum sprite 3D baixado ainda (opcional)' : `${n}/${total} sprites 3D guardados.`;
}
export async function baixarImagensAnimadasOffline(gen) {
  const el = () => document.getElementById('offline-progresso');
  if (!el()) return;
  if (offline()) { el().innerHTML = '📴 Sem internet agora: conecte pra poder baixar.'; return; }
  if (semServiceWorker()) { el().innerHTML = '⚠ <b>Recarregue a página primeiro</b> (F5): sem o service worker no comando, imagem baixada não fica guardada em lugar nenhum.'; return; }
  el().innerHTML = 'Baixando sprites animados…';
  const r = await baixarImagensAnimadas(+gen, (f, t) => { const p = el(); if (p) p.innerHTML = `Baixando sprites animados… <b>${f}/${t}</b>`; });
  const p = el(); if (!p) return;
  p.innerHTML = r.ok ? `✅ Sprites animados da Gen ${gen} guardados (${r.total} Pokémon).`
    : `Terminou com ${r.falhas} sprite(s) animado(s) que não desceram — dá pra rodar de novo, o que já veio fica guardado.`;
  mostrarImagensAnimadas();
}
async function mostrarImagensAnimadas() {
  const el = document.getElementById('offline-imagens-animadas'); if (!el) return;
  const gen = genDe(G.S), total = alvosDaGen(gen).length, n = await imagensGuardadasAnimadas(gen);
  if (!document.getElementById('offline-imagens-animadas')) return;
  el.innerHTML = n === null ? '' : n >= total ? `✅ ${n}/${total} sprites animados guardados.`
    : n === 0 ? 'nenhum sprite animado baixado ainda (opcional)' : `${n}/${total} sprites animados guardados.`;
}
/* Preferência de cookies de anúncio (js/ads.js). Só aparece se a conta AdSense estiver configurada — sem isso,
   perguntar "aceita cookie de anúncio?" não faz sentido nenhum, porque não existe anúncio nenhum. */
function htmlAds() {
  if (!adsConfigurado()) return '';
  const c = consentimento();
  return `<h3 class="passo"><span>F</span> Cookies de anúncio</h3>
    <p class="small muted">Sua escolha atual: <b>${c === 'aceito' ? 'aceitou' : c === 'recusado' ? 'recusou' : 'ainda não escolheu'}</b>.
      Recusar não limita nada no jogo: só impede que o anúncio seja personalizado.
      Detalhes na <button type="button" class="link" data-act="privacidade" style="background:none;border:0;color:var(--yellow);text-decoration:underline;cursor:pointer;font:inherit;padding:0">Política de Privacidade</button>.</p>
    <div class="subrow">
      <button class="btn ${c === 'aceito' ? '' : 'ghost'} sm" data-act="ads-consentimento" data-v="aceito">Aceitar</button>
      <button class="btn ${c === 'recusado' ? '' : 'ghost'} sm" data-act="ads-consentimento" data-v="recusado">Recusar</button>
    </div>`;
}
/* Notificações do navegador (js/notificacoes.js): o aviso dentro da aba (🤖 auto-explorar, "achei o Pokémon") e,
   com conta, os LEMBRETES por push — o jogo fechado avisando que o seu Pokémon está esperando, que falta pouco
   pra uma badge ou que o chefe da semana trocou (js/lembretes.js escolhe o texto).
   A permissão SÓ pode ser pedida dentro de um clique — por isso é um botão, e não algo que o jogo tente sozinho
   ao abrir a tela. Recusou? O navegador não pergunta de novo; só as configurações do site resolvem, e o texto diz
   isso em vez de deixar um botão que não faz nada.
   A linha do push só aparece pra quem PODE recebê-lo (`pushDisponivel`: chave VAPID configurada e conta ligada) —
   prometer na tela o que não vai chegar é pior que não falar. */
function htmlNotificacoes() {
  const p = permissao();
  const explica = `<p class="small muted">O jogo avisa na tela de qualquer jeito; a notificação é pra quando você não está olhando — o Pokémon que você estava caçando apareceu, por exemplo.</p>
    ${pushDisponivel() ? '<p class="small muted">🔔 Com a sua conta ligada, o jogo também manda <b>lembretes</b> com ele fechado: o seu Pokémon esperando numa rota, um ovo quase chocando, uma badge a pouco do alvo, o chefe novo da semana. No máximo um por dia, e desmarcar aqui cancela na hora.</p>' : ''}`;
  if (p === 'sem-suporte') return `<h3 class="passo"><span>N</span> Notificações</h3>${explica}
    <p class="small muted">Este navegador não tem notificação. No iPhone, ela só funciona depois de adicionar o jogo à tela de início.</p>`;
  if (p === 'denied') return `<h3 class="passo"><span>N</span> Notificações</h3>${explica}
    <p class="small muted">🔕 Você bloqueou as notificações deste site. Pra liberar, é no cadeado ao lado do endereço — daqui o jogo não consegue perguntar de novo.</p>`;
  if (p === 'granted') return `<h3 class="passo"><span>N</span> Notificações</h3>${explica}
    <label class="check"><input type="checkbox" id="pv-notificacoes" ${notificacoesLigadas() ? 'checked' : ''}> Receber notificações</label>`;
  return `<h3 class="passo"><span>N</span> Notificações</h3>${explica}
    <div class="subrow"><button class="btn" data-act="notif-ligar">🔔 Ativar notificações</button></div>`;
}
/* Presença global (js/presenca.js): o "🟢 X jogando agora" da tela inicial + o registro (sem PII) de visitante
   sem conta. Só aparece com Supabase configurado — sem isso, presenca.js já é no-op e não tem o que desligar. */
function htmlPresenca() {
  if (!nuvemConfigurada()) return '';
  const on = presencaLigada();
  return `<h3 class="passo"><span>E</span> Presença global</h3>
    <p class="small muted">O jogo conta, sem guardar quem você é, se você está jogando agora — é o "🟢 jogando
      agora" da tela inicial. Detalhes na <button type="button" class="link" data-act="privacidade" style="background:none;border:0;color:var(--yellow);text-decoration:underline;cursor:pointer;font:inherit;padding:0">Política de Privacidade</button>.</p>
    <label class="check"><input type="checkbox" id="pv-presenca" ${on ? 'checked' : ''}> Contar minha presença</label>`;
}
/* 🧪 Painel de testes — só pra conta admin (dev.js explica o porquê e como virar admin).
   Existe pra validar mecânica sem jogar 1.000 batalhas: a Mega pede 1.000 golpes finais com a espécie, o que
   é inviável de checar à mão toda vez que o código muda. Tudo o que ele concede é marcado e reversível. */
function htmlDev() {
  if (!devLigado()) return '';
  return `<h3 class="passo"><span>🧪</span> Testes (conta de manutenção)</h3>
    <p class="small muted">Concede na marra o que normalmente leva muitas batalhas, pra dar pra validar as mecânicas.
      Tudo entra marcado como teste e sai junto no botão de limpar — o que você conquistou jogando não é tocado.</p>
    <div class="subrow">
      <button class="btn" data-act="dev-megas">⚡ Liberar todas as Megas</button>
      <button class="btn" data-act="dev-especies">🔓 Desbloquear todas as espécies</button>
      <button class="btn ghost" data-act="dev-gimmicks">💎 Encher Tera / Z-Move</button>
      <button class="btn ghost" data-act="dev-ivs">🧬 IVs perfeitos nas próximas jornadas</button>
      <button class="btn ghost" data-act="dev-limpar" ${temProgressoDeTeste() ? '' : 'disabled'}>🧹 Limpar o que foi de teste</button>
    </div>
    <p class="small muted" style="margin-top:10px">⏩ <b>Forjar a jornada em andamento</b>: põe o nível escolhido, ₽50.000 e 5 de cada item na
      mochila, pra caçar bug de fim de jogo sem jogar horas. Mexe só nesta run (não entra no progresso de teste).
      Itens de raide ficam de fora — eles iriam pro inventário da conta no fim da jornada.</p>
    <div class="subrow">
      <label>Nível <select id="dev-nivel">${NIVEIS_FORJA.map(n => `<option>${n}</option>`).join('')}</select></label>
      <button class="btn" data-act="dev-forjar" ${G.S?.player && G.mode !== 'battle' ? '' : 'disabled'}>⏩ Forjar jornada</button>
    </div>
    <div id="dev-msg" class="small muted" style="margin-top:8px">${temProgressoDeTeste() ? '⚠ Há progresso de teste ativo nesta conta.' : ''}</div>`;
}
// as concessões do painel de testes; `render` de novo pra tela refletir na hora
export async function acaoDev(qual) {
  if (!devLigado()) return;
  const msg = t => { const el = document.getElementById('dev-msg'); if (el) el.innerHTML = t; };
  // ⏩ forjar sai antes: é a única que mexe na run, espera as perguntas de evolução e já traz o resultado pronto
  if (qual === 'forjar') {
    const nivel = +(document.getElementById('dev-nivel')?.value || NIVEIS_FORJA[0]);
    const r = await forjarJornada(nivel);
    telaAjustes();
    return msg(r ? `⏩ Jornada forjada: nível ${r.nivel}, ${r.golpes} golpe(s) do learnset, ₽50.000 e 5 de cada item${r.evolucoes ? `, ${r.evolucoes} evolução(ões)` : ''}. Volte ao jogo pra continuar.`
      : '⚠ Não deu: precisa de uma jornada em andamento e fora de batalha.');
  }
  if (qual === 'megas') msg(`✅ ${liberarMegas()} espécies com a Pedra Mega liberada. Entre numa batalha com uma delas e o botão ⚡ aparece.`);
  else if (qual === 'especies') msg(`✅ ${liberarEspecies()} espécies desbloqueadas pra escolher na criação.`);
  else if (qual === 'gimmicks') { liberarOutrasGimmicks(); msg('✅ Contadores de Tera e Z-Move no alvo (essas gimmicks ainda não são jogáveis).'); }
  else if (qual === 'ivs') msg(`✅ Badge “Potencial máximo” conquistada (${liberarIvsPerfeitos().toLocaleString('pt-BR')} de dano). Toda jornada NOVA nasce com os 6 IVs em 31 — a atual continua como está, e “jogar sem vantagens” desliga.`);
  else if (qual === 'limpar') { const n = limparTeste(); msg(`🧹 Progresso de teste removido (${n} espécie(s)). O que veio de jogo continua.`); }
  telaAjustes();
}

// espaço que o jogo ocupa neste aparelho (dados + sprites), quando o navegador deixa consultar
async function mostrarEspaco() {
  const e = await espacoUsado(); const el = document.getElementById('offline-espaco');
  if (!e || !el) return;
  const mb = n => (n / 1024 / 1024).toFixed(1).replace('.', ',');
  el.innerHTML = ` Guardado agora: <b>${mb(e.usado)} MB</b>${e.total ? ` de ${mb(e.total)} MB disponíveis` : ''} (${itensNoCache()} itens).`;
}
