/* GERADO A MÃO: notas de atualização mostradas na tela 📜 Novidades (tela-patchnotes.js).
   O texto de cada ITEM aceita HTML simples (<b>, <br>) e é mostrado sem escapar — o conteúdo é escrito aqui,
   versionado junto com o código, e não vem de fora. Título, versão, seção e piada são escapados e devem ser
   texto puro.
   Mais nova primeiro. `versao` = rótulo curto, `data` = AAAA-MM-DD, `titulo` = manchete curta,
   `piada` = uma linha de humor no estilo "nota de bugfix absurda", `secoes` = [{ nome, itens: [texto] }].

   COMPILADO DUAS VEZES. Em 29/09/2026 as 96 versões originais (uma por leva de mudanças, com o mesmo assunto
   espalhado em cinco entradas) viraram 71. Em 03/10/2026 essas 71 viraram as 43 etapas de hoje: cada entrada
   conta um TEMA inteiro, da primeira versão ao estado atual — a leva de som num lugar só, a de ovos num lugar
   só —, e a numeração foi refeita em sequência (0.1 … 4.3), por isso ela não bate com a de antes. A data de
   cada etapa é a da última mudança que entrou nela. O detalhe cronológico fino está no histórico do repositório;
   aqui vale o que o jogador precisa saber sobre o jogo de hoje.
   Leva nova = uma entrada nova no topo, com o número seguinte. Fundir de novo só quando virar enxurrada. */
export const PATCH_NOTES = [
  { versao: '7.7', data: '2026-10-17', titulo: '🪨 Smack Down sem surpresa', piada: 'O Smack Down derrubava o alvo no chão e, de brinde, queimava, congelava ou paralisava. Ninguém pediu o brinde. O brinde foi devolvido.',
    secoes: [
      { nome: 'Correções', itens: [
        '<b>Smack Down e Thousand Arrows davam status aleatório</b> (relato #87). Todo acerto que não derrubava o alvo deixava ele queimado, congelado ou paralisado, sempre. Agora os dois só fazem o que dizem: derrubam quem voa e o deixam no chão. O <b>Tri Attack</b> continua com a chance dele de 20%.'
      ] }
    ] },
  { versao: '7.6', data: '2026-10-14', titulo: '➕ Totais na ficha', piada: 'Por meses, quem queria saber o total de IVs do seu Pokémon somava seis números de cabeça, errava, somava de novo e chegava a um terceiro resultado. A calculadora do celular agradece a folga.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>➕ Linha de Total na tabela de atributos.</b> No pé da ficha (seu Pokémon, aliados e quem está no esconderijo) agora aparece a soma de cada coluna: <b>Valor</b>, <b>Base</b> (o famoso total de base da espécie), <b>IV</b> (no máximo 186) e <b>EV</b> (no máximo 510). Dá pra ver de relance quanto treino ainda cabe e comparar dois Pokémon sem conta de cabeça.'
      ] }
    ] },
  { versao: '7.5', data: '2026-10-14', titulo: '🐺 Luta de cinco cabe e faz sentido', piada: 'Numa luta de três contra dois, as placas moravam num prédio no alto da cena e os Pokémon num porão lá embaixo, do tamanho de uma moeda. Agora cada um mora em cima da própria placa — e o Intimidate, que gritava três vezes seguidas só porque três inimigos entraram juntos, foi encaminhado a uma fonoaudióloga.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>📱 Cinco ou seis em campo, no celular em pé.</b> Cada Pokémon virou uma <b>coluna</b>: os inimigos numa fileira em cima (placa e, logo abaixo, o sprite), o seu lado numa fileira embaixo (sprite e, logo abaixo, a placa). Os sprites se encaram no meio, maiores do que antes, e <b>cada placa fica colada em quem ela descreve</b> — antes as placas ficavam empilhadas no alto e os sprites em miniatura lá no pé, e não dava pra dizer de quem era cada uma. Nome comprido quebra a linha em vez de virar "Dragon…".'
      ] },
      { nome: 'Correções', itens: [
        '<b>Intimidate disparando várias vezes</b> (relato #82). Quando um treinador mandava 2 ou 3 Pokémon de uma vez, as habilidades de entrada de <b>todo mundo em campo</b> rodavam uma vez <b>por Pokémon enviado</b>: com 3 inimigos, cada Intimidate baixava o Ataque três vezes — dos dois lados. Agora cada um entra uma vez só.'
      ] }
    ] },
  { versao: '7.4', data: '2026-10-14', titulo: '🍖 Oferecer petisco com um toque', piada: 'Fazer amizade com um selvagem era um ritual: abrir a Mochila, rolar até a divisão certa, achar o petisco que o bicho gosta, tocar, ver o turno passar, e repetir tudo de cabeça fria quatro vezes. O Mel Silvestre agora tem um botão próprio — e finalmente a ocupação mais honesta do Pokémon, ser comprado com comida, ficou a um toque de distância.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>🍖 Botão "Oferecer petisco".</b> Num selvagem, quando a mochila tem algum petisco, aparece um botão logo acima de <b>Mochila / Fugir</b>. Ele <b>escolhe sozinho o petisco que o Pokémon gosta</b> (o que você tem mais) e <b>repete a oferta, uma por turno</b>, até ele aceitar. Cinco ofertas enchem a amizade de qualquer Pokémon comum — então, na maioria das vezes, é <b>um toque só</b>. Funciona em todos os modos, <b>menos a ⚔ Saga</b>.',
        '<b>🛑 Para sozinho quando fica perigoso.</b> A repetição pára se o seu <b>HP chegar à metade</b>, se um <b>aliado cair</b>, se acabarem os petiscos que ele gosta ou depois de <b>5 ofertas</b> — e o registro diz qual foi o motivo, pra você decidir se cura ou segue. A <b>primeira oferta sempre sai</b>; o que o HP baixo corta é a repetição. Tem também o <b>⏹ Parar</b>, que termina a oferta em andamento e devolve o comando.',
        '<b>💡 Não gasta à toa.</b> Se nenhum petisco seu agrada o tipo dele — ou ele é <b>forte demais</b> pra confiar em você (acima do seu nível +5) —, o botão fica apagado e <b>diz por quê</b>, em vez de te deixar jogar o petisco fora. Sem petisco nenhum na mochila, o botão nem aparece.',
        '<b>🐺 Em luta de grupo</b> ele pergunta <b>pra quem</b> vai o petisco (a mesma escolha de alvo dos golpes), e o rótulo diz o nome.'
      ] },
      { nome: 'Correções', itens: [
        '<b>O chefe da semana aceitava petisco.</b> Quem passava do nível 65 podia fazer amizade com ele (o chefe nunca é mais fraco que o nível 70) — o que o evento existe pra impedir. Agora ele responde que <b>não é Pokémon de se conquistar com petisco</b>, igual ao Alfa.'
      ] }
    ] },
  { versao: '7.3', data: '2026-10-14', titulo: '📱 O jogo cabe na tela: luta, rota e criação reorganizadas', piada: 'No computador, o botão Explorar morava uns 350 pixels abaixo da dobra: quem entrava via um mapa, uma rota e nenhuma ideia de como começar. Ele agora fica de plantão na base da tela, fingindo que sempre esteve ali. Na luta, os golpes subiram para logo abaixo do campo de batalha — o Charmander agradece, que cansou de ouvir "role a página" no meio do turno.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>⚔ Os golpes ficam logo abaixo do campo.</b> Antes o registro da luta vinha no meio e, no computador, os golpes começavam pela metade da tela — dava pra ver meio Scratch. Agora a ordem é <b>cena → golpes → Mochila/Fugir → registro</b>, em qualquer tamanho de tela.',
        '<b>📱 A luta cabe no celular.</b> A placa do seu Pokémon deixou de ser cortada embaixo e ficou <b>ao lado</b> do sprite, como a do inimigo. Os golpes vêm <b>dois por linha</b>, com tipo, poder, PP e se o golpe vai bem ou mal contra quem está na frente; <b>Mochila</b> e <b>Fugir</b> dividem uma linha só.',
        '<b>🐺 Luta em grupo, sem bagunça.</b> Com 2 ou 3 inimigos e aliados em campo, as placas ficaram compactas: o <b>nome</b> numa linha, e na de baixo a barra de HP junto de uma nuvem de etiquetas — tipos, status, estágios (<b>Atq −2</b>) e item. Três inimigos + dois aliados com tudo isso cabem na tela, no celular em pé, no celular <b>deitado</b> (a cena vira duas colunas: <b>inimigos | você</b>) e no computador.',
        '<b>▶ Explorar sempre à mão.</b> O botão <b>Explorar</b> (com <b>Centro Pokémon</b> e <b>Abrir loja</b> embaixo) fica <b>preso na base da tela</b>, no computador e no celular. A <b>loja</b> abre no <b>topo</b>, com a carteira e o "Sair da loja" sempre à vista enquanto você rola.',
        '<b>🗺 Rotas numa fileira que rola.</b> No celular as 11 rotas viravam oito linhas de botões antes de qualquer informação. Agora é uma faixa que rola de lado, com a rota atual no meio. A legenda da Pokédex da rota virou um <b>"Como ler"</b> recolhido.',
        '<b>🧭 Barra de cima mais baixa.</b> Dentro do jogo ela mostra só o logo, a carteira e o <b>☰</b> (que agora abre em duas colunas, com um pontinho vermelho quando há Novidades). No computador eram uns 190 px de botões antes do jogo.',
        '<b>🆕 Criar a jornada ficou mais curta no celular.</b> As dificuldades não escolhidas mostram só duas linhas (a escolhida abre o texto inteiro), os mapas ficam em <b>três colunas</b>, as <b>Opções da jornada</b> e os <b>Chefes da semana</b> vêm recolhidos com um resumo — e o <b>Começar</b> acompanha você na base da tela. A página encolheu quase um terço.',
        '<b>🎒 Mochila legível.</b> Os botões <b>⚡ · Usar · Vender</b> descem pra baixo do nome do item (o "Full Heal" não quebra mais em três linhas), e voltam pro lado quando o painel é largo. No celular os botões ▲ ▼ ⇄ ▾ dos painéis ficaram do tamanho de um dedo.',
        '<b>🏁 Fim de jornada.</b> O <b>Nova jornada</b> acompanha a rolagem em vez de ficar depois das doze estatísticas.'
      ] },
      { nome: 'Correções', itens: [
        '<b>Loja no computador:</b> ao tocar em "Abrir loja" ela nascia uns mil pixels abaixo da tela e o botão simplesmente sumia — parecia que nada tinha acontecido.',
        '<b>Luta com aliados no celular:</b> a cena passava de 450 px (mais da metade da tela) e os golpes ficavam inalcançáveis sem rolar. E quando a cena é grande demais ela <b>solta</b> do topo em vez de ficar presa cobrindo os golpes.',
        '<b>Alfa e Lendários:</b> o <b>Desafiar</b> era amarelo cheio, igual ao <b>Explorar</b> — dois botões principais na mesma tela. Agora ele usa a cor da própria caixa.'
      ] }
    ] },
  { versao: '7.2', data: '2026-10-13', titulo: '🏁 Acabou: todo golpe do jogo faz algo', piada: 'Durante meses, usar Splash era indistinguível de usar Counter, Trick Room ou Wonder Room: todos anunciavam que o efeito seria ajustado em atualizações futuras e então, com grande dignidade, não faziam absolutamente nada. Hoje o futuro chegou para os 65 que restavam. O Splash continua não fazendo nada, mas agora é por escolha dele.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>🎒 Mexer no item do outro.</b> <b>Trick</b> e <b>Switcheroo</b> trocam o item com o inimigo, <b>Bestow</b> entrega o seu, <b>Corrosive Gas</b> destrói o dele, <b>Fling</b> arremessa o seu (quanto mais pesado, mais dói — uma Bola de Ferro bate muito mais que uma fruta), <b>Natural Gift</b> vira um golpe <b>do tipo da fruta</b> que você segura, <b>Recycle</b> traz de volta o item que você já gastou e <b>Teatime</b> faz <b>todo mundo em campo</b> comer a fruta que estiver segurando.',
        '<b>🎒 E o seu item sempre volta se você vencer.</b> Golpe que derruba ou troca item — inclusive o <b>Knock Off</b> e o <b>Thief</b>, que já existiam — agora anota o que era seu, e <b>no fim de uma batalha vencida você recupera</b>. A regra é uma: <b>o que era seu volta, o que você ganhou de mão vazia fica</b>. Então roubar continua valendo a pena, e nenhum inimigo leva o seu Restos pra sempre. Perder ou fugir não devolve — aí a perda vale.',
        '<b>⚔ Contra-ataque.</b> <b>Counter</b> devolve <b>o dobro</b> do último golpe físico que você levou no turno, <b>Mirror Coat</b> o dobro do especial, <b>Metal Burst</b> uma vez e meia de qualquer um, e <b>Bide</b> passa dois turnos encaixando porrada calado pra devolver <b>tudo em dobro</b> no terceiro. Se ninguém te acertou antes de você agir, eles falham — e dizem isso.',
        '<b>⏱ Mexer na ordem do turno.</b> <b>Trick Room</b> inverte a velocidade por 5 turnos: o <b>mais lento age primeiro</b> (prioridade, Garra Rápida e Stall continuam valendo por cima). <b>After You</b> faz o alvo agir em seguida, <b>Quash</b> o empurra pro fim da fila, e <b>Ally Switch</b> troca de lugar com um companheiro — os golpes mirados em você passam a ir nele.',
        '<b>🛡 Proteger o lado inteiro.</b> <b>Wide Guard</b> barra golpe de área, <b>Quick Guard</b> barra golpe de prioridade, <b>Crafty Shield</b> barra golpe de status, <b>Mat Block</b> barra golpe de dano (só na estreia), <b>Lucky Chant</b> tira o crítico do seu lado por 5 turnos e <b>Sticky Web</b> baixa a Velocidade de quem entrar em campo.',
        '<b>👁 Tirar a imunidade.</b> <b>Foresight</b> e <b>Odor Sleuth</b> fazem o Fantasma <b>levar golpe Normal e de Luta</b>; <b>Miracle Eye</b> faz o Sombrio levar Psíquico. O resto da tabela de tipos continua igual — some só a imunidade.',
        '<b>🏠 As salas e o campo.</b> <b>Wonder Room</b> troca Defesa com Def. Esp. de todo mundo, <b>Magic Room</b> desliga todos os itens segurados, <b>Mud Sport</b> e <b>Water Sport</b> cortam pela metade o dano Elétrico e de Fogo, <b>Ion Deluge</b> transforma golpe Normal em Elétrico, <b>Fairy Lock</b> impede qualquer fuga e <b>Court Change</b> <b>troca os campos de lado</b> — as suas telas vão pro inimigo e as armadilhas dele vêm pra você.',
        '<b>🔄 Os que dependiam de trocar de Pokémon.</b> <b>Healing Wish</b> e <b>Lunar Dance</b> sacrificam você pra deixar um <b>companheiro</b> totalmente curado (o Lunar Dance devolve os PP também), e <b>Revival Blessing</b> <b>levanta um companheiro caído</b> com metade do HP.',
        '<b>E a cauda inteira:</b> <b>Curse</b> (Fantasma paga meio HP pra sangrar o alvo 1/4 por turno; quem não é Fantasma se reforça), <b>Destiny Bond</b> (se você cair neste turno, leva quem te derrubou), <b>Grudge</b> (zera o PP do golpe que te derrubou), <b>Spite</b>, <b>Imprison</b> (sela os golpes que vocês dois sabem), <b>Embargo</b>, <b>Heal Block</b>, <b>Magic Coat</b> (reflete o status de volta), <b>Snatch</b> (<b>furta</b> o buff que o inimigo ia usar em si), <b>Psycho Shift</b>, <b>Camouflage</b>, <b>Conversion</b>, <b>Conversion 2</b>, <b>Reflect Type</b>, <b>Mind Reader</b>, <b>Lock On</b>, <b>Laser Focus</b>, <b>Spotlight</b>, <b>Octolock</b>, <b>Powder</b>, <b>Electrify</b>, <b>Present</b>, <b>Beat Up</b>, <b>Stockpile/Spit Up/Swallow</b>, <b>Trump Card</b>, <b>Power Shift</b> e <b>Throat Chop</b>.'
      ] },
      { nome: 'Correções', itens: [
        '<b>Chilly Reception estava escrito errado na tabela interna</b> desde que entrou (sem o hífen do nome real), e por isso <b>nunca funcionou</b> — nem a nevasca. Agora funciona, e com a saída de campo que faltava.',
        '<b>Snore e Sleep Talk eram inutilizáveis</b> por outro motivo que o anterior: a trava de sono respondia "está dormindo profundamente" e engolia o turno antes de eles saírem. Os dois existem <b>exatamente</b> pra funcionar dormindo.'
      ] }
    ] },
  { versao: '7.1', data: '2026-10-13', titulo: '🎭 Metronome, Transform e Substituto chegaram', piada: 'O Ditto passou o jogo inteiro usando Transform, que até ontem fazia exatamente nada — ou seja, ele se transformava em si mesmo, com sucesso, todas as vezes. Tecnicamente nunca falhou. Agora ele vira o inimigo de verdade, copia os golpes dele e descobre que ser um Gyarados é bem melhor que ser uma gosma.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>🪆 Substituto.</b> <b>Substitute</b> gasta 1/4 do seu HP máximo e põe um boneco no seu lugar: enquanto ele estiver de pé, <b>o golpe do inimigo bate nele</b>, e golpe de status <b>não passa</b> — nem paralisia, nem queda de atributo, nem Leech Seed, nem roubo de item, nem ser arrastado pra fora. O dano que sobra quando ele estoura <b>se perde</b>. Quem fura: golpe sonoro e companhia (os que ignoram substituto nos jogos) e quem tem <b>Infiltrator</b>. <b>Shed Tail</b> veio junto: custa metade do HP e você sai de campo com um aliado cobrindo.',
        '<b>🎭 Usar o golpe do outro.</b> <b>Metronome</b> sorteia um golpe na hora, <b>Mirror Move</b> devolve o último golpe do inimigo, <b>Copycat</b> repete o último golpe usado na luta por qualquer um, <b>Assist</b> pega um golpe de um companheiro, <b>Me First</b> rouba o golpe que o inimigo <b>ia usar</b> neste turno e bate com ele <b>50% mais forte</b>, e <b>Instruct</b> obriga o inimigo a <b>repetir</b> o golpe dele na hora.',
        '<b>😴 Sleep Talk e Snore funcionam dormindo</b> — que é o único momento em que eles deveriam funcionar e justamente o momento em que o jogo dizia "está dormindo profundamente" e engolia o seu turno. Sleep Talk sorteia um dos seus outros golpes; Snore bate normal. Acordado, os dois falham e <b>dizem que só funcionam dormindo</b>.',
        '<b>📝 Mimic e Sketch.</b> <b>Mimic</b> copia o último golpe do inimigo pro seu slot <b>até o fim da batalha</b> (com 5 PP). <b>Sketch</b> copia <b>para sempre</b> — é por isso que o Smeargle existe, e agora ele funciona: o golpe fica com você depois da luta, no save.',
        '<b>🌿 Nature Power</b> vira um golpe diferente conforme o chão: Tri Attack sem terreno, <b>Thunderbolt</b> no campo elétrico, <b>Energy Ball</b> na grama, <b>Moonblast</b> na névoa e <b>Psychic</b> no campo psíquico.',
        '<b>🎭 Transform.</b> Você vira uma <b>cópia do inimigo</b>: os tipos dele, os atributos dele, a habilidade dele, a cara dele e os 4 golpes dele com 5 PP cada. O <b>HP continua o seu</b>, como nos jogos. Tudo volta ao normal no fim da batalha.',
        '<b>🧠 Trocar habilidade.</b> <b>Role Play</b> copia a do inimigo, <b>Entrainment</b> impõe a sua a ele, <b>Skill Swap</b> troca as duas, <b>Doodle</b> dá a do inimigo pra você <b>e pros companheiros</b>, <b>Simple Beam</b> e <b>Worry Seed</b> trocam a dele por Simple e Insomnia, e <b>Gastro Acid</b> <b>anula</b> a habilidade dele até ele sair de campo — aquele Gengar com Levitate passa a levar golpe de Terra.'
      ] },
      { nome: 'Correções', itens: [
        'A <b>habilidade anulada</b> pelo Gastro Acid continua aparecendo na ficha, com o nome e tudo: o que ela deixa de ter é <b>efeito</b>. Esconder o nome seria tirar informação de quem está olhando.',
        'Habilidade que é <b>mecânica do jogo</b> (a troca de forma do Aegislash e a do Castform) não pode ser copiada, trocada nem anulada — esses golpes falham nela de propósito, em vez de embaralhar a forma no meio da luta.'
      ] }
    ] },
  { versao: '7.0', data: '2026-10-13', titulo: '🪐 Mais 39 golpes saíram do "será ajustado"', piada: 'Um jogador reclamou que o Gravity não fazia nada. Ele estava certo: o golpe anunciava que a gravidade ficava intensa e em seguida absolutamente nada acontecia, o que é uma descrição razoável de como a física funciona quando ninguém está olhando. Agora o Pokémon que flutua cai no chão, leva golpe de Terra e descobre que o Earthquake sempre esteve esperando por ele.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>🪐 A gravidade virou de verdade.</b> <b>Gravity</b> puxa <b>todo mundo em campo</b> pro chão por 5 turnos: quem é Voador (ou tem Levitate, ou está num Balão de Ar) perde a imunidade a golpe <b>Terrestre</b>, passa a sentir o terreno e a pisar nas armadilhas — e os golpes que saem do chão (Fly, Bounce, Magnet Rise…) <b>não podem mais ser escolhidos</b> enquanto ela durar.',
        '<b>🧲 E o contrário também.</b> <b>Magnet Rise</b> levanta você do chão por 5 turnos e <b>Telekinesis</b> levanta o inimigo por 3: golpe Terrestre passa embaixo. <b>Smack Down</b> e <b>Thousand Arrows</b> fazem o oposto — derrubam quem está no ar <b>de vez</b>, e nem o fim da gravidade o levanta de novo.',
        '<b>🪢 Agora prende de verdade:</b> <b>Bind, Wrap, Fire Spin, Clamp, Whirlpool, Sand Tomb, Magma Storm, Infestation, Snap Trap</b> e <b>Thunder Cage</b> seguram o alvo por <b>4 a 5 turnos</b>, tirando <b>1/8 do HP máximo</b> em cada um — e ele <b>não consegue fugir</b> enquanto estiver preso.',
        '<b>⏳ Os que resolvem no turno seguinte:</b> <b>Yawn</b> (o alvo fica com sono agora e <b>dorme no fim do próximo turno</b>), <b>Nightmare</b> (1/4 do HP por turno enquanto ele dorme — acorda e passa), <b>Wish</b> (metade do seu HP máximo volta no turno seguinte), <b>Ingrain</b> (cria raízes: cura 1/16 por turno, mas você não consegue mais sair), <b>Aqua Ring</b> (cura 1/16, sem o preço) e <b>Perish Song</b>, que condena <b>os dois lados</b> a desmaiar em 3 turnos.',
        '<b>📊 Atributos:</b> <b>Haze</b> apaga as mudanças de atributo de <b>todo mundo</b> (inclusive as suas), <b>Psych Up</b> copia as do alvo, <b>Topsy-Turvy</b> inverte as dele, <b>Belly Drum</b> paga metade do HP máximo pelo Ataque <b>no máximo</b>, <b>Pain Split</b> deixa os dois com a média do HP, e <b>Power/Guard/Heart Swap, Speed Swap, Power Trick, Guard Split</b> e <b>Power Split</b> trocam ou dividem os números com o alvo.',
        '<b>💥 Dano que não liga pra atributo:</b> <b>Sonic Boom</b> (20), <b>Dragon Rage</b> (40), <b>Seismic Toss</b> e <b>Night Shade</b> (o seu nível), <b>Psywave</b> (de 50% a 150% dele), <b>Super Fang</b> e <b>Nature&#39;s Madness</b> (metade do HP atual do alvo) e <b>Final Gambit</b>, que entrega todo o HP que você tem e te derruba junto. A tabela de tipos continua valendo: Night Shade não pega Normal.',
        '<b>E mais:</b> <b>Return</b> e <b>Frustration</b> agora medem a <b>amizade</b> de verdade (quanto mais vínculo, mais forte um; mais forte o outro), <b>Magnitude</b> sorteia o poder de 10 a 150, <b>Tri Attack</b> tem a chance de <b>queimar, congelar ou paralisar</b> que sempre devia ter, <b>Refresh</b> limpa o seu próprio status e <b>Sappy Seed</b> planta a semente do Leech Seed.',
        '<b>🙃 Splash, Celebrate e Happy Hour pararam de prometer.</b> Esses três <b>não fazem nada nos jogos</b> — então, em vez de "o efeito será ajustado em atualizações futuras", eles agora dizem com todas as letras que nada aconteceu. Prometer efeito pra golpe que não tem efeito é pior que não ter.'
      ] },
      { nome: 'Correções', itens: [
        '<b>🥚 "Só o primeiro casal do esconderijo põe ovo"</b> — não era: o ovo sempre saiu de um casal <b>sorteado</b>. O problema é que a linha do Ninho só falava do primeiro casal, e quem guardava dois pares achava que o segundo era ignorado. Agora ela diz <b>quantos casais</b> existem ali e, principalmente, <b>quem está no esconderijo sem par e por quê</b>: bebê (Riolu, Pichu, Igglybuff e cia. <b>só cruzam depois de evoluir</b>, como nos jogos), sem sexo (só com um Ditto), ou simplesmente sem ninguém que combine.',
        'A IA do inimigo aprendeu a usar tudo o que entrou agora — e, mais importante, aprendeu a <b>não</b> usar: nada de gastar quatro turnos bocejando em quem já está com sono, nem de puxar a gravidade sobre quem já está no chão.'
      ] }
    ] },
  { versao: '6.9', data: '2026-10-11', titulo: '✨ Uma Pokédex só para os brilhantes', piada: 'Perguntamos a um jogador quantos shinies ele já tinha visto na vida. Ele disse "uns seis, acho", olhou pro teto, mudou pra "quatro", e depois passou vinte minutos tentando lembrar se aquele Zubat de dois anos atrás era shiny ou se o monitor estava com a cor estranha. Agora tem uma tela que responde isso por ele.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>✨ A Pokédex ganhou um modo shiny.</b> O botão no topo da tela 📖 Pokédex troca a grade inteira por sprites <b>brilhantes</b> — e só acende quem você já viu assim. As 1025 espécies continuam lá, com as que faltam como "?", porque a graça é exatamente essa.',
        '<b>Três números próprios:</b> quantas <b>espécies</b> você já viu brilhando (de 1025), quantos <b>shinies no total</b> você encontrou e quantos deles <b>viraram seus</b>. Abrindo a ficha de alguém, a conta dele aparece junto com as outras.',
        '<b>Conta o encontro, não só o recrutamento.</b> Aquele shiny que fugiu, que você derrotou ou que simplesmente apareceu e a batalha terminou de outro jeito está na dex do mesmo jeito — ele apareceu pra você, e isso é o que a tela registra.',
        '<b>Shiny antigo:</b> os que você encontrou antes desta atualização só aparecem se você os <b>recrutou</b>. Até agora o jogo só levava pra carreira o shiny que virava seu; o encontro em si ficava na jornada e sumia junto com ela. A partir de hoje todo shiny que cruzar o seu caminho fica registrado pra sempre — um aviso na própria tela lembra disso.'
      ] }
    ] },
  { versao: '6.8', data: '2026-10-11', titulo: '🏠 O site ganhou uma porta de entrada', piada: 'Durante dois anos o endereço do jogo abria direto numa tela de escolher inicial, sem nunca explicar o que era aquilo. Quem chegava pelo link de um amigo tinha dez segundos pra deduzir sozinho que não ia comandar ninguém — ia SER alguém. Agora tem uma página dizendo isso, com todas as letras, antes de você ter que escolher entre três filhotes.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>🏠 O endereço do site agora abre uma página de apresentação</b>, com o que o jogo é, como é a primeira partida, o que tem dentro e as seis dificuldades — para quem nunca jogou entender antes de começar, e para quem conhece ter o que mandar junto com o link.',
        '<b>O jogo mudou de endereço: ele agora fica em <code>/jogar.html</code></b> (o botão <b>▶ Jogar</b> está no topo e no fim da apresentação). Se você salvou o site nos favoritos ou na tela inicial do celular, o atalho continua funcionando — ele leva à apresentação, e dali é um clique.',
        '<b>Convite de sala não mudou nada.</b> Todo link de multiplayer já enviado continua caindo direto no lobby, inclusive os antigos.',
        '<b>Sua jornada está intacta.</b> O save é do navegador e não tem nada a ver com o endereço: ele está lá, do jeito que você deixou.'
      ] }
    ] },
  { versao: '6.7', data: '2026-10-09', titulo: '🤝 Golpe de companheiro agora acha o companheiro', piada: 'Durante meses um Blissey leal usou Heal Pulse em todas as lutas e curou, sem exceção, a si mesma — enquanto o parceiro caía ao lado dela. Em paralelo, um Alcremie usava Decorate no inimigo, que agradecia e batia dois estágios mais forte. Os dois foram chamados para uma conversa sobre pontaria.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>🤝 Golpe que mira o seu lado agora mira o seu lado.</b> Com mais de um Pokémon em campo, <b>Helping Hand, Coaching, Howl, Heal Bell, Aromatherapy, Life Dew, Jungle Healing, Aromatic Mist, Dragon Cheer, Decorate, Heal Pulse, Floral Healing, Acupressure, Follow Me</b> e <b>Rage Powder</b> encontram quem deviam ter encontrado desde sempre: o alvo deles é <b>companheiro</b>, não o inimigo em foco.',
        '<b>Dois estavam fazendo o contrário do que prometiam:</b> o <b>Heal Pulse</b> curava <b>quem usou</b> em vez do parceiro ferido, e o <b>Decorate</b> subia <b>+2 de Ataque e At. Esp. do INIMIGO</b>. Pedimos desculpas a quem levou aquele golpe na cara logo depois.',
        '<b>Helping Hand</b>: o próximo golpe do companheiro neste turno sai <b>50% mais forte</b>.<br><b>Heal Bell</b> e <b>Aromatherapy</b>: limpam o status do <b>lado inteiro</b>.<br><b>Howl</b>: Ataque de todos.<br><b>Life Dew</b> e <b>Jungle Healing</b>: curam o lado todo (e o Jungle limpa o status).<br><b>Heal Pulse</b> e <b>Floral Healing</b>: vão pro <b>companheiro mais ferido</b> — sozinho, curam você mesmo.<br><b>Follow Me</b> e <b>Rage Powder</b>: o inimigo passa a <b>mirar em você</b> até o fim da rodada, que é o jeito de salvar um aliado pendurado no último HP.',
        '<b>Coaching</b> e <b>Dragon Cheer</b> não pegam quem usou: sem nenhum companheiro em campo, o golpe <b>avisa e falha</b> em vez de fingir que fez algo. <b>Hold Hands</b> também avisa — nos jogos ele não faz nada mesmo, e agora o jogo é honesto sobre isso.',
        '<b>Vale pros dois lados.</b> A matilha selvagem e o treinador com mais de um em campo usam tudo isso contra você — e a cabeça deles aprendeu que esse tipo de golpe <b>é desperdício quando estão sozinhos</b>.'
      ] }
    ] },
  { versao: '6.6', data: '2026-10-09', titulo: '🥚 O choco ganha uma revelação, e o lembrete perde a hora boa', piada: 'Um jogador dormiu com três ovos no ninho e os três chocaram durante a noite. O jogo, educadamente, esperou o sol nascer pra avisar — às 9h, quando ele já tinha aberto o jogo sozinho e visto tudo. Pedimos desculpas ao sol, que não tinha nada a ver com isso, e removemos a educação.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>🥚 O choco agora tem revelação</b> — quando um ovo abre de verdade, aparece um quadro com o <b>sprite do filhote</b>, não só uma linha no log. Chocou mais de um de uma vez (depois de uma noite fora, por exemplo)? Vem um quadro por ovo, em sequência.',
        '<b>🔔 O lembrete do ovo chega a qualquer hora</b> — inclusive de madrugada, se foi de madrugada que ele ficou pronto. Antes o aviso esperava a manhã (7–9h) ou a tarde (15–22h) e, com frequência, chegava depois de você já ter aberto o jogo sozinho. Vale pra todos os lembretes: badge quase feita, parceiro parado e chefe da semana também.'
      ] }
    ] },
  { versao: '6.5', data: '2026-10-08', titulo: '🔒 Cinco Pokémon que não existem (até você provar que merece)', piada: 'O Gimmighoul pediu 999 moedas pra evoluir e, quando entregamos, ele contou uma por uma, na nossa frente, em silêncio. Decidimos então que ninguém mais ganha um Gholdengo de graça. O Arceus, que criou o universo, concordou com a medida e pediu nove regiões de distância.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>🔒 Pokémon de missão</b> — cinco espécies agora <b>não existem no mundo</b> até a sua conta cumprir a missão delas. Não aparecem na rota, não entram na Pokédex da rota, não vêm na caça shiny e nenhum treinador carrega um. Cada missão soma a <b>carreira inteira</b> — todas as jornadas, qualquer modo — e nunca anda para trás.',
        '<b>🪙 Gholdengo</b>: junte <b>₽100.000.000</b> somando o maior saldo de cada jornada. São as 999 moedas do Gimmighoul em escala de carreira — uma jornada muito bem jogada chega a ₽3 milhões, então dá trabalho, e é pra dar.',
        '<b>👻 Spiritomb</b>: derrote <b>180.000</b> Pokémon. São 108 almas presas numa pedra, e nenhuma delas tem pressa.<br><b>⚙️ Melmetal</b>: derrote <b>50.000</b> do tipo <b>Aço</b>.<br><b>🥀 Shedinja</b>: choque <b>100 ovos</b> — ele é o que fica quando a vida sai da casca e a casca continua de pé.<br><b>✨ Arceus</b>: feche as <b>9 Gens no Roguelike</b>. O criador só aparece pra quem já viu o mundo inteiro.',
        '<b>Cumprida a missão</b>, a espécie passa a aparecer selvagem a partir da <b>próxima jornada</b> — e dali em diante funciona como qualquer outra: derrotar, fazer amizade ou evoluir pra ela a libera pra jogar.',
        '<b>Enquanto a missão não sai, a Pokédex completa daquela Gen espera por ela.</b> É o ponto: o bicho é o último selo da região.',
        'O progresso de cada uma está na tela <b>🏅 Conquistas</b>, com o número exato e quanto falta. <b>A missão é pública</b> — inclusive o sprite. Só o esforço é grande.'
      ] }
    ] },
  { versao: '6.4', data: '2026-10-08', titulo: '🔔 O ovo choca sozinho no relógio, e o seu Pokémon aprendeu a te ligar', piada: 'Uma auditoria interna encontrou 4.312 Pokémon parados no meio de uma rota, em pé, esperando ordens há semanas. Um Bidoof em Kanto já tinha montado barraca e começado a cobrar aluguel dos outros. Agora eles podem simplesmente te ligar.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>🥚 O ovo agora choca no relógio também</b> — <b>um minuto fora do jogo = um passo</b>, somando com as explorações. O ovo mais rápido abre em <b>1h40</b> sem você fazer nada, o mais demorado em <b>6h40</b>, e explorar continua adiantando. Fechou o jogo com um ovo no ninho? Ele avançou do mesmo jeito, e trinca no instante em que você voltar. A barra no painel de Aliados mostra quanto falta nas duas contas.',
        '<b>🔔 Lembretes</b> — com a conta ligada e as notificações ligadas em <b>⚙ Ajustes</b>, o jogo passa a te chamar de volta com ele <b>fechado</b>. Quatro motivos: o <b>🥚 ovo prestes a chocar</b> (este tem hora marcada, justamente porque o ovo anda sozinho), o <b>🎒 parceiro parado</b> numa rota há 10 horas (com nome, nível e onde ficou), a <b>🏅 badge com 90% andado</b> ("você está em 950 de 1.000") e o <b>🏆 chefe novo da semana</b>, na virada. E, quando sair versão nova, o aviso das <b>📜 Novidades</b>.',
        '<b>No máximo um por dia</b>, e sempre o motivo mais interessante — ovo passa na frente de badge, badge passa na frente do parceiro parado. Quem joga todo dia <b>nunca recebe nada</b>: o prazo conta da última vez que você abriu o jogo, então ele só vence pra quem parou de verdade.',
        '<b>E em hora de gente</b>: lembrete só chega das <b>7 às 9</b> e das <b>15 às 22</b>, no seu horário. Nada de madrugada — se o prazo vencer às 4 da manhã, o aviso espera o café.',
        '<b>O ovo continua secreto</b> na notificação: ela avisa que ele está prestes a abrir, nunca o que tem dentro.',
        '<b>Desmarcar cancela na hora</b> — o aparelho é desinscrito de verdade, não é uma caixinha que finge. E o texto do lembrete é escrito <b>no seu aparelho</b>, na última vez que você jogou: o servidor só entrega o envelope, ele não sabe nada do seu jogo.',
        'No <b>iPhone</b>, lembrete só chega depois de <b>adicionar o jogo à tela de início</b> — é limitação do Safari, não escolha nossa. No Android e no computador funciona com o navegador normal.'
      ] }
    ] },
  { versao: '6.3', data: '2026-10-08', titulo: '🥚 Criação de verdade: Pedra Eterna, Nó do Destino, golpes-ovo e um Ditto que finalmente serve pra algo', piada: 'O Ditto passou nove gerações sendo o profissional mais requisitado da criação de Pokémon e aqui ele estava sentado no esconderijo, sem gênero e sem convite, olhando os casais passarem. Pedimos desculpas formais. Ele se transformou num pedido de desculpas de volta.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>🫠 O Ditto cruza com qualquer um</b> — sem olhar sexo nem grupo-ovo, como nos jogos. E, mais importante: ele é o <b>único par de quem não tem sexo</b>. Magnemite, Voltorb, Beldum, Klink, Golett e companhia saíram de "não cruza com ninguém, nunca" pra "cruza, mas só com um Ditto" — que é exatamente a regra dos jogos. Dois Dittos continuam não dando nada, e a espécie do filhote vem sempre do outro lado (o Ditto nunca é a mãe, e o golpe herdado também não vem dele: ele só sabe Transform).',
        '<b>🪨 Pedra Eterna</b> (loja, divisão nova <b>🥚 Criação</b>) — na mão de um dos pais no esconderijo, o filhote nasce com a <b>natureza dele</b> em vez de uma das 25 sorteadas. Os dois segurando: sorteia entre as duas. Quer um filhote Adamant? Agora dá pra querer.',
        '<b>🪢 Nó do Destino</b> — na mão de um dos pais, o filhote herda <b>5 dos 6 IVs</b> do melhor dos dois, em vez de 3. Ele sobe <i>quantos</i>, nunca escolhe <i>quais</i>. Com um casal bom no esconderijo, cada ovo sai melhor que o anterior — é a criadoria dos jogos, sem a planilha.',
        '<b>🥚 Golpes-ovo</b> — cada espécie tem golpes que só se aprendem nascendo, e o filhote pode vir com um. Se um dos pais já sabe um golpe-ovo da espécie do bebê, ele <b>nasce sabendo</b>. E porque os pais daqui são selvagens recrutados (e selvagem só sabe golpe de nível), há também uma chance de sortear um da lista da espécie — senão a mecânica nunca apareceria. O log diz na hora, com o selo 🥚.',
        '<b>🗺 Forma regional no ovo</b> — mãe de forma regional põe filhote da forma regional daquele mapa. A Sandslash de Alola punha um Sandshrew de Kanto; agora põe um de Alola.',
        'Tudo isso, com as chances exatas, está na tela 📈 <b>Taxas</b>.'
      ] }
    ] },
  { versao: '6.2', data: '2026-10-08', titulo: '📦 O esconderijo deixou de ser um armário escuro: cada guardado tem ficha', piada: 'Até agora o esconderijo funcionava como uma caixa de meias: você sabia que tinha seis lá dentro, sabia o nome de todas, e descobria qual era a boa calçando. Instalamos luz.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>📦 Ficha de quem está no esconderijo</b> — no painel de <b>Aliados</b>, cada parceiro guardado agora abre em <b>"Ver ficha completa"</b>: a tabela de atributos com <b>valor, base, IV e EV</b>, a <b>natureza</b> (com o ▲▼ de qual stat ela sobe e desce), o vínculo, a habilidade e os <b>quatro golpes</b> com tipo, poder, precisão, PP e descrição. É a mesma ficha de um aliado em campo.',
        'Pra que serve: <b>escolher quem trazer de volta sabendo o que está trazendo</b> — e escolher quem fica no ninho, já que o filhote herda <b>3 IVs do melhor dos dois pais</b>. Antes, isso era chute: a caixa mostrava sprite, nome, sexo e nível, e nada mais.',
        'A ficha é <b>só leitura</b>. Reordenar golpe e trocar item segurado continuam valendo pra quem está na equipe: traga o bicho de volta e mexa à vontade.'
      ] }
    ] },
  { versao: '6.1', data: '2026-10-08', titulo: '\ud83c\udf3f Rotas em potencial máximo: 500 amizades e a rota inteira nasce no teto', piada: 'Pedimos ao departamento de genética que elevasse ao máximo o potencial de todos os Pokémon selvagens das rotas. Eles cumpriram. Ninguém pensou em avisar que isso incluía os selvagens que querem te bater. O departamento alega que o pedido dizia "todos".',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>\ud83c\udf3f Rotas em potencial máximo</b> — badge nova de conta, e a segunda de toda a lista que muda uma <b>regra</b> do jogo em vez de dar item. <b>Recrute 500 aliados</b> somando a carreira inteira e, daí em diante, <b>todo Pokémon selvagem das rotas nasce com os 6 IVs em 31</b>, o teto.',
        '<b>O que isso te dá:</b> todo amigo que você fizer com um petisco vem <b>perfeito</b> — e, como os ovos saem do casal que mora no seu esconderijo, os filhotes herdam de pais perfeitos. É a badge \ud83e\uddec <b>Potencial máximo</b> (o 1.000.000 de dano, que põe os <i>seus</i> IVs em 31) vista do outro lado do campo.',
        '<b>E o que ela te cobra,</b> porque ninguém merece descobrir isso na pancada: <b>quem te enfrentar também nasce no teto</b>. Rota nenhuma vai ficar mais fácil. Alfa, lendário e chefe de rota já vinham com IVs 31 desde sempre, então pra eles nada muda; a equipe de um treinador continua sorteando os dela, porque aquele Pokémon é do treinador, não da rota.',
        'Como toda badge, ela desliga junto no <b>\ud83c\udf96 jogar sem as vantagens da conta</b> — o bônus de pontuação do desafio puro continua sendo do desafio puro.'
      ] },
      { nome: 'Correções', itens: [
        'Na tela \ud83c\udfc5 <b>Conquistas</b>, a badge <b>Potencial máximo</b> aparecia com <b>"Dá: —"</b>, como se não pagasse nada — justamente a badge mais longa do jogo. A lista só sabia descrever prêmio de item, dinheiro e loja grátis; agora ela diz o que a vantagem de regra faz.'
      ] }
    ] },
  { versao: '6.0', data: '2026-10-07', titulo: '🐉 O Mega Rayquaza não era um chefe, era um alvo — e a Sala de Raide ganhou impacto', piada: 'O Mega Rayquaza foi contratado como chefe de raide e passou o contrato inteiro levando o dobro de pancada de todos os colegas, em silêncio, por um número copiado da ficha errada. Perguntado se havia notado, respondeu que sim, mas que não quis fazer escândalo. Corrigimos o número. Ele agora faz escândalo.',
    secoes: [
      { nome: 'Correções', itens: [
        '<b>O Mega Rayquaza era, de longe, o chefe de raide mais fácil do jogo</b> — e por um motivo bobo. Ele é o único chefe <b>sem couraça</b>, de propósito: o desafio dele é acertar a janela do ponto fraco, que gira a cada duas ações. Só que o bônus de acertar essa janela tinha sido copiado dos chefes que <b>têm</b> couraça, onde ele é cortado pela redução dela. Sem couraça pra cortar, o bônus ficou solto — e como os cinco tipos da janela são justamente as fraquezas naturais de um Dragão/Voador (Gelo é ×4 nele!), tudo <b>empilhava</b>.',
        '<b>Na prática:</b> ele levava <b>175</b> de dano onde o segundo chefe mais frágil levava 87 e a média do elenco era 45. De duas a quatro vezes mais mole que os outros quinze. Agora acertar a janela vale o que vale nos irmãos dele, e <b>errar a janela custa bem mais caro</b> — a luta virou o quebra-cabeça que ela sempre quis ser. <i>(Relato #81 — obrigado, e desculpe a vitória fácil!)</i>',
        '<b>E a regra que faltava:</b> fora da 💥 RUPTURA, a defesa de um chefe agora só pode <b>reduzir</b> dano, nunca aumentar. Um teste confere isso nos dezesseis, então nenhum chefe novo nasce com o mesmo engano.'
      ] },
      { nome: 'Novidades', itens: [
        '<b>💥 A Sala de Raide e a Arena agora tremem.</b> Quem apanha sacode e <b>pisca na cor do tipo do golpe</b>, e o som do impacto toca — labareda pro fogo, lufada pro vento, estalo pro elétrico. Era o que a batalha de um jogador já fazia desde sempre; a sala era a única tela do jogo onde a luta acontecia em <b>silêncio absoluto</b>, com os cartões parados, e isso fazia até o chefe mais pesado parecer de papel. <i>(Mesmo relato #81: "as animações do Boss parecem estar fracas". Não estavam fracas — não existiam.)</i>',
        'Como sempre, quem desligou <b>animações</b> ou <b>som</b> em ⚙ Ajustes não recebe nenhum dos dois: cada metade se cala sozinha.'
      ] }
    ] },
  { versao: '5.9', data: '2026-10-07', titulo: '🪨 Rock Slide, agora de verdade (e a caixa dos lendários cabendo na tela)', piada: 'A correção anterior consertava o alcance dos golpes indo perguntar o alcance deles pela internet, toda vez, e desistindo em silêncio quando a internet não atendia. É o equivalente a ligar para a prefeitura todas as manhãs para confirmar que a sua rua continua no mesmo lugar. A rua continua no mesmo lugar. Anotamos num papel.',
    secoes: [
      { nome: 'Correções', itens: [
        '<b>Golpe de área continuava pegando um alvo só — mesmo depois da correção de ontem.</b> Rock Slide, Earthquake, Surf e companhia agora pegam o grupo inteiro de verdade, com qualquer jornada, qualquer aparelho e <b>sem precisar de internet</b>. <i>(Relatado duas vezes pelo mesmo jogador, com toda a razão — obrigado!)</i>',
        '<b>O que estava errado:</b> a correção de ontem consertava o dado <b>buscando ele na internet</b> ao abrir a jornada. Quando a busca não completava — rede ruim, aba já aberta, jogo offline — o golpe continuava sem saber o próprio alcance, e nada avisava. Agora <b>quem o golpe alcança vem junto com o jogo</b>, numa tabela que não depende de nada: o alcance do Rock Slide não muda, então não havia razão nenhuma pra ele ser perguntado a cada partida.',
        '<b>A caixa dos lendários não cabia na tela do celular.</b> Os sprites atravessavam a borda, o texto quebrava uma palavra por linha, o botão <b>⚔ Enfrentar</b> ficava por cima de tudo e a página inteira rolava pro lado. A fileira de lendários agora ocupa a linha dela e quebra em duas quando precisa, e o botão desce pra baixo do texto em tela estreita.',
        '<b>De quebra:</b> o último lendário da fileira (o chefão da Gen) voltou a aparecer <b>maior que os outros</b>, como era pra ser desde o começo.'
      ] }
    ] },
  { versao: '5.8', data: '2026-10-07', titulo: '👾 A fonte pixelada voltou — e o Rock Slide voltou a ser Rock Slide', piada: 'A fonte pixelada havia sido demitida por justa causa depois que um jogador leu "₽2.580" como "₽5.280" e tomou decisões financeiras com base nisso. Ela recorreu, alegando que o problema não era ela, era o departamento de contabilidade estar usando ela. Tinha razão. Foi recontratada para o departamento de placas, onde não há um único número.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>👾 Fonte Pixelada, em ⚙ Ajustes → Fonte.</b> Agora são <b>treze</b>. Ela já tinha estado no jogo e tinha <b>saído</b>, porque num jogo que mostra HP, dano e ₽ o tempo todo um 5 que parece 8 não é estilo, é defeito.',
        '<b>O que mudou não foi a fonte — foi onde ela entra.</b> O pixel agora fica <b>só nos títulos</b>: nome do Pokémon, nome da rota, nome da tela. O nível, o HP, o dano e o dinheiro saem numa <b>monoespaçada</b> (números alinhados, dígito nenhum parecido com outro), e a narração da batalha numa fonte de <b>alta legibilidade</b>, que é o texto que você mais lê.',
        'Ou seja: dá pra ter a cara de jogo de Game Boy <b>sem</b> precisar adivinhar quanto de HP sobrou.'
      ] },
      { nome: 'Correções', itens: [
        '<b>Golpe de área não estava pegando em área pra quem já jogava.</b> Rock Slide, Earthquake, Surf — todos continuavam batendo num inimigo só, mesmo depois da atualização que fez eles pegarem o grupo inteiro. <i>(Relatado na mesma hora — obrigado!)</i>',
        '<b>O motivo:</b> cada golpe guarda <b>quem ele alcança</b>, e esse dado passou a ser gravado no seu aparelho em setembro. Golpe que o jogo tinha guardado <b>antes</b> disso não sabia dizer o próprio alcance — e nada mandava buscar de novo, então ele ficava desatualizado pra sempre. Enquanto todo golpe batia num alvo só, isso não fazia diferença nenhuma. No dia em que a área passou a existir, fez.',
        '<b>Agora o jogo conserta sozinho.</b> Ao abrir uma jornada, ele completa em segundo plano o que estiver faltando nos golpes seus, dos aliados e de quem está no esconderijo — você não precisa fazer nada, e nem vai perceber. Quem joga <b>offline</b> vai ver o mapa pedir pra ser <b>baixado de novo</b>: é de propósito, porque no avião não há de onde buscar o dado que falta.'
      ] }
    ] },
  { versao: '5.7', data: '2026-10-07', titulo: '🔤 Mais três fontes, uma delas com serifa', piada: 'Pedimos ao departamento de tipografia três fontes bonitas. Ele voltou com quarenta, todas lindas, e em onze delas o 5 e o 8 eram a mesma letra usando chapéus diferentes. Ficamos com três. As outras trinta e sete seguem no portfólio dele, que é muito bonito e que ninguém consegue ler.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Três fontes novas em ⚙ Ajustes → Fonte</b>, agora <b>doze</b> no total. Cada uma é um estilo que ainda <b>não existia</b> na lista — não é "mais uma redondinha".',
        '<b>Fofinha:</b> pontas arredondadas e traço cheio, a cara de menu de jogo japonês. É a mais "jogo" de todas.',
        '<b>Divertida:</b> letra saltitante nos títulos, firme e calma no texto. Diverte onde dá pra divertir e se comporta onde você precisa ler.',
        '<b>Livro de aventura:</b> a <b>única com serifa</b> do jogo. Num RPG que é feito de texto, ler a narração da batalha com cara de livro muda bastante a sensação — vale experimentar pelo menos uma luta.',
        'E a regra de sempre: <b>2, 5 e 8 impossíveis de confundir</b> em todas as doze. Num jogo que mostra HP, dano e dinheiro o tempo todo, dígito ambíguo não é estilo, é defeito — e é por isso que nenhuma fonte pixelada entra na lista, por mais que ela combinasse.'
      ] }
    ] },
  { versao: '5.6', data: '2026-10-07', titulo: '💥 Terremoto que acerta um Pokémon só acabou', piada: 'Durante anos o Earthquake deste jogo abalava a crosta terrestre inteira e, por uma questão de etiqueta, derrubava apenas o Pokémon para quem havia sido formalmente apresentado. Os outros dois assistiam de pé, a meio metro de distância, achando aquilo muito estranho e não comentando por educação.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Golpe de área agora pega em área.</b> <b>Earthquake</b>, <b>Surf</b>, <b>Rock Slide</b>, <b>Discharge</b>, <b>Hyper Voice</b>, <b>Heat Wave</b> e toda a família acertam <b>todo mundo que o golpe alcança</b>, em vez de um só. Agora que o jogo tem manada de um lado e aliados do outro, era o que faltava pra eles existirem de verdade.',
        '<b>E eles não escolhem lado.</b> Os que pegam só o <b>outro lado</b> (Rock Slide, Muddy Water) limpam o grupo inimigo sem risco. Os que pegam <b>todo mundo em volta</b> (Earthquake, Surf, Discharge) <b>respingam no seu próprio aliado</b> — o que, por acaso, também vale pro inimigo, que agora pensa duas vezes antes de usar um com o bando dele em campo.',
        '<b>Pegando mais de um, o dano em cada alvo sai 25% menor</b>, como nas batalhas duplas dos jogos. Pegando um só, sai cheio. Área é alcance, não dano grátis.',
        '<b>Damp acordou.</b> Com um <b>Psyduck</b>, <b>Golduck</b>, <b>Politoed</b> ou <b>Wooper</b> em campo — <b>de qualquer um dos dois lados</b> —, <b>ninguém</b> consegue usar Explosion ou Self-Destruct. O <b>Aftermath</b> de quem cai também fica mudo. É a habilidade inteira, exatamente como nos jogos.',
        '<b>Telepathy também.</b> Quem tem não leva golpe de área do próprio colega: o seu Earthquake passa por baixo dele.',
        '<b>Friend Guard, Battery, Power Spot, Steely Spirit e Plus/Minus agora valem do lado inimigo também.</b> Elas dependem de ter um aliado ao lado, e até aqui o jogo só enxergava um Pokémon por vez do outro lado da cena — então na prática elas nunca ligavam numa manada. Ligam.'
      ] },
      { nome: 'Correções', itens: [
        '<b>"Pokémon derrotados" da sua carreira não batia com o das conquistas.</b> Quando você derrubava uma manada de 3, a carreira contava 3 e as conquistas contavam <b>1</b> — o jogo só creditava o Pokémon principal da luta. Quem jogou muito com grupo tinha centenas de abates sumindo das insígnias. Agora cada um que cai conta, com o golpe e o tipo certos. <i>(Relato #80 — obrigado!)</i>',
        '<b>E o contador de dano da insígnia "Potencial máximo" só via o alvo em foco.</b> Dano que respingasse no resto do grupo não entrava na conta. Agora ele mede o lado inimigo inteiro, antes e depois do seu golpe. <i>(Relato #79)</i>'
      ] }
    ] },
  { versao: '5.5', data: '2026-10-06', titulo: '📈 Todas as chances do jogo, numa tela só', piada: 'O setor de estatística do jogo passou dois anos calculando as taxas num caderno e se recusando a mostrar a quem perguntava, alegando sigilo metodológico. O caderno foi finalmente localizado. Era o código-fonte, que estava ali o tempo todo, e agora ele se imprime sozinho.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Tela 📈 Taxas:</b> tudo o que o jogo sorteia, com o número de verdade. O que cada clique em <b>Explorar</b> pode dar, <b>qual item você acha</b> e com que chance, a taxa de um <b>Pokémon brilhante</b>, de onde sai a <b>taxa de aparição</b> de uma espécie na rota, a chance de cair numa <b>manada</b> rota por rota, quantos Pokémon um <b>treinador</b> tem e o que eles carregam, a <b>fórmula da captura</b> balanço por balanço, os passos de um <b>ovo</b>, o <b>crítico</b> por degrau, quanto dura cada <b>status</b>, de onde vem cada ₽ e cada ponto de <b>XP</b>, e como a <b>pontuação</b> da jornada é montada.',
        '<b>Nada ali é estimativa.</b> Cada porcentagem da tela é lida da <b>mesma constante que o sorteio usa</b> — não é um texto escrito à mão que alguém precisa lembrar de atualizar. Se uma chance mudar no jogo, ela muda na tela no mesmo instante.',
        'Está em <b>📈 Taxas</b>, junto das outras telas (menu ☰ no celular). As taxas de <b>cada espécie</b> continuam onde já estavam: na Pokédex da rota, no 📖 da tela de explorar, que mostra a porcentagem exata de quem vive ali.'
      ] }
    ] },
  { versao: '5.4', data: '2026-10-06', titulo: '🥎 O caçador agora mira nos seus aliados — e ser capturado virou a sua última cartada', piada: 'Um caçador passou a carreira inteira ignorando o Pokémon selvagem que lutava ao seu lado, porque ele tecnicamente não constava no formulário. O formulário foi atualizado. Ele pediu para avisar que agora tem interesse em todos e que o interesse é recíproco em relação ao cinto dele.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>A bola do treinador não é mais só pra você.</b> Com o HP na metade ou menos, ele mira em <b>qualquer um do seu lado</b> — e escolhe o <b>mais fraco</b>, porque é o que um caçador faria. Antes ele olhava o seu companheiro lutando ao seu lado e, por algum motivo, não tinha interesse nenhum.',
        '<b>E ser capturado deixou de ser o fim na hora.</b> Se a bola se fechar em você e <b>ainda houver aliado de pé</b>, a luta <b>continua sem você</b>: eles partem pra cima do treinador, e <b>derrotar ele te liberta</b>. A tela mostra quem ainda está lutando por você. Se todos caírem, aí sim ele te leva embora.',
        '<b>Aliado preso volta se você vencer.</b> A bola se abre no fim da luta e ele continua na sua equipe, como se nada tivesse acontecido.',
        '<b>Mas se você fugir ou perder, ele fica com o treinador — e você não o vê mais.</b> É perda definitiva, igual à do Roguelike. Fugir de uma luta em que um companheiro seu está dentro de uma bola passou a ser uma decisão de verdade.',
        'Nos modos <b>Fácil</b> e <b>Médio</b> você continua sempre escapando da bola no último segundo. O aliado, não — mas como ele volta ao vencer, a promessa daqueles modos (a sua jornada não acaba por captura) continua valendo inteira.'
      ] }
    ] },
  { versao: '5.3', data: '2026-10-06', titulo: '🐺 Matilhas, enxames e cardumes — e o treinador que joga 3 Pokémon de uma vez', piada: 'Os Weedle da Floresta de Viridian estavam sindicalizados desde 2026 e ninguém havia notado. Eles andam em 24. Conseguimos negociar para 3 por vez. O representante do sindicato pediu para registrar que foi uma concessão generosa e que eles poderiam ter vindo em 24.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Pokémon selvagem agora anda em grupo.</b> Um <b>enxame</b> de Weedle, um <b>cardume</b> de Magikarp, uma <b>revoada</b> de Pidgey, uma <b>alcateia</b> de Houndour — a palavra sai do tipo que eles têm em comum, e cada um dos 18 tipos tem a sua.',
        '<b>Não é sempre.</b> As <b>três primeiras rotas nunca</b> têm grupo: jornada nova começa no Nv. 5 e sozinha, e cair numa manada ali não é dificuldade, é fim de jogo sem nenhuma decisão no meio. Da quarta rota em diante a chance sobe, até cerca de <b>35%</b> na última do mapa.',
        '<b>E o grupo nunca é maior que o seu lado + 1.</b> Sozinho, você enfrenta no máximo <b>2</b>; com um aliado, até <b>3</b>. Ou seja: <b>recrutar com petisco virou resposta à manada</b>, não só conforto. Cada um do grupo dá XP, EVs e conta na Pokédex — mais perigo, mais retorno.',
        '<b>Treinadores agora têm até 6 Pokémon.</b> O de 6 é <b>raro</b> e só aparece em rota avançada — e quando aparece, o jogo avisa.',
        '<b>E eles não mandam mais um por vez.</b> Cada treinador tem um <b>campo</b> de <b>1, 2 ou 3</b> Pokémon ao mesmo tempo, e <b>só o de 6 consegue pôr 3</b>. Então um treinador de 6 pode te dar <b>seis lutas de um</b>, três de dois, ou <b>duas ondas de três</b> — e as três são lutas completamente diferentes. Derrubou a onda? Ele <b>repõe o campo inteiro</b>.',
        '<b>A barra de turno passou a mostrar quem é quem:</b> <b>◉</b> em campo · <b>●</b> esperando no banco · <b>○</b> derrotado. Antes eram bolinhas iguais e não dava pra saber quantas ondas ainda vinham — que é justamente o que decide gastar a Poção agora ou guardar.',
        'Quem entra numa troca <b>não ataca naquela rodada</b>: a janela é sua.'
      ] }
    ] },
  { versao: '5.2', data: '2026-10-06', titulo: '🥚 O ninho agora diz o que está acontecendo (os ovos sempre funcionaram — ninguém sabia como)', piada: 'Dois Nidoran passaram a jornada inteira guardados no esconderijo, de sexos opostos, perfeitamente compatíveis, esperando autorização por escrito. A autorização existia desde o começo. O aviso é que não existia. Pedimos desculpas aos Nidoran e instalamos uma placa.',
    secoes: [
      { nome: 'Correções', itens: [
        '<b>O painel de Aliados passou a explicar o ninho.</b> Os ovos funcionam desde que foram feitos, mas nada na tela contava a regra: o esconderijo só falava em "esperar aqui", e a barra do ovo só aparecia <b>depois</b> que já havia um ovo. Dava pra jogar uma jornada inteira sem descobrir que dava pra criar.',
        '<b>Agora o ninho fala, mesmo vazio:</b> "guarde dois aqui e eles podem deixar um ovo" · "só um aqui, guarde mais um de sexo oposto" · <b>"Nidoran♀ e Nidoran♂ se dão bem: pode aparecer um ovo"</b> (com os nomes, em verde) · "são todos do mesmo sexo, não vai sair ovo" · "precisam de um grupo-ovo em comum" · "alguém aqui não tem sexo e não cruza".',
        'E quando o jogo ainda <b>não sabe</b> se os dois combinam (a ficha da espécie não está guardada no aparelho), ele diz isso — <b>"ainda não sei, explore um pouco e eu confiro"</b> — em vez de dizer que não dá. Prometer "não" quando a verdade é "não sei" faz desistir de algo que ia funcionar.',
        'Lembrete que a tela agora dá de graça: o ninho é o <b>esconderijo</b>, não a equipe. Quem está lutando com você não bota ovo.'
      ] }
    ] },
  { versao: '5.1', data: '2026-10-06', titulo: '📦 Rotas e missões podem ser atualizadas sem atualizar o jogo', piada: 'A missão da Rota 1 pedia 24 Rattata porque alguém digitou 24 numa planilha em 2026 e aquilo virou lei do universo. Agora a lei do universo pode ser alterada por quem digitou, de onde ele estiver, sem reiniciar o universo. O Rattata pediu vista do processo.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Conteúdo do jogo deixou de depender de atualização do jogo.</b> As rotas e as missões agora chegam num <b>pacote guardado no seu aparelho</b>: o jogo abre com o que você tem — <b>inclusive sem internet</b> — e, quando há conexão, confere se saiu versão nova.',
        '<b>E ela não atropela a sua jornada.</b> Se saiu conteúdo novo e <b>nada do que você está fazendo depende do que mudou</b>, passa a valer na hora e o log avisa. Se depende — uma missão que você já começou a cumprir, ou o Alfa justamente da rota em que você está pisando —, a atualização <b>fica guardada e entra na sua próxima jornada</b>. Ninguém vai ter uma missão travada no meio porque o objetivo dela mudou embaixo do pé.',
        'Offline continua offline: sem internet, você joga com o pacote que já está no aparelho, e nada muda sem avisar.'
      ] }
    ] },
  { versao: '5.0', data: '2026-10-06', titulo: '🔄 Recuar virou comando — e o treinador do outro lado aprendeu a trocar de Pokémon', piada: 'Um treinador de Pewter passou dois anos vendo o Geodude dele tomar Surf em silêncio porque ninguém tinha avisado que era permitido chamar o bicho de volta. Avisamos. Ele pediu desculpas ao Geodude e agora troca na cara dura, no melhor momento possível, e ninguém mais acha isso simpático.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>🔄 Recuar.</b> No lugar de atacar, dá pra <b>sair de campo por uma rodada</b> e deixar um <b>aliado cobrindo</b>. O botão fica junto de Mochila e Fugir, e só aparece quando há alguém de pé pra cobrir o seu lugar.',
        '<b>Pra que serve recuar:</b> os seus degraus de atributo vão embora na saída (ótimo quando você tomou três quedas de Defesa, péssimo quando acabou de subir o Ataque), as <b>habilidades de saída disparam pelo gatilho de verdade</b> — <b>Regenerator</b> cura, <b>Natural Cure</b> limpa o status — e na volta você passa pelas armadilhas do seu lado e pelas habilidades de entrada outra vez. É um turno gasto por uma troca de situação.',
        '<b>O treinador do outro lado também troca agora.</b> Antes ele só mudava de Pokémon quando era <b>empurrado</b> (Roar, Cartão Vermelho) ou quando um caía — dava pra ficar moendo o Pokémon errado dele à vontade. Agora ele <b>recua de um confronto ruim por conta própria</b>: compara o que o bicho em campo devolve com o que ele toma dos <b>seus</b> golpes, e chama outro quando a troca melhora muito a vida dele, ou quando o atual está com o HP no fim.',
        '<b>E trocar custa o turno dele.</b> Quem entra <b>não ataca naquela rodada</b>, então o seu golpe cai de graça no recém-chegado — é a janela que você tem pra castigar a troca. O teto é de <b>3 trocas por luta</b>: ele pode gastar as três seguidas se for esperto, mas não enrola a luta inteira.',
        'Efeito prático: luta de treinador deixou de ser uma fila e virou uma conversa. Vale a pena guardar um golpe pro que vem depois.'
      ] }
    ] },
  { versao: '4.9', data: '2026-10-06', titulo: '🎁 O selvagem agora aparece segurando item — e dá pra roubar', piada: 'Um Rattata foi visto guardando uma Fruta Oran debaixo da pedra. Perguntado sobre a procedência, alegou que "estava lá". Os Pokémon com Pickpocket foram informados e já estão a caminho.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Cerca de 1 em 12 selvagens aparece com um item na mão.</b> Coisa barata — <b>Fruta Oran</b>, <b>Lum</b>, <b>Sitrus</b>, uma das 17 <b>frutas de aperto</b> por tipo, <b>Faixa Muscular</b> ou <b>Óculos do Sábio</b> —, e ele <b>usa</b>: aquele Golbat que se curou na metade do HP não é defeito, é a fruta dele. Pra você não ser pego de surpresa, o item aparece num <b>chip 🎁 na plaquinha</b>, do lado do nome, antes de ser usado. Vale pro selvagem comum, pro grupo e pros acompanhantes do Alfa; o <b>Alfa, os lendários e o chefe da semana não seguram nada</b> — já vêm fortes o bastante.',
        '<b>Três golpes saíram do limbo.</b> <b>Thief</b> e <b>Covet</b> roubam o item do alvo (se o seu Pokémon estiver de mãos vazias) e <b>Knock Off</b> <i>derruba</i> — não vai pra ninguém, se perde, e funciona mesmo se você já estiver segurando algo. Os três não faziam nada até agora pelo melhor dos motivos: não havia nada pra roubar. <b>Pickpocket</b> e <b>Magician</b>, que já existiam, finalmente têm serviço.',
        '<b>Vencer na porrada quase nunca entrega o item:</b> ele cai no chão em <b>2,5%</b> das vitórias contra quem estava segurando. É de propósito — o jeito certo de ficar com a fruta é tomar, não moer. Já quem <b>vira seu aliado</b> com um petisco chega segurando o que tinha.',
        '<b>✕ Cancelar o repelente.</b> O aviso de repelente ativo ganhou um botão: mudou de ideia no meio das 30 explorações, desliga na hora. As que sobraram são perdidas — o item já tinha sido gasto.',
        '<b>Três fontes novas em ⚙ Ajustes → Fonte</b>, agora <b>nove</b> no total: <b>Gordinha</b> (bem redonda, cara de livro infantil), <b>Delicada</b> (fina e arejada) e <b>Geométrica</b> (círculos perfeitos, ar de app). As seis de antes foram escolhidas por legibilidade; estas três, por gosto. Todas continuam com 2, 5 e 8 impossíveis de confundir.'
      ] },
      { nome: 'Correções', itens: [
        '<b>Petisco na tecla de atalho funciona.</b> Pôr o Mel Silvestre no ⚡ item rápido e apertar a tecla no meio da batalha não fazia <b>absolutamente nada</b> — a barra mandava o petisco pelo caminho dos itens de cura, que não sabe o que é oferecer comida a um selvagem. Agora qualquer caminho (tecla, mochila, atalho) chega no lugar certo.',
        'Usar petisco <b>fora</b> da batalha dizia "não teria efeito agora", que não explicava nada. Agora diz o que fazer com ele.'
      ] }
    ] },
  { versao: '4.8', data: '2026-10-05', titulo: '💎 A mochila abre por divisão e diz pra quem serve cada item de evolução', piada: 'Um jogador passou a tarde segurando um Eletrizador do lado de um Electabuzz esperando algo acontecer. O item estava funcionando perfeitamente: ele só não dizia, em lugar nenhum, que precisava do Cabo de Conexão pra terminar o serviço. O Electabuzz pediu desculpas pelo mal-entendido e evoluiu na hora seguinte.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Marcador 💎 nos itens de evolução.</b> Eles sumiam no meio da lista. Agora todos levam a marca — e quando o item serve pra alguém do seu lado, a marca <b>diz o nome dele</b>: <i>"💎 Serve pro seu Electabuzz"</i>.',
        '<b>Os itens que não têm botão agora explicam por quê.</b> Eletrizador, Magmatizador, Revestimento Metálico, Escama de Dragão e companhia funcionam <b>estando na mochila</b>: quem termina o serviço é o <b>Cabo de Conexão</b> (₽3.000 na loja) usado no Pokémon, ou subir de nível, quando a evolução dele é assim. A descrição de cada um diz isso agora, em vez de deixar parecendo defeito.',
        '<b>A mochila abre por divisão.</b> Cada parte (🧪 Cura e status, ⚔ Em batalha, 🎒 Para segurar, 💎 Evolução, 🍖 Petiscos, ✨ Especiais) abre e fecha num toque, com a <b>contagem de itens</b> no cabeçalho. Fechada, a mochila inteira cabe em seis linhas — antes, com a mochila cheia, era uma lista única enorme e achar algo no celular dava rolagem sem fim. A divisão que você abre fica aberta enquanto você mexe nela.',
        '<b>No celular, a descrição de cada item ocupa no máximo duas linhas</b> (o texto inteiro continua no toque longo). Era ela que fazia a lista crescer sem parar.'
      ] }
    ] },
  { versao: '4.7', data: '2026-10-04', titulo: '🧩 Todo item tem figura, a pedra na mochila atrai quem evolui com ela e mais 32 habilidades funcionando', piada: 'O Scyther passou três gerações ouvindo falar de uma tal Augurita Negra que ninguém nunca tinha visto. Não era lenda: a figura dela simplesmente não existia no catálogo, e o item aparecia na mochila como uma caixinha anônima. Mandamos buscar em outro arquivo. O Scyther olhou, aprovou e virou Kleavor na mesma tarde.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Item de evolução na mochila dobra a chance de encontrar quem evolui com ele.</b> Guardou a <b>Maçã Doce</b>? O <b>Applin</b> passa a aparecer duas vezes mais nessa rota. Vale pras pedras também (a Pedra do Fogo atrai Vulpix, Growlithe e Eevee de uma vez), e a <b>Pokédex da rota mostra a taxa já dobrada, com um ×2 do lado</b> — o número na tela é o mesmo que o sorteio usa.',
        '<b>Nenhum item aparece mais como caixinha genérica.</b> Eram <b>53</b>: os 17 Pratos do Arceus, o Lenço de Seda, os itens de chefe e os de evolução mais novos (Pergaminhos do Kubfu, armaduras do Charcadet, Augurita Negra, Bloco de Turfa, Mochi, Cabo de Conexão, Maçãs, Bule Rachado, Braceletes Galarica…). Agora cada um tem a figura certa, e as que não existiam no catálogo da PokéAPI <b>vieram de outros lugares e moram aqui dentro</b> — ou seja, aparecem até offline.',
        '<b>+32 habilidades com efeito de verdade em batalha</b> (de 217 para <b>249</b> das 314). Entre elas: os quatro <b>Tesouros da Ruína</b> (Chi-Yu e companhia, que derrubam um atributo de todo mundo menos o deles), <b>Dark Aura</b>/<b>Fairy Aura</b>/<b>Aura Break</b>, <b>Protean</b>/<b>Libero</b>/<b>Color Change</b> (o tipo muda em batalha), <b>Scrappy</b> e <b>Mind\'s Eye</b> (Normal e Lutador acertam Fantasma), <b>Infiltrator</b> (atravessa Refletir, Tela de Luz e Salvaguarda), <b>Cursed Body</b> (desativa o golpe que te acertou), <b>Bad Dreams</b>, <b>Suction Cups</b> (ninguém te arrasta pra fora), <b>Steadfast</b>, <b>Tera Shell</b>, <b>Fluffy</b>, <b>Toxic Chain</b>, <b>As One</b> e as de entrada em campo <b>Curious Medicine</b>, <b>Screen Cleaner</b>, <b>Hospitality</b>, <b>Costar</b> e <b>Supersweet Syrup</b>.',
        '<b>🔄 Revezamento:</b> <b>U-turn</b>, <b>Volt Switch</b>, <b>Flip Turn</b>, <b>Teleport</b> e <b>Parting Shot</b> finalmente fazem algo. Quem usa <b>sai de campo até o fim da rodada</b>, com um <b>aliado cobrindo</b>, e volta passando pelas armadilhas e pelas habilidades de entrada — uma troca de verdade, com o mesmo Pokémon. Os bônus de atributo somem na troca (é pra isso que existe o Baton Pass), e <b>sem aliado em pé o golpe avisa em vez de fingir</b>. Pokémon selvagem não abandona a luta assim: ninguém perde XP pela escolha dele.',
        '<b>Duas coisas vieram de carona:</b> as <b>armadilhas no seu lado do campo</b> (Spikes e companhia) passam a valer quando você volta, e <b>Regenerator</b>/<b>Natural Cure</b> agora disparam no momento certo — <b>ao sair de campo</b> —, e não só no fim da luta.',
        '<b>A ficha continua honesta:</b> habilidade sem efeito ainda diz isso. As <b>65</b> que faltam estão listadas no código com o motivo — a maioria depende de <b>trocar de Pokémon</b> (coisa que não existe num jogo em que você É o Pokémon) ou de <b>mudar de forma</b>, que pede sprite e regra próprios.'
      ] }
    ] },
  { versao: '4.6', data: '2026-10-04', titulo: '🏋 Dá pra desfazer treino, corrigir o azar de nascença e trocar de habilidade — por um preço', piada: 'O Machamp da loja passou duas gerações jurando que "IV ruim é destino". Depois apareceu com uma caixa de tampinhas de garrafa debaixo do balcão, uma cápsula que ele garante ser "cem por cento regulamentada" e a cobrança de um quarto de milhão por unidade. Ninguém conseguiu provar nada e o preço continua esse.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Mochi do Recomeço (₽250.000):</b> zera os <b>EVs</b> de um Pokémon da equipe. Tudo que ele treinou derrubando outros volta a 0 (e os atributos caem junto) — serve pra recomeçar o treino em outros atributos quando o seu se encheu dos errados.',
        '<b>Tampa de Garrafa (₽250.000):</b> leva <b>um IV ao máximo (31)</b>. <b>Qual deles é sorteado</b> entre os que ainda não estão em 31 — você não escolhe. A boa notícia: nenhuma tampa é desperdiçada num IV que já está no máximo, então a última custa caro mas acerta na certa.',
        '<b>Cápsula de Habilidade (₽250.000):</b> troca a habilidade por <b>outra da mesma espécie</b>, inclusive a <b>oculta</b>. Aqui <b>você escolhe</b>: a lista mostra o que cada habilidade faz e avisa se ela já tem efeito em batalha, igual à tela de criação. Quem tem habilidade única não tem pra onde trocar, e a cápsula diz isso em vez de ser gasta.',
        '<b>Só na loja.</b> Nenhum dos três aparece explorando nem como prêmio de Alfa, e nenhum funciona dentro da batalha. Com aliados na equipe, o jogo pergunta em quem usar. Os EVs e os IVs de cada um aparecem na ficha, nas colunas <b>EV</b> e <b>IV</b>.',
        '<b>A loja agora diz o que cada item faz.</b> A descrição aparece dentro do próprio cartão, junto do nome e do preço — antes ela era só uma dica ao passar o mouse, o que no celular significava <b>nenhuma descrição</b>.'
      ] }
    ] },
  { versao: '4.5', data: '2026-10-04', titulo: '💯 O XP depois do nível 100 parou de cair no vazio', piada: 'Um Blissey nível 100 derrubou mais mil Pokémon e recebeu, em troca, exatamente nada: a barra de XP já estava cheia e ninguém tinha pensado no assunto. Ela não reclamou (Blissey não reclama), mas o Chansey do sindicato reclamou por ela. Agora cada XP depois do teto vira pontuação.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Todo XP ganho depois do nível 100 agora conta na pontuação da jornada.</b> Antes o teto era o fim da linha: continuar jogando com o Pokémon no 100 não mudava mais nada no placar.',
        '<b>Quanto vale:</b> cada <b>1.000 de XP</b> no teto rende <b>3 pontos</b> — na prática, ganhar o equivalente a mais um nível lá em cima vale quase o mesmo que os 100 pontos de um nível de verdade. A tela de fim de jornada mostra a linha <b>"XP além do nível 100"</b> pra quem chegou lá.',
        '<b>Vale retroativamente dentro da jornada em andamento:</b> a conta sai do XP que o seu Pokémon já tem acumulado, e não de um contador que começou agora — quem está no 100 há horas não perdeu nada.'
      ] }
    ] },
  { versao: '4.4', data: '2026-10-03', titulo: '🔔 O jogo agora sabe te chamar quando você está em outra aba', piada: 'Um jogador deixou o jogo aberto numa aba, foi fazer outra coisa e voltou vinte minutos depois pra descobrir que o que ele procurava tinha aparecido havia dezenove. O Chatot foi designado para avisar daqui em diante. Ele aceitou na hora: finalmente alguém quer ouvir o que ele tem a dizer.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Notificações, em ⚙ Ajustes → Notificações.</b> O aviso continua aparecendo na tela de sempre; a notificação é o extra pra quando o jogo está numa aba de fundo ou minimizado.',
        '<b>São notificações locais:</b> nascem no seu aparelho, com o jogo aberto, e <b>não existe servidor nenhum envolvido</b> — nada sobre você sai daqui pra isso funcionar. O botão de ativar existe porque o navegador só deixa pedir permissão num clique seu; se você recusar, o jogo não insiste (dá pra liberar depois no cadeado ao lado do endereço).',
        'No iPhone, notificação só funciona depois de <b>adicionar o jogo à tela de início</b> — a tela de Ajustes avisa isso em vez de deixar um botão que não faria nada.'
      ] }
    ] },
  { versao: '4.3', data: '2026-10-03', titulo: '📊 A Pokédex da rota: taxas honestas e o Arceus de volta ao Santuário', piada: 'Um jogador somou as porcentagens da Estrada Vitória e achou 101,8%. A conta do sorteio estava certa; a da tela andava arredondando para cima e devolvendo troco que não existia. No meio da auditoria encontramos o Arceus perambulando pelo mato da mesma rota, entre um Purugly e um Probopass, alegando que estava "só dando uma volta". Foi reconduzido ao Santuário.',
    secoes: [
      { nome: 'Correções', itens: [
        '<b>A porcentagem de encontro de cada espécie agora é mostrada truncada pra baixo</b> (11,6% em vez de "12%"). Somando tudo que aparece na Pokédex da rota, o resultado nunca passa de 100% — antes passava, e dava a impressão de que os espaços ainda ocultos (📦) não tinham chance nenhuma de sair.',
        '<b>Nada mudou no sorteio:</b> a chance sempre foi calculada sobre o pool inteiro da rota, incluindo quem ainda está escondido. O que estava errado era só o número na tela, que arredondava pra cima oito vezes seguidas.',
        '<b>Quem é chefe de Raide na própria forma normal não aparece mais como encontro selvagem nas rotas</b> — o caso é o <b>Arceus</b>, que saía como mítico raríssimo na Estrada Vitória de Sinnoh sendo o mesmo Arceus que toma a tela inteira no evento da semana.',
        '<b>Rayquaza, Groudon, Kyogre, Mewtwo e companhia não mudam nada:</b> no evento eles vêm numa forma alternativa (Mega, Primal, Eternamax), então a forma normal continua valendo como <b>lendário da rota final</b>, como sempre foi.',
        '<b>O Santuário continua com todos.</b> Depois de vencer a Gen, o Arceus está lá — a Pokédex completa não depende de ganhar o chefe da semana.',
        'Estas <b>notas de atualização</b> foram compiladas de novo: 71 entradas viraram 43, agrupadas por assunto — a leva de ovos num lugar só, a de som num lugar só, e assim por diante. Por isso a numeração deu um salto; nada do que você leu antes sumiu.'
      ] }
    ] },
  { versao: '4.2', data: '2026-10-02', titulo: '📱 Celular deitado: a batalha para de fugir pro pé da página', piada: 'A cena da batalha estava descendo sozinha para o rodapé, e o subtítulo prometia um "RPG de texto" — um jogador passou um bom tempo procurando onde digitar. Não havia onde. A batalha voltou para o topo e o subtítulo foi aposentado com honras.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Botões de golpe mais baixos no celular deitado</b>, sempre <b>2 em cima e 2 embaixo</b>: cabe a luta inteira sem rolar.',
        '<b>Celular deitado: o menu voltou pro ☰.</b> As quinze telas abriam em três fileiras de botões e comiam metade da tela — agora ficam guardadas no menu, que rola se não couber.',
        '<b>O botão principal agora fica na borda direita</b> quando o aparelho está deitado: saindo da batalha, o <b>Explorar</b> cai no mesmo canto onde estavam os golpes, debaixo do polegar.',
        'O jogo agora se apresenta como <b>"Você é o Pokémon"</b> — o antigo "RPG de texto" prometia um teclado que nunca existiu.'
      ] },
      { nome: 'Correções', itens: [
        '<b>Celular deitado:</b> ao entrar numa luta, a cena da batalha agora fica <b>grudada na lateral esquerda</b> e <b>sempre visível</b> — antes ela ia parar no fim da página e era preciso <b>rolar pra baixo pra achar a própria batalha</b>.',
        'Tudo mais (golpes, registro, ficha, mochila) continua na coluna da direita e rola por baixo dela, sem nunca levar a batalha embora.',
        'Celular de tela um pouco mais alta (540px deitado) também entra nesse layout agora — antes caía num meio de caminho entre o celular e o computador e ficava torto.',
        '<b>A logo voltou a aparecer no topo</b> do celular deitado: com muito botão na barra, ela era espremida até virar um risco de nada.'
      ] }
    ] },
  { versao: '4.1', data: '2026-10-02', titulo: '🥚 Apareceu um ovo no esconderijo e ninguém quer explicar como', piada: 'Perguntamos aos dois Pokémon do esconderijo de onde tinha vindo o ovo. Um olhou para o teto. O outro assobiou — era um Chatot, então saiu uma melodia inteira. Encerramos a investigação por falta de provas e porque o ovo já estava chocando.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Agora tem ovo.</b> Dois parceiros de <b>gêneros opostos</b> esperando no 📦 esconderijo podem aparecer com um <b>ovo</b> do nada. Nenhum dos dois comenta o assunto. Cabem <b>3 ovos</b> ao mesmo tempo.',
        '<b>Ovo choca andando:</b> cada <b>exploração</b> é um passo, e espécie demorada demora mais — de <b>100 a 400 explorações</b>, seguindo os ciclos de choco dos jogos. A barra fica no painel de <b>Aliados</b>.',
        '<b>O que tem dentro é segredo.</b> Você vê "🥚 Ovo misterioso" e a barra, e mais nada, até ele trincar. Quando abre, nasce a <b>forma base da mãe</b> no <b>Nv. 5</b>, com <b>um golpe herdado do pai</b> e <b>3 IVs</b> puxados do melhor dos dois. E sim: ele pode nascer <b>shiny</b>.',
        '<b>Ovo pronto não se perde.</b> Com a equipe e o esconderijo lotados, ele fica trincando parado até você abrir uma vaga — em vez de sumir com as suas 300 explorações.',
        '<b>🥚 Criadouro</b> (nova conquista de conta): choque <b>100 ovos</b> somando a carreira e <b>toda jornada nova começa com o ovo de um pseudo-lendário</b> sorteado. Qual? Segredo, até chocar.',
        '<b>🐣 Guardião do ninho:</b> <b>1.000 ovos</b> chocados e você também começa toda jornada com o ovo de um <b>lendário ou mítico</b>. É de longe a conquista mais longa do jogo, junto com o milhão de dano. Boa sorte.',
        '<b>Ovo agora segue os grupos-ovo dos jogos.</b> Além de serem de <b>gêneros opostos</b>, os dois precisam ter um <b>grupo-ovo em comum</b> — Gyarados e Magikarp dividem o grupo Dragão e dão ovo; Pikachu e Gyarados não dividem nada e não dão mais.',
        '<b>Quem é do grupo "sem ovos" não bota, nem com outro do mesmo grupo:</b> lendário, mítico, os bebês — e a <b>Nidoqueen</b>, que é a surpresa da lista e é assim nos jogos de verdade.',
        'Pra combinar o casal, o jogo olha a ficha de espécie de quem está no esconderijo. Se ela ainda não chegou, <b>nenhum ovo aparece</b> — melhor nenhum ovo que ovo errado.'
      ] },
      { nome: 'Correções', itens: [
        'Se você baixou um mapa pra jogar offline, a tela de <b>⚙ Ajustes</b> vai pedir pra baixar de novo: quantas explorações cada ovo pede é um dado novo da ficha de cada espécie, e sem ele o ovo de lendário chocaria tão rápido quanto um de Magikarp. Com internet, chega sozinho.',
        'Se você baixou um mapa pra jogar offline, a <b>⚙ Ajustes</b> vai pedir pra baixar de novo (de novo, desculpe): o grupo-ovo é mais um dado da ficha de cada espécie, e sem ele o esconderijo não tem como formar casal nenhum no avião.'
      ] }
    ] },
  { versao: '4.0', data: '2026-10-02', titulo: '♂♀ Agora todo Pokémon tem gênero — e isso muda a batalha', piada: 'O Combee macho que virou Vespiquen apresentou recurso formal. O recurso foi analisado por uma Vespiquen — que, por definição da espécie, é fêmea — e negado por conflito de interesses. Ele hoje é um Combee muito bem informado.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Todo Pokémon nasce com gênero</b>, sorteado pela proporção real da espécie — Vulpix é fêmea em 75% das vezes, Tauros é sempre macho, e quem não tem gênero (Magnemite, Voltorb, quase todo lendário) continua sem. O ♂ ou ♀ aparece na plaquinha de batalha, na ficha e no cartão da sala.',
        '<b>Atração funciona.</b> Antes ela dizia "nada aconteceu": agora o alvo se apaixona e fica <b>sem atacar em metade dos turnos</b> — só entre gêneros opostos, como nos jogos. <b>Charme Fofo</b> faz o mesmo em quem encostar em você, e <b>Oblivious</b> e <b>Aroma Veil</b> não caem nessa.',
        '<b>Rivalidade (Rivalry) entrou em campo:</b> bate <b>25% mais forte</b> contra o mesmo gênero e <b>25% mais fraco</b> contra o oposto. Contra quem não tem gênero, nada muda.',
        '<b>Vespiquen, Salazzle, Froslass e Wormadam só saem de fêmeas</b> — e Mothim, só de machos. Era uma exigência que o jogo simplesmente ignorava.',
        'O inimigo aprendeu tudo junto: a IA não gasta mais o turno com uma Atração que não tem como funcionar.'
      ] },
      { nome: 'Correções', itens: [
        '<b>Cativar (Captivate) funcionava em qualquer um</b>, inclusive em bicho sem gênero. Agora só no gênero oposto, como deveria.',
        'Se você baixou um mapa pra jogar offline, a tela de <b>⚙ Ajustes</b> vai pedir pra baixar de novo: o gênero é um dado novo da ficha de cada espécie e sem ele, no avião, todo mundo nasceria sem gênero. Com internet, chega sozinho na primeira vez que o jogo falar com a PokéAPI.'
      ] }
    ] },
  { versao: '3.9', data: '2026-10-02', titulo: '⚖ As contas do golpe: peso, defesa certa e o gelo que derrete', piada: 'Descobrimos que o Snorlax levava Low Kick como se pesasse 0,6 kg e que um Charizard congelado cuspia Lança-Chamas sem notar o gelo nas próprias asas. Os dois pediram para não aparecer na nota. Estão na nota.',
    secoes: [
      { nome: 'Correções', itens: [
        '<b>Golpe que depende de peso finalmente pesa.</b> <b>Low Kick</b> e <b>Grass Knot</b> batiam com força fixa, igual contra um Caterpie e contra um Snorlax — agora valem mais quanto mais pesado é o alvo (até 120 de poder contra bicho de 200 kg ou mais). <b>Heavy Slam</b> e <b>Heat Crash</b> olham a <b>diferença</b>: ser 5 vezes mais pesado que o alvo é o golpe mais forte que você tem.',
        '<b>Psyshock, Psystrike e Secret Sword atacavam a defesa errada.</b> Eles são golpes especiais que, nos jogos, batem na <b>Defesa física</b> do alvo — era justamente o ponto deles. Aqui iam na Defesa Especial, então o dano saía errado sem avisar ninguém. Consertado.',
        '<b>Body Press usava o seu Ataque</b> em vez da sua <b>Defesa</b>, que é a razão de o golpe existir: agora quanto mais duro você é, mais forte ele bate. E <b>Foul Play</b> passou a usar o Ataque do <b>inimigo</b> contra ele mesmo, como deveria desde sempre.',
        '<b>Stored Power, Power Trip e Punishment</b> ignoravam os aumentos de atributo que deveriam contar: cada degrau a mais soma <b>+20 de poder</b> (os seus, nos dois primeiros; os do alvo, no Punishment). <b>Wring Out</b> e <b>Crush Grip</b> agora batem mais forte quanto mais cheia está a vida do alvo.',
        '<b>O inimigo aprendeu tudo isso junto.</b> A IA calcula o dano pela mesma conta, então um Alfa pesado agora SABE que o Heavy Slam dele vale a pena contra alvo leve. Boa sorte.',
        'Um detalhe chato: o jogo não guardava o peso dos Pokémon — ele passou a vir junto com o resto da ficha. Se você baixou um mapa pra jogar offline antes desta atualização, o peso chega na primeira vez que o jogo falar com a internet; até lá esses golpes usam a força antiga, em vez de achar que todo mundo pesa zero.',
        '<b>Golpe de Fogo descongela quem leva.</b> Um inimigo congelado levava Lança-Chamas na cara e continuava congeladinho — nos jogos, o calor quebra o gelo na hora. Agora quebra aqui também (e <b>Água Fervente</b> e companhia, que também derretem, contam).',
        '<b>Golpe quente descongela quem usa.</b> Estar congelado travava TUDO, inclusive <b>Roda de Fogo</b>, <b>Fogo Sagrado</b>, <b>Investida Flamejante</b>, <b>Água Fervente</b> e <b>Bola de Fogo</b> — justamente os golpes que existem pra te tirar do gelo. Agora saem normalmente e te descongelam de quebra.',
        '<b>Sol forte não deixa mais ninguém congelar.</b> Fazia 40 graus no campo e o Raio Congelante congelava do mesmo jeito. Não congela mais.'
      ] }
    ] },
  { versao: '3.8', data: '2026-10-01', titulo: '🗺 180 missões novas: cada rota das 9 Gens tem as suas', piada: 'O Rattata da Rota 1 soube que a meta subiu de 10 para 24 e convocou assembleia geral. Compareceram 24 Rattata. A assembleia foi encerrada por motivos óbvios.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Cada rota do jogo agora tem duas missões próprias:</b> uma de <b>espécie</b> (derrote tantos daquele bicho que vive ali) e uma de <b>Alfa</b> (derrote o Alfa da rota). São <b>10 rotas x 9 Gens</b> — e a corrente vai da primeira rota até os lendários, com a última valendo "Campeão da região".',
        '<b>Missão pode pedir mais de uma espécie.</b> No Monte Pira, "Mais ou Menos" quer 8 Plusle <i>e</i> 8 Minun; cada contagem fecha sozinha, e exagerar numa não paga a outra.',
        '<b>As quantidades subiram.</b> O que antes era "derrote 10 Pidgey" virou "derrote 24 Rattata" na rota onde ele realmente mora — e os prêmios acompanham, subindo de 4 Poções na primeira rota a Max Revive e ₽12.000 nas últimas.',
        'Fora de Kanto, antes, <b>15 missões ficavam escondidas pra sempre</b>: eram todas de espécie de Kanto e nunca apareciam em Johto, Hoenn ou qualquer outro mapa. O contador dizia "21 escondidas" e não havia como revelar a maioria. Agora cada mapa mostra as suas 20, e só elas.'
      ] },
      { nome: 'Correções', itens: [
        '<b>Uma missão nascia pronta.</b> "Lâminas no capim" aparecia e concluía no mesmo instante, pagando ₽3.000 por nada — e estava rotulada como missão do Safari, onde não existe nenhum Scyther. Agora ela mora na Caverna Cerúlea, onde ele vive, e pede 8.',
        '<b>A trilha dos Alfas pulava três rotas.</b> Usina Elétrica, Ilhas Espuma e Estrada Vitória não tinham missão nenhuma — justamente o trecho mais longo da jornada. E a 5ª da fila aparecia por nível, não pela rota anterior, entao o jogo te oferecia a Torre Pokémon enquanto você ainda estava na Rota 24.'
      ] }
    ] },
  { versao: '3.7', data: '2026-10-01', titulo: '🧬 Potencial máximo: um milhão de dano, IVs perfeitos pra sempre', piada: 'Somamos todo o dano que você já causou desde a primeira jornada. O número passou de um milhão, o contador pediu férias e voltou trazendo seis IVs 31 de presente.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Nova insígnia: 🧬 Potencial máximo.</b> Cause <b>1.000.000 de dano</b> com os seus golpes, somando a carreira inteira — e, a partir daí, <b>todo Pokémon que você começar a jogar nasce com os 6 IVs em 31</b>, o teto. Não é por jornada: é pra sempre, em qualquer modo, como as outras insígnias.',
        'Só conta o dano que <b>você</b> bate: golpe de aliado, veneno, armadilha e recuo ficam de fora. O modo Fácil também não conta (como em todo progresso de conta). A barra de progresso está na tela 🏅 Conquistas, no grupo <b>Maestria</b>.',
        'Ela é a <b>segunda insígnia da história do jogo a mudar uma regra</b> em vez de dar item ou dinheiro — a outra é a loja de graça do Senhor dos céus. Como todas, ela é desligada pelo interruptor <b>“jogar sem as vantagens da conta”</b> na criação: o bônus de pontuação continua sendo pra quem começa do zero de verdade.'
      ] }
    ] },
  { versao: '3.6', data: '2026-10-01', titulo: '☄ Os chefes da semana: 16 chefes, itens de raide e o calendário', piada: 'O Eternatus pediu para constar que não é ele que está atrasado: é o resto do universo que chegou cedo. O Regigigas, que entrou em campo cinco turnos depois de todo mundo, concordou — mas só no sexto turno.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Evento semanal:</b> um chefe por semana, que vira toda <b>segunda-feira à meia-noite</b> (horário de Brasília), na rota final da Gen dele, só no <b>Roguelike</b> e no <b>Hardcore</b>. Ele aparece numa caixa roxa brilhante acima dos lendários, o mapa da Gen mostra o sprite dele na escolha, e a tela inicial traz a <b>agenda dos próximos 3 chefes</b> com as datas. Uma tentativa a cada <b>8 horas</b>.',
        'São <b>14 chefes</b>, e depois do último a lista recomeça: Eternatus Eternamax → Mega Rayquaza → Groudon Primal → Kyogre Primal → Mega Mewtwo → Necrozma Ultra → Calyrex Cavaleiro Espectral → Zacian Coroada → Kyurem Negro → Giratina Origem → Dialga Origem → Terapagos Estelar → Ursaluna Lua de Sangue → Zygarde Completo.',
        'Cada um é <b>muito difícil</b> e tem a sua mecânica. O <b>Eternatus</b> tem uma couraça de energia que corta o dano até se romper, o <b>Eternabeam</b> carregado com aviso (dá pra interromper causando dano suficiente no mesmo turno) e três fases. A <b>Mega Rayquaza</b> não tem couraça: tem um ponto fraco que muda a cada duas ações e o Dragon Ascent carregado. <b>Groudon e Kyogre</b> nascem com Sol e Chuva permanentes e anulam Água e Fogo; o <b>Giratina</b> abre o <b>Mundo Reverso</b> (a tabela de tipos inverte); o <b>Terapagos</b> resiste ao tipo do último golpe; a <b>Ursaluna</b> se cura com o dano que causa; o <b>Zygarde</b> se regenera; o <b>Calyrex</b> cresce a cada Pokémon seu que derruba. Todos são imunes a status e não dá pra fugir — mas perder não encerra a sua jornada.',
        '<b>Chefe no co-op:</b> na sala, o botão ☄ desafia o chefe da semana com o grupo. O HP dele cresce com o número de jogadores, mas menos que proporcional — jogar junto compensa. O golpe carregado atinge <b>o time todo</b>. Quem ficar sem nenhum Pokémon de pé pode <b>usar um Revive</b> (até 3 por luta) enquanto os outros seguram, e volta com metade do HP.',
        '<b>Itens de raide</b>, dados como prêmio e só válidos na luta do chefe (um de cada por luta): <b>Cristal de Ruptura</b> (expõe o chefe na hora), <b>Selo de Interrupção</b> (corta o golpe que ele está carregando) e <b>Escudo Astral</b> (o próximo golpe carregado causa metade do dano no time todo). No co-op qualquer jogador do grupo pode usar, sem gastar o turno.',
        'Derrotar um chefe libera a espécie dele na Pokédex e pra começar jornadas, dá a <b>insígnia de evento</b> dele (Domador do Infinito, Guardião do Pilar Celeste…) com título incluído, e um prêmio uma vez por semana. Na tela 👤 Conta você escolhe <b>uma</b> insígnia pra mostrar ao lado do seu nome — ela aparece também na sala do multiplayer, na lista de amigos e no ranking, e o servidor só mostra a de quem realmente venceu aquele chefe.',
        'Prêmio da Raide completo: 7 itens <b>consumíveis</b> novos (Cinza Vulcânica, Escama Abissal, Prisma de Luz, Espelho Reverso, Relógio de Areia, Fragmento Tera, Célula Zygarde) e 7 <b>segurados</b> novos que valem em qualquer batalha (Núcleo Eternamax, Escama do Céu, Cristal Psíquico, Rédea Espectral, Emblema da Coroa, Cristal Gélido, Presa da Lua) — todos só vêm de vencer o chefe da semana.',
        '🧪 <b>Modo beta temporário</b>: a espera de 8 horas entre tentativas contra o chefe da semana está DESLIGADA, pra facilitar os testes da Raide (Arena, dentro da run, ou em grupo). Volta a valer depois do período de teste.',
        'A tela da <b>Arena do Chefe</b> ganhou um cartão "👥 Jogar em grupo" explicando que ela é só single-player (Hall da Fama) e levando direto pro Multiplayer, onde dá pra montar uma sala de até 6 jogadores (3 Pokémon cada) pra encarar o chefe em co-op.',
        'Todo <b>item de raide</b> agora diz <b>o que faz</b> e <b>contra quais chefes serve</b>, na dica do botão, na mochila e numa tabela nova em <b>❓ Como funcionam os chefes da semana</b> (que também mostra quem dá cada item de prêmio).',
        'O prêmio dos chefes gira em rodízio e não combina com o chefe: o Groudon dá Prisma de Luz (que só serve contra chefe com ponto fraco, e ele não tem), e o Calyrex dá Célula Zygarde (que só serve contra o Zygarde). Por isso, na caixa do chefe da semana, uma linha separa os seus itens em <b>servem</b> e <b>não servem contra ele</b>, pra você não gastar à toa.',
        '<b>Arceus é o 15º chefe da semana</b> (Gen 4): a cada duas ações ele <b>troca de Prato</b> — e o Prato é <b>sorteado</b> entre os 17, não tem ordem pra decorar. Só golpes do tipo do Prato da vez machucam de verdade (×2); os outros quase não arranham. A troca tem <b>animação</b>: um anel com a cor de cada tipo gira em volta dele e o Prato sorteado fica brilhando. Ele ainda tem couraça e carrega o <b>Julgamento</b> — e o <b>Prisma de Luz</b> arranca a armadura de Prato na hora.',
        '<b>Regigigas é o 16º</b> (Gen 4), o líder dos Regis: ele entra <b>adormecido</b> (Slow Start — metade do Ataque e da Velocidade nos 5 primeiros turnos) e vai acordando a cada fase, até o <b>Esmagamento Colossal</b>. A couraça dele é a mais grossa do jogo; quem demora a derrubá-lo enfrenta outro bicho no fim.',
        'Como sempre, derrotar cada um dá o Pokémon (Pokédex e jornadas novas), uma insígnia com título e prêmio. Eles entraram <b>no fim da fila</b>: o chefe desta semana continua sendo o mesmo de antes.',
        '<b>A tela inicial agora mostra o calendário do ano inteiro.</b> Abaixo dos próximos 3 chefes tem um “📅 Calendário do ano inteiro”: abriu, você vê semana a semana quem vem, com a data de cada segunda-feira — dá pra planejar a jornada pro chefe que você quer enfrentar.'
      ] },
      { nome: 'Correções', itens: [
        '<b>Sucker Punch</b> (e Thunderclap) agora só funciona se o alvo escolheu um golpe de dano neste turno e ainda não agiu. Antes era só um golpe de prioridade que nunca falhava.',
        'Uma jornada que termina (fim de Roguelike/Hardcore, vitória na Arena ou no chefe em grupo) agora tenta de novo sozinha se a sincronização com a nuvem falhar na hora — antes era uma tentativa só, e uma rede instável bem na tela de Game Over podia deixar o Pokémon de fora do Hall da Fama.',
        'O <b>Espelho Reverso</b> dizia que inverte os tipos "a seu favor". Na verdade ele inverte a tabela nos golpes que <b>você</b> dá: ajuda contra quem resiste aos seus tipos e <b>atrapalha</b> contra quem é fraco a eles. A descrição agora avisa.'
      ] }
    ] },
  { versao: '3.5', data: '2026-09-30', titulo: '🔒 Faxina de segurança: sua conta, sua mochila e sua run', piada: 'Contratamos alguém para tentar invadir o jogo. Ele entrou sete vezes, anotou tudo num caderninho e foi embora sem se despedir. Passamos o dia lendo o caderninho. Hoje o caderninho está vazio, e nós dormimos bem melhor.',
    secoes: [
      { nome: 'Segurança', itens: [
        '<b>Ninguém mais gasta os SEUS itens numa sala.</b> Antes, o que saía da sua mochila durante uma luta em grupo era decidido pelo que chegava pela rede. Agora o jogo só desconta o que <i>você</i> pediu: se a mensagem disser que você usou quarenta Poções, ela é ignorada. Vale também pro inventário da Sala de Raide, que é comprado com o seu saldo.',
        '<b>Ninguém mais acaba com a sua jornada.</b> O botão de <i>desistir</i> existe no PvP, mas a luta aceitava a desistência em qualquer modo — inclusive em co-op, onde, no Roguelike, isso encerrava a run de quem nem tinha clicado. Agora só vale onde deveria.',
        '<b>Duas brechas que podiam levar a sua conta foram fechadas.</b> Uma na sala de multiplayer, outra na tela de perfil de amigo: em ambas, um endereço de imagem malformado conseguia virar código dentro do navegador de quem estava só olhando a tela. Nada disso chegava ao seu save, mas era o suficiente pra pegar o seu login — e agora não é mais.',
        '<b>O seu histórico voltou a ser seu.</b> Dava pra forjar uma amizade aceita e, com isso, abrir o perfil de qualquer jogador (nível, pontuação, últimas jornadas) sem que a pessoa tivesse aceitado nada. A regra de amizade agora é conferida no servidor dos dois lados, e o par de uma amizade não pode mais ser reescrito.'
      ] },
      { nome: 'Correções', itens: [
        '<b>O ranking está limpo de novo.</b> Havia uma conta possível em que a penalidade de continuar a jornada com o mesmo Pokémon, em vez de tirar pontos, multiplicava a pontuação — o bastante pra cravar um primeiro lugar impossível. O servidor agora recusa, e a mesma conta foi corrigida dentro do jogo.',
        'Também apertamos os bastidores: os geradores de dados dos mapas e das Megas passaram a recusar nome estranho vindo da PokéAPI em vez de embutir do jeito que vier — era o tipo de coisa que, num dia ruim, deixa o jogo inteiro sem carregar.'
      ] }
    ] },
  { versao: '3.4', data: '2026-09-30', titulo: '☀ A Mega Evolução voltou a trazer o clima dela', piada: 'O Mega Charizard Y vinha entrando em campo com o sol guardado no bolso, dizendo que era "para depois". Não era para depois. Era para agora — e o Solar Beam estava esperando há semanas, de braços cruzados.',
    secoes: [
      { nome: 'Correções', itens: [
        '<b>Megaevoluir agora ativa a habilidade da nova forma na hora.</b> O Mega Charizard Y põe o sol forte, o Mega Abomasnow começa a nevar, o Mega Mawile intimida — como nos jogos, porque a forma <i>entra em campo</i> naquele momento. Antes a habilidade só valia se você já tivesse entrado na luta com ela, ou seja: nunca. Vale pros dois lados e também no co-op.',
        '<b>Como consequência, o Solar Beam volta a sair na hora sob o seu próprio sol.</b> Ele sempre soube dispensar o turno de carga no sol forte — o problema é que o sol do Mega Charizard Y não estava lá.',
        '<b>A busca da lista de desbloqueados, na criação de jornada, filtra de novo.</b> Digitar “gengar” ou “94” esconde o resto. Um estilo da grade passava por cima do “esconder”, então o jogo escondia os botões e o navegador insistia em mostrá-los.'
      ] }
    ] },
  { versao: '3.3', data: '2026-09-30', titulo: '🎒 Itens: na loja, no mato e na mão', piada: 'Havia uma Fruta Yache atrás do balcão da loja e nenhuma no mato inteiro, o que levanta a questão de quem plantou aquilo. O lojista disse que "é assim que funciona o comércio". Abrimos o mato. O lojista está bem.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Golpes que trocam o tipo do alvo.</b> <b>Soak</b> deixa qualquer um Água puro e <b>Pó Mágico</b> deixa Psíquico; <b>Maldição da Floresta</b> e <b>Doces ou Travessuras</b> acrescentam Planta ou Fantasma. Vale pra tudo — o que é super efetivo contra ele, o STAB dele, o terreno, as imunidades — e dura até o fim da luta. Soak num Voador, por exemplo, tira a imunidade a golpe Terrestre.',
        '<b>6 itens segurados novos na loja:</b> <b>Balão de Ar</b> (você flutua: golpe Terrestre não te acerta, até o balão estourar), <b>Apólice de Fraqueza</b> (levou super efetivo? Ataque e At. Especial sobem 2 de uma vez), <b>Lente de Mira</b> (mais crítico) e as ervas <b>Branca</b> (desfaz queda de atributo), <b>Mental</b> (livra de Provocação, Bis, Desativar e Tormento) e <b>do Poder</b> (Solar Beam e companhia saem sem turno de carga).',
        '<b>As 17 frutas de aperto por tipo</b> — Occa, Passho, Wacan, Yache e o resto da turma. Cada uma corta pela metade UM golpe super efetivo daquele tipo. É a rede de segurança contra aquele golpe que te derrubaria de uma vez.',
        '<b>Seis itens de evolução agora também funcionam segurados</b>, como nos jogos: <b>Pedra do Rei</b> e <b>Presa Afiada</b> (10% de chance de fazer o alvo recuar), <b>Garra Afiada</b> (mais crítico), <b>Revestimento Metálico</b> (golpes de Aço +20%) e <b>Dente</b> e <b>Escama Abissal</b> (dobram At. e Def. Especial — só no Clamperl, o dono de direito).',
        'Eles continuam guardados em <b>💎 Evolução</b> e continuam evoluindo quem sempre evoluíram. A diferença é que agora dá pra equipar em vez de deixar parado na mochila esperando o nível certo.',
        '<b>E evoluir funciona com o item na mochila ou na mão.</b> Antes, se você equipasse a Pedra do Rei, o seu Poliwhirl simplesmente não evoluía e o jogo não explicava por quê.',
        '<b>As frutas agora aparecem explorando, em qualquer rota.</b> São 20 no total — Oran, Sitrus, Lum e as 17 de aperto por tipo (Occa pro fogo, Yache pro gelo, Shuca pra terra…) —, e cerca de 1 em cada 6 itens achados é uma delas. Como são muitas, cada fruta específica continua sendo sorte: achar a Yache justo antes de encarar um Pokémon de Gelo é o tipo de coisa que dá vontade de contar pra alguém.',
        '<b>Os itens de segurar permanentes também caem, da 4ª rota em diante.</b> Restos, Orbe da Vida, Faixa de Foco, Faixa Escolha, Eviolite, Balão de Ar e companhia entram no mesmo degrau dos itens de evolução — quem não passa na loja não fica mais sem conhecer a mecânica.',
        '<b>Os itens de prêmio de raide continuam sendo só de prêmio.</b> Achar um Núcleo Eternamax no chão tiraria o motivo de enfrentar o chefe da semana.',
        'A chance de <b>item de evolução</b> e de <b>Escama do Coração</b> ficou exatamente onde estava: o que mudou foi o que apareceria como item comum.',
        '<b>Marque até 2 itens como rápidos e eles ficam junto dos botões principais.</b> Na mochila, cada item tem um botão <b>⚡</b>: marcado, ele aparece do lado de <i>Explorar</i> fora da luta e do lado de <i>Mochila</i> e <i>Fugir</i> dentro dela. Chega de abrir a mochila e caçar a Poção a cada turno.',
        '<b>E eles têm atalho de teclado: 1 e 2.</b> O primeiro item rápido é o 1, o segundo é o 2 — o próprio botão mostra qual tecla é a dele.',
        'A escolha vale pra <b>jornada</b> (os itens são seus, dessa run). Se o item acabar, o atalho some da barra e <b>volta sozinho</b> quando você comprar outro — não precisa reconfigurar.',
        'Isso nasceu de um pedido de "botões pra subir e descer os itens da mochila". O que incomodava não era a ordem da lista, era a procura: um atalho fixo resolve sem mexer na mochila.'
      ] },
      { nome: 'Equilíbrio', itens: [
        '<b>Endeavor não é mais um botão de vitória contra o chefe da semana.</b> Ele iguala o HP do alvo ao seu — e contra o chefe isso passava por cima da couraça de energia e de todas as defesas dele: bastava estar quase morto pra acabar com a luta. Agora o dano dele entra pelas mesmas regras de qualquer outro golpe. Contra o chefe continua valendo muito a pena; só não decide mais a luta sozinho.',
        'Fora do chefe, o Endeavor não mudou em nada.'
      ] }
    ] },
  { versao: '3.2', data: '2026-09-30', titulo: '🔊 O jogo ganhou som (desligado, até você ligar)', piada: 'O compositor da casa é um Loudred com um sintetizador e nenhuma formação musical. Ele não sabe tocar nada: sabe fazer um computador fingir que sabe, dezesseis vezes por segundo, para sempre. Pedimos que baixasse o tom. Ele baixou uma oitava inteira, por via das dúvidas.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Som, em ⚙ Ajustes → Som — desligado por padrão.</b> Liga o grito de quem aparece na luta (o mesmo grito dos jogos de verdade, vindo da PokéAPI) e uma música que toca sozinha.',
        'A música não é arquivo nenhum: o jogo <b>compõe ela na hora</b>, com uma faixa diferente pra tela inicial, pra exploração, pra batalha comum, pra batalha de chefe/lendário, e uma fanfarra curta quando você vence. Nunca se repete nota por nota — é gerada de novo a cada vez, dentro de uma escala que combina com o clima da tela.',
        'Sem trilha pronta de propósito: música de verdade dos jogos é direito autoral de outra empresa. O jeito era compor, não tocar.',
        '<b>Cada rota tem a sua música.</b> Caverna soa como caverna, mar soa como mar — e vulcão, deserto, gelo, floresta, usina, ruínas assombradas, montanha e o Santuário também. A trilha lê o tema da rota, o mesmo que já decide o cenário da batalha, então as 99 rotas do jogo têm tonalidade própria.',
        '<b>As telas fora do jogo ganharam trilha</b> — Carreira, Pokédex, Conquistas, Ranking e companhia agora têm um fundo calmo em vez do silêncio.',
        '<b>As músicas foram reescritas.</b> Antes cada nota era sorteada na hora: nenhuma soava errada, mas a música não ia a lugar nenhum. Agora cada tema tem uma <b>frase própria, escrita nota por nota</b>, que se repete e dá pra reconhecer — do jeito que música de jogo funciona.',
        'Continua tendo variação pra não ficar mecânico, mas agora ela é o tempero, não o prato.',
        '<b>A batalha tem música própria agora.</b> Antes era o tema da rota tocando mais rápido; agora existe uma melodia de luta (e outra, mais pesada, pro chefe) que toca em qualquer rota — a rota continua entrando pela tonalidade.',
        '<b>A troca de música virou uma passagem.</b> A faixa antiga desce, tem um respiro de silêncio e a nova entra subindo: dá pra sentir que você mudou de lugar, sem o corte seco de antes.',
        '<b>Som de derrota</b> quando a jornada acaba mal, <b>som de subir de nível</b> (seu e dos aliados) e um <b>“ca-ching” ao comprar</b> na loja.',
        '<b>Na tela inicial, o Pokémon que você seleciona solta o grito dele.</b> Dá pra escolher pelo ouvido também.',
        '<b>Golpe que acerta agora faz barulho, e o barulho é do tipo do golpe.</b> Fogo é uma labareda; Voador e Dragão são uma lufada de ar; Água é um baque molhado; Gelo trinca; Elétrico estala; Aço soa como metal batendo; Grama e Inseto farfalham; Terra e Pedra são um estrondo grave; Fantasma, Psíquico, Sombrio, Fada e Venenoso têm um lamento; Normal e Lutador são pancada seca. Vale pros <b>dois lados</b>: quando você acerta e quando você apanha.',
        '<b>A piscada de dano ganhou a cor do tipo.</b> Levar um golpe de fogo acende laranja no sprite, um de água acende azul — as mesmas cores dos selos de tipo. Dano sem tipo (confusão, o esforço do próprio golpe, veneno) continua no vermelho.',
        '<b>Agora dá pra desligar as animações de combate</b> em <b>⚙ Ajustes → Som e animações</b>, separado do som. Sem animação o combate fica mais <b>rápido</b> de propósito: a pausa entre as mensagens existia pra dar tempo de ver a tremida e ouvir o impacto, então ela encurta junto. Quem já pediu “reduzir animações” no próprio aparelho não precisa mexer em nada.'
      ] },
      { nome: 'Correções', itens: [
        '<b>O grito não atrasa mais.</b> Ele era baixado no instante em que devia tocar — e chegava depois da cena. Agora vem pronto de antemão: sai junto com o Pokémon aparecendo.',
        '<b>Trocou de aba? O som para.</b> Antes a música continuava tocando por cima de tudo, inclusive com o celular na sua bolsa. Voltando pra aba, ela volta de onde estava.',
        '<b>Bem menos agudo.</b> A trilha tinha notas altas demais e cansava o ouvido em poucos minutos. As melodias desceram de oitava e um filtro corta o que sobrava de estridente.',
        'Se o áudio demorar muito pra chegar (internet ruim), ele é <b>descartado</b> em vez de gritar fora de hora, quando a cena já passou.',
        '<b>Sumiu o retângulo escuro atrás do seu Pokémon na batalha.</b> Era um estilo da ficha vazando pra cena da luta.',
        '<b>Os sprites não são mais esticados pra encher a caixa.</b> Cada Pokémon aparece no tamanho de verdade dele: acabou o serrilhado de imagem ampliada, e as espécies voltaram a ter tamanhos diferentes entre si.'
      ] }
    ] },
  { versao: '3.1', data: '2026-09-29', titulo: '📄 O site em volta do jogo: páginas, guia, privacidade e cookies', piada: 'A Política de Privacidade morava numa tela que só abria para quem já estava dentro do jogo, como um aviso de incêndio trancado por dentro do prédio. O Guia morava na cabeça de um amigo seu. Os dois se mudaram para endereços de verdade.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Nova tela <b>🔒 Privacidade</b>, explicando em português claro o que fica só no seu aparelho, o que a conta guarda (se você tiver uma) e o que a PokéAPI/Supabase recebem.',
        'Cinco páginas novas, com endereço próprio e abertas a quem nem começou a jogar: <b>Sobre</b> (o que é o jogo e como ele foi feito), <b>Guia</b> (dificuldades, rotas e Alfas, batalha, clima, aliados, as quatro transformações e o progresso de carreira), <b>Privacidade</b>, <b>Termos de Uso</b> e <b>Contato</b>.',
        'Todas elas ficam a um clique de qualquer tela, num <b>rodapé novo</b> — que some sozinho durante a batalha, porque ali ele só atrapalharia.',
        'Agora existe um <b>e-mail de contato</b> de verdade, pra privacidade, direitos autorais ou qualquer assunto que não caiba em 🐞 Bugs e sugestões. Pra bug e sugestão a tela de dentro do jogo continua sendo o caminho mais rápido: ela aceita print, funciona sem internet e mostra o andamento.',
        'O <b>Guia</b> deixou de ser uma página só e virou <b>seis capítulos</b>, cada um com endereço próprio (dá pra mandar o link do tema certo pra quem está começando): <b>Como começar</b>, <b>A batalha</b>, <b>Mundo e rotas</b>, <b>Transformações</b>, <b>Progresso</b> e <b>Multiplayer</b>. Chega-se a ele pelo rodapé de qualquer tela.',
        'Ele explica o que o jogo nunca teve espaço pra explicar: como a ordem do turno é decidida de verdade, por que clima e terreno mudam tanto uma luta, o que a Pokédex da rota está te dizendo, como cada uma das quatro transformações é conquistada, e — a parte que mais gente descobre tarde — <b>o que continua valendo depois de uma jornada perdida</b>.',
        'Também responde o que costuma aparecer em 🐞 Bugs e sugestões: por que uma luta de multiplayer às vezes não dá XP (a resposta é "nível real"), por que uma rota parou de dar encontros e pra que serve o saldo que sobra de cada jornada.',
        'Os capítulos se ligam entre si e ao índice, então dá pra ler em ordem ou pular direto pro assunto — e ficam guardados junto com o jogo, ou seja, <b>funcionam sem internet</b>, como o resto.',
        'Você vai ver um <b>aviso de cookies</b> no pé da tela, uma vez. Explicação honesta: o jogo é de graça e a ideia é sustentar ele com anúncio, e pra isso o Google precisa analisar o site antes — o que exige que o código dele esteja aqui. <b>Nenhum anúncio é exibido ainda</b>, e nada mudou no jogo.',
        'Antes de você responder qualquer coisa, o jogo já diz ao Google que o consentimento está <b>negado</b>: nada de cookie de anúncio e nada de personalização. <b>Recusar não limita absolutamente nada</b> — e a escolha pode ser mudada quando quiser em <b>⚙ Ajustes → Cookies de anúncio</b>.',
        'Quando os anúncios existirem de verdade, eles vão ficar nas <b>páginas do guia</b> e no <b>fim da tela inicial</b>. Nunca perto dos botões de batalha: além de ser irritante, clique acidental é o jeito mais rápido de o projeto perder a conta de anúncios.',
        'A <b>Política de Privacidade</b> foi atualizada junto pra contar exatamente esse estado — ela já dizia o que aconteceria; agora diz também o que já acontece.'
      ] },
      { nome: 'Correções', itens: [
        'A <b>Política de Privacidade</b> contava menos do que o jogo realmente faz. Foi reescrita e ficou bem mais completa e honesta: agora fala do banco de dados local que guarda os Pokémon baixados, do que os outros veem de você numa sala de multiplayer, do que acontece com as imagens que você anexa num relato, e de todos os serviços que o jogo toca. Ganhou também data de atualização, seus direitos pela LGPD e pelo GDPR, por quanto tempo cada coisa fica guardada e pra onde escrever.',
        'A política que aparece dentro do jogo e a da página pública passaram a ser <b>o mesmo texto</b>, escrito num lugar só — não tem como uma dizer uma coisa e a outra dizer outra.'
      ] }
    ] },
  { versao: '3.0', data: '2026-09-29', titulo: '🐞 Relatos: agora dá pra saber no que deu', piada: 'Mandar um relato era como entregar um bilhete a um Psyduck: ele guardava, ele entendia, ele até resolvia — mas a cara dele continuava exatamente a mesma. Agora o Psyduck responde por escrito.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Em <b>🐞 Relatar</b>, a lista "Seus relatos" agora mostra <b>a situação de cada um</b>: ⏳ Aguardando, 👀 Em análise, <b>✅ Atendido</b> ou 📦 Arquivado — e, quando houver, um recado de quem cuida do jogo dizendo o que foi feito. Antes aparecia só uma palavra solta do banco de dados, que não dizia nada.',
        'Dá pra acompanhar sem perguntar: se o seu bug já virou correção, ele aparece como <b>Atendido</b> — e o que mudou está em 📜 Novidades.',
        'Isso só funciona pra quem envia <b>com a conta aberta</b> (é o que permite ligar o relato a você depois). Sem conta o envio continua igual, e a tela agora explica isso em vez de não mostrar nada.'
      ] },
      { nome: 'Correções', itens: [
        '<b>Todos os relatos abertos foram respondidos</b> — os de bug viraram correção, e os pedidos que já existiam no jogo foram marcados como atendidos. Obrigado a quem mandou. 💛',
        'Estas <b>notas de atualização</b> foram compiladas: eram 96 versões, muitas do mesmo assunto, e várias só corrigiam um problema que a leva anterior tinha criado. Agora cada entrada conta um tema inteiro, da primeira versão ao estado de hoje.',
        '<b>Anexar imagem num relato agora exige estar na sua conta.</b> Mandar o relato continua <b>sem precisar de conta</b> — isso não mudou e não vai mudar. O que precisa de conta é o print.',
        'O porquê, sem enrolação: a caixa onde os prints ficam guardados aceitava envio de qualquer pessoa, sem limite nenhum. Uns poucos milhares de arquivos de 2 MB e o espaço do jogo acabava — e sem conta não tem como saber de quem veio pra segurar. Com conta, cada envio tem dono, e aí dá pra limitar.',
        'A tela não esconde isso: sem conta, o lugar do print <b>explica o motivo</b> e deixa o botão de entrar ali do lado, em vez de simplesmente não aparecer.',
        'Se você tinha um relato guardado esperando internet e ele levava print, ele <b>sobe do mesmo jeito</b> — sem a imagem, e a tela avisa. Antes de mais nada o seu texto chega; era o que importava.'
      ] }
    ] },
  { versao: '2.9', data: '2026-09-29', titulo: '🔧 Faxina de correções: Tera, caçada, Mega no registro e os campos brancos', piada: 'Você terastalizava bem na frente do Pokémon selvagem. Ele via o cristal, aplaudia educadamente e continuava batendo exatamente no seu tipo antigo. Muito gentil da parte dele. Completamente errado.',
    secoes: [
      { nome: 'Correções', itens: [
        '<b>O botão da 🎯 Caça Shiny não fazia nada.</b> Você revelava a rota inteira, a lista de Pokémon aparecia, você clicava — e nada acontecia, nem escolha, nem aviso, nem erro. Corrigido: escolher (e parar) a caça funciona, só o escolhido aparece na rota, e a mudança agora sai num aviso bem visível, não só numa borda que passava despercebida.',
        'De quebra, <b>ação que falhar agora avisa na tela</b> em vez de fingir que você não clicou. Se algum botão der erro, você vê o motivo — e dá pra mandar pelo 🐞 Relatar com a informação que faltava.',
        'A <b>Terastalização</b> agora vale em todo canto. A eficácia anunciada ("É super efetivo!"), as imunidades (Leech Seed, Guilhotina, esporos), o <b>Stealth Rock</b> e o <b>Tera Blast</b> seguem o tipo Tera — antes o dano já saía certo, mas a mensagem e essas regras ainda olhavam o tipo de origem.',
        'O <b>Pokémon selvagem</b> escolhia o golpe pelos seus tipos antigos: você virava Tera Água e ele continuava insistindo no golpe super efetivo contra o tipo de antes. Agora ele enxerga o tipo novo. O <b>Lodo Negro</b> e o <b>Ímã (Magnet Pull)</b> também seguem o tipo atual — quem vira Tera Veneno passa a ser curado pelo Lodo, e o Aço que vira Tera de outro tipo consegue fugir do Ímã.',
        'Derrotar um Pokémon <b>já Mega Evoluído</b> (Alfa, lendário ou de treinador) gravava a <b>forma Mega no lugar da espécie</b> no seu progresso: "Alakazam #10037", com o sprite da Mega, na tela de desbloqueios, na Pokédex da conta e nas conquistas. Agora o que conta é sempre a espécie original, inclusive pra quem já tinha o engano guardado na carreira. As <b>formas regionais</b> não são tocadas — elas têm sprite próprio de propósito.',
        'Um <b>Alfa</b> (ou o lendário principal) que Mega Evoluía no meio da luta podia desmaiar na hora, sem ninguém encostar nele: o bônus de HP que todo chefe ganha ao entrar em campo se perdia na troca de forma. Agora ele sobrevive à Mega.',
        'Evoluir pra uma espécie que você nunca tinha encontrado no mundo deixava ela eternamente "?" na Pokédex de toda rota onde ela vive, mesmo com uma dela na sua equipe. Agora evoluir já revela a silhueta.',
        'Caixas de texto e seletores apareciam com o <b>fundo branco padrão do navegador</b> — uma faixa clara no meio da tela escura, com o texto quase ilegível por cima. Acontecia no "Equipar item" da Sala de Raide, na busca de Pokémon da criação, no chat da sala, no código da sala e no apelido. Agora todo campo do jogo já nasce com a cara do resto.',
        'Clicar em <b>Novo jogo</b> durante uma batalha não fazia nada — nem abria, nem explicava. Continua trancado de propósito (sair no meio da luta seria fuga), mas agora ele diz isso; vale pra todas as ações que a batalha tranca.'
      ] }
    ] },
  { versao: '2.8', data: '2026-09-29', titulo: '🎮 A sala virou uma batalha de verdade', piada: 'Três Swampert com o mesmo nome atacando no mesmo turno, e o registro repetindo "Swampert usou Surf" três vezes sem dizer qual. Parecia um turno; era uma reunião de condomínio. Agora são Swampert 1, 2 e 3 — e o 2 continua sendo o problemático.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Agora dá pra entrar numa sala (Co-op ou PvP) com os seus <b>Pokémon do Hall da Fama</b> — sem precisar de uma jornada em andamento e sem se contentar com um convidado de nível 5. A escolha "Com qual Pokémon você entra?" também aparece <b>dentro da sala</b>, no lobby: dá pra trocar entre a sua run, o Hall da Fama e um convidado a qualquer momento antes da luta, sem sair e perder o código.',
        'O turno <b>não aparece mais todo de uma vez</b>: as linhas saem uma a uma e o cartão de <b>quem está agindo naquele momento</b> fica destacado. Pokémon de mesmo nome no seu time viraram numerados (Swampert 1, Swampert 2, Swampert 3) — sem isso o registro não dizia qual dos três tinha atacado. Quem liga "reduzir animações" no aparelho continua recebendo o turno inteiro de uma vez.',
        'A <b>luta em sala virou uma cena de verdade</b>: campo ao fundo, sprites grandes (o seu de costas, como manda a tradição), placa de papel com tipos, HP e — finalmente — <b>status e mudanças de atributo</b>. Antes dava pra passar a luta inteira envenenado sem ver isso em lugar nenhum. Com muita gente em campo, tudo encolhe sozinho pra caber.',
        '<b>🔗 Convite por link</b>: um toque copia um endereço que já entra na sua sala. Quem receber cai direto no lobby, sem digitar nada. O <b>📋 código</b> continua ali, agora em letras garrafais pra ditar sem erro.',
        '<b>👁 Só assistir</b>: dá pra entrar numa sala sem entrar no time, acompanhar a luta e conversar no chat. Bom pra ver a Raide dos amigos sem atrapalhar.',
        'O lobby mostra <b>em que pé cada um está</b> — 👑 anfitrião, ✅ pronto, ⏳ escolhendo, 👁 assistindo — e o <b>✅ Pronto passou a valer em todos os modos</b>, não só na Sala de Raide. Quando o botão de começar está apagado, agora ele <b>diz por quê</b>, com nome e tudo.',
        'Durante o turno: <b>barra de tempo</b> que esvazia (e fica vermelha na reta final), <b>fichas de quem já escolheu</b> no lugar de uma frase com nomes, e <b>📜 turnos anteriores</b>, pra reler o que passou voando.',
        'Escolher com o que você entra (jornada, Hall da Fama, convidado ou só assistir) agora acontece <b>dentro da sala</b>, onde você já vê o tipo de luta e quem chegou. E <b>Pokémon desmaiado não impede mais de entrar</b>: o Centro Pokémon está ali no lobby.'
      ] },
      { nome: 'Correções', itens: [
        '<b>Quem criava a sala travava depois da primeira rodada</b>: dava pra atacar uma vez e nunca mais, a tela ficava em "Escolhas enviadas" e os turnos passavam sozinhos enquanto o chefe batia. Numa luta nova acontecia já no turno 1. Quem entrava numa sala dos outros nunca foi afetado.',
        'A ☄ Sala de Raide não abria a escolha de Pokémon pra quem tinha um <b>shiny</b> no Hall da Fama: a tela quebrava na metade, o topo já dizia "Sala de Raide" e a parte de baixo continuava mostrando as opções de Co-op, sem nenhum aviso. E o resumo no topo dizia "Co-op" (com uma rota) mesmo no modo Raide.',
        'Quando algo quebra ao desenhar a sala, agora aparece o erro na tela em vez de ficar meia tela velha fingindo que está tudo certo.',
        'A sala <b>parou de piscar</b>. O anfitrião mandava a batalha inteira de quatro em quatro segundos e a cada escolha de qualquer um, e cada pacote desses redesenhava a tela toda. Agora o que viaja é um sinal curtinho, e o que não mudou não é redesenhado: menos internet gasta, menos tremedeira, e o que você está digitando no chat fica onde estava.',
        'Se algo der errado ao desenhar a sala, ela não fica mais <b>meia velha e meia nova</b> contando duas histórias diferentes: ou aparece inteira, ou aparece o erro.',
        '<b>Segurança da sala de multiplayer.</b> A sala aceitava de olhos fechados tudo o que chegava pela internet — e parte disso ia direto pra tela. Quem estivesse na mesma sala podia mandar um pacote torto e fazer coisa que ninguém deveria poder fazer no seu navegador, incluindo mexer com a sua conta. Agora <b>todo pacote é conferido antes de encostar no jogo</b>: número tem que ser número, texto tem que ser texto, e endereço de imagem só vale se vier dos servidores de sprite de sempre. O que não passa é jogado fora e vai pro diagnóstico da sala (o 🔎 lá embaixo).',
        'De quebra, o mesmo cuidado conserta um jeito silencioso de <b>estragar a sua jornada</b>: uma recompensa que chegasse torta no fim de uma luta em grupo podia embaralhar o seu dinheiro no save.',
        '<b>Pacote que se diz do anfitrião agora é conferido.</b> Estado da luta, fim de luta e configuração do lobby só valem se vierem de quem realmente está hospedando.',
        'Sala com <b>pacote sem pé nem cabeça</b> não deixa mais a tela em branco: ela ignora e segue, em vez de travar no meio.'
      ] }
    ] },
  { versao: '2.7', data: '2026-09-29', titulo: '🧠 Inimigos que pensam, e golpes que tiram você da luta', piada: 'Ensinamos o inimigo a provocar. No primeiro teste ele provocou uma Chansey, que esqueceu que sabia curar e passou a luta inteira dando Pound. Pedimos desculpas à Chansey e mantivemos o recurso.',
    secoes: [
      { nome: 'Novidades', itens: [
        'A IA dos inimigos foi refeita: em vez de "sempre o golpe de maior dano", cada golpe ganha uma <b>nota</b> pela situação da luta (quem apanha, o clima, as telas, o HP dos dois). <b>Selvagens</b> continuam como eram — batem no que dói mais e erram bastante.',
        '<b>Treinadores</b> agora contam o dano de verdade (precisão, imunidades, se o golpe derruba), <b>paralisam, queimam e põem pra dormir</b> quem ainda não tem status, e <b>se curam</b> quando estão no fim.',
        '<b>Alfas, lendários e o chefe da semana</b> jogam com tudo: sobem atributos (sem exagerar além de +2), derrubam os seus, montam Reflect e Light Screen, mudam o clima e provocam quem depende de golpe de status. E todos evitam bobagem: não usam golpe que você é imune, não se curam com o HP cheio, não se explodem à toa e não repetem o que já está ativo.',
        'Quatro golpes que <b>travam o que o alvo pode escolher</b> passaram a funcionar: <b>Taunt</b> (só golpes de dano), <b>Encore</b> (repete o último golpe), <b>Disable</b> (desativa o último golpe) e <b>Torment</b> (não deixa repetir o golpe anterior). Se o inimigo é mais rápido e te provoca antes de você agir, <b>o seu golpe de status falha</b>; sob Encore, a sua escolha é trocada pelo golpe repetido.',
        'A tela de golpes mostra <b>o que está prendendo o seu Pokémon</b> (provocado, Encore, golpe desativado, atormentado, item que trava) e por quantos turnos; o botão bloqueado explica o motivo. <b>Oblivious</b> ficou imune ao Taunt e <b>Aroma Veil</b> (nova) protege contra os quatro.',
        '<b>Roar, Whirlwind, Dragon Tail e Circle Throw</b> passam a funcionar. Contra um <b>selvagem</b> a luta acaba (sem XP nem dinheiro). Contra um <b>treinador</b> ele manda outro Pokémon da equipe — o que saiu não conta como derrotado e pode voltar. Os seus também podem ser arrastados: quem levou o golpe sai e a luta segue sem ele; se era o último em campo, acaba como uma fuga. Alfas, lendários e o chefe da semana não saem.',
        'Se você foi tirado da luta com aliados ainda lutando, a tela mostra <b>⏭ Assistir o turno</b> (quem ficou de fora não ganha XP). Novo item: <b>Cartão Vermelho</b> (loja, ₽3.000) — quem acerta o portador é expulso da luta, e o cartão se gasta.',
        '<b>Regenerator</b> (recupera 1/3 do HP) e <b>Natural Cure</b> (tira o status) funcionam ao vencer a luta. <b>Wimp Out</b> e <b>Emergency Exit</b> fazem inimigos e aliados saírem ao cair da metade do HP (no seu Pokémon principal não valem, pra uma habilidade sorteada não te expulsar da luta). <b>Mean Look, Block e Spider Web</b> impedem o alvo de fugir, <b>Baton Pass</b> passa os seus bônus pra um aliado em campo, e <b>Slow Start</b> (Regigigas) e <b>Stakeout</b> ficaram ativas.'
      ] },
      { nome: 'Correções', itens: [
        'O <b>Colete de Assalto</b> deixava você clicar num golpe de status e só depois recusava. Agora os botões de status já aparecem bloqueados — e os inimigos e aliados nunca escolhem um golpe proibido no momento, caindo no Struggle se não sobrar nenhum.',
        'O treinador podia mostrar bolinhas erradas na equipe restante quando um Pokémon saía e voltava. Agora só conta quem ainda está de pé.',
        'Em luta de sala (multiplayer) os golpes que tiram da luta ainda não valem: eles avisam que não funcionam ali, em vez de fingir.'
      ] }
    ] },
  { versao: '2.6', data: '2026-09-28', titulo: '🏟 A sua conta: Arena, Hall da Fama, perfil e loja de preparo', piada: 'A Insígnia Alpha é uma Poké Ball de ouro maciço, segundo ela própria. O Meowth pediu para morder só por precaução. Negamos. Ele considerou a negativa uma confissão.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>🏟 Arena do Chefe:</b> enfrente o chefe da semana <b>sem precisar fazer uma run até a Gen dele</b> (chegar ao Eternatus exigia passar pelas 8 Gens). Ela está no menu e na tela inicial, não usa nenhuma jornada em andamento, e perder não custa nada.',
        '<b>Hall da Fama:</b> o Pokémon principal de cada jornada <b>Roguelike ou Hardcore que você termina</b> (venceu, perdeu ou encerrou) entra no Hall com o nível que tinha. Na Arena você leva de 1 a 3 deles contra o chefe. Os itens de raide que sobram numa jornada que termina vão para a sua conta, e o prêmio da Arena também.',
        'Quem criou a conta durante o Alpha ganha a <b>Insígnia Alpha</b>: uma Poké Ball dourada com o α, num cartão na tela 👤 Conta e uma versão pequena ao lado do seu nome no topo. Ela é sua para sempre — quem entrar depois que o Beta abrir não consegue.',
        '<b>👤 Ver perfil:</b> na lista de amigos cada amigo tem um botão <b>Ver perfil</b>: ícone, insígnia escolhida, se é <b>Treinador do Alpha</b>, desde quando joga, os números das jornadas (vitórias, Gens fechadas, melhor pontuação, maior nível, Pokémon derrotados, shinies, espécies desbloqueadas, mais jogado), todas as <b>insígnias de evento</b> e as <b>últimas 5 runs</b>. Também dá pra ver o seu próprio perfil, como os amigos veem. Só amigos veem o perfil um do outro.',
        'Três badges novas de <b>parceiros</b> na tela 🏅 Conquistas: <b>Casa cheia</b> (feche uma Gen com a equipe e o esconderijo lotados), <b>Lobo solitário</b> (feche uma Gen sem recrutar ninguém) e <b>Cemitério de parceiros</b> (perca 15 parceiros numa mesma run). Fora do modo Fácil.',
        'Nova explicação <b>"Como funcionam os chefes da semana"</b> na tela inicial e na Arena, com uma <b>tabela dos 3 caminhos</b> (Arena, dentro de uma run e em grupo): o que cada um precisa e o que muda em cada um.',
        'Toda jornada terminada deixa 10% do seu dinheiro máximo como <b>saldo de conta</b>, pra sempre — contando a carreira inteira, inclusive as jornadas que você fechou antes desta atualização. Na 🏟 Arena, esse saldo abre a "Loja de preparo": cura, revive, itens de stat e itens de segurar, pelo mesmo preço da loja normal, e você escolhe quem equipa cada item antes de entrar na luta.',
        'A Arena ganhou <b>Reviver</b> (traz um aliado caído de volta no meio da luta, sem esperar o time inteiro cair) e <b>usar item</b> durante o combate, igual numa jornada de verdade.'
      ] },
      { nome: 'Correções', itens: [
        'Enviar uma <b>sugestão</b> na tela de bugs e sugestões dava "violates row-level security policy". A regra do servidor recusava relatos sem contexto técnico (só o bug tem). Corrigido — e o que já estava na fila de envio sai sozinho.',
        'O aviso de <b>jornadas de outro aparelho</b> voltava depois de você guardar ou excluir: a sincronização rodava duas vezes ao mesmo tempo e perguntava de novo.'
      ] }
    ] },
  { versao: '2.5', data: '2026-09-28', titulo: 'Mochila no multiplayer, golpes na ordem e quem está jogando', piada: 'Os Restos passaram semanas sem curar ninguém nas salas de multiplayer, alegando que ali estavam "fora do expediente". Mostramos o contrato. Agora eles curam em qualquer endereço.',
    secoes: [
      { nome: 'Novidades', itens: [
        'O <b>item segurado</b> do seu Pokémon (Restos, Orbe da Vida, Faixa de Foco, Sino-Concha, Elmo Rochoso, Vínculo de Batalha…) agora funciona em qualquer luta de multiplayer — antes não fazia efeito nenhum em sala. Também dá pra usar um <b>item comum</b> da mochila (Potion, X Attack, curas de status, Éter…) na sua vez, dentro de uma sala: ocupa o turno, sempre em você mesmo.',
        'Agora dá pra reordenar os <b>golpes</b> na lista com os botões ▲▼ — não gasta turno, é só a posição. Funciona na ficha (dentro ou fora de batalha, na sua jornada) e também nas Raides, tanto na Arena quanto em sala.',
        'A tela inicial mostra <b>quantas pessoas estão jogando no momento</b> — sem dizer quem, só quantas. Dá pra desligar em ⚙ Ajustes.',
        '3 habilidades novas com efeito real: <b>Sheer Force</b> (golpe com efeito secundário bate mais forte, mas perde o efeito), <b>Unnerve</b> (o oponente não consegue comer a própria fruta logo depois de levar um golpe seu) e <b>Friend Guard</b> (reduz o dano que um aliado seu recebe).'
      ] }
    ] },
  { versao: '2.4', data: '2026-09-28', titulo: '🎬 Sprites 3D, animados — e o jogo ganhou vida', piada: 'O Pikachu é pixel art desde 1996 e tem opinião formada sobre o assunto. Oferecemos três estilos: clássico, 3D e animado. Ele escolheu os três, dependendo do dia e do humor.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>Estilo de sprite</b> (⚙ Ajustes → Sprites): além do <b>Clássico</b> (o pixel-art de sempre), agora tem <b>🧊 3D</b> (o render usado em Pokémon HOME) e <b>🎬 Animado</b> (os GIFs do Pokémon Showdown, com versão de costas de verdade).',
        'O 3D não tem versão de costas — nesse estilo, na batalha, o seu Pokémon aparece de frente também. Os dois estilos têm download opcional em ⚙ Ajustes → Jogar offline, à parte do download normal.',
        'A <b>barra de HP</b> anima ao tomar dano ou se curar, em vez de saltar pro número novo. A de <b>XP</b> faz o mesmo, e o número de <b>PP</b> pisca quando você usa um golpe.',
        'Cena de batalha com mais vida: quem ataca dá um pulo, quem apanha pisca vermelho, quem se cura pisca verde, e status/mudanças de atributo pulsam sutilmente enquanto durarem.',
        'Botões reagem ao toque (um leve "afundar") e as telas trocam com uma transição suave em vez de aparecer seco. Na tela inicial, o marcador "jogando agora" pulsa, o Pokémon da prévia flutua sozinho e a grade de iniciais levanta um pouco no toque.',
        'Batalha no celular <b>deitado</b>: a cena vira uma coluna fixa à esquerda em vez de ficar presa no topo, aproveitando a tela larga e baixa.',
        'Tudo isso respeita a preferência de <b>"reduzir animações"</b> do aparelho — quem a liga continua vendo as mudanças na hora, sem transição.'
      ] },
      { nome: 'Correções', itens: [
        'Os <b>GIFs animados</b> esticavam pra caber numa caixa quadrada, ficando com a proporção errada — cada Pokémon tem um tamanho de sprite diferente lá. Agora encolhem mantendo a forma certa.'
      ] }
    ] },
  { versao: '2.3', data: '2026-09-27', titulo: '🥷 Ash-Greninja, e a pedra na prateleira', piada: 'O Greninja derrubou mil oponentes antes de alguém reparar que ele trocava de forma no meio da luta. Ele não comentou nada. Greninja não comenta.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>🥷 Vínculo de Batalha:</b> conquiste <b>1.000 golpes finais sendo Greninja</b> pra liberar a compra do item (₽15.000). Segurando-o, derrubar um oponente transforma seu Greninja em <b>Ash-Greninja</b> pro resto da luta — atributos mais altos e <b>Water Shuriken</b> vira poder fixo 20 com <b>sempre 3 acertos</b> (a versão normal é 2 a 5, aleatório). Não precisa apertar botão nenhum: acontece sozinho, como uma habilidade.',
        'A <b>Pedra Mega</b> e o <b>Cristal Z</b> agora mostram a pedra/cristal de VERDADE da sua espécie ou tipo na mochila e na loja, em vez do ícone genérico de caixinha — quem joga de Charizard vê a Charizardita. Metade das Megas deste jogo não existe nos jogos de verdade e não tem pedra desenhada; nesses casos aparece a <b>Pedra-Chave</b>, o item real que ativa qualquer Mega Evolução.'
      ] },
      { nome: 'Correções', itens: [
        'A <b>loja escondia a Pedra Mega, o Cristal Z e o Vínculo de Batalha</b> — às vezes os três de uma vez, às vezes a loja inteira nem abria. Eram três causas somadas: a checagem dos três era feita numa tentativa só (um problema em qualquer um apagava todos), ela tentava ler o Pokémon de dentro de uma luta que não estava acontecendo (ou seja, quase sempre, já que quase toda compra é fora de batalha), e não tinha plano B se o progresso da conta falhasse. Agora cada item é verificado por conta própria, sempre olhando pro Pokémon certo, e se o progresso permanente falhar a conta é refeita a partir das suas jornadas — a loja nunca deixa de abrir por causa disso.'
      ] }
    ] },
  { versao: '2.2', data: '2026-09-27', titulo: '💰 Vender itens, e o shiny que desbloqueia de verdade', piada: 'O Beedrill shiny passou a carreira inteira sendo verde-limão sem receber crédito nenhum por isso. Agora ele desbloqueia a espécie. Pediu retroativo. Teve retroativo.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>💰 Vender ou jogar fora:</b> cada item da mochila ganhou um botão pra vender (metade do preço de compra) ou jogar fora, pra quem não tem preço de loja. Mesmo HUD de quantidade da compra, só que ao contrário.'
      ] },
      { nome: 'Correções', itens: [
        'Pegar (ou evoluir até) um Pokémon <b>shiny</b> agora desbloqueia mesmo a opção "✨ Começar shiny" daquela espécie em jornadas futuras — antes só recrutar um aliado shiny fazia isso, e o seu PRÓPRIO Pokémon shiny nunca contava, nem quando evoluía. Quem já tinha um shiny antes disso recebe o crédito retroativo assim que abrir a jornada de novo.',
        'A loja só tinha o botão <b>"Sair da loja"</b> lá embaixo, depois de toda a lista de itens — quem clicava nela sem querer tinha que rolar a tela inteira pra voltar. Agora o botão também aparece no topo.',
        'A ficha de cada espécie na Pokédex mostra também o progresso ESPECÍFICO do Roguelike (que só conta o que foi feito em jornadas Roguelike) — antes só dava pra ver o total da carreira inteira, o que confundia quem via "derrotou 12" e achava que já tinha passado dos 10 exigidos.'
      ] }
    ] },
  { versao: '2.1', data: '2026-09-27', titulo: 'Mais de 50 habilidades com efeito real', piada: 'O Slakoth pediu para constar que a habilidade nova dele (Truant) está funcionando perfeitamente. Ele provou descansando. No turno seguinte, provou de novo.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Mais de <b>50 habilidades</b> passam a valer em batalha, entre elas <b>Moxie</b>, <b>Defiant</b>, <b>Competitive</b>, <b>Contrary</b>, <b>Simple</b>, <b>Unaware</b>, <b>Mirror Armor</b>, <b>Poison Heal</b>, <b>Truant</b>, <b>Pressure</b>, <b>Iron Fist</b>, <b>Strong Jaw</b>, <b>Sharpness</b> e <b>Steelworker</b>.',
        'Habilidades que <b>reagem a levar um golpe</b>: Steam Engine, Water Compaction, Stamina, Weak Armor, Justified, Rattled, Anger Point, Sand Spit e Seed Sower. Também entram Gooey e Tangling Hair (baixam a Velocidade de quem encosta), Poison Touch, Wonder Skin e as três que barram golpe de prioridade (Dazzling, Queenly Majesty, Armor Tail).',
        'Defesa e entrada em campo: <b>Fur Coat</b> e <b>Ice Scales</b> (metade do dano físico / especial), <b>Super Luck</b> (crítico mais fácil), <b>Intrepid Sword</b> e <b>Dauntless Shield</b> (sobem um atributo ao entrar), Grass Pelt e Flower Gift. Hadron Engine e Orichalcum Pulse ligam o terreno elétrico / o sol e ainda dão o bônus de atributo junto.',
        'Seis <b>habilidades</b> novas com efeito real em batalha: <b>Protosynthesis</b> e <b>Quark Drive</b> (reforçam seu maior atributo no sol ou no Campo Elétrico), <b>Magnet Pull</b> (prende selvagens do tipo Aço, nem fugir adianta), <b>Anticipation</b> (avisa se o oponente tem golpe perigoso), <b>Synchronize</b> (devolve queimadura, paralisia ou veneno pra quem causou) e <b>Stench</b> (chance extra de fazer o oponente recuar).'
      ] },
      { nome: 'Equilíbrio', itens: [
        'A <b>XP por vitória caiu para 60%</b>: são mais batalhas por nível e a jornada dura cerca de <b>1,65× mais</b>. O equilíbrio relativo não mudou — treinador continua valendo 1,5× de um selvagem, e o modo escolhido continua pesando igual.',
        'Mexemos na XP ganha, e não na curva de nível: a curva vem da PokéAPI e fica guardada no seu aparelho, então mudá-la quebraria a comparação com as jornadas que você já terminou.'
      ] },
      { nome: 'Correções', itens: [
        '<b>Download</b> agora lê o oponente: sobe o Ataque se a Defesa dele é menor que a Defesa Especial, e o Ataque Especial no caso contrário (antes subia sempre o Ataque Especial).',
        '<b>Guard Dog</b> sobe o Ataque quando alguém tenta intimidar, em vez de só impedir a queda. <b>Sand Force</b> dá +30% em golpes de Pedra, Terra e Aço na tempestade de areia. <b>Effect Spore</b> sorteia entre sono, paralisia e veneno, como no jogo, e não pega em Grama.',
        '<b>Water Bubble</b> também dobra os seus golpes de Água. <b>Toxic Boost</b> só vale envenenado e <b>Flare Boost</b> só queimado. <b>Magic Guard</b> bloqueia todo dano indireto (veneno, queimadura, recuo, armadilhas, Rough Skin…), e não só o clima.',
        'Inner Focus, Own Tempo e Oblivious agora são imunes à Intimidação. E no <b>multiplayer</b> a Intimidação, o Download e as habilidades de degrau ao entrar em campo finalmente funcionam (antes só valiam no single player).'
      ] }
    ] },
  { versao: '2.0', data: '2026-09-25', titulo: '⚡ As quatro transformações: Mega, Tera, Z-Move e Gigantamax', piada: 'Mil golpes finais depois, a pedra reagiu. Mil e um, para ser exato: ela também estava contando, só que no ritmo dela. Pedra é assim. O Rayquaza, que não precisa de pedra nenhuma, assistiu a tudo lá de cima achando a maior graça.',
    secoes: [
      { nome: 'Novidades', itens: [
        'A <b>Mega Evolução</b> chegou. Conquistada a Pedra Mega de uma espécie (1.000 golpes finais dados sendo ela, na evolução final), aparece um botão ⚡ na batalha — e ele <b>não gasta o seu turno</b>: você megaevolui e ataca na mesma rodada. A forma Mega muda status, tipos, habilidade e aparência de verdade, e dura até o fim da batalha. Charizard e Mewtwo perguntam qual forma você quer (X ou Y), e Groudon e Kyogre entram pela mesma porta com o nome certo: <b>Reversão Primitiva</b>.',
        'A <b>Pedra Mega</b> existe de verdade: conquistar a Mega de uma espécie libera a <b>compra</b> da pedra (₽15.000 na loja, só para a sua espécie), e é preciso <b>segurá-la</b> para megaevoluir. Rayquaza é a exceção, como nos jogos: ele megaevolui por saber <b>Dragon Ascent</b>, sem pedra nenhuma.',
        'O outro lado também joga esse jogo: <b>Alfa, lendários e treinadores</b> podem megaevoluir, e fazem isso quando caem à metade do HP. A luta tem segunda fase agora. Selvagem de rota continua selvagem de rota, e só você megaevolui — aliado não, mesmo que a espécie dele esteja liberada.',
        'São <b>95 formas cobrindo 89 espécies</b>, e a tela de Conquistas ganhou o <b>catálogo das Megas</b>: dá para ver todas elas, de todas as Gens, e quais você já conquistou.',
        'Dá para <b>acompanhar uma conquista da conta</b> durante a jornada: o botão 📌 na tela de Conquistas fixa uma, ela aparece no painel de Missões com o quanto falta, e ao completar você é avisado e <b>ganha a recompensa nesta run</b> — além de valer nas próximas.',
        'A tela de batalha agora tem a <b>cara da rota</b>: caverna, mar, usina, vulcão, floresta, gelo e mais, cada uma com céu, chão e luz próprios. E a lista de espécies desbloqueadas ganhou <b>busca</b> (por nome ou número) e vem sempre em ordem de Pokédex, com o número visível.',
        'A <b>Terastalização</b> chegou. Cada tipo é conquistado à parte (200 derrotados daquele tipo), e na batalha você escolhe entre os que já tem: o botão 💎 <b>não gasta o turno</b>, igual à Mega.',
        'Terastalizado, você passa a ter <b>um tipo só</b> para receber golpe — é o que muda a luta: um Charizard Tera Água deixa de tomar 4× de Pedra. No ataque, a regra é a dos jogos: golpe do tipo Tera que você <b>já tinha</b> bate ×2, um tipo Tera novo bate ×1,5, e o STAB que você já tinha continua valendo. Dá para usar Tera e Mega na mesma batalha — são conquistas diferentes, cada uma com o seu custo.',
        'O <b>Z-Move</b> chegou. Conquistado um Z (250 eliminações com o golpe, ou 500 com golpes do mesmo elemento), a loja passa a vender o <b>Cristal Z</b> por ₽12.000 — e, segurando o cristal, o botão 🌀 converte um golpe seu num golpe muito mais forte, uma vez por batalha.',
        'Ao contrário da Mega e da Tera, o <b>Z-Move é o seu turno</b>: ele não transforma nada, ele é o ataque da rodada (e gasta o PP do golpe). O botão é laranja justamente para não ser clicado achando que é de graça. A conversão segue a tabela dos jogos, achatada no topo: um golpe de 60 vira 120, um de 120 vira 190 — usar o Z no golpe fraco rende mais.',
        'O <b>Gigantamax</b> chegou, e com ele as quatro gimmicks estão jogáveis. Conquistado (nível 50 com a espécie em 25 jornadas), o botão 🔴 <b>dobra o seu HP</b> por 3 turnos e transforma todo golpe num golpe Max — e o seu Pokémon fica <b>gigante na tela</b>. É a única das quatro que <b>não pede item</b>: quem levou 25 jornadas para chegar aqui já pagou o preço.',
        'O HP do Gigantamax volta na mesma proporção ao encolher: se você estava com metade da vida gigante, volta com metade da vida normal. E a tabela do golpe Max é mais modesta que a do Z de propósito — o Z é um tiro único, o Max vale três turnos.',
        'O <b>inimigo agora terastaliza</b>: Alfa, lendários e treinadores, ao cair à metade do HP, como já acontecia com a Mega. Mas só uma virada por luta — quem já megaevoluiu não terastaliza também, senão o combate viraria de cabeça para baixo de uma vez só.',
        '<b>Gimmicks no co-op:</b> na luta em grupo (selvagens, Alfa e chefe da semana) o seu Pokémon <b>principal</b> pode <b>Mega Evoluir, Terastalizar, Gigantamaxar e usar Z-Move</b>, com as mesmas regras do single player: conquista da sua conta, Pedra Mega e Cristal Z segurados, uma vez de cada por luta. Aliados, Pokémon convidado e PvP ficam de fora, e nada disso muda o Pokémon da sua run depois da luta.',
        '<b>Gigantamax do inimigo:</b> só Pokémon de <b>treinador</b> gigantamaxam — na metade do HP, como a Mega e a Tera dele. Ele dobra o HP, os golpes viram Max por 3 turnos e depois encolhe. Ainda vale <b>uma virada por luta</b>: quem não tem Mega sorteia entre Tera e Gigantamax.',
        '<b>Z-Move do inimigo:</b> só <b>treinadores e Alfas</b>. O treinador sempre carrega um Z; o Alfa só de vez em quando (chance baixa, sorteada no começo da luta). Uma vez por luta, num golpe de dano.',
        '<b>Mega Z:</b> Absol, Garchomp e Lucario agora têm a <b>Mega comum e a Mega Z</b> (Legends Z-A), e você escolhe qual na hora, como no X/Y do Charizard.',
        'Os Pokémon que você derrota no <b>co-op</b> contam para as conquistas da conta (a barra da Mega da espécie que você usa e os marcos de caçada), como no single player. Tera e Z-Move continuam pedindo o golpe final seu, então só andam no single player.'
      ] },
      { nome: 'Equilíbrio', itens: [
        'A <b>Terastalização do inimigo</b> (treinadores, Alfas e lendários) é <b>totalmente aleatória</b>: qualquer um dos 18 tipos, seja um dos dele ou não. Antes ele sempre virava o próprio primeiro tipo, e não havia surpresa nenhuma. Olhe o tipo 💎 na plaquinha dele depois da virada: a fraqueza nova pode ser qualquer uma.',
        'Cada gimmick do inimigo tem a sua faixa de nível: a <b>Mega</b> só de <b>nível 40 em diante</b> (antes treinadores das primeiras rotas já megaevoluíam) e a <b>Tera</b> e o <b>Gigantamax</b> só em rotas de <b>nível 30 ou mais</b>.'
      ] },
      { nome: 'Correções', itens: [
        'O <b>botão de Gigantamax nunca aparecia numa batalha de verdade</b>: a tela de Conquistas contava certo as 25 jornadas no nível 50, mas a batalha lia uma lista vazia. Agora os dois leem o mesmo progresso.',
        'Inimigo Alfa, lendário ou de treinador <b>nível 40+ que não tem Mega</b> (quase todos) nunca terastalizava: a checagem de Mega o marcava como "já virou". Agora ele segue pra Tera (ou Gigantamax) como devia.',
        'A tela de Conquistas cortava a lista da Mega em 24 espécies, mesmo as já conquistadas. Agora toda Mega conquistada aparece; o corte vale só pras barras em andamento.'
      ] }
    ] },
  { versao: '1.9', data: '2026-09-25', titulo: '💰 Carteira, compras em atacado e curas pro nível 100', piada: 'Uma Potion de 20 HP num Pokémon nível 100 é um copo d’água num Magcargo. O lojista ouviu as reclamações, assentiu com seriedade e passou a estocar o balde — por ₽2.500, sem desconto.',
    secoes: [
      { nome: 'Novidades', itens: [
        '<b>💰 Carteira:</b> o dinheiro virou uma pílula grande no topo, sempre fora do menu ☰ (feito pra quem joga no celular). Na <b>batalha</b> ele também aparece na barra de turno, que não sai da tela, e a <b>loja</b> abre com "Você tem ₽X". Quando o valor muda, aparece um <b>+₽ / −₽</b> ao lado.',
        'Comprar na loja abre um <b>HUD de quantidade</b>: botões −10, −, +, +10 e <b>Máx</b>, mais um campo para digitar, com o total e o troco atualizando na hora. Depois da compra, um <b>aviso 🛒</b> diz o que você levou, quanto pagou e quantos tem na mochila.',
        'Novas curas que acompanham o seu HP: <b>Mega Potion</b> (50% do HP máximo), <b>Max Potion</b> (todo o HP) e <b>Full Restore</b> (todo o HP e cura qualquer status). Também chegaram o <b>Max Ether</b> (restaura todos os PP), o <b>Max Revive</b> (reanima um aliado com o HP cheio) e o <b>X Sp. Def</b>.',
        '<b>📎 Imagens nos bugs e sugestões:</b> dá pra anexar até <b>2 imagens de até 2 MB cada</b>, em PNG, JPG ou WebP. No computador dá pra colar com Ctrl+V. O jogo reduz o print antes de enviar. Sem internet, as imagens ficam guardadas junto com o relato (se couberem) e sobem sozinhas depois.'
      ] },
      { nome: 'Equilíbrio', itens: [
        'Explorando agora dá pra achar mais variedade: Super, Hyper e Mega Potion, Burn Heal, Ice Heal e todos os X-itens.'
      ] }
    ] },
  { versao: '1.8', data: '2026-09-25', titulo: '🌦 Clima, terreno e o tempo de cada rota', piada: 'O departamento meteorológico de Kanto pede desculpas pelos trinta anos de sol ininterrupto. O responsável, um Torkoal, alegou que estava apenas respirando. Foi transferido para o deserto de Hoenn, onde o defeito dele virou currículo.',
    secoes: [
      { nome: 'Novidades', itens: [
        'As batalhas agora têm <b>clima</b>: sol forte, chuva, tempestade de areia, granizo e neve. Ele aparece no topo da luta, com quantos turnos ainda faltam. Sol deixa os golpes de Fogo 50% mais fortes e afraquece os de Água; a chuva faz o contrário. Areia e granizo machucam todo turno quem não for do tipo certo, e a neve dá mais Defesa pros Pokémon de Gelo.',
        'Chegaram os <b>terrenos</b>: Campo Elétrico, Campo de Grama, Campo Psíquico e Campo de Névoa, que também duram 5 turnos e aparecem no topo da luta junto do clima. Elétrico deixa os golpes Elétricos 30% mais fortes e ninguém dorme; Grama fortalece golpes de Planta e cura um pouquinho todo turno; Psíquico fortalece os Psíquicos e barra golpes de prioridade; Névoa corta o dano de Dragão pela metade e bloqueia qualquer status.',
        'O terreno só vale pra quem está <b>NO CHÃO</b>: Pokémon do tipo Voador e quem tem Levitate flutuam e ficam de fora — inclusive da cura e da proteção.',
        'Rain Dance, Sunny Day, Sandstorm, Hail, Snowscape, Electric Terrain, Grassy Terrain, Psychic Terrain e Misty Terrain funcionam: ligam o tempo ou o chão por 5 turnos, valendo pros dois lados.',
        'Habilidades de clima e terreno entraram em peso: Drizzle, Drought, Sand Stream e Snow Warning mudam o tempo assim que o Pokémon aparece, e Electric Surge, Grassy Surge, Psychic Surge e Misty Surge ligam o campo. Swift Swim, Chlorophyll, Sand Rush, Slush Rush e Surge Surfer dobram a velocidade no ambiente certo; Rain Dish, Ice Body e Dry Skin curam; Sand Veil e Snow Cloak fazem o inimigo errar mais; Hydration limpa status na chuva; Leaf Guard protege no sol; Solar Power troca poder por HP.',
        'Thunder e Hurricane nunca erram na chuva (e ficam bem imprecisos no sol) e Blizzard acerta sempre no granizo e na neve. Solar Beam e Solar Blade disparam na hora quando está sol.',
        '<b>Clima e terreno de rota:</b> 27 rotas já começam a luta com o tempo da paisagem — neve nas geladas, <b>tempestade de areia</b> nos desertos, <b>sol forte</b> nos vulcões e praias, chuva nos lagos e pântanos — e 20 com terreno próprio (grama nos bosques, elétrico nas usinas, psíquico nas ruínas, névoa em Rivière e Glimwood). Vale para os dois lados, no single player e no co-op.',
        'O efeito da rota é <b>permanente</b>: só sai quando um golpe ou habilidade troca o tempo ou o chão. A troca dura os 5 turnos de sempre e, quando acaba, a rota volta ao que era. O selo na cena mostra <b>da rota</b> no lugar da contagem de turnos.',
        'Nova opção na tela inicial: <b>🌦 Clima e terreno das rotas</b>. No <b>Roguelike</b> e no <b>Hardcore</b> ela é sempre ligada; nos outros modos vem <b>desligada</b> e você liga se quiser. Só dá pra escolher no começo da jornada.',
        '<b>Weather Ball</b> muda de tipo e dobra o poder conforme o tempo (Fogo no sol, Água na chuva, Pedra na areia, Gelo no granizo e na neve), e o botão do golpe mostra o tipo de agora.',
        '<b>Castform</b> agora muda de forma com o tempo (Forecast): vira Fogo no sol, Água na chuva e Gelo no granizo ou na neve — os tipos e o sprite acompanham, inclusive o tempo da rota, e ele volta ao normal no fim da luta.'
      ] }
    ] },
  { versao: '1.7', data: '2026-09-24', titulo: 'A eficácia no próprio botão, e o esconderijo', piada: 'Ninguém nasce com a tabela de tipos decorada — só os Alakazam, e eles não compartilham. Agora o próprio botão conta se o golpe é bom. Corrigimos o jogo, não as pessoas.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Cada golpe seu agora mostra, no próprio botão, <b>o quanto ele é vantajoso</b> contra quem está na sua frente: extremamente efetivo (⏫), super efetivo (🔼), dano normal, pouco efetivo (🔽), quase sem efeito (⏬) ou não afeta (✖). Vem com cor, seta e texto ao mesmo tempo — cor sozinha não serve para quem não a distingue.',
        'O <b>tipo</b> de quem está em campo aparece na plaquinha de batalha, dos dois lados. Era o dado que explicava por que o seu golpe bateu fraco e ele estava escondido na ficha, a um clique de distância. Quem terastalizou mostra o tipo Tera, que é o que vale.',
        'Na Pokédex da rota, os Pokémon que você já encontrou viraram <b>clicáveis</b>: abrem a ficha completa na Pokédex.',
        'Chegou o <b>esconderijo</b>: aliados que não cabem na equipe esperam lá, em vez de se despedir para sempre. Dá para <b>guardar e trazer</b> quando quiser, fora de batalha, pelo painel de Aliados — quem volta entra descansado (atributos baixados e recuo são zerados ao guardar).',
        'O tamanho da equipe <b>não mudou</b>: a decisão de quem leva para a próxima rota continua existindo. O que acabou foi a perda permanente.',
        'Mais 16 habilidades ativas em batalha, entre elas <b>Battle Armor</b> e <b>Shell Armor</b> (o golpe nunca sai crítico contra você, nem quando seria garantido), Earth Eater, Purifying Salt, Victory Star e No Guard.'
      ] }
    ] },
  { versao: '1.6', data: '2026-09-24', titulo: 'A região decide a forma, e a rota não acaba antes da missão', piada: 'O Exeggcute passou duas semanas em Alola e voltou com onze metros de altura, tipo Dragão e um chapéu de palha. A alfândega de Kanto olhou aquilo por um tempo e liberou sem perguntas.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Evoluir <b>dentro da região</b> agora dá a forma regional: use a Pedra da Folha num Exeggcute em Alola e vem o Exeggutor de Alola, não o de Kanto. Vale pra todas as regiões e todas as formas que existem no mapa — Alola, Galar, Hisui e Paldea. Antes a evolução saía sempre na forma padrão, e a única maneira de ter uma forma regional era encontrar uma pronta no Santuário.',
        'O registro continua contando na espécie (Exeggutor), então Pokédex, desbloqueios e conquistas não mudam — o que muda é o Pokémon que fica com você, com os tipos, os status e os golpes da forma de lá.'
      ] },
      { nome: 'Equilíbrio', itens: [
        'Tivemos que nerfar o jogador Berga, só o diabo para parar ele.',
        'Rota de nível baixo agora tem folga mínima de 15 níveis antes de esgotar. Na Rota 1 (teto 6) o limite era o dobro, 12 — e como a jornada começa no nível 5, a rota parava de dar caçada antes de dar pra terminar as missões dela. Rota de teto alto não muda: o dobro continua valendo.',
        'A Mega Evolução só acumula para espécies que <b>têm Mega</b>. Antes cada estágio tinha a própria barra, então evoluir parecia zerar o progresso — e derrotar como Marshtomp enchia um contador que não levava a Mega nenhuma. Tera, Z-Move e Gigantamax seguem contando tudo.',
        'A conquista "Nunca precisei de médico" agora pede <b>fechar uma Gen</b> sem usar o Centro Pokémon. Antes bastava terminar uma jornada de qualquer jeito: dava pra entrar e sair na hora seguinte e levar a medalha. Quem tinha pego assim perde — ela é recalculada, não guardada.'
      ] },
      { nome: 'Correções', itens: [
        'O Repelente Seletivo listava TODAS as espécies da rota pelo nome, inclusive as que você ainda não tinha descoberto: a Pokédex da rota mostrava "?" e o repelente entregava a resposta. Agora só aparecem as que você já encontrou.',
        'A tela de Bugs e sugestões dizia "sem conexão" para qualquer falha de envio — inclusive quando o servidor recusava o relato. Agora ela diz o motivo de verdade e tenta reenviar a fila toda vez que você abre a tela, em vez de esperar um aviso de "internet voltou" que podia nunca chegar.'
      ] }
    ] },
  { versao: '1.5', data: '2026-09-24', titulo: '📥 Jogar offline de verdade (e não era a sua internet)', piada: 'O navegador contou 1.082 sprites de 600 bytes e concluiu, com absoluta convicção, que aquilo pesava 20 GB. No mesmo dia descobrimos que metade dos "a conexão falhou" era uma função que ninguém nunca escreveu. Pedimos desculpas à sua operadora.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Em ⚙ Ajustes tem uma seção nova: baixe um mapa inteiro (Pokémon, golpes e sprites) pra jogar sem internet sem faltar nada. Antes, offline, só aparecia quem você já tinha encontrado — e Pokémon novo ficava sem imagem.',
        'A tela mostra quantos Pokémon daquele mapa já estão guardados no aparelho e marca com ✅ os mapas completos.',
        'Dá pra baixar o JOGO INTEIRO pra jogar sem internet: ⚙ Ajustes → Jogar offline → "⬇⬇ Baixar o jogo inteiro". São os 9 mapas, com dados, golpes e sprites de todo mundo.',
        'O que o jogo guarda no aparelho saiu da caixinha apertada de antes e foi pro armazenamento grande do navegador — é o que permite guardar todos os sprites sem estourar o limite. A mesma tela mostra quanto espaço está em uso.',
        'Os iniciais das 9 regiões (e as evoluções deles) não aparecem mais soltos nas rotas: escolher o seu no começo da jornada volta a significar alguma coisa. Pikachu e Eevee continuam aparecendo normalmente.',
        'Treinadores de rota não têm mais só bicho da rota: metade da equipe deles pode ser qualquer espécie do mapa, sempre no nível da rota. Eles viajam, afinal.'
      ] },
      { nome: 'Correções', itens: [
        'A tela de "Jogar offline" dizia que o jogo ocupava mais de <b>20 GB</b> no aparelho. Não ocupava: os sprites são minúsculos (cerca de 600 bytes cada) e o jogo inteiro cabe em uns 20 MB. O número inflado vinha de como as imagens eram pedidas, e isso também podia fazer o download do jogo inteiro falhar por "falta de espaço" sem motivo nenhum. O espaço antigo é liberado sozinho na próxima vez que você abrir o jogo.',
        'Quando a internet do celular piscava, a exploração morria com um "Failed to fetch". Agora o jogo tenta de novo sozinho (até 3 vezes, com uma pausa entre elas) antes de desistir — o que resolve a maioria dessas falhas.',
        'As mensagens de erro de rede foram reescritas pra quem joga: falam de conexão instável, de limite da PokéAPI ou de erro do servidor, e lembram que dá pra baixar o mapa inteiro em ⚙ Ajustes → Jogar offline. Os avisos de "sem internet" do Alfa, dos lendários e da exploração também apontam pra lá.',
        "Evolução agora entrega os golpes que ela deveria entregar: o golpe assinatura da forma nova (o King's Shield do Aegislash é o caso clássico) era perdido para sempre por quem evoluía acima do nível 1. A habilidade também acompanha a evolução direito, mantendo o slot — quem tinha habilidade oculta continua com a oculta, e o jogo avisa no registro quando ela muda de nome.",
        'Se a internet cair bem na hora de uma evolução, ela não some mais: fica pendente, aparece na ficha e acontece sozinha assim que a rede volta.',
        'Item sem imagem na PokéAPI (Coroa Galárica e companhia) mostra um ícone de caixinha no lugar do buraco que ficava antes.',
        'O menu ☰ do celular estava com menos opções do que as telas ofereciam. Agora ele mostra os mesmos acessos: Início, Jornadas, Carreira, Ranking, Multiplayer, Conta, Novidades, Ajustes e Bugs — além de Layout e Novo jogo.',
        'Clicar num Pokémon na tela de criação dava "A conexão falhou ao buscar um dado da PokéAPI" e não deixava começar jornada nenhuma. Não era a conexão: a prévia chamava uma função que nunca tinha sido escrita, e o erro caía no mesmo tratamento da busca de rede. Por isso limpar cache, trocar de rede e baixar tudo de novo não adiantavam — e por isso o Full Randomizer continuava funcionando, já que ele não desenha a prévia. A função que faltava é a opção <b>✨ Começar shiny</b>, que agora existe de verdade. <b>Erro de código não se disfarça mais de erro de rede.</b>',
        'Não dava pra começar uma jornada quando a conexão estava ruim, mesmo com o mapa todo baixado. O jogo tinha o dado guardado, mas só aceitava a versão guardada quando o aparelho se declarava SEM internet — e wi-fi de metrô, portal cativo de hotel e 4G fraco contam como "com internet" pro navegador. Agora, se a rede falhar, o jogo segue com o que já está guardado.',
        'As imagens agora vêm de um CDN (o jsDelivr, que espelha o mesmo repositório de sprites). O endereço antigo é bloqueado em várias redes — provedor, DNS de celular, rede corporativa — e quando isso acontece TODA imagem do jogo some de uma vez, online inclusive.',
        'Baixar um mapa em "Jogar offline" agora traz também as <b>curvas de XP e as árvores de evolução</b>. Sem elas, dava pra explorar offline mas NÃO dava pra começar uma jornada nem evoluir. A árvore de evolução também deixou de ser obrigatória pra começar: ela só é consultada quando você sobe de nível.',
        'A tela de "Jogar offline" pedia pra baixar de novo e nada mudava, por mais vezes que você baixasse: uma única imagem que não descia, entre centenas de pedidos, impedia o mapa de ser marcado como pronto. Agora falha de dado e falha de imagem são contadas separadas — sem o dado não dá pra jogar, sem a imagem dá. Sprite que falha é tentada de novo, e o download avisa em vez de mentir.',
        'Novo botão <b>🗑 Limpar tudo e baixar de novo</b>: apaga o que está guardado da PokéAPI e baixa do zero, pra quando algo ficou pela metade (baixar por cima só busca o que falta). Saves, carreira e conquistas não são tocados.',
        'A tela de "Jogar offline" agora avisa quando a página está fora do controle do service worker (acontece logo depois de uma recarga forçada). Nessa situação os dados seriam guardados mas as imagens não, e você só descobriria sem internet — com o download inteiro já jogado fora.',
        'As mensagens de erro de rede agora dizem QUAL dado faltou (a curva de XP, a árvore de evolução, um golpe…) em vez de só "a conexão falhou". E o jogo passou a se atualizar sozinho quando sai uma versão nova: antes, uma aba deixada aberta continuava rodando a versão velha até você fechar o navegador.',
        'Aliado que usava Self-Destruct no Roguelike quebrava o turno inteiro ("Algo deu errado neste turno"): ele é perdido na hora, e a tela ainda tentava mostrar quem estava agindo usando a posição dele na equipe, que já não existia.'
      ] }
    ] },
  { versao: '1.4', data: '2026-09-23', titulo: '🏅 A conta começou a contar: Conquistas, Pokédex e badges', piada: 'O contador de vitórias já existia, mas só fazia contato visual com o Pokémon derrotado e anotava mentalmente. Agora ele tem prancheta, caneta e uma medalha para te entregar.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Nova tela <b>🏅 Conquistas</b>: tudo o que a sua conta acumulou ao longo da carreira inteira, incluindo a jornada em andamento. A partir de agora o jogo registra, a cada vitória, os tipos do Pokémon derrotado, a espécie que você estava usando, o golpe que finalizou e o elemento dele — é o que vai desbloquear as gimmicks quando elas chegarem. Com marcos de caçada de 1.000, 10.000, 100.000 e 1.000.000 de Pokémon derrotados.',
        'O abate do aliado conta para a espécie que você está usando (ele luta ao seu lado, afinal), mas tipo e golpe só contam quando o golpe final foi seu.',
        'Nova tela <b>📖 Pokédex</b>: as 1025 espécies do jogo, as que você já encontrou com sprite e nome, as outras ainda como "?". Toque em quem você conhece pra abrir a ficha completa: tipos, atributos base, habilidades com descrição, quantas vezes você já viu, derrotou e recrutou, e <b>onde</b> aquele Pokémon aparece (quais rotas de quais mapas, com a chance de encontro, avisando quando ele é Alfa ou participa de uma luta final).',
        'Recrutou um Pokémon <b>shiny</b>? A espécie dele fica desbloqueada na hora — e você pode começar jornadas novas jogando com ele ✨ shiny, quantas vezes quiser. Encontrar um é 1 em 4096; o direito é seu pra sempre.',
        'Os <b>Alfas de rota</b> foram refeitos: nenhum se repete mais dentro do mesmo mapa, cada um combina com o tema da rota (nada de Aggron guardando o Mar de Hoenn) e cada mapa fecha com seu pseudo-lendário — Dragonite, Tyranitar, Salamence, Garchomp, Hydreigon, Goodra, Kommo-o, Dragapult e Archaludon. E o lendário da luta final agora é sorteado a cada jornada: fechar Kanto não é mais sempre Mewtwo.',
        'Fechar uma Gen agora ENCERRA a jornada em vitória: o seu Pokémon se aposenta como campeão daquele mapa, a jornada é pontuada e entra na carreira, e a próxima começa do zero na Gen seguinte — outro Pokémon, nível 5, mapa nos níveis normais dele. A tela de fim já propõe o mapa seguinte.',
        'Seguir com o MESMO Pokémon continua sendo possível, escolhendo ali na hora: você leva equipe, mochila e dinheiro, e o mapa novo se ajusta ao seu nível. Só que cada continuação vale 20% menos pontos no ranking (com piso de metade), porque chegar num mapa novo já forte é bem mais fácil.',
        '<b>Badges da conta:</b> conquistas de longo prazo na tela 🏅 Conquistas — marcos de caçada, um especialista por tipo, Pokédex regional e nacional, 100 aliados recrutados, recrutar um lendário, recrutar um shiny, fechar uma Gen no Hardcore, terminar uma jornada sem usar o Centro Pokémon, e mais.',
        'Cada badge conquistada vira vantagem na PRÓXIMA jornada: itens ou dinheiro no começo. Derrotar 1.000 Pokémon do tipo Planta, por exemplo, faz você começar com uma Pedra da Folha na mochila. Na criação dá pra desligar as vantagens e jogar do zero — quem faz isso ganha 10% a mais de pontos no ranking.',
        'As duas conquistas do Rayquaza entraram: recrutar um shiny e conquistar a Mega dele contam separadas, em qualquer ordem. Quem tiver as duas ganha a loja de graça para sempre.'
      ] },
      { nome: 'Equilíbrio', itens: [
        'No Roguelike, quando o seu nível passa do dobro do teto de uma rota, ela fica esgotada: não aparece mais ninguém pra lutar ali. Você continua entrando e vendo a Pokédex da rota — o que acaba é o farm em rota fraca. Nos outros modos nada muda.'
      ] },
      { nome: 'Correções', itens: [
        'As conquistas da conta estavam sendo <b>perdidas no fim de cada jornada</b>: o contador subia enquanto você jogava e a carreira nunca recebia nada. E o que sobrevivia era recalculado a partir do histórico, então apagar uma jornada da carreira apagava junto o que ela tinha liberado. Agora as espécies desbloqueadas e o progresso das gimmicks ficam gravados na conta, em lugar próprio, e <b>só crescem</b> — nada do que você conquistou se perde. Com conta, isso sobe pra nuvem e volta em qualquer aparelho.',
        'As espécies desbloqueadas passaram a valer em TODOS os modos, não só no Roguelike. Conquistar o desbloqueio continua sendo coisa de jornada Roguelike; usar o que você já conquistou, não — e a tela de criação agora avisa isso, em vez de deixar você jogar uma jornada inteira esperando o contrário.',
        'A tela de Conquistas estava com texto montado em cima das barras de progresso nas linhas sem sprite (tipos e golpes).'
      ] }
    ] },
  { versao: '1.3', data: '2026-09-23', titulo: '🏛 O Santuário: a Gen inteira, depois da vitória', piada: 'Os iniciais só aceitaram voltar a aparecer no mato sob três condições: bairro nobre, grama aparada e porteiro. Chamamos aquilo de Santuário e fingimos que a ideia tinha sido nossa.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Cada mapa ganhou uma 11ª área, o <b>🏛 Santuário</b>, que abre quando você vence os lendários daquela Gen. Nele vive a Gen inteira: todas as espécies, com as linhas evolutivas completas, mais os iniciais, os lendários e os míticos. Com isso, dá para encontrar todo Pokémon de uma Gen depois de fechá-la — nenhuma espécie fica inalcançável.',
        'As <b>formas regionais</b> entraram no jogo pela primeira vez: Alolan no Santuário de Alola, Galarian e Hisuian no de Galar, Paldean no de Paldea. São 53 formas que antes não existiam em lugar nenhum.',
        'A raridade de cada Pokémon no Santuário segue a dificuldade de captura da espécie, igual ao resto do jogo — comum aparece mais, raro aparece menos.',
        'No Roguelike, vencer os lendários não encerra mais a run na marra: a vitória fica garantida na hora (o mapa seguinte libera do mesmo jeito) e você escolhe entre encerrar ou continuar explorando o Santuário que acabou de abrir. Se você seguir e desmaiar lá, a run termina em derrota — mas a Gen vencida continua fechada e liberada pras próximas.',
        'Lendários e míticos encontrados no Santuário aceitam petisco e podem virar aliados, mas confiam bem mais devagar que um Pokémon comum: espere mais de uma dezena de ofertas.'
      ] }
    ] },
  { versao: '1.2', data: '2026-09-23', titulo: 'Golpes, telas e armadilhas', piada: 'Instalamos Pedras Afiadas na entrada do campo. O sindicato dos Charizard entrou com liminar alegando metade do HP só por chegar. Negada: está nos jogos desde 2006, e eles sabem disso.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Cada lado da batalha passou a ter o seu campo, e o que está no ar aparece no topo da luta: 🛡 do seu lado, ⚔ do lado do inimigo.',
        '<b>Telas:</b> Reflect corta pela metade o dano dos golpes físicos, Light Screen o dos especiais e Aurora Veil os dois (mas só funciona no granizo ou na neve). Duram 5 turnos e não empilham. <b>Safeguard</b> bloqueia status vindos do inimigo por 5 turnos (e não atrapalha quando você mesmo se põe pra dormir com Rest), <b>Mist</b> impede o inimigo de baixar os seus atributos e <b>Tailwind</b> dobra a velocidade do seu lado por 4 turnos.',
        '<b>Armadilhas de entrada:</b> Stealth Rock machuca conforme a fraqueza de quem entra (dobra em Voador!), Spikes empilha até 3 camadas e Toxic Spikes até 2 (a segunda envenena gravemente). Quem é Venenoso e anda no chão limpa os espinhos venenosos ao entrar. Elas pegam o próximo Pokémon que entra em campo — os do treinador e a fila de lendários; como você nunca troca de Pokémon, o jogo avisa na hora de usar que, do seu lado, não há em quem pegar.',
        "<b>Mudança de Postura</b> entrou no jogo: o Aegislash vira a Forma Lâmina quando ataca (ataque altíssimo, defesa de papel) e volta para a Forma Escudo quando usa King's Shield. É a primeira habilidade do jogo que troca a forma do Pokémon no meio da batalha.",
        "As <b>barreiras</b> deixaram de ser todas iguais: King's Shield tira 2 de Ataque de quem tenta encostar, Obstruct tira 2 de Defesa, Spiky Shield machuca, Baneful Bunker envenena, Silk Trap tira Velocidade e Burning Bulwark queima. Só vale para golpes físicos — quem ataca de longe é bloqueado sem se machucar.",
        '<b>Escama do Coração</b> (₽5.000): faz o Pokémon relembrar um golpe que ele já podia ter aprendido subindo de nível e que você deixou passar. Também aparece, bem raramente, entre os itens achados explorando.',
        '<b>Disco Técnico</b> (₽8.000, só na loja): ensina um golpe que a Pokédex diz que a espécie aprende por MT, tutor ou herança — golpes que nunca apareceriam subindo de nível. Cada Disco usado deixa o próximo ₽4.000 mais caro. Os dois funcionam em você e em qualquer aliado, e é você quem escolhe qual golpe sai pra dar lugar ao novo.',
        'Aliado que aprende um golpe sozinho agora tem vontade própria: metade das vezes ele prefere ficar com o que já sabe, e quando troca, troca um golpe qualquer — nada de sempre descartar o mais fraco pelo mais forte.',
        'As três raças do Tauros de Paldea e o Darmanitan de Galar entraram nos Santuários, junto das outras formas regionais (agora são 57).'
      ] },
      { nome: 'Correções', itens: [
        'Flame Charge (e todo golpe que dá bônus a quem usa: Power-Up Punch, Ancient Power, Charge Beam…) estava aumentando o atributo do OPONENTE. Agora o bônus vai para quem usou o golpe — e os golpes que cobram um preço de quem usa, como Close Combat e Draco Meteor, continuam baixando os atributos do próprio usuário.',
        "Evoluir não reescreve mais o moveset inteiro: a evolução entrega o golpe que ela realmente concede (o Stomp do Exeggutor, o King's Shield do Aegislash), e não toda a lista de golpes que a forma nova saberia se tivesse acabado de nascer.",
        'O <b>Disco Técnico</b> não funcionava em jornadas começadas antes dele existir: a ficha do Pokémon guarda uma cópia dos dados da espécie, e essa cópia não tinha a lista de golpes de MT, tutor e herança. Agora ela é atualizada sozinha na primeira vez que você usa o item com internet.',
        'Os Alfas que eram formas evoluídas de inicial estavam anunciando um nome e aparecendo com o corpo de outro Pokémon. Agora o nome e a espécie do Alfa mudam sempre juntos.'
      ] }
    ] },
  { versao: '1.1', data: '2026-09-22', titulo: 'Celular, sala mais firme e 🎯 Caça Shiny', piada: 'O Fake Out estava funcionando no turno nove, o que tecnicamente faz dele um Fake Out Permanente. O Hitmonchan adorou. A tabela de prioridade, nem tanto.',
    secoes: [
      { nome: 'Novidades', itens: [
        'No celular, a batalha virou tela fixa: a cena do combate fica presa no topo e o resto da página (golpes, registro, ficha, aliados e mochila) rola normalmente por baixo, então dá pra ver o seu Pokémon e o inimigo enquanto escolhe o que fazer.',
        'Novo modo <b>🎯 Caça Shiny</b>, ligado no começo da jornada: quando você revelar todas as espécies de uma rota, escolhe UMA delas pra ser a única que aparece por ali. Bom pra caçar shiny — ou pra farmar uma espécie específica. Muda só o selvagem: treinador, item e dinheiro continuam aparecendo igual.',
        'Dois <b>repelentes</b> na loja: o Seletivo (30 explorações) deixa passar só a espécie que você escolher da rota, e o Total (40 explorações) espanta todos os selvagens. Com eles ligados você segue achando treinadores, itens e dinheiro normalmente.',
        'Na sala multiplayer agora tem Centro Pokémon: dá pra curar a equipe entre as lutas sem sair da sala.'
      ] },
      { nome: 'Equilíbrio', itens: [
        'O inimigo não sorteia mais qualquer golpe: agora ele tende a escolher o que dá mais dano em você, olhando tipo e eficácia.',
        'O quanto ele acerta a escolha depende de quem é: selvagem erra bastante (metade das vezes), treinador pensa melhor, e Alfa e lendário quase sempre escolhem o melhor golpe. Vale também nas batalhas multiplayer.'
      ] },
      { nome: 'Correções', itens: [
        'Dava pra escapar de qualquer batalha "sem fuga" — treinador, Alfa, lendário — só recarregando a página. A batalha em andamento agora vai junto no save e volta do jeito que estava, no mesmo turno.',
        'Fake Out (e First Impression) só funcionam no primeiro golpe da batalha. Antes dava pra usar em qualquer turno e fazer o inimigo recuar sempre.',
        'Sala multiplayer: as escolhas às vezes não chegavam no anfitrião e o turno só saía quando o prazo de 45 segundos estourava. Agora cada mensagem é reenviada quando falha, o anfitrião repete o estado da luta de tempos em tempos e existe um botão 🔄 Sincronizar.',
        'Trocar de aba não derruba mais você da sala: a conexão tenta voltar sozinha, e o jogo espera o anfitrião reaparecer antes de encerrar a sala. A sala também mostra o estado da conexão (conectado / instável / sem conexão) e tem um diagnóstico com as últimas mensagens trocadas.'
      ] }
    ] },
  { versao: '1.0', data: '2026-09-22', titulo: 'Itens para segurar e a mochila arrumada', piada: 'Demos Restos a um Snorlax. Ele curou. Comeu os Restos. Curou de novo. Em algum ponto o servidor pediu para sair. O Snorlax não percebeu nada e segue dormindo na Rota 12.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Cada Pokémon da equipe pode segurar um item, que age sozinho na batalha. São 13 para começar: Restos, Lodo Negro, Orbe da Vida, Faixa de Foco, Sino-Concha, Elmo Rochoso, Cinto do Perito, Faixa Muscular, Óculos do Sábio, Colete de Assalto e as frutas Oran, Sitrus e Lum.',
        'Para equipar: na mochila, divisão 🎒 Para segurar, toque em "Segurar" e escolha quem leva. A ficha mostra o que cada um está segurando, com um botão para guardar de volta.',
        'As frutas são comidas sozinhas na hora do aperto: Oran e Sitrus quando o HP cai à metade, Lum quando você pega qualquer status.',
        'A mochila e a loja agora têm divisões: 🧪 Cura e status, ⚔ Em batalha, 🎒 Para segurar, 💎 Evolução, 🍖 Petiscos e ✨ Especiais. Fica bem mais fácil achar as coisas.',
        'Nova tela 📜 Novidades: estas notas de atualização, para você acompanhar o que muda no jogo a cada leva.',
        'A ficha agora tem atalho: se você tem um item pra segurar na mochila, dá pra equipar direto ali, sem procurar.',
        'Uma Fruta Oran pode ser achada explorando, então a mecânica de segurar item aparece mesmo pra quem não passou na loja.',
        'A loja ganhou uma frase explicando cada divisão (para segurar, evolução, exploração).'
      ] },
      { nome: 'Equilíbrio', itens: [
        'O Orbe da Vida bate 30% mais forte, mas cobra 10% do seu HP máximo a cada golpe. O Colete de Assalto dá 50% de Defesa Especial, mas tranca os golpes de status. Escolha com carinho.'
      ] }
    ] },
  { versao: '0.9', data: '2026-09-19', titulo: 'Um mapa para cada geração', piada: 'Os lendários se recusaram a dividir rota com Rattata. Negociamos três semanas. Eles ficaram com a rota 10 inteira e o Rattata ficou com a rota 1 inteira, onde ele já mandava mesmo.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Agora existe um mapa para cada geração — Kanto, Johto, Hoenn, Sinnoh, Unova, Kalos, Alola, Galar e Paldea —, cada um com 10 rotas que vão abrindo conforme você sobe de nível, do 2 até por volta do 62.',
        'Os selvagens de cada mapa são os daquela geração, cada um colocado na rota que combina com o nível e o tipo dele. Nenhuma rota tem todo mundo: para conhecer todos os Pokémon, você passa pelos vários mapas.',
        'A última rota de cada mapa guarda os lendários da geração. Você enfrenta até quatro em sequência, e o principal (Mewtwo, Ho-Oh, Rayquaza…) vem por último, bem mais forte que os outros.',
        'Vencer os lendários fecha a geração e vale 2000 pontos. Fora do Roguelike, você escolhe qual mapa quer encarar em seguida e continua com a mesma equipe: as rotas do mapa novo começam no seu nível e sobem até o 100.',
        'No Roguelike, derrubar os lendários termina a jornada em vitória e libera o mapa da geração seguinte para as próximas runs.',
        'Pokédex da rota: cada espécie aparece como "?" até você enfrentá-la, vira silhueta depois do primeiro encontro e só fica colorida, com a taxa de aparição daquela rota, quando você derrota 10 dela somando todas as suas jornadas.',
        'Míticos como Mew e Celebi podem aparecer nas duas rotas mais altas de cada mapa, mas raríssimo (cerca de 4 em cada 1000 encontros). E toda rota tem o seu Alfa: o dobro de HP, 30% a mais no resto, atributos perfeitos e prêmio na primeira vitória.'
      ] },
      { nome: 'Correções', itens: [
        'A antiga Fenda Dimensional saiu do jogo. Quem tinha uma jornada parada lá recomeça a explorar pela primeira rota, sem perder nada.'
      ] }
    ] },
  { versao: '0.8', data: '2026-09-09', titulo: 'Golpes especiais funcionando de verdade', piada: 'O Electrode usava Explosion e continuava em campo, constrangido, olhando para os lados. Agora o sacrifício é um sacrifício. Ele pediu para registrar que preferia o bug.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Todos os golpes que algum Pokémon aprende por nível foram conferidos um a um contra o motor de batalha. A primeira leva de correções entrou agora, e o que ainda falta (clima, terrenos, itens segurados e golpes de lado do campo) já está mapeado para as próximas atualizações.'
      ] },
      { nome: 'Equilíbrio', itens: [
        'Poder variável de verdade em Flail, Reversal, Eruption, Water Spout, Gyro Ball, Electro Ball, Hex, Facade, Venoshock e Brine: agora eles olham o HP, a velocidade ou o status antes de decidir a força. Endeavor iguala o HP do alvo ao seu.'
      ] },
      { nome: 'Correções', itens: [
        'Protect, Detect e a turma toda protegem de verdade: o golpe do inimigo simplesmente falha. Usar várias vezes seguidas fica cada vez menos confiável, como nos jogos.',
        'Rest cura todo o HP e o status e faz você dormir dois turnos. Endure garante sobrar com 1 de HP no turno, e Focus Energy aumenta mesmo a sua chance de crítico até o fim da batalha.',
        'Explosion, Self-Destruct e Memento derrubam quem usa. O sacrifício agora é um sacrifício.',
        'Toxic envenena gravemente e o dano cresce a cada turno. Leech Seed drena um pedaço do HP do alvo por turno para quem plantou, e Pokémon do tipo Planta são imunes. Dream Eater só funciona com o alvo dormindo.',
        'Golpes de dois turnos (Solar Beam, Sky Attack, Fly, Dig, Dive…) carregam num turno e saem no seguinte, e quem voa ou cava fica fora de alcance enquanto isso. Hyper Beam, Giga Impact e parecidos obrigam a recarregar depois — mas só se o golpe tiver acertado.',
        'Thrash, Outrage e Petal Dance atacam sozinhos por dois ou três turnos e deixam quem usou confuso no fim. Fissure, Guillotine, Sheer Cold e Horn Drill voltaram a derrubar de um golpe só, com chance ligada à diferença de nível — e nunca funcionam contra quem é mais forte que você.'
      ] }
    ] },
  { versao: '0.7', data: '2026-08-26', titulo: 'Evoluções especiais', piada: 'Explicamos ao Kadabra que o Cabo de Conexão vale como troca. Ele leu o cabo inteiro com a colher, concordou que era legítimo e evoluiu na hora. O Machoke ainda quer ver o contrato.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Chegaram as 10 pedras de evolução (Fogo, Água, Trovão, Folha, Lua, Sol, Brilhante, Crepúsculo, Aurora e Gelo) e itens como a Maçã Doce, o Bule Rachado e a Armadura Auspiciosa. As pedras e o Cabo de Conexão são vendidos na loja; o resto você acha explorando, da quarta rota em diante, e como prêmio de Alfa.',
        'O Cabo de Conexão simula a troca e evolui quem só evolui assim: Kadabra, Machoke, Graveler, Haunter e companhia. Alguns pedem também um item na mochila (Metal Coat, Escama de Dragão…), que é gasto junto, e outros pedem o parceiro na equipe, como Karrablast com Shelmet.',
        'Cada Pokémon agora tem um vínculo de 0 a 255, que sobe a cada nível e a cada vitória e aparece na ficha. Com 160 ou mais evoluem Golbat, Pichu e Eevee — Espeon de dia, Umbreon à noite.',
        'A hora do dia conta: o jogo usa o relógio do seu aparelho, com dia das 6h às 18h e noite das 18h às 6h.',
        'Outras condições dos jogos também valem: saber um golpe específico, ter um aliado de certa espécie ou tipo, comparar Ataque com Defesa (o caso do Tyrogue) e segurar determinados itens.',
        'Shedinja: quando Nincada vira Ninjask, a casca ganha vida. Se houver vaga na equipe, Shedinja entra sozinho como aliado; com a equipe cheia, você escolhe em qual dos dois o seu Pokémon vira.',
        "Evoluções que dependiam de coisas que este jogo não tem ganharam uma regra equivalente: Sirfetch'd com 3 críticos numa batalha, Runerigus ao aguentar 49 de dano, Kingambit ao derrotar 3 Bisharp e Annihilape sabendo Rage Fist. A ficha mostra exatamente o que falta para cada evolução possível.",
        'Os seus aliados também evoluem, e o jogo sempre pergunta antes de deixar acontecer.'
      ] }
    ] },
  { versao: '0.6', data: '2026-08-13', titulo: 'Jornadas salvas, navegação e fontes', piada: 'O Slowpoke foi contratado para carregar a lista de jornadas salvas. Ele entregou. Três dias depois, mas entregou. Agradecemos os serviços e contratamos um Jolteon.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Dá para ter várias jornadas em andamento ao mesmo tempo. Em "Novo jogo", escolha "Guardar e começar outra" (nada se perde) ou "Encerrar". Cabem até 12 guardadas.',
        'Nova tela 💾 Jornadas salvas, com "Continuar" e "Excluir" em cada uma. Com conta, todas ficam na nuvem e seguem com você para outro aparelho.',
        'Quando chega uma jornada de outro aparelho, você decide o que fazer: continuar nela, guardar pra depois (e o jogo não pergunta de novo) ou excluir. Nada é descartado sem a sua escolha.',
        'Voltar para o 🏠 Início com uma jornada aberta não perde mais nada: ela é guardada sozinha e reaparece na lista.',
        'Toda tela fora do jogo — Carreira, Ranking, Conta, Jornadas salvas, Multiplayer, Bugs e Ajustes — começa com a mesma barra, com "← Voltar" e atalhos para as outras. A tecla Esc também volta.',
        'Nova tela ⚙ Ajustes com seis fontes à escolha, incluindo a Atkinson Hyperlegible (feita para baixa visão), a Lexend (para textos longos), a Andika (ajuda quem tem dislexia) e uma monoespaçada para comparar números. Cada opção já aparece escrita na própria fonte, vale para o jogo inteiro e fica salva neste navegador.'
      ] },
      { nome: 'Correções', itens: [
        'No celular, o menu ☰ fecha sozinho ao tocar num botão, ao tocar fora dele ou com Esc, em vez de ficar aberto por cima da tela seguinte.'
      ] }
    ] },
  { versao: '0.5', data: '2026-07-30', titulo: 'Habilidades com efeito de verdade', piada: 'O Shedinja passou meses com "Wonder Guard" escrito na ficha e apanhando de Tackle mesmo assim. Agora a habilidade funciona. Ele chorou de emoção, o que foi arriscado: ele tem 1 de HP.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Cerca de 60 habilidades passaram a ter efeito de verdade na batalha, e funcionam igualzinho no jogo sozinho e no multiplayer. A ficha marca quais das suas estão ativas.',
        'Ataque: Overgrow, Blaze, Torrent e Swarm dão o gás quando o HP fica baixo; Adaptability, Technician, Huge Power, Hustle, Guts, Sniper, Tinted Lens, Skill Link, Serene Grace e Rock Head mudam dano, crítico, precisão e recuo.',
        'Defesa: Thick Fat, Filter, Multiscale, Sturdy (que segura o nocaute com o HP cheio) e Wonder Guard, que só deixa passar golpe supereficaz.',
        'Absorção de tipo: Levitate, Flash Fire, Volt Absorb, Water Absorb, Lightning Rod, Motor Drive e Sap Sipper transformam o golpe do inimigo em nada — ou em vantagem para você.',
        'Imunidade a status (Immunity, Limber, Insomnia, Own Tempo) e atributos que não caem (Clear Body, Hyper Cutter).',
        'Contato e fim de turno: Static, Flame Body e Rough Skin castigam quem encosta em você; Speed Boost e Shed Skin agem ao fim de cada turno. Intimidate e Run Away também entraram.'
      ] },
      { nome: 'Correções', itens: [
        'Golpes, status e mudanças de atributo passaram a ser resolvidos por um motor só: o que acontece numa batalha sozinho acontece exatamente igual numa batalha com outros jogadores.',
        'Golpe ou habilidade que ainda não tem efeito diz isso com todas as letras, em vez de fingir que funcionou.'
      ] }
    ] },
  { versao: '0.4', data: '2026-07-16', titulo: 'Ícone, amigos e canal de bugs', piada: 'Um Ditto copiou o ícone de outro jogador e passou dois dias respondendo pelo nome dele na lista de amigos. Ninguém notou, nem o original. O Ditto trabalha no suporte agora.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Escolha o seu ícone entre os 1025 Pokémon, normal ou ✨ shiny. Ele aparece no topo da tela, no ranking, nas salas de multiplayer e para os seus amigos.',
        'Amigos por código: cada conta tem um código de 6 caracteres. Adicione alguém pelo código e a pessoa aceita ou recusa.',
        'Na sala de multiplayer, o anfitrião chama um amigo com um toque, e o convite chega em qualquer tela do jogo — é só clicar em "Entrar".',
        'Nova tela 🐞 Bugs e sugestões, na tela inicial e no topo do jogo: escolha entre "Bug" e "Sugestão", dê um título e descreva o que aconteceu. Não precisa de conta.',
        'Nos bugs dá para anexar um resumo técnico (versão, navegador, tela em que você estava, Pokémon e as últimas linhas do registro, sem nada pessoal) — e você vê exatamente o que vai junto antes de enviar.',
        'Sem internet, o relato fica guardado no aparelho e é enviado sozinho quando a conexão volta.'
      ] },
      { nome: 'Correções', itens: [
        'Sem conta, o ícone fica salvo só no seu navegador — e sobe para a conta no primeiro login, sem você precisar escolher de novo.'
      ] }
    ] },
  { versao: '0.3', data: '2026-06-30', titulo: 'Multiplayer: co-op e PvP', piada: 'Um Magikarp entrou em sete salas seguidas e usou Splash em todas. Ninguém foi ferido, ninguém foi curado, ninguém entendeu. Ele hoje é mascote oficial do PvP.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Multiplayer por sala: um jogador cria e passa o código de 4 letras, e até 6 pessoas entram. Não precisa de conta.',
        'Co-op: chame amigos para a sua jornada e lutem juntos contra os selvagens (um para cada jogador) ou contra o Alfa da rota, que vem reforçado para aguentar o grupo todo.',
        'PvP: cada um escolhe o Time A ou o Time B. Dá para fazer 1×1, 2×2, 3×3 e até times desiguais, como 2×1 e 3×2.',
        'Você leva de 1 a 3 Pokémon: só o principal ou também os seus aliados.',
        'Balancear, ligado por padrão: no co-op todo mundo fica no nível do Pokémon do anfitrião, então um amigo forte não atropela a sua run; no PvP todos ficam no nível médio da luta e o time em menor número ganha HP extra. Desligado, valem os níveis reais e os inimigos acompanham o mais forte do grupo.',
        'Entre com o Pokémon da sua jornada (e a luta conta para ela) ou com um convidado, emprestado só para aquela sala e que não mexe em nada. Sem jornada em andamento, dá para entrar direto com um convidado.'
      ] },
      { nome: 'Equilíbrio', itens: [
        'Ganhos do co-op — XP, EVs, dinheiro, itens e prêmio de Alfa — voltam com você para a sua jornada quando lutou no seu nível real. Com o nível ajustado pelo Balancear, a luta vale pela diversão.',
        'O PvP é amistoso: não gasta HP nem PP, só conta vitórias e derrotas, e dá para desistir. Cada um escolhe o golpe e o alvo dos seus Pokémon, e o turno sai quando todos escolherem ou em 45 segundos, no automático.'
      ] }
    ] },
  { versao: '0.2', data: '2026-06-11', titulo: 'Roguelike e ranking global', piada: 'Um Bidoof nível 340 liderava o ranking com nove trilhões de pontos. Foi convidado a explicar. Respondeu "Bi". O servidor entendeu como confissão.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Chegou o modo Roguelike, agora o principal do jogo: cada jornada é uma run. Você começa só com os iniciais e, jogando, vai desbloqueando novas espécies para as próximas runs.',
        'Para desbloquear uma espécie: derrote 10 dela, faça amizade com 5 ou evolua 5 vezes para a forma do meio (como Charmeleon) e 10 vezes para a forma final (como Charizard). Os contadores somam todas as suas jornadas, e só as do Roguelike contam.',
        'A tela inicial mostra o que você já desbloqueou e o que está "quase lá", a tela de fim mostra o que aquela run liberou, e a Carreira reúne todo o progresso.',
        'Ranking global: a melhor jornada de cada jogador, geral ou por espécie, com a sua posição destacada. Dá para olhar sem conta; para aparecer nele, é só entrar e terminar jornadas.'
      ] },
      { nome: 'Equilíbrio', itens: [
        'No Roguelike não existe segunda chance: se você desmaiar, a run acaba (nem Revive salva), um aliado que desmaia é perdido para sempre e ser capturado também encerra tudo.',
        'O Roguelike começa no nível 5, tem Centro Pokémon pago com 10% de desconto por vitória e vale 1,5× de pontos no fim.'
      ] },
      { nome: 'Correções', itens: [
        'A pontuação do ranking é recalculada no servidor a partir dos números da jornada, e valores impossíveis são recusados. Uma jornada recusada não trava o envio das outras.'
      ] }
    ] },
  { versao: '0.1', data: '2026-05-20', titulo: 'O começo: você é o Pokémon', piada: 'Um Zubat apareceu. Depois outro. Depois mais onze. Fomos conferir a taxa de encontro no código e descobrimos que o Zubat não está no código: ele simplesmente se convidou.',
    secoes: [
      { nome: 'Novidades', itens: [
        'Primeira versão do PokéRPG: aqui você é o Pokémon, sem treinador e sem Pokébola. Escolha entre os iniciais das nove regiões, mais Pikachu e Eevee, e saia explorando as rotas.',
        'Batalha por turnos com prioridade e velocidade, precisão e evasão, crítico, estágios de atributo, status (queimado, envenenado, paralisado, dormindo, congelado e confuso) e dano no fim do turno.',
        'Treinadores caçadores aparecem enquanto você explora, com 1 a 3 Pokémon e Pokébolas. Com o seu HP pela metade, eles podem tentar te capturar — e a chance depende da taxa de captura da sua espécie.',
        'Amizade e aliados: ofereça a um selvagem um petisco que o tipo dele goste e, com a amizade cheia, ele passa a te seguir (até 2 aliados). Eles lutam no mesmo turno que você, ganham XP e aceitam ordens como "Pegar leve", "Só status" e "Descansar".',
        'Rotas que abrem por nível, Alfas para desafiar, 36 missões que vão aparecendo conforme você joga, Centro Pokémon, loja, mochila e shiny em 1 a cada 4096 encontros.',
        'Conta com Google ou link por e-mail: a carreira e a jornada em andamento ficam salvas na nuvem e seguem para outro aparelho. E, depois do primeiro acesso, o jogo abre e roda mesmo sem internet.',
        'Os painéis (Ficha, Missões, Aliados, Mochila e Registro) podem ser arrastados, redimensionados, recolhidos e trocados de coluna, com o botão "↺ Layout" para voltar ao padrão; no celular tudo vira uma coluna só. E a tela 📊 Carreira guarda Pokémon favorito, Pokédex, shinies, nível máximo, tempo total e o seu melhor resultado por espécie.'
      ] },
      { nome: 'Equilíbrio', itens: [
        'Cinco modos de dificuldade — Fácil, Médio, Difícil, Hardcore e o 🎲 Full Randomizer, que sorteia até a sua espécie —, mudando se o treinador pode te capturar, o custo do Centro, quantos desmaios você aguenta e a pontuação final. As contas seguem as fórmulas dos jogos: atributos com IV, EV e natureza, dano com STAB, tipos e crítico, XP por curva de crescimento e captura da terceira e quarta gerações.'
      ] }
    ] }
];
