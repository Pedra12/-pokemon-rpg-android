/* ============ progressão ============ */
// XP → nível, golpes aprendidos por nível e evolução — pra você e pros aliados. As condições de evolução (nível,
// pedra, troca, vínculo, hora do dia, golpe conhecido…) moram em evolucao.js; aqui fica a narração e a troca de espécie.
// Diferença entre você e o aliado: você escolhe qual golpe esquecer; o aliado troca sozinho o de menor poder.
// A evolução pergunta nos dois casos (é decisão sua deixar o aliado evoluir ou não).
import { G, nm, registrar, rotulo, ladoJogador } from './estado.js';
import { formaRegionalDaGen, genDe, dadosDaGen } from './mapas.js';
import { say, ask } from './ui.js';
import { render } from './render.js';
import { API, STATS, STAT_PT, TYPE_PT, CLS_PT, ITEMS } from './dados.js';
import { recalc, tetoDaEquipe, golpesDaEvolucao } from './regras.js';
import { habilidadeDaEvolucao } from './habilidades.js';
import { makeMon } from './pokemon.js';
import { evolucoesPossiveis, caminhoMostrado, textoCondicao, ganharFelicidade, ganhoFelicidadeNivel, felicidadeDe, FELICIDADE_ALIADO } from './evolucao.js';
import { loadMove, loadSpecies, loadPokemon, loadEvo, loadGrowth } from './api.js';
import { esc, fmt, offline } from './util.js';
import { tocarSfx } from './som.js';

const ehJogador = M => M === G.S.player;
// chance de um aliado simplesmente não querer o golpe novo quando já sabe 4 (ver `aprender`)
export const CHANCE_ALIADO_RECUSA = 0.5;

export async function gainExp(xp) {
  const P = G.S.player, GR = G.S.meta.growth;
  P.exp += xp; recalc(P);
  let leveled = false;
  while (P.level < 100 && P.exp >= GR[P.level + 1]) {
    const before = { ...P.stats };
    P.level++; recalc(P); leveled = true; ganharFelicidade(P, ganhoFelicidadeNivel(felicidadeDe(P))); render(); tocarSfx('nivel');
    await say(`<b>${esc(P.nick || fmt(P.name))} subiu para o nível ${P.level}!</b>`, 'level');
    await say(STATS.map(s => `${STAT_PT[s]} +${P.stats[s] - before[s]}`).join(', '), 'muted');
    for (const mv of P.data.learnset.list.filter(m => m.level === P.level)) await aprender(P, mv);
  }
  render();
  if (leveled) await checkEvolution(P);
}
// XP de aliado: sobe de nível pela curva da espécie dele (A.growth) e evolui como você
export async function gainExpAliado(A, xp) {
  if (!A.growth) return;
  A.exp += xp;
  let leveled = false;
  while (A.level < 100 && A.exp >= A.growth[A.level + 1]) {
    A.level++; recalc(A); leveled = true; ganharFelicidade(A, ganhoFelicidadeNivel(felicidadeDe(A))); render(); tocarSfx('nivel');
    await say(`${nm(A)} subiu para o nível ${A.level}!`, 'level');
    for (const ref of A.data.learnset.list.filter(m => m.level === A.level)) await aprender(A, ref);
  }
  render();
  if (leveled) await checkEvolution(A);
}

/* Ensina um golpe. Devolve `true` se ele entrou mesmo no moveset (os itens de golpe só são gastos no true).
   `escolher` = quem decide o golpe a esquecer: por padrão você escolhe pelos SEUS golpes e o aliado troca sozinho o
   de menor poder ao subir de nível. Usando um item no aliado, porém, quem escolhe é você — foi você que pagou. */
export async function aprender(M, ref, escolher = ehJogador(M)) {
  if (M.moves.some(m => m.name === ref.name)) return false;
  const mv = await loadMove(ref.url);
  if (M.moves.length < 4) { M.moves.push({ ...mv, ppLeft: mv.pp }); render(); await say(`${nm(M)} aprendeu ${esc(fmt(mv.name))}!`, 'good'); return true; }
  if (!escolher) {
    /* Aliado aprendendo sozinho: ele decide na hora, como um bicho decidiria — metade das vezes topa e troca um
       golpe QUALQUER, metade das vezes prefere ficar com o que já sabe. Antes ele sempre trocava o de menor poder
       pelo novo (se o novo fosse mais forte): dava um moveset ótimo, previsível, e sem nenhum "jeito" próprio. */
    if (Math.random() < CHANCE_ALIADO_RECUSA) { await say(`${nm(M)} pensou um pouco e preferiu continuar com os golpes que já sabe.`, 'muted'); return false; }
    const i = Math.floor(Math.random() * M.moves.length);
    const velho = M.moves[i]; M.moves[i] = { ...mv, ppLeft: mv.pp }; render();
    await say(`${nm(M)} esqueceu ${esc(fmt(velho.name))} e aprendeu ${esc(fmt(mv.name))}!`, 'good');
    return true;
  }
  const card = `<div class="mcard"><b>${esc(fmt(mv.name))}</b>: ${TYPE_PT[mv.type] || mv.type}, ${CLS_PT[mv.cls]}, poder ${mv.power ?? '—'}, precisão ${mv.acc ?? '—'}, PP ${mv.pp}<br>${esc(mv.desc)}</div>`;
  const c = await ask(`${nm(M)} quer aprender <b>${esc(fmt(mv.name))}</b>, mas já sabe 4 golpes. Esquecer qual?`,
    [...M.moves.map((m, i) => ({ label: `Esquecer ${esc(fmt(m.name))} (${m.power ?? '—'} pod.)`, value: i })), { label: `Não aprender ${esc(fmt(mv.name))}`, value: -1, ghost: true }], card);
  if (c >= 0) { const old = M.moves[c]; M.moves[c] = { ...mv, ppLeft: mv.pp }; render(); await say(`${nm(M)} esqueceu ${esc(fmt(old.name))} e aprendeu ${esc(fmt(mv.name))}!`, 'good'); return true; }
  await say(`${nm(M)} não aprendeu ${esc(fmt(mv.name))}.`);
  return false;
}

export function findNode(n, name) { if (n.name === name) return n; for (const c of n.to) { const f = findNode(c, name); if (f) return f; } return null; }
// Árvore de evolução: a sua fica em S.meta.evo; a do aliado é buscada na 1ª vez e guardada nele (A.evo, null = não
// evolui). Árvore abaixo de `v: 3` é de save antigo (v nenhum = só nível; v: 2 = sem o `gender` de cada caminho):
// busca de novo com todas as condições (offline: usa a velha).
async function arvoreDe(M) {
  const atual = ehJogador(M) ? G.S.meta.evo : M.evo;
  if (atual === null || atual?.v >= 3) return atual;
  try {
    const sp = await loadSpecies(M.data.speciesUrl);
    const nova = sp.evoUrl ? await loadEvo(sp.evoUrl) : null;
    if (ehJogador(M)) G.S.meta.evo = nova; else M.evo = nova;
    return nova;
  } catch (e) { if (atual) return atual; throw e; }
}
// o que as condições precisam saber (evolucao.js): hora de verdade, os outros da equipe, mochila, registro, dinheiro
/* A `bag` que a condição vê inclui o item que o PRÓPRIO Pokémon está segurando. Motivo: os itens de dupla função
   (dados.duplo — Pedra do Rei, Revestimento Metálico…) evoluem E valem segurados, e equipar tira da mochila.
   Sem isto, equipar a Pedra do Rei travava a evolução do Poliwhirl sem explicar nada — e nos jogos é justamente
   SEGURANDO que esses itens evoluem. `pagar` sabe tirar da mão quando foi de lá que veio. */
const contexto = (M, extra) => ({ gatilho: 'level-up', hora: new Date().getHours(), aliados: ladoJogador().filter(x => x !== M),
  bag: M?.item ? { ...G.S.bag, [M.item]: (G.S.bag[M.item] || 0) + 1 } : G.S.bag,
  registro: G.S.registro, dinheiro: G.S.money, ...extra });
const nomeItem = k => ITEMS[k]?.name || fmt(k);
// gasta o que a evolução pede (item segurado na mochila, dinheiro)
function pagar(o, M = null) {
  const S = G.S;
  if (o.consome) {
    // o item pode estar SEGURADO em vez de na mochila (item de dupla função): gasta da mão nesse caso
    if (!(S.bag[o.consome] > 0) && M?.item === o.consome) M.item = null;
    else { S.bag[o.consome]--; if (S.bag[o.consome] <= 0) delete S.bag[o.consome]; }
  }
  if (o.custo) S.money -= o.custo;
}
const extraTexto = o => [o.consome ? `gasta ${nomeItem(o.consome)}` : '', o.custo ? `custa ₽${o.custo.toLocaleString('pt-BR')}` : ''].filter(Boolean).join(', ');

// Evolução por nível (ou depois da batalha, `extra.gatilho = 'pos-batalha'`): pergunta se deixa evoluir.
export async function checkEvolution(M, extra = {}) {
  let arvore;
  try { arvore = await arvoreDe(M); }
  catch (e) {
    // A REDE FALHOU bem na hora de evoluir: o nível subiu e ficou salvo, mas a evolução sumiria sem ninguém ver.
    // Fica marcada como pendente e o jogo tenta de novo sozinho (verificarEvolucoesPendentes).
    M.evoPendente = true;
    await say(`${nm(M)} parece querer mudar, mas a conexão falhou agora. Fica pendente: o jogo tenta de novo em instantes.`, 'status');
    return false;
  }
  if (!arvore) { delete M.evoPendente; return false; }
  const node = findNode(arvore, M.data.speciesName); if (!node) { delete M.evoPendente; return false; }
  const opts = evolucoesPossiveis(node, M, contexto(M, extra));
  delete M.evoPendente; // a árvore chegou: não há mais nada pendente, evoluindo ou não
  if (!opts.length) return false;
  const pergunta = ehJogador(M) ? `Algo está acontecendo com ${nm(M)}... Você sente seu corpo mudar. Deixar evoluir?`
    : `Algo está acontecendo com seu aliado ${nm(M)}... Deixar ele evoluir?`;
  const c = await ask(pergunta, [...opts.map(o => ({ label: `Evoluir para ${esc(fmt(o.name))}${extraTexto(o) ? ` (${extraTexto(o)})` : ''}`, value: o.name })), { label: ehJogador(M) ? 'Resistir à evolução' : 'Impedir a evolução', value: null, ghost: true }]);
  if (!c) { await say(`${nm(M)} ${ehJogador(M) ? 'resistiu à' : 'não passou pela'} evolução.`); return false; }
  pagar(opts.find(o => o.name === c), M);
  try {
    await evolve(M, await casulo(M, c, node), arvore);
  } catch (e) {
    // caiu a rede DEPOIS de você aceitar: não perde a evolução, ela volta a ficar pendente
    console.error(e); M.evoPendente = true;
    await say(`A evolução de ${nm(M)} travou por falta de conexão. Ela continua pendente e acontece assim que a rede voltar.`, 'hit');
    return false;
  }
  return true;
}

// Evolução que ficou pendente por falta de rede: tenta de novo. Chamada quando você explora e depois de vencer —
// assim ninguém fica "no vácuo" subindo de nível sem nunca evoluir. Não faz nada offline nem no meio da batalha.
export async function verificarEvolucoesPendentes() {
  if (offline() || G.mode === 'battle') return false;
  let algum = false;
  for (const M of ladoJogador()) {
    if (!M.evoPendente || M.hp <= 0) continue;
    if (await checkEvolution(M)) algum = true;
  }
  return algum;
}

// Nincada: ao virar Ninjask, o casco deixado pra trás vira Shedinja. Com vaga na equipe, ele entra sozinho como
// aliado; com a equipe cheia, você escolhe em qual dos dois o seu Pokémon vira. Devolve a espécie final.
const CASCA_PRA_TRAS = { ninjask: 'shedinja' };
async function casulo(M, escolha, node) {
  const outra = CASCA_PRA_TRAS[escolha];
  if (!outra || !node.to.some(x => x.name === outra)) return escolha;
  const S = G.S; S.aliados ||= [];
  if (S.aliados.length >= tetoDaEquipe(S)) {
    const c = await ask(`A casca de ${nm(M)} vai ficar pra trás e ganhar vida própria — mas sua equipe já está cheia (${tetoDaEquipe(S)} aliados). Em qual dos dois ${ehJogador(M) ? 'você vira' : 'ele vira'}?`,
      [{ label: `Virar ${esc(fmt(escolha))}`, value: escolha }, { label: `Virar ${esc(fmt(outra))}`, value: outra }]);
    return c || escolha;
  }
  try {
    const data = await loadPokemon(outra);
    const novo = await makeMon(data, M.level);
    const sp = await loadSpecies(data.speciesUrl);
    novo.growth = await loadGrowth(sp.growthUrl); novo.exp = novo.growth[novo.level];
    novo.felicidade = FELICIDADE_ALIADO;
    S.aliados.push(novo); G.abertos.clear();
    registrar(S, 'amigos', data.speciesName, data.id);
    if (novo.shiny) registrar(S, 'shiniesAmigos', data.speciesName, data.id);
    render();
    await say(`A casca vazia se mexe... <b>${esc(fmt(data.name))}</b> ganhou vida e agora segue com você!${novo.shiny ? ' ✨ E é shiny!' : ''}`, 'level');
  } catch (e) { console.error(e); await say('A casca ficou pra trás, imóvel. (não deu pra buscar os dados dela agora)', 'muted'); }
  return escolha;
}

// Usar um item de evolução (pedra etc.: 'use-item') ou o Cabo de Conexão ('trade') fora de batalha.
// Pergunta em quem (só quem pode evoluir com ele agora) e pra quê. true = item gasto.
export async function evoluirComItem(id) {
  const it = ITEMS[id], gatilho = it.troca ? 'trade' : 'use-item', S = G.S;
  const cands = [], faltas = [];
  for (const M of ladoJogador().filter(x => x.hp > 0)) {
    let arvore; try { arvore = await arvoreDe(M); } catch { continue; }
    const node = arvore && findNode(arvore, M.data.speciesName); if (!node) continue;
    const opts = evolucoesPossiveis(node, M, contexto(M, { gatilho, item: id }));
    if (opts.length) { cands.push({ M, arvore, opts }); continue; }
    // quase: tem esse tipo de evolução, mas falta algo (ex.: o item que vai junto na troca)
    for (const alvo of node.to) {
      const d = caminhoMostrado(alvo);
      if (d?.trigger === gatilho && (gatilho === 'trade' || d.item === id)) faltas.push(`${esc(rotulo(M))} → ${esc(fmt(alvo.name))}: precisa ${esc(textoCondicao(d, nomeItem))}`);
    }
  }
  if (!cands.length) {
    await say(`${it.name} não faz ninguém da equipe evoluir agora.${faltas.length ? '<br>' + faltas.join('<br>') : ''}`, 'muted');
    return false;
  }
  let esc1 = cands[0];
  if (cands.length > 1) {
    const i = await ask(`Usar <b>${it.name}</b> em quem?`, [...cands.map((x, j) => ({ label: `${esc(rotulo(x.M))} → ${x.opts.map(o => esc(fmt(o.name))).join(' / ')}`, value: j })), { label: 'Cancelar', value: -1, ghost: true }]);
    if (i < 0) return false;
    esc1 = cands[i];
  }
  const { M, arvore, opts } = esc1;
  const c = await ask(`Usar <b>${it.name}</b> em ${nm(M)}?`, [...opts.map(o => ({ label: `Evoluir para ${esc(fmt(o.name))}${extraTexto(o) ? ` (${extraTexto(o)})` : ''}`, value: o.name })), { label: 'Cancelar', value: null, ghost: true }]);
  if (!c) return false;
  S.bag[id]--; if (S.bag[id] <= 0) delete S.bag[id];
  pagar(opts.find(o => o.name === c), M);
  await say(it.troca ? `Você conecta o ${it.name}... ${nm(M)} sente uma energia estranha.` : `Você usa ${it.name} em ${nm(M)}.`);
  await evolve(M, c, arvore);
  return true;
}
async function evolve(M, speciesName, arvore) {
  // forma do meio (ainda evolui) ou final (não evolui mais): o Roguelike pede 5 ou 10 evoluções pra desbloquear
  const forma = findNode(arvore, speciesName)?.to.length ? 'meio' : 'final';
  const sp = await loadSpecies(`${API}/pokemon-species/${speciesName}/`);
  /* Evoluiu NA REGIÃO da forma regional? Sai na forma de lá. É a regra dos jogos (Exeggcute + Pedra da Folha em
     Alola = Exeggutor de Alola) e vale pra qualquer região: a fonte é o próprio mapa (mapas.formaRegionalDaGen),
     então região nova entra sozinha. Antes a evolução ia SEMPRE pra forma padrão (`sp.defaultPokemon`), e a
     única maneira de ter uma forma regional era encontrar uma pronta no Santuário.
     `data.speciesName` continua sendo a espécie base ('exeggutor'), que é a chave que o registro, a Pokédex e os
     desbloqueios usam desde sempre — só `id`/`name` mudam. */
  const regional = formaRegionalDaGen(speciesName, genDe(G.S));
  const data = await loadPokemon(regional ? regional.forma : sp.defaultPokemon);
  const oldName = ehJogador(M) ? fmt(M.name) : (M.nick || fmt(M.name));
  const habVelha = M.ability, habVelhas = M.data.abilities, golpesVelhos = M.data.learnset.list;
  M.id = data.id; M.name = data.name; M.data = data;
  M.ability = habilidadeDaEvolucao(habVelhas, data.abilities, habVelha);
  recalc(M); render();
  registrar(G.S, 'evolucoes', data.speciesName, data.id); // conta pro Roguelike (5× forma do meio / 10× final)
  /* Evoluir pra uma espécie que você nunca viu no mundo a deixava eternamente "?" na Pokédex de toda rota onde
     ela vive — mesmo tendo uma na sua equipe. Conta como VISTA (silhueta), não como DERROTADA: a % de chance
     na rota é sobre quem aparece ALI de verdade, e uma evolução em outro mapa não informa nada sobre isso — só
     encontrar de fato ainda revela a taxa. Relatado em jogo. */
  registrar(G.S, 'vistos', data.speciesName, data.id);
  // Segredo do brilho: quem já era shiny continua shiny na evolução — desbloqueia a NOVA espécie pro início-shiny
  // também (bug corrigido em 27/09/2026: só o recrutamento de aliado shiny registrava isso, evoluir nunca).
  if (M.shiny) registrar(G.S, 'shiniesAmigos', data.speciesName, data.id);
  (G.S.registro.formas ||= {})[data.speciesName] = forma;
  await say(`Parabéns! ${esc(oldName)} evoluiu para <b>${esc(fmt(data.name))}</b>!`, 'level');
  // dizer POR QUE saiu diferente: senão parece bug ("evoluí e veio outro Pokémon")
  if (regional) await say(`Foi a região que decidiu a forma: evoluindo em ${esc(dadosDaGen(genDe(G.S)).regiao)}, ${esc(fmt(speciesName))} vira <b>${esc(fmt(data.name))}</b>.`, 'status');
  // a habilidade acompanha a evolução (mesmo slot): avisa quando ela troca de nome, senão some sem ninguém ver
  if (M.ability !== habVelha) await say(`A habilidade de ${nm(M)} virou <b>${esc(fmt(M.ability))}</b> (era ${esc(fmt(habVelha))}).`, 'status');
  for (const mv of golpesDaEvolucao(golpesVelhos, data.learnset.list, M.level)) await aprender(M, mv);
}
