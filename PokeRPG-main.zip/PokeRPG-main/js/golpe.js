/* ============ motor do golpe (único: single player e multiplayer) ============ */
// Tudo que acontece quando um Pokémon usa um golpe, muda estágios, pega status ou chega ao fim do turno — com as
// habilidades (habilidades.js) ligadas. Não sabe de tela nem de rede: quem chama passa um `ctx` que diz COMO narrar:
//   ctx.nome(m)      nome pra exibir (single player: HTML com <b>; multiplayer: texto puro)
//   ctx.golpe(g)     nome do golpe pra exibir
//   ctx.say(txt, cls)  narra (pode ser async: o single player espera entre mensagens)
//   ctx.atualizar()  redesenha (barras de HP) — opcional
//   ctx.tremer(m, tipo)  animação + som de quem levou dano; `tipo` é o do golpe (pinta e escolhe o som) — opcional
//   ctx.atacar(m)    animação de quem usou o golpe — opcional
//   ctx.refDe(m) / ctx.monPorRef(ref)  identificam quem plantou Leech Seed (pra curar no fim do turno) — opcionais
//   ctx.campo        objeto do campo da batalha, compartilhado pelos dois lados: { clima, turnos } — opcional
//   ctx.abrirBrecha(alvo, n)  ⚔ Saga: tira `n` da Guarda do alvo e narra a Ruína — opcional, como ctx.forcarSaida.
//                    O motor só PEDE; quem tem Guarda e quem narra é batalha.js. Sem o gancho (multiplayer),
//                    nada acontece, e nenhum outro modo muda de comportamento.
// Golpes especiais (Protect, Rest, Explosion, carga/recarga…) vêm da tabela de especiais.js.
// Sem DOM: importável no Node (tests/golpe.test.js).
import { STAT_PT, AIL_MSG, SELF_TARGETS, ALVOS_OPONENTES, ALVOS_TODOS, ALVOS_ALIADOS, TYPE_PT } from './dados.js';
import { GOLPE_AREA } from './dados-golpe-flags.js';
import { hab } from './habilidades.js';
import { especial, GOLPE_DO_TERRENO, TIPO_DO_TERRENO, TIPO_DA_FRUTA_DE_CURA, PODER_NATURAL_GIFT } from './especiais.js';
import { seg, fimDeTurnoDoItem, frutaAgora, statusDoItem, frutaDeAperto, SEGURADOS } from './segurados.js';
import { ITEMS, ITEM_VINCULO, FRUTA_DO_TIPO, ALVOS_OPONENTES as AO } from './dados.js';
import { calcDamage, confDamage, heal, typeEff, chanceAcerto, imuneAoStatusMon, danoResidual, chanceOhko, effStat,
  CLIMAS, CLIMA_TURNOS, climaDe, danoClima, TERRENOS, TERRENO_TURNOS, terrenoDe, terrenoBloqueiaStatus, noChao,
  LADO_VAZIO, TELA_TURNOS, VENTO_TURNOS, MAX_ESPINHOS, MAX_TOXINAS, MULT_AREA, multTelas, temSalvaguarda, temNeblina,
  passarLado, NOME_LADO, danoPedras, danoEspinhos, efeitoToxinas, recalc, golpeDoClima, golpeDoTera, golpeDoBattleBond, golpeDaConversaoDeTipo, tiposDefensivos, tiposDe, maiorStatBase,
  GRAVIDADE_TURNOS, APERTO_MIN, APERTO_MAX, APERTO_FRACAO, danoFixoDe, podeCopiar, danoDoContra, tipoQueResiste,
  SALA_TURNOS, salaAtiva, GUARDAS_DE_LADO,
  fazContato, temFlag, motivoBloqueio, golpeForcado, falhaDaTrava, passarTravas, TURNOS_TRAVA, generoOposto, somarAmeaca, eficacia,
  multSaga, BRECHA_SUPER, BRECHA_CRITICO, BRECHA_STATUS, BRECHA_SELO, golpeDeApoio } from './regras.js';
import { danoNoChefe, aposDanoNoChefe, antesDoChefeAgir, drenoDoChefe, anulaTexto } from './boss.js';
import { rand, clamp, fmt } from './util.js';
import { loadPokemon } from './api.js';

const nada = () => {};
const up = ctx => (ctx.atualizar || nada)();
const nomeDoItem = m => ITEMS[m.item]?.name || 'o item';
// sorteia um valor de uma lista [[valor, peso], …] (Effect Spore: sono 11, paralisia 9, veneno 10)
const sortearPeso = lista => {
  let r = Math.random() * lista.reduce((s, [, p]) => s + p, 0);
  for (const [v, p] of lista) if ((r -= p) < 0) return v;
  return lista[lista.length - 1][0];
};
const climaDoCtx = ctx => climaDe(ctx.campo);
const terrenoDoCtx = ctx => terrenoDe(ctx.campo);
// habilidades que uma troca (Trace/Mummy/Wandering Spirit) NUNCA sobrescreve nem copia: mexem com mecânica própria
// do motor (a troca de forma do Aegislash), não só descrição — copiar/trocar isso pra outro Pokémon quebraria a conta
/* Habilidade que NUNCA é trocada, copiada nem anulada: ela é mecânica do motor (a troca de forma do Aegislash,
   a do Castform), não só uma descrição — passá-la pra outro Pokémon, ou tirá-la, quebraria a conta de forma no
   meio da luta. Vale pro Trace/Mummy e pros golpes de troca de habilidade (Role Play, Skill Swap, Gastro Acid…). */
const TRAVADAS = new Set(['stance-change', 'forecast']);
const ABILIDADE_TRAVADA = a => TRAVADAS.has(a);
// troca a habilidade guardando a antiga: é o caminho do Trace, e `desfazerTrace` (endBattle) o desfaz
const trocarHabilidade = (m, nova) => { m.abilityAntes ??= m.ability; m.ability = nova; };
// lado do campo de um Pokémon (telas, salvaguarda, armadilhas). ctx.ladoDe(m) diz em qual lado ele está.
export function ladoDoCampo(ctx, m) {
  const chave = ctx.ladoDe?.(m); if (!chave || !ctx.campo) return null;
  const lados = (ctx.campo.lados ||= {});
  return (lados[chave] ||= LADO_VAZIO());
}
// fim da rodada: telas, salvaguarda, névoa e vento andam um turno nos dois lados (batalha.js / mp-motor)
export async function passarLados(campo, ctx) {
  for (const lado of Object.values(campo?.lados || {})) {
    for (const k of passarLado(lado)) await ctx.say(`${NOME_LADO[k]} passou.`, 'muted');
  }
}
// liga um terreno novo (golpe ou habilidade) e narra
export async function mudarTerreno(terreno, ctx, quem = null) {
  if (!TERRENOS[terreno] || !ctx.campo) return false;
  const repetido = terrenoDoCtx(ctx) === terreno;
  if (repetido && ctx.campo.terrenoFixo) {          // o chão da rota já é este: continua permanente, não vira um de 5 turnos
    await ctx.say(`${TERRENOS[terreno].icone} O campo continua: ${TERRENOS[terreno].nome.toLowerCase()}.${quem ? ` (${ctx.nome(quem)})` : ''}`, 'status');
    return true;
  }
  ctx.campo.terreno = terreno; ctx.campo.terrenoTurnos = TERRENO_TURNOS; ctx.campo.terrenoFixo = false;
  await ctx.say(`${TERRENOS[terreno].icone} ${repetido ? `O campo continua: ${TERRENOS[terreno].nome.toLowerCase()}.` : TERRENOS[terreno].comeca}${quem ? ` (${ctx.nome(quem)})` : ''}`, 'status');
  return true;
}
// fim da rodada: o terreno anda um turno (chamado junto de passarClima)
export async function passarTerreno(campo, ctx) {
  if (!campo?.terrenoTurnos || campo.terrenoFixo) return;   // o chão da rota não gasta turno
  campo.terrenoTurnos--;
  if (campo.terrenoTurnos > 0) return;
  const t = TERRENOS[campo.terreno];
  campo.terreno = null;
  if (t) await ctx.say(t.acaba, 'muted');
  const p = campo.padrao?.terreno;                          // acabou o que foi trocado: a rota volta ao chão dela
  if (p && TERRENOS[p]) { campo.terreno = p; campo.terrenoTurnos = TERRENO_TURNOS; campo.terrenoFixo = true; await ctx.say(`${TERRENOS[p].icone} ${TERRENOS[p].comeca}`, 'status'); }
}
// liga um clima novo (golpe ou habilidade) e narra; o mesmo clima de novo só renova o tempo
export async function mudarClima(clima, ctx, quem = null) {
  if (!CLIMAS[clima] || !ctx.campo) return false;
  const repetido = climaDoCtx(ctx) === clima;
  if (repetido && ctx.campo.climaFixo) {            // o tempo da rota já é este: continua permanente, não vira um de 5 turnos
    await ctx.say(`${CLIMAS[clima].icone} O tempo continua: ${CLIMAS[clima].nome.toLowerCase()}.${quem ? ` (${ctx.nome(quem)})` : ''}`, 'status');
    return true;
  }
  ctx.campo.clima = clima; ctx.campo.turnos = CLIMA_TURNOS; ctx.campo.climaFixo = false;
  await ctx.say(`${CLIMAS[clima].icone} ${repetido ? `O tempo continua: ${CLIMAS[clima].nome.toLowerCase()}.` : CLIMAS[clima].comeca}${quem ? ` (${ctx.nome(quem)})` : ''}`, 'status');
  return true;
}
// fim da rodada: o clima anda um turno e acaba quando o tempo esgota (chamado por batalha.js e mp-motor.js)
export async function passarClima(campo, ctx) {
  if (!campo?.turnos || campo.climaFixo) return;           // o tempo da rota não gasta turno
  campo.turnos--;
  if (campo.turnos > 0) return;
  const c = CLIMAS[campo.clima];
  campo.clima = null;
  if (c) await ctx.say(c.acaba, 'muted');
  const p = campo.padrao?.clima;                            // acabou o que foi trocado: a rota volta ao tempo dela
  if (p && CLIMAS[p]) { campo.clima = p; campo.turnos = CLIMA_TURNOS; campo.climaFixo = true; await ctx.say(`${CLIMAS[p].icone} ${CLIMAS[p].comeca}`, 'status'); }
}

/* ---- 🪐 Gravidade (Gravity) ----
   É o único efeito de campo que mexe em cada Pokémon, não só num número do `campo`: enquanto ela vale, todo mundo
   em campo fica com `vol.noSolo` (sente o terreno, pisa nos espinhos, leva golpe Terrestre) e `vol.gravidade` (os
   golpes com a flag `gravity` ficam proibidos — regras.motivoBloqueio). Por isso ela recebe a LISTA de quem está
   em campo, dos dois lados: quem conta os turnos já tem essa lista na mão (batalha.js e mp-motor.js a montam pro
   fim de turno), e sem ela não haveria como desfazer a marca de cada um quando a gravidade passa.
   Marca a diferença entre "posto no chão pela gravidade" e "derrubado pelo Smack Down" guardando a ORIGEM em
   `vol.noSolo` — senão o fim da gravidade levantaria de volta quem o Thousand Arrows tinha derrubado de vez. */
export async function mudarGravidade(ctx, mons, quem = null) {
  if (!ctx.campo) return false;
  if (ctx.campo.gravidade > 0) { await ctx.say('Mas falhou! (a gravidade já está pesando)'); return true; }
  ctx.campo.gravidade = GRAVIDADE_TURNOS;
  await ctx.say(`🪐 A gravidade fica intensa!${quem ? ` (${ctx.nome(quem)})` : ''}`, 'status');
  for (const m of mons || []) {
    if (m.hp <= 0 || !m.vol) continue;
    const voava = m.vol.voando > 0 || !noChao(m);
    m.vol.gravidade = true; m.vol.noSolo ||= 'gravidade'; delete m.vol.voando;
    if (voava) await ctx.say(`${ctx.nome(m)} é puxado para o chão!`, 'muted');
  }
  return true;
}
// fim da rodada: a gravidade anda um turno (chamada junto de passarClima, com a MESMA lista do fim de turno)
export async function passarGravidade(campo, ctx, mons) {
  if (!campo?.gravidade) return;
  if (--campo.gravidade > 0) return;
  for (const m of mons || []) {
    if (!m.vol) continue;
    delete m.vol.gravidade;
    if (m.vol.noSolo === 'gravidade') delete m.vol.noSolo;   // o Smack Down (`noSolo: true`) continua valendo
  }
  await ctx.say('🪐 A gravidade voltou ao normal.', 'muted');
}

/* ---- 🎭 usar o golpe de OUTRO ----
   Mimic, Metronome, Mirror Move, Copycat, Sleep Talk, Assist, Nature Power, Me First, Instruct e Transform têm
   um problema só em comum: **executar um golpe que não é o escolhido**. O que o motor precisava e não tinha era
   de onde vem o OBJETO do golpe (com tipo, poder, `meta` e PP) — porque `vol.ultimo` guarda só o NOME.

   A resposta é que o objeto **nunca precisa de busca nova**: quem usou um golpe sabe esse golpe, e o moveset dele
   está em campo. `golpeDeNome` procura o nome nos movesets de quem for candidato, e com isso Mirror Move, Copycat,
   Instruct, Mimic e Sketch saem todos de graça. Metronome e Assist sorteiam no mesmo lugar. Nature Power é a única
   exceção, e por isso virou TABELA (`especiais.GOLPE_DO_TERRENO`) em vez de busca: 5 golpes cujos números não
   mudam, contra uma chamada de rede no meio do turno.

   `SEM_COPIA` (regras.js) é a trava de recursão: nenhum golpe de cópia pode ser copiado. */
const golpeDeNome = (nome, donos) => {
  if (!podeCopiar(nome)) return null;
  for (const d of donos || []) { const g = d?.moves?.find(m => m?.name === nome); if (g) return g; }
  return null;
};
const copiaveis = m => (m?.moves || []).filter(g => podeCopiar(g?.name));
/* 🎒 ANOTA o item antes de qualquer golpe mexer nele. Pedido do usuário (13/10/2026): numa batalha VENCIDA o que
   era seu volta (`batalha.desfazerItens`). `'itemAntes' in m` em vez de `??=` porque "não tinha item" (null) é
   diferente de "ainda não anotei" (undefined) — e é essa diferença que faz o Thief continuar valendo a pena:
   quem roubou de MÃO VAZIA fica com o espólio, quem foi roubado recupera o seu. */
export const anotarItem = m => { if (m && !('itemAntes' in m)) m.itemAntes = m.item ?? null; };
/* Item CONSUMIDO (fruta comida, Faixa de Foco gasta, Erva usada, Fling arremessado). Guarda o id em
   `vol.itemGasto` pro ♻ Recycle e some com ele. NÃO anota `itemAntes`: consumo não é roubo, e `desfazerItens`
   não deve devolver uma fruta que foi comida — só o que outro Pokémon tirou de você. */
export const gastarItem = m => { if (m?.item) { m.vol.itemGasto = m.item; m.item = null; } };
const trocaItemDe = (m, novo) => { anotarItem(m); m.item = novo; };
/* …e o par que desfaz, no fim de uma batalha VENCIDA (`batalha.endBattle`). A regra é UMA: **o que era seu volta;
   o que você ganhou de mão vazia, fica.** É o que mantém o Thief valendo a pena (roubar segurando nada rende o
   espólio) sem deixar nenhum golpe do inimigo tomar o seu Restos pra sempre. Devolve o id que voltou, pra narrar.
   Fica aqui e não em `batalha.js` porque é função PURA sobre um Pokémon — e porque ali ela não seria testável
   sem DOM (`batalha.js` importa `ui.js`), que é exatamente o erro que ela deu quando nasceu no lugar errado. */
export function desfazerItens(m) {
  if (!m || !('itemAntes' in m)) return null;
  const antes = m.itemAntes; delete m.itemAntes;
  if (antes && m.item !== antes) { m.item = antes; return antes; }
  return null;
}
const todosEmCampo = (u, ctx) => [u, ...(ctx.aliadosDe?.(u) || []), ...(ctx.oponentesDe?.(u) || [])].filter(m => m?.hp > 0);

/* Roda um golpe COPIADO. De propósito NÃO é uma chamada recursiva de `usarGolpe`: o golpe de cópia já passou por
   tudo o que decide "consigo agir?" (sono, paralisia, recuo, confusão, travas) e já gastou o próprio PP — repetir
   aquele bloco faria o Sleep Talk falhar na trava de sono que ele existe pra furar.
   O que esta função faz é o MIOLO de `usarGolpe`: anunciar, marcar o `ultimo` e chamar `executar` por alvo, que é
   a porta única de todo efeito. O que ela deixa de fora, consciente: **golpe de dois turnos não carrega** (sai na
   hora — e por isso eles estão em `SEM_COPIA`), não gasta PP do golpe copiado e não trava Choice.
   // ponytail: `autoDesmaio` e `recarga` são as duas linhas que valiam copiar; o resto do rabo de `usarGolpe`
   // (fúria, carga, Damp) só valeria pro caso que SEM_COPIA já barra. */
export async function usarCopia(u, t, g, primeiro, ctx, mult = 1) {
  const copia = mult === 1 ? g : { ...g, power: g.power ? Math.round(g.power * mult) : g.power };
  await ctx.say(`${ctx.nome(u)} usou ${ctx.golpe(copia)}!`);
  u.vol.ultimo = copia.name;                                  // Encore/Disable/Torment olham o golpe que SAIU
  if (ctx.campo && podeCopiar(copia.name)) ctx.campo.ultimo = copia.name;
  const esp = especial(copia), alvos = alvosDoGolpe(u, t, copia, ctx);
  if (!alvos.length) { await ctx.say('Mas falhou! (não há companheiro em campo)'); return; }
  for (const [i, alvo] of alvos.entries()) {
    if (u.hp <= 0 && i) break;
    await executar(u, alvo, copia, primeiro, ctx, esp, { varios: alvos.length > 1, respingo: i > 0 });
  }
  if (esp.autoDesmaio && u.hp > 0) { u.hp = 0; up(ctx); await ctx.say(`${ctx.nome(u)} desmaiou com o esforço!`, 'hit'); }
  if (esp.recarga && u.hp > 0) u.vol.recarga = true;
}

/* 🪆 Fim da batalha: desfaz o que Mimic e Transform escreveram no PRÓPRIO Pokémon (moveset e atributos). Mora ao
   lado de `desfazerForma`/`desfazerTrace` e é chamado na mesma linha do `endBattle`, pelo mesmo motivo: sem isso
   a cópia ia junto no save. Sketch é o único de propósito PERMANENTE (é a razão de existir do Smeargle), e por
   isso ele nem passa por aqui — grava direto e pronto. */
export function desfazerCopia(m) {
  if (!m) return false;
  const tinha = !!(m.movesAntes || m.statsAntes);
  if (m.movesAntes) { m.moves = m.movesAntes; delete m.movesAntes; }
  if (m.statsAntes) { m.stats = m.statsAntes; delete m.statsAntes; }
  delete m.transformado;
  return tinha;
}

// Golpe em que o Pokémon está travado (carregando, em fúria) — a escolha do jogador/IA é ignorada neste turno
export const golpeTravado = m => m.vol?.carregando || m.vol?.furia?.golpe || m.vol?.bide?.golpe || null;
// Algo impediu de agir: carga e fúria se perdem (como nos jogos)
function interromper(u) { delete u.vol.carregando; delete u.vol.invul; delete u.vol.furia; }
// Fim da rodada (depois de todos agirem): proteções de um turno só acabam
// `muralha` (⚔ Saga, perícia do Guardião) tem exatamente a vida de `protegido`/`aguenta`: vale a rodada e acaba
export function fimDaRodada(m) {
  if (!m.vol) return;
  delete m.vol.golpeEscolhido; delete m.vol.recemEntrou; m.vol.flinch = false; m.vol.protegido = false; m.vol.aguenta = false;
  delete m.vol.punicao; delete m.vol.muralha; delete m.vol.ajuda; delete m.vol.chamariz;
  /* Da leva de 13/10: o contra-ataque conta só o dano DESTA rodada (`ultimoDano`), e Destiny Bond, Grudge, Magic
     Coat, Snatch, Powder, Electrify e Ally Switch valem só até o fim dela — é o que os separa de um buff. */
  delete m.vol.ultimoDano; delete m.vol.laco; delete m.vol.rancor; delete m.vol.manto; delete m.vol.furtar;
  delete m.vol.poExplosivo; delete m.vol.eletrificado;
}

// Muda estágios. `fonte` = quem causou (se for outro Pokémon, Clear Body & cia. podem impedir a queda)
/* Em QUEM o golpe mexe os atributos. A PokéAPI separa por categoria:
     'damage-lower' → mexe nos atributos do ALVO (Crunch, Acid Spray);
     'damage-raise' → mexe nos do USUÁRIO — inclusive quando o golpe baixa os DELE MESMO (Close Combat, Draco
                      Meteor, Overheat). Por isso a regra não é o sinal da mudança, é a categoria.
   Já foi bug real, relatado em jogo: o código comparava com 'damage+raise' (com +), string que a API nunca devolve,
   então Flame Charge, Power-Up Punch, Ancient Power e companhia davam o bônus pro OPONENTE. Aceita as duas grafias
   pra não depender de qual delas a API usa. */
export const mudaOUsuario = meta => /[-+]raise$/.test(meta?.cat || '');

/* Mudança de Postura (Aegislash). Golpe de dano vira a Forma Lâmina (ataque altíssimo, defesa de papel); King's
   Shield volta pra Forma Escudo. As duas formas têm os MESMOS números trocados de lado (Ataque ↔ Defesa e
   At. Esp. ↔ Def. Esp.), então a troca é espelhar os atributos base — sem buscar a outra forma na rede, o que
   deixaria a batalha esperando por uma requisição no meio do turno.
   Cuidado: `m.data` é o objeto do CACHE, compartilhado por todo Aegislash que aparecer. Por isso a troca cria uma
   cópia (`{ ...m.data, base }`) em vez de mexer no original — senão o primeiro Aegislash do jogo contaminaria os
   próximos, e o cache guardaria a forma errada. */
export async function trocarPostura(m, paraLamina, ctx) {
  const h = hab(m); if (!h.postura || !!m.lamina === paraLamina) return false;
  const base = { ...m.data.base };
  for (const [a, b] of [h.postura.ataque, h.postura.especial]) { const t = base[a]; base[a] = base[b]; base[b] = t; }
  m.data = { ...m.data, base };
  m.lamina = paraLamina;
  recalc(m); (ctx.atualizar || nada)();
  await ctx.say(`${ctx.nome(m)} mudou para a Forma ${paraLamina ? 'Lâmina' : 'Escudo'}!`, 'good');
  return true;
}
// `refletido` = esta mudança já é o rebote do Mirror Armor (não reflete de novo, senão dois espelhos se devolvem pra sempre)
export async function mudarEstagios(m, mudancas, ctx, fonte = null, refletido = false) {
  const h = hab(m);
  for (let c of mudancas) {
    if (!(c.stat in m.vol.stages)) continue;
    // Contrary inverte o sentido da mudança (queda vira alta) e Simple dobra o tamanho dela — as duas valem pra qualquer origem
    if (h.inverteEstagios) c = { ...c, change: -c.change };
    if (h.dobraEstagios) c = { ...c, change: c.change * 2 };
    // Mirror Armor: a queda causada por OUTRO Pokémon volta pra quem causou
    if (c.change < 0 && fonte && fonte !== m && h.espelhaQueda && !refletido) {
      await ctx.say(`A habilidade ${fmt(m.ability)} de ${ctx.nome(m)} devolveu o efeito!`);
      await mudarEstagios(fonte, [c], ctx, m, true); continue;
    }
    if (c.change < 0 && fonte && fonte !== m && (h.semQueda === 'todas' || h.semQueda?.includes(c.stat))) {
      await ctx.say(`A habilidade ${fmt(m.ability)} de ${ctx.nome(m)} impede que ${STAT_PT[c.stat]} caia!`); continue;
    }
    if (c.change < 0 && fonte && fonte !== m && temNeblina(ladoDoCampo(ctx, m))) {   // Mist
      await ctx.say(`${NOME_LADO.neblina} impede que ${STAT_PT[c.stat]} de ${ctx.nome(m)} caia!`); continue;
    }
    // Flower Veil: Grama não perde atributo por ação de OUTRO Pokémon, se ele ou um aliado tem a habilidade
    if (c.change < 0 && fonte && fonte !== m && protegidoPorFlores(m, ctx)) {
      await ctx.say(`O Véu de Flores protege ${ctx.nome(m)} da queda de ${STAT_PT[c.stat]}!`); continue;
    }
    const cur = m.vol.stages[c.stat], nv = clamp(cur + c.change, -6, 6);
    if (nv === cur) { await ctx.say(`${STAT_PT[c.stat]} de ${ctx.nome(m)} não pode ${c.change > 0 ? 'subir' : 'cair'} mais!`); continue; }
    m.vol.stages[c.stat] = nv;
    const d = Math.abs(c.change), subiu = c.change > 0;
    await ctx.say(`${STAT_PT[c.stat]} de ${ctx.nome(m)} ${subiu ? (d >= 3 ? 'subiu drasticamente' : d === 2 ? 'subiu muito' : 'subiu') : (d >= 3 ? 'caiu drasticamente' : d === 2 ? 'caiu muito' : 'caiu')}!`, subiu ? 'good' : 'status');
    /* Erva Branca: desfaz a queda que acabou de acontecer. Vem ANTES do Defiant de propósito — a habilidade
       reage a ter sido baixado, e com a erva o atributo volta ao que era, mas a reação continua valendo (é o
       comportamento dos jogos: a erva desfaz o número, não o fato de ter sido atacado). */
    if (!subiu && seg(m).desfazQueda) {
      m.vol.stages[c.stat] = cur;
      await ctx.say(`A ${ITEMS[m.item]?.name || 'Erva Branca'} de ${ctx.nome(m)} desfez a queda de ${STAT_PT[c.stat]}!`, 'good');
      m.item = null;
    }
    // Defiant / Competitive: uma queda causada por OUTRO Pokémon dispara o contra-ataque (a reação usa fonte = o próprio,
    // então não dispara de novo)
    if (!subiu && fonte && fonte !== m && h.aoSerBaixado) {
      await ctx.say(`A habilidade ${fmt(m.ability)} de ${ctx.nome(m)} reagiu!`, 'status');
      await mudarEstagios(m, [{ stat: h.aoSerBaixado[0], change: h.aoSerBaixado[1] }], ctx, m);
    }
  }
  up(ctx);
}

/* Forecast (Castform): a forma acompanha o tempo — Sol vira Fogo, Chuva vira Água, Granizo/Neve viram Gelo, o resto
   (inclusive areia) fica Normal. Muda os TIPOS (é o que pesa na luta) e o sprite. Chamado quando entra em campo, ao
   fim de cada turno e no começo de cada golpe (do usuário E do alvo), então uma troca de tempo no meio da rodada
   já vale no golpe seguinte. `m.data` é o objeto do CACHE (compartilhado): a troca cria uma CÓPIA, como a postura do
   Aegislash. Os ids das formas são os da PokéAPI (Sunny 10013, Rainy 10014, Snowy 10015). */
export const FORMA_CASTFORM = { sol: { tipo: 'fire', id: 10013 }, chuva: { tipo: 'water', id: 10014 }, granizo: { tipo: 'ice', id: 10015 }, neve: { tipo: 'ice', id: 10015 } };
const spriteDaForma = (url, id) => (url ? url.replace(/\/\d+\.(png|gif|webp)/, `/${id}.$1`) : url);
export async function ajustarForma(m, ctx) {
  if (!hab(m).formaDoClima || m.hp <= 0) return false;
  const alvo = FORMA_CASTFORM[climaDoCtx(ctx)] || null, chave = alvo ? alvo.tipo : null;
  if ((m.formaClima || null) === chave) return false;
  m.formaBase ||= { types: [...m.data.types], sprite: m.data.sprite, back: m.data.back, art: m.data.art };
  const b = m.formaBase;
  m.data = { ...m.data,
    types: alvo ? [alvo.tipo] : [...b.types],
    sprite: alvo ? spriteDaForma(b.sprite, alvo.id) : b.sprite, back: alvo ? spriteDaForma(b.back, alvo.id) : b.back, art: alvo ? spriteDaForma(b.art, alvo.id) : b.art };
  m.formaClima = chave;
  if (alvo) m.formaSprite = alvo.id; else delete m.formaSprite;   // o sprite shiny é montado pelo id (render.spriteFrente)
  up(ctx);
  await ctx.say(`${ctx.nome(m)} mudou de forma com o tempo!`, 'status');
  return true;
}
// fim da batalha: volta à forma normal (a forma é do tempo daquela luta, não da espécie)
export function desfazerForma(m) {
  if (!m?.formaBase) return false;
  m.data = { ...m.data, types: [...m.formaBase.types], sprite: m.formaBase.sprite, back: m.formaBase.back, art: m.formaBase.art };
  delete m.formaBase; delete m.formaClima; delete m.formaSprite;
  return true;
}

/* Vínculo de Batalha / Battle Bond (Greninja): segurando o item ITEM_VINCULO (conquista de conta, 1.000 golpes
   finais sendo Greninja — igual à Pedra Mega em espírito, mas não é Mega: item checado DIRETO pelo id, como
   Pedra Mega/Cristal Z, não pela tabela genérica de segurados.js), derrubar um oponente vira Ash-Greninja pro
   resto da luta — atributos mais altos e Water Shuriken vira fixo em poder 20 e 3 acertos (regras.js
   golpeDoBattleBond, mesmo padrão de golpeDoClima e golpeDoTera). Troca completa (id/nome/dados), igual à Mega
   — diferente do Castform, que só muda tipo e sprite, porque os atributos-base do Ash-Greninja são mesmo
   outros. `greninja-ash` fica pré-carregado no começo da luta (batalha.js iniciar, igual à Mega): se a rede
   falhar aqui no meio do turno, o golpe.js simplesmente não vira, sem travar o combate. Uma vez só por luta
   (m.ashGreninja); desfaz em endBattle, igual Mega/Tera/Dynamax. */
export async function virarAshGreninja(m, ctx) {
  if (m.item !== ITEM_VINCULO || m.ashGreninja || m.data?.speciesName !== 'greninja' || m.hp <= 0) return false;
  let data;
  try { data = await loadPokemon('greninja-ash'); } catch { return false; }
  m.ashAntes = { id: m.id, name: m.name, data: m.data };
  m.id = data.id; m.name = data.name; m.data = data; m.ashGreninja = true;
  recalc(m); up(ctx);
  await ctx.say(`<b>${ctx.nome(m)} sincronizou com você! Virou Ash-Greninja!</b>`, 'level');
  return true;
}
export function desfazerAshGreninja(m) {
  if (!m?.ashAntes) return false;
  const antes = m.ashAntes;
  m.id = antes.id; m.name = antes.name; m.data = antes.data;
  delete m.ashAntes; delete m.ashGreninja;
  recalc(m);
  return true;
}
// Trace, Mummy, Wandering Spirit, Lingering Aroma mudam `m.ability` durante a luta — sem desfazer, a troca ficaria
// pra sempre no save (diferente do multiplayer, onde `m` é uma cópia de rede descartada no fim, e por isso nunca
// precisa disso).
export function desfazerTrace(m) {
  if (!m?.abilityAntes) return false;
  m.ability = m.abilityAntes; delete m.abilityAntes;
  return true;
}
// Pré-carrega 'greninja-ash' se alguém do lado entrar segurando o Vínculo — mesma ideia de mega.preCarregarMegas:
// no começo da luta, não no meio do turno. Só o lado do jogador pode ter o item (o inimigo não tem inventário).
export async function preCarregarAshGreninja(lista) {
  if (!lista.some(m => m?.item === ITEM_VINCULO)) return;
  await loadPokemon('greninja-ash').catch(() => null);
}

/* Habilidades que agem ao ENTRAR em campo (o mesmo código no single player e no multiplayer):
   Intimidate baixa o Ataque do oponente — salvo quem é imune a ela (Inner Focus, Own Tempo, Oblivious) ou reage (Guard Dog
   sobe o Ataque em vez de cair); depois vêm o clima, o terreno e os degraus de entrada (Intrepid Sword…). Download lê os
   oponentes: se a Defesa deles é menor que a Def. Esp., sobe o Ataque; senão, o At. Esp.
   `entrantes` = quem acabou de entrar; `oponentesDe(m)` = quem está do outro lado dele. */
export async function aoEntrarEmCampo(entrantes, oponentesDe, ctx) {
  /* Balão de Ar: quem entra segurando um começa flutuando. Mora no `vol` (regras.noChao lê de lá) porque some
     sozinho no fim da batalha — o item continua na mochila pra próxima luta, como nos jogos. */
  for (const a of entrantes) if (seg(a).balao && a.vol) a.vol.balao = true;
  for (const a of entrantes) if (hab(a).intimida) {
    await ctx.say(`A Intimidação de ${ctx.nome(a)} assusta o oponente!`);
    for (const b of oponentesDe(a)) {
      const hb = hab(b);
      if (hb.imuneIntimidacao) { await ctx.say(`A habilidade ${fmt(b.ability)} de ${ctx.nome(b)} não se abala!`); continue; }
      if (hb.intimidaSobe) {
        await ctx.say(`A habilidade ${fmt(b.ability)} de ${ctx.nome(b)} reage à Intimidação!`, 'good');
        await mudarEstagios(b, [{ stat: 'attack', change: 1 }], ctx, b); continue;
      }
      await mudarEstagios(b, [{ stat: 'attack', change: -1 }], ctx, a); // Clear Body & cia. impedem
    }
  }
  // Trace: copia a habilidade de um oponente vivo ao entrar (não copia habilidades que mexem com mecânica
  // própria do motor, como a troca de forma do Aegislash). Desfeito no fim da luta (desfazerTrace).
  for (const m of entrantes) if (hab(m).copiaHabilidadeAoEntrar) {
    const alvo = oponentesDe(m).find(o => o.hp > 0 && o.ability && o.ability !== m.ability && !ABILIDADE_TRAVADA(o.ability));
    if (alvo) {
      m.abilityAntes ??= m.ability; m.ability = alvo.ability;
      await ctx.say(`${ctx.nome(m)} copiou a habilidade ${fmt(alvo.ability)} de ${ctx.nome(alvo)}!`, 'status');
    }
  }
  // Forewarn (avisa o golpe mais forte) / Frisk (avisa o item): só narram, sem efeito mecânico
  for (const m of entrantes) if (hab(m).avisaGolpeForte) {
    const golpes = oponentesDe(m).filter(o => o.hp > 0).flatMap(o => (o.moves || []).filter(g => g.cls !== 'status'));
    if (golpes.length) {
      const maisForte = golpes.reduce((a, b) => (b.power || 0) > (a.power || 0) ? b : a);
      await ctx.say(`${ctx.nome(m)} pressente o golpe ${ctx.golpe(maisForte)}!`, 'status');
    }
  }
  for (const m of entrantes) if (hab(m).revelaItem) {
    const alvo = oponentesDe(m).find(o => o.hp > 0 && o.item);
    await ctx.say(alvo ? `${ctx.nome(m)} espiou: ${ctx.nome(alvo)} está com ${fmt(ITEMS[alvo.item]?.name || alvo.item)}!` : `${ctx.nome(m)} não encontrou nada.`, 'muted');
  }
  for (const m of entrantes) {
    const h = hab(m);
    if (h.climaAoEntrar) await mudarClima(h.climaAoEntrar, ctx, m);
    if (h.terrenoAoEntrar) await mudarTerreno(h.terrenoAoEntrar, ctx, m);
    let est = h.estagioAoEntrar;
    if (h.analisa) {
      const ops = oponentesDe(m);
      const def = ops.reduce((s, o) => s + effStat(o, 'defense'), 0), esp = ops.reduce((s, o) => s + effStat(o, 'special-defense'), 0);
      est = [def < esp ? 'attack' : 'special-attack', 1];
      await ctx.say(`${ctx.nome(m)} analisou o oponente!`);
    } else if (est) await ctx.say(`${ctx.nome(m)} entra decidido!`);
    // passa por mudarEstagios, então Clear Body e Névoa continuam valendo — é o mesmo caminho da Intimidação
    if (est) await mudarEstagios(m, [{ stat: est[0], change: est[1] }], ctx, m);
  }
  /* Habilidades de ENTRADA que mexem no campo ou no aliado. Ficam aqui porque este é o único ponto que já tem
     quem entrou E os oponentes de cada um; as que mudam degrau passam por `mudarEstagios`, então Clear Body e
     Névoa continuam valendo, como na Intimidação. */
  for (const m of entrantes) {
    const h = hab(m);
    // Curious Medicine: zera os degraus de atributo do próprio lado (ele e os aliados), os bons e os ruins
    if (h.zeraEstagiosAoEntrar) {
      for (const a of [m, ...(ctx.aliadosDe?.(m) || [])]) for (const k in a.vol?.stages || {}) a.vol.stages[k] = 0;
      up(ctx); await ctx.say(`${ctx.nome(m)} mexe um remédio estranho: os atributos do seu lado voltaram ao normal.`, 'status');
    }
    // Screen Cleaner: limpa as telas dos DOIS lados (nos jogos não escolhe lado — quebra tudo)
    if (h.limpaTelas && ctx.campo?.lados) {
      let tinha = false;
      for (const lado of Object.values(ctx.campo.lados)) {
        if (lado.reflect || lado.luz || lado.veu) tinha = true;
        lado.reflect = 0; lado.luz = 0; lado.veu = 0;
      }
      if (tinha) await ctx.say(`${ctx.nome(m)} estilhaçou todas as telas do campo!`, 'status');
    }
    // Hospitality: serve algo ao aliado e cura uma fração do HP MÁXIMO dele
    if (h.curaAliadoAoEntrar) {
      const amigo = (ctx.aliadosDe?.(m) || []).find(a => a.hp > 0 && a.hp < a.stats.hp);
      if (amigo) {
        const cura = Math.max(1, Math.floor(amigo.stats.hp * h.curaAliadoAoEntrar));
        heal(amigo, cura); up(ctx);
        await ctx.say(`${ctx.nome(m)} serve algo quente: ${ctx.nome(amigo)} recuperou ${cura} HP.`, 'good');
      }
    }
    // Costar: entra copiando os degraus de atributo do aliado (inclusive os ruins)
    if (h.copiaEstagiosDoAliado) {
      const amigo = (ctx.aliadosDe?.(m) || []).find(a => a.hp > 0 && Object.values(a.vol?.stages || {}).some(v => v));
      if (amigo) {
        m.vol.stages = { ...amigo.vol.stages };
        up(ctx); await ctx.say(`${ctx.nome(m)} imitou ${ctx.nome(amigo)} e copiou os atributos dele!`, 'status');
      }
    }
    // Supersweet Syrup: o xarope baixa a evasão de quem está do outro lado. Uma vez por batalha, como nos jogos
    if (h.estagioInimigoAoEntrar && !m.vol.xaropeUsado) {
      const alvos = oponentesDe(m).filter(o => o.hp > 0);
      if (alvos.length) {
        m.vol.xaropeUsado = true;
        await ctx.say(`${ctx.nome(m)} espalha um cheiro adocicado pelo campo!`, 'status');
        const [stat, change] = h.estagioInimigoAoEntrar;
        for (const o of alvos) await mudarEstagios(o, [{ stat, change }], ctx, m);
      }
    }
  }
  for (const m of entrantes) await ajustarForma(m, ctx);   // Castform já entra na forma do tempo (o da rota ou o que acabou de ser ligado)
  // Anticipation: só avisa (não muda nada) se algum oponente tem golpe super efetivo, OHKO ou autodestrutivo contra quem entrou
  for (const m of entrantes) if (hab(m).anticipa) {
    const perigo = oponentesDe(m).some(o => (o.moves || []).some(g =>
      g.cls !== 'status' && (especial(g).ohko || especial(g).autoDesmaio || typeEff(g.type, tiposDefensivos(m)) >= 2)));
    if (perigo) await ctx.say(`${ctx.nome(m)} pressente um golpe perigoso por perto!`, 'status');
  }
}

// Reação a levar um golpe de dano (Steam Engine, Stamina, Weak Armor, Sand Spit…). Dispara UMA vez por golpe, mesmo
// que ele acerte várias vezes.
async function reagirAoGolpe(t, g, crit, ctx) {
  for (const r of hab(t).aoSerAtingido || []) {
    if (r.tipos && !r.tipos.includes(g.type)) continue;
    if (r.cls && r.cls !== g.cls) continue;
    if (r.soCritico && !crit) continue;
    await ctx.say(`A habilidade ${fmt(t.ability)} de ${ctx.nome(t)} reagiu!`, 'status');
    if (r.estagios) await mudarEstagios(t, r.estagios.map(([stat, change]) => ({ stat, change })), ctx, t);
    if (r.clima) await mudarClima(r.clima, ctx, t);
    if (r.terreno) await mudarTerreno(r.terreno, ctx, t);
  }
}
// Chefe de evento (boss.js): aplica e narra a lista de efeitos que as regras dele devolveram
async function aplicarEfeitosChefe(m, efeitos, ctx) {
  for (const e of efeitos || []) {
    if (e.pratos) (ctx.pratos || nada)(m, e.pratos);    // Arceus trocando de Prato: a animação vem ANTES do texto (ctx sem DOM não tem)
    if (e.dizer) await ctx.say(e.dizer, e.cls || 'status');
    if (e.cura) { heal(m, e.cura); up(ctx); }
    if (e.curaStatus) { m.status = null; m.sleep = 0; m.vol.conf = 0; delete m.vol.toxico; delete m.vol.semente; }
    if (e.estagios) await mudarEstagios(m, e.estagios.map(([stat, change]) => ({ stat, change })), ctx, m);
  }
  up(ctx);
}
// Magic Guard: nenhum dano que não venha direto de um golpe (veneno, queimadura, recuo, armadilha, espinhos…)
const indireto = m => !!hab(m).semDanoIndireto;

/* ---- golpe de ÁREA (🐺 grupo) ----
   O `target` da PokéAPI já diz quem o golpe pega; até agora o jogo ignorava e todo golpe batia em um só, porque
   só havia um inimigo. Com grupo em todos os modos, Earthquake e Rock Slide passam a pegar mesmo.
   A lista sai dos ganchos que os DOIS ctx já têm (`oponentesDe`/`aliadosDe`) — nenhuma API nova, e o multiplayer
   ganha de graça. `t` vai sempre na frente: é o alvo escolhido, e é dele que sai a narração principal.
   `random-opponent` (Outrage, Thrash) fica de fora de propósito: ele sorteia UM, que é o que já acontece. */
export function alvosDoGolpe(u, t, g, ctx) {
  const amigos = () => (ctx.aliadosDe?.(u) || []).filter(a => a && a.hp > 0 && !a.vol?.retirado);
  /* 🤝 Golpe de COMPANHEIRO (dados.ALVOS_ALIADOS): o efeito cai em quem RECEBE, não em quem usou. Vale pros dois
     lados — `ctx.aliadosDe` já responde pelo grupo selvagem e pelo treinador com vários em campo. Sem companheiro,
     o golpe que EXIGE um devolve lista vazia e `usarGolpe` narra a falha. */
  if (ALVOS_ALIADOS.has(g.target)) {
    const esp = especial(g);
    const lado = esp.soAliados ? amigos() : [u, ...amigos()];     // Coaching e Dragon Cheer não pegam quem usou
    return g.target === 'ally' ? amigos().slice(0, 1) : lado;     // `ally` é UM companheiro (Helping Hand, Aromatic Mist)
  }
  if (SELF_TARGETS.has(g.target) || u === t) return [t];
  /* Golpe de apoio de alvo escolhido (regras.golpeDeApoio): vai pro companheiro mais ferido, ou pra quem usou se
     estiver sozinho — nunca pro inimigo, que é o alvo que a tela escolheu. */
  if (golpeDeApoio(g)) return [amigos().sort((a, b) => a.hp / a.stats.hp - b.hp / b.stats.hp)[0] || u];
  /* O `target` vem da PokéAPI dentro do golpe, e pode simplesmente NÃO estar lá: golpe gravado num save de antes
     de 21/09/2026, registro velho no cache, mapa baixado pra jogar offline. Quando falta, a tabela fixa
     (`dados-golpe-flags.GOLPE_AREA`, gerada do repositório-fonte) responde — o alvo de Rock Slide não é dado
     vivo. Foi a terceira vez que essa dependência de rede virou "a área não pega em área" na mão de quem joga. */
  const alvo = g.target || GOLPE_AREA[g.name];
  const op = ALVOS_OPONENTES.has(alvo), todos = ALVOS_TODOS.has(alvo);
  if (!op && !todos) return [t];
  const lista = [t, ...(ctx.oponentesDe?.(u) || [])];
  // `all-other-pokemon`: pega o aliado junto (Earthquake, Surf). Telepathy é justamente quem não leva do colega.
  if (todos) lista.push(...(ctx.aliadosDe?.(u) || []).filter(a => !hab(a).imuneGolpeAliado));
  return [...new Set(lista)].filter(m => m && m.hp > 0 && !m.vol?.retirado);
}
// Damp: ninguém em campo (dos dois lados) consegue explodir enquanto ele estiver lá
const quemAbafa = (u, ctx) => [u, ...(ctx.aliadosDe?.(u) || []), ...(ctx.oponentesDe?.(u) || [])].find(m => hab(m).abafaExplosao);
// Pressure: o oponente gasta 1 PP a mais ao usar um golpe contra quem tem
const pressao = (u, t, g) => (t !== u && !SELF_TARGETS.has(g.target) && hab(t).pressao ? 1 : 0);
// Flower Veil: protege QUALQUER Pokémon de tipo Grama que esteja no mesmo lado de quem tem a habilidade (ele
// mesmo incluído) de queda de atributo e status vindos de outro Pokémon
const protegidoPorFlores = (m, ctx) => tiposDefensivos(m).includes('grass') &&
  (hab(m).protegeAliadoStatus || (ctx.aliadosDe?.(m) || []).some(a => hab(a).protegeAliadoStatus));

// Aplica status (inclui confusão). `avisar` = narra por que não pegou (golpe de status); secundário falha calado.
// Armadilhas pegam quem ENTRA em campo (o próximo Pokémon do treinador / da fila de lendários)
export async function aplicarArmadilhas(m, ctx) {
  const lado = ladoDoCampo(ctx, m); if (!lado || m.hp <= 0) return;
  const semDano = indireto(m);   // Magic Guard: pedras e espinhos são dano indireto e não pegam (o veneno das toxinas é status, esse pega)
  if (lado.pedras && !semDano) {
    const d = danoPedras(m); m.hp = Math.max(0, m.hp - d); up(ctx);
    await ctx.say(`Pedras afiadas acertam ${ctx.nome(m)} ao entrar! (−${d})`, 'hit');
  }
  if (m.hp > 0 && lado.espinhos && !semDano) {
    const d = danoEspinhos(m, lado.espinhos);
    if (d) { m.hp = Math.max(0, m.hp - d); up(ctx); await ctx.say(`${ctx.nome(m)} pisa nos espinhos! (−${d})`, 'hit'); }
  }
  // 🕸 Sticky Web: quem entra em campo tem a Velocidade baixada (quem voa não encosta na teia)
  if (m.hp > 0 && lado.teia && noChao(m)) {
    await ctx.say(`${ctx.nome(m)} se enrosca na teia!`, 'status');
    await mudarEstagios(m, [{ stat: 'speed', change: -1 }], ctx);
  }
  if (m.hp > 0 && lado.toxinas) {
    const r = efeitoToxinas(m, lado.toxinas);
    if (r === 'limpa') { lado.toxinas = 0; await ctx.say(`${ctx.nome(m)} absorveu os espinhos venenosos.`, 'muted'); }
    else if (r) {
      await aplicarStatus(m, 'poison', ctx);
      if (r === 'grave' && m.status === 'poison') { m.vol.toxico = 1; await ctx.say(`O veneno em ${ctx.nome(m)} é grave!`, 'status'); }
    }
  }
}

// `fonte` = quem causou (Salvaguarda só protege de status vindo do inimigo, como nos jogos)
export async function aplicarStatus(t, ail, ctx, avisar = false, fonte = null) {
  if (t.boss) { if (avisar) await ctx.say(`Não afeta ${ctx.nome(t)}... (chefe de evento: imune a status)`); return; }
  if (fonte && fonte !== t && temSalvaguarda(ladoDoCampo(ctx, t)) && !hab(fonte).atravessaTelas) {
    if (avisar) await ctx.say(`${NOME_LADO.salvaguarda} protege ${ctx.nome(t)}!`);
    return;
  }
  // Flower Veil: Grama no lado de quem tem a habilidade (ele mesmo ou um aliado) não pega status de fora
  if (fonte && fonte !== t && protegidoPorFlores(t, ctx)) {
    if (avisar) await ctx.say(`O Véu de Flores protege ${ctx.nome(t)}!`);
    return;
  }
  // Leaf Guard: no sol forte não pega status nenhum
  if (hab(t).semStatusClima && hab(t).semStatusClima === climaDe(ctx.campo)) {
    if (avisar) await ctx.say(`A habilidade ${fmt(t.ability)} de ${ctx.nome(t)} protege ${ctx.nome(t)} no ${CLIMAS[climaDe(ctx.campo)].nome.toLowerCase()}!`);
    return;
  }
  // terreno: Campo Elétrico não deixa dormir, Campo de Névoa não deixa pegar status nenhum (só quem está no chão)
  if (terrenoBloqueiaStatus(terrenoDe(ctx.campo), t, ail)) {
    if (avisar) await ctx.say(`${TERRENOS[terrenoDe(ctx.campo)].nome} protege ${ctx.nome(t)}!`);
    return;
  }
  // Sol forte não deixa ninguém congelar (fiel aos jogos)
  if (ail === 'freeze' && climaDe(ctx.campo) === 'sol') {
    if (avisar) await ctx.say(`O ${CLIMAS.sol.nome.toLowerCase()} impede o congelamento!`);
    return;
  }
  let imune = imuneAoStatusMon(t, ail);
  // Corrosion: ignora a imunidade de TIPO ao veneno (Venenoso/Aço) de quem é atingido — não a de habilidade (Immunity…)
  if (imune && ail === 'poison' && fonte && hab(fonte).podeEnvenenarQualquer) imune = !!hab(t).imuneStatus?.includes(ail);
  if (imune) {
    if (avisar) await ctx.say(hab(t).imuneStatus?.includes(ail) ? `A habilidade ${fmt(t.ability)} de ${ctx.nome(t)} impede isso!` : `Não afeta ${ctx.nome(t)}...`);
    return;
  }
  if (ail === 'confusion') {
    if (t.vol.conf > 0) { if (avisar) await ctx.say(`${ctx.nome(t)} já está confuso!`); return; }
    t.vol.conf = rand(2, 5); await ctx.say(`${ctx.nome(t)} ficou confuso!`, 'status');
    if (fonte && fonte !== t) await ctx.abrirBrecha?.(t, BRECHA_STATUS);   // ⚔ Saga: status abre meia Brecha
    return;
  }
  /* Paixão (Attract, Cute Charm): só pega quem é do gênero OPOSTO de quem causou — sem gênero de um dos dois
     (Magnemite, lendário, save de antes do gênero existir) o efeito falha. Vive no `vol`, como a confusão, então
     morre ao entrar/sair de campo e no fim da batalha: nunca vaza pro save. */
  if (ail === 'infatuation') {
    if (!generoOposto(t, fonte)) { if (avisar) await ctx.say(`Não afeta ${ctx.nome(t)}...`); return; }
    if (t.vol.paixao) { if (avisar) await ctx.say(`${ctx.nome(t)} já está apaixonado!`); return; }
    t.vol.paixao = true; await ctx.say(`${ctx.nome(t)} se apaixonou por ${ctx.nome(fonte)}!`, 'status'); return;
  }
  /* 🪢 APERTO (`trap`): Bind, Wrap, Fire Spin, Clamp, Whirlpool, Sand Tomb, Magma Storm, Infestation, Snap Trap e
     Thunder Cage. 4 a 5 turnos tirando 1/8 do HP máximo no fim de cada um, e sem poder fugir enquanto durar.
     São DEZ golpes com um `ailment` só na PokéAPI, então nenhum deles precisa de linha em `especiais.js`: vir
     pelo `ail` é o que faz a lista crescer sozinha se a API trouxer mais um. O nome do golpe vai junto só pra
     narrar ("Fire Spin continua queimando"). */
  if (ail === 'trap') {
    if (t.vol.aperto) { if (avisar) await ctx.say(`${ctx.nome(t)} já está preso!`); return; }
    t.vol.aperto = { turnos: rand(APERTO_MIN, APERTO_MAX), golpe: fonte?.vol?.ultimo || null };
    await ctx.say(`${ctx.nome(t)} ficou preso e não consegue escapar!`, 'status');
    if (fonte && fonte !== t) await ctx.abrirBrecha?.(t, BRECHA_STATUS);
    return;
  }
  /* 🌱 `leech-seed` como ailment de golpe de DANO (Sappy Seed, do Pokémon Unite/LGPE): planta a mesma semente do
     Leech Seed, que já tem motor próprio (`esp.semente` + o dreno em fimDeTurno). */
  if (ail === 'leech-seed') {
    if (tiposDefensivos(t).includes('grass') || t.vol.semente != null) { if (avisar) await ctx.say(`Não afeta ${ctx.nome(t)}...`); return; }
    t.vol.semente = fonte && ctx.refDe ? ctx.refDe(fonte) : true;
    await ctx.say(`${ctx.nome(t)} foi semeado!`, 'status'); return;
  }
  /* `unknown` é como a PokéAPI descreve o status do **Tri Attack**: 20% de queimar, congelar OU paralisar, um
     sorteado. Sem este caso o golpe dizia "nada aconteceu" na chance que deveria ser a interessante dele. */
  if (ail === 'unknown') {
    await aplicarStatus(t, ['burn', 'freeze', 'paralysis'][rand(0, 2)], ctx, avisar, fonte); return;
  }
  if (!AIL_MSG[ail]) { if (avisar) await ctx.say('Mas nada aconteceu... (este efeito será ajustado em atualizações futuras)', 'muted'); return; }
  if (t.status) { if (avisar) await ctx.say(`${ctx.nome(t)} já tem uma condição de status.`); return; }
  t.status = ail; delete t.vol.toxico; if (ail === 'sleep') t.sleep = rand(2, 4);
  up(ctx); await ctx.say(`${ctx.nome(t)} ${AIL_MSG[ail]}!`, 'status');
  /* ⚔ Saga: status abre MEIA Brecha — é o que faz o Encantador participar da abertura sem ter golpe super
     efetivo. Só status vindo de FORA (`fonte !== t`): Rest em si mesmo não deveria quebrar a própria guarda. */
  if (fonte && fonte !== t) await ctx.abrirBrecha?.(t, BRECHA_STATUS);
  // Synchronize: devolve queimadura/paralisia/veneno pra quem causou (não sono/congelamento). `fonte: null` na
  // chamada espelhada evita ping-pong se os dois tiverem a habilidade — só a aplicação ORIGINAL espelha.
  if (hab(t).sincroniza && fonte && fonte !== t && fonte.hp > 0 && !fonte.status && ['burn', 'paralysis', 'poison'].includes(ail)) {
    await ctx.say(`A Sincronia de ${ctx.nome(t)} passa a condição para ${ctx.nome(fonte)}!`, 'status');
    await aplicarStatus(fonte, ail, ctx, false, null);
  }
  // Poison Puppeteer (Pecharunt): quem ELE envenena fica confuso de tabela
  if (ail === 'poison' && fonte && fonte !== t && hab(fonte).venenoConfunde && t.vol.conf <= 0) {
    await ctx.say(`O veneno de ${ctx.nome(fonte)} embaralha a cabeça de ${ctx.nome(t)}!`, 'status');
    await aplicarStatus(t, 'confusion', ctx, false, fonte);
  }
  return true;
}

// Golpes de status com regra própria (especiais.js). true = tratou (o genérico não roda).
async function statusEspecial(u, t, g, esp, ctx, primeiro, dest = u) {
  const U = ctx.nome(u), T = ctx.nome(t), D = ctx.nome(dest);
  /* 🤝 Golpes de companheiro. Quem RECEBE é `dest` (golpe.executar): em Heal Bell & cia. o motor roda uma vez por
     Pokémon do lado, então cada linha aqui trata UM só. Sem companheiro em campo, os que exigem um nem chegam
     aqui — `alvosDoGolpe` devolve lista vazia e `usarGolpe` narra a falha. */
  // Helping Hand: o próximo golpe do companheiro neste turno sai mais forte (`vol.ajuda`, lido no dano)
  if (esp.ajudaAliado) { dest.vol.ajuda = esp.ajudaAliado; await ctx.say(`${U} está ajudando ${D}!`, 'good'); return true; }
  // Follow Me / Rage Powder: o outro lado passa a mirar em quem usou até o fim da rodada (batalha.turn lê `vol.chamariz`)
  if (esp.chamariz) { u.vol.chamariz = true; await ctx.say(`${U} chamou a atenção do inimigo!`, 'good'); return true; }
  // Gear Up / Magnetic Flux: só mexem com quem tem Plus ou Minus (os atributos vêm do `meta`, então a trava é aqui)
  if (esp.soPlusMinus && hab(dest).aliadoBoost !== 'plusminus') { await ctx.say(`${D} não é afetado. (só vale pra Plus e Minus)`, 'muted'); return true; }
  // Heal Bell, Aromatherapy, Jungle Healing, Lunar Blessing, Purify, Take Heart: limpa o status de quem recebe
  if (esp.curaStatus) {
    if (esp.cura && dest.hp < dest.stats.hp) { heal(dest, Math.floor(dest.stats.hp * esp.cura)); up(ctx); await ctx.say(`${D} recuperou HP.`, 'good'); }
    if (dest.status || dest.sleep || dest.vol.conf > 0) {
      dest.status = null; dest.sleep = 0; dest.vol.conf = 0; delete dest.vol.toxico; up(ctx);
      await ctx.say(`${D} ficou curado!`, 'good');
    } else if (!esp.cura) await ctx.say(`${D} não tinha nada pra curar.`, 'muted');
    if (esp.sobeEstagios) await mudarEstagios(dest, esp.sobeEstagios.map(([stat, change]) => ({ stat, change })), ctx, u);
    return true;
  }
  // Acupressure: +2 num atributo sorteado de quem recebe
  if (esp.statAleatorio) {
    const stat = ['attack', 'defense', 'special-attack', 'special-defense', 'speed'][rand(0, 4)];
    await mudarEstagios(dest, [{ stat, change: esp.statAleatorio }], ctx, u); return true;
  }
  // Hold Hands: nos jogos ele não faz NADA mesmo — dizer "será ajustado" seria prometer efeito que não existe
  if (esp.semEfeitoReal) { await ctx.say(`${U} e ${D} deram as mãos. Que fofo — e nada mais aconteceu.`, 'muted'); return true; }
  // Captivate: só funciona em quem é do gênero OPOSTO. Os estágios dele são comuns (`g.stats`), então sem esta
  // trava o golpe baixava a At.Esp. de qualquer um — inclusive de quem não tem gênero.
  if (esp.generoOposto && !generoOposto(t, u)) { await ctx.say(`Não afeta ${T}...`); return true; }
  if (esp.clima) { if (!await mudarClima(esp.clima, ctx)) await ctx.say('Mas falhou!'); return true; }
  if (esp.terreno) { if (!await mudarTerreno(esp.terreno, ctx)) await ctx.say('Mas falhou!'); return true; }
  // telas e proteções: valem no lado de quem usou
  if (esp.lado) {
    const meu = ladoDoCampo(ctx, u);
    if (!meu) { await ctx.say('Mas falhou!'); return true; }
    if (esp.soNoGelo && !['granizo', 'neve'].includes(climaDoCtx(ctx))) { await ctx.say('Mas falhou! (só funciona no granizo ou na neve)'); return true; }
    if (meu[esp.lado] > 0) { await ctx.say('Mas falhou! (já está no ar)'); return true; }
    // Mat Block só vale na ESTREIA de quem usa, como nos jogos
    if (esp.soPrimeiroTurno && u.vol.golpesDados > 1) { await ctx.say('Mas falhou! (só no primeiro turno em campo)'); return true; }
    // `umTurno` = as guardas de uma rodada (Wide/Quick Guard, Crafty Shield, Mat Block): nascem com 1 e
    // `regras.passarLado` as zera no fim da própria rodada
    meu[esp.lado] = esp.umTurno ? 1 : esp.lado === 'vento' ? VENTO_TURNOS : TELA_TURNOS;
    await ctx.say(`${NOME_LADO[esp.lado]} protege o lado de ${U} por ${meu[esp.lado]} turnos!`, 'good');
    return true;
  }
  // armadilhas: ficam esperando no lado do inimigo
  if (esp.armadilha) {
    const deles = ladoDoCampo(ctx, t);
    if (!deles) { await ctx.say('Mas falhou!'); return true; }
    if (esp.armadilha === 'pedras') {
      if (deles.pedras) { await ctx.say('Mas falhou! (as pedras já estão lá)'); return true; }
      deles.pedras = true;
    } else {
      const max = esp.armadilha === 'espinhos' ? MAX_ESPINHOS : MAX_TOXINAS;
      if (deles[esp.armadilha] >= max) { await ctx.say('Mas falhou! (não cabe mais)'); return true; }
      deles[esp.armadilha]++;
    }
    await ctx.say(`${esp.armadilha === 'pedras' ? 'Pedras afiadas flutuam' : esp.armadilha === 'espinhos' ? 'Espinhos se espalham' : 'Espinhos venenosos se espalham'} em volta de ${T}!`, 'status');
    if (!ctx.trocaDePokemon) await ctx.say('(só machuca quem entrar em campo depois — do seu lado ninguém troca)', 'muted');
    return true;
  }
  /* Soak e cia.: o tipo novo vai pro `vol` (regras.tiposDe), NUNCA pro `m.data` — aquele objeto vem do cache e é
     compartilhado por toda a espécie. Falha quando não mudaria nada, como nos jogos: Soak num alvo que já é Água
     pura, ou acrescentar um tipo que o alvo já tem. Terastalizado não muda de tipo (o Tera manda na defesa). */
  if (esp.viraTipo || esp.ganhaTipo) {
    if (t.tera) { await ctx.say(`Mas falhou! (${T} está terastalizado)`); return true; }
    const agora = tiposDe(t);
    const novos = esp.viraTipo ? [...esp.viraTipo] : [...agora, esp.ganhaTipo];
    if (agora.join() === novos.join() || (esp.ganhaTipo && agora.includes(esp.ganhaTipo))) { await ctx.say('Mas falhou!'); return true; }
    t.vol.tipos = novos;
    await ctx.say(`${T} agora é do tipo ${novos.map(x => TYPE_PT[x] || x).join('/')}!`, 'status');
    return true;
  }
  if (esp.protege) {
    // King's Shield devolve o Aegislash pra Forma Escudo — e isso acontece mesmo se a proteção falhar
    if (esp.voltaPostura) await trocarPostura(u, false, ctx);
    // repetir seguido: 1/3, 1/9… de chance
    const n = u.vol.protSeguidas || 0;
    if (Math.random() < 1 / 3 ** n) {
      u.vol.protegido = true; u.vol.protSeguidas = n + 1;
      // a barreira lembra o que faz com quem encostar nela (King's Shield, Spiky Shield, Obstruct…)
      if (esp.puneContato) u.vol.punicao = esp.puneContato; else delete u.vol.punicao;
      await ctx.say(`${U} se protegeu!`, 'good');
    } else { u.vol.protSeguidas = 0; delete u.vol.punicao; await ctx.say('Mas falhou!'); }
    return true;
  }
  if (esp.aguentaTurno) {
    const n = u.vol.protSeguidas || 0;
    if (Math.random() < 1 / 3 ** n) { u.vol.aguenta = true; u.vol.protSeguidas = n + 1; await ctx.say(`${U} se preparou para aguentar!`, 'good'); }
    else { u.vol.protSeguidas = 0; await ctx.say('Mas falhou!'); }
    return true;
  }
  if (esp.foco) {
    if (dest.vol.foco) { await ctx.say('Mas falhou!'); return true; }
    // Dragon Cheer vale o dobro no companheiro do tipo Dragão (`focoDragao`); Focus Energy é sempre em quem usou
    dest.vol.foco = esp.focoDragao && tiposDefensivos(dest).includes('dragon') ? esp.focoDragao : esp.foco;
    await ctx.say(`${D} está concentrado! (chance de crítico maior)`, 'good'); return true;
  }
  if (esp.descanso) {
    if (u.hp >= u.stats.hp) { await ctx.say(`O HP de ${U} já está cheio!`); return true; }
    if (imuneAoStatusMon(u, 'sleep')) { await ctx.say('Mas falhou!'); return true; }
    u.hp = u.stats.hp; u.status = 'sleep'; u.sleep = 3; delete u.vol.toxico; up(ctx);
    await ctx.say(`${U} dormiu e recuperou todo o HP!`, 'good'); return true;
  }
  if (esp.toxico) {
    const antes = t.status;
    if (await aplicarStatus(t, 'poison', ctx, true) && !antes) { t.vol.toxico = 1; await ctx.say(`O veneno em ${T} é grave!`, 'status'); }
    return true;
  }
  // Taunt / Encore / Disable / Torment (regras.motivoBloqueio decide o que fica proibido). Prazo: se o alvo ainda vai agir
  // neste turno (`primeiro`) o efeito já o pega agora; se ele já agiu, ganha +1 pra compensar o turno que passou.
  if (esp.trava) {
    const falha = falhaDaTrava(t, esp.trava);
    if (falha) { await ctx.say(`Mas falhou! (${falha})`); return true; }
    const n = (TURNOS_TRAVA[esp.trava] || 0) + (primeiro ? 0 : 1), ult = t.vol.ultimo;
    if (esp.trava === 'provocar') { t.vol.provocado = n; await ctx.say(`${T} foi provocado! Só poderá usar golpes de dano por ${n} turnos.`, 'status'); }
    else if (esp.trava === 'encore') { t.vol.encore = { golpe: ult, turnos: n }; await ctx.say(`${T} sofreu Encore! Vai repetir ${fmt(ult)} por ${n} turnos.`, 'status'); }
    else if (esp.trava === 'disable') { t.vol.desativado = { golpe: ult, turnos: n }; await ctx.say(`${fmt(ult)} de ${T} foi desativado por ${n} turnos!`, 'status'); }
    else { t.vol.tormento = true; await ctx.say(`${T} foi atormentado! Não poderá repetir o mesmo golpe.`, 'status'); }
    // Erva Mental: a trava é posta e desfeita no mesmo instante (é o que o item faz nos jogos)
    if (seg(t).livraTrava) {
      delete t.vol.provocado; delete t.vol.encore; delete t.vol.desativado; delete t.vol.tormento;
      await ctx.say(`A ${ITEMS[t.item]?.name || 'Erva Mental'} de ${T} o livrou na hora!`, 'good');
      t.item = null;
    }
    return true;
  }
  // Roar / Whirlwind: o alvo sai de campo (batalha.forcarSaida decide o que isso quer dizer)
  if (esp.forcaSaida) {
    const r = await sairDeCampo(t, ctx, 'forcada');
    if (r === undefined) await ctx.say('Mas falhou! (este golpe não funciona em luta de sala)');
    else if (!r) await ctx.say('Mas falhou!');
    return true;
  }
  // Mean Look / Block / Spider Web: o alvo não consegue mais fugir (Fantasma é imune, como nos jogos). Vale a luta toda.
  if (esp.prende) {
    if (tiposDefensivos(t).includes('ghost')) { await ctx.say(`Não afeta ${T}...`); return true; }
    if (t.vol.preso) { await ctx.say('Mas falhou! (já está preso)'); return true; }
    t.vol.preso = true; await ctx.say(`${T} não consegue mais fugir!`, 'status'); return true;
  }
  // Baton Pass: como você nunca troca de Pokémon, os estágios vão para um aliado em campo (quem usa volta ao zero)
  if (esp.passaBonus) {
    const aliado = (ctx.aliadosDe?.(u) || []).find(a => a.hp > 0 && !a.vol?.retirado);
    if (!aliado) { await ctx.say('Mas falhou! (não há aliado em campo pra receber)'); return true; }
    aliado.vol.stages = { ...u.vol.stages }; if (u.vol.foco) aliado.vol.foco = u.vol.foco;
    for (const k of Object.keys(u.vol.stages)) u.vol.stages[k] = 0;
    delete u.vol.foco; up(ctx);
    await ctx.say(`${U} passou os seus bônus para ${ctx.nome(aliado)}!`, 'good'); return true;
  }
  if (esp.semente) {
    if (tiposDefensivos(t).includes('grass')) { await ctx.say(`Não afeta ${T}...`); return true; }
    if (t.vol.semente != null) { await ctx.say(`${T} já está semeado!`); return true; }
    t.vol.semente = ctx.refDe ? ctx.refDe(u) : true; await ctx.say(`${T} foi semeado!`, 'status'); return true;
  }
  /* 🪐 Gravidade: mexe em todo mundo em campo, então precisa da lista dos dois lados. `ctx.aliadosDe`/
     `ctx.oponentesDe` são os mesmos ganchos do Friend Guard e do Bad Dreams — existem nos dois ctx. */
  if (esp.gravidade) {
    await mudarGravidade(ctx, [u, ...(ctx.aliadosDe?.(u) || []), ...(ctx.oponentesDe?.(u) || [])], u);
    return true;
  }
  // 🧲 Magnet Rise (em si) e Telekinesis (`noAlvo`, no inimigo): sai do chão por alguns turnos
  if (esp.voa) {
    const quem = esp.noAlvo ? t : u, Q = ctx.nome(quem);
    if (ctx.campo?.gravidade > 0) { await ctx.say('Mas falhou! (a gravidade não deixa ninguém sair do chão)'); return true; }
    if (quem.vol.voando > 0) { await ctx.say('Mas falhou! (já está flutuando)'); return true; }
    if (quem.vol.noSolo) { await ctx.say(`Mas falhou! (${Q} está preso ao chão)`); return true; }
    quem.vol.voando = esp.voa;
    await ctx.say(`${Q} flutua no ar por ${esp.voa} turnos! (golpe Terrestre não alcança)`, 'good'); return true;
  }
  // 💀 Canção Final: quem OUVIU (os dois lados, como nos jogos) desmaia em 3 turnos — a contagem é em fimDeTurno
  if (esp.cancaoFinal) {
    const todos = [u, ...(ctx.aliadosDe?.(u) || []), ...(ctx.oponentesDe?.(u) || [])].filter(m => m.hp > 0 && m.vol && !m.vol.cancaoFinal);
    if (!todos.length) { await ctx.say('Mas falhou! (todos já ouviram a canção)'); return true; }
    for (const m of todos) m.vol.cancaoFinal = 3;
    await ctx.say(`${U} entoa uma canção sinistra — quem ouviu desmaia em 3 turnos!`, 'status'); return true;
  }
  // 🥱 Bocejo: dorme no fim do turno SEGUINTE (2 = este turno e o próximo). Falha em quem não pode dormir
  if (esp.bocejo) {
    if (t.status || t.vol.bocejo) { await ctx.say('Mas falhou!'); return true; }
    if (imuneAoStatusMon(t, 'sleep')) { await ctx.say(`Não afeta ${T}...`); return true; }
    t.vol.bocejo = 2; await ctx.say(`${T} fica com sono... vai dormir no próximo turno!`, 'status'); return true;
  }
  // 😱 Pesadelo: só pega quem está DORMINDO (e acaba sozinho quando ele acorda)
  if (esp.pesadeloGolpe) {
    if (t.status !== 'sleep') { await ctx.say(`Mas falhou! (só funciona em quem está dormindo)`); return true; }
    if (t.vol.pesadelo) { await ctx.say(`${T} já está tendo pesadelos!`); return true; }
    t.vol.pesadelo = true; await ctx.say(`${T} começa a ter pesadelos!`, 'status'); return true;
  }
  // 🌱 Raiz: cura 1/16 por turno e não sai mais de campo (é a mesma trava de fuga do Mean Look)
  if (esp.raiz) {
    if (u.vol.raiz) { await ctx.say('Mas falhou! (já está enraizado)'); return true; }
    u.vol.raiz = true; u.vol.preso = true;
    await ctx.say(`${U} criou raízes! Vai se curando — e não consegue mais sair.`, 'good'); return true;
  }
  if (esp.anel) {
    if (dest.vol.anel) { await ctx.say('Mas falhou! (o véu de água já está aí)'); return true; }
    dest.vol.anel = true; await ctx.say(`${D} se envolveu num véu de água! Vai se curando a cada turno.`, 'good'); return true;
  }
  // 🌟 Desejo: metade do HP máximo volta no fim do turno SEGUINTE. Guarda a cura JÁ CALCULADA, como nos jogos
  if (esp.desejo) {
    if (u.vol.desejo) { await ctx.say('Mas falhou! (já há um desejo no ar)'); return true; }
    u.vol.desejo = { turnos: 2, cura: Math.max(1, Math.floor(u.stats.hp / 2)) };
    await ctx.say(`${U} faz um desejo — a cura chega no próximo turno.`, 'good'); return true;
  }
  // 📊 Haze: zera os estágios de TODO mundo em campo, dos dois lados (inclusive os seus)
  if (esp.limpaEstagios) {
    for (const m of [u, ...(ctx.aliadosDe?.(u) || []), ...(ctx.oponentesDe?.(u) || [])]) {
      if (!m.vol?.stages) continue;
      for (const k of Object.keys(m.vol.stages)) m.vol.stages[k] = 0;
    }
    up(ctx); await ctx.say('Uma névoa apaga todas as mudanças de atributo!', 'status'); return true;
  }
  if (esp.copiaEstagios) {
    u.vol.stages = { ...t.vol.stages }; up(ctx);
    await ctx.say(`${U} copiou as mudanças de atributo de ${T}!`, 'good'); return true;
  }
  if (esp.inverteEstagios) {
    if (!Object.values(t.vol.stages).some(v => v !== 0)) { await ctx.say('Mas falhou! (não há nada pra inverter)'); return true; }
    for (const k of Object.keys(t.vol.stages)) t.vol.stages[k] = -t.vol.stages[k];
    up(ctx); await ctx.say(`As mudanças de atributo de ${T} foram invertidas!`, 'status'); return true;
  }
  // 🥁 Belly Drum: paga metade do HP MÁXIMO e põe o Ataque no teto (+6), não "+6 estágios"
  if (esp.tambor) {
    const custo = Math.floor(u.stats.hp / 2);
    if (u.hp <= custo || u.vol.stages.attack >= 6) { await ctx.say('Mas falhou!'); return true; }
    u.hp -= custo; u.vol.stages.attack = 6; up(ctx);
    await ctx.say(`${U} bate no próprio peito (−${custo}) e o Ataque vai ao máximo!`, 'good'); return true;
  }
  if (esp.divideHp) {
    const media = Math.floor((u.hp + t.hp) / 2);
    u.hp = Math.min(u.stats.hp, media); t.hp = Math.min(t.stats.hp, media); up(ctx);
    await ctx.say(`O sofrimento foi dividido: os dois ficam com ${media} HP.`, 'status'); return true;
  }
  /* Trocas e médias de atributo. `trocaProprios`/`trocaStat`/`mediaStat` mexem no `stats` calculado (e por isso
     NÃO sobrevivem a um `recalc`, o que é certo: subir de nível refaz os atributos do zero); `trocaEstagios` mexe
     só nos estágios, que é onde o Heart Swap & cia. valem. */
  if (esp.trocaProprios) {
    const [a, b] = esp.trocaProprios;
    [u.stats[a], u.stats[b]] = [u.stats[b], u.stats[a]]; up(ctx);
    await ctx.say(`${U} trocou ${STAT_PT[a]} por ${STAT_PT[b]}!`, 'status'); return true;
  }
  if (esp.trocaEstagios) {
    const chaves = esp.trocaEstagios === 'todos' ? Object.keys(u.vol.stages) : esp.trocaEstagios;
    for (const k of chaves) [u.vol.stages[k], dest.vol.stages[k]] = [dest.vol.stages[k] || 0, u.vol.stages[k] || 0];
    up(ctx); await ctx.say(`${U} trocou mudanças de atributo com ${D}!`, 'status'); return true;
  }
  if (esp.trocaStat) {
    [u.stats[esp.trocaStat], dest.stats[esp.trocaStat]] = [dest.stats[esp.trocaStat], u.stats[esp.trocaStat]];
    up(ctx); await ctx.say(`${U} e ${D} trocaram de ${STAT_PT[esp.trocaStat]}!`, 'status'); return true;
  }
  if (esp.mediaStat) {
    for (const k of esp.mediaStat) {
      const media = Math.floor((u.stats[k] + dest.stats[k]) / 2);
      u.stats[k] = media; dest.stats[k] = media;
    }
    up(ctx); await ctx.say(`${U} e ${D} dividiram ${esp.mediaStat.map(k => STAT_PT[k]).join(' e ')}!`, 'status'); return true;
  }

  /* 🪆 Substituto: paga a fração do HP MÁXIMO e põe um boneco com esse tanto de vida. Falha se não houver HP de
     sobra (nos jogos é preciso SOBRAR algo: pagar o HP inteiro não vale) ou se já houver um de pé. */
  if (esp.substituto) {
    const custo = Math.max(1, Math.floor(u.stats.hp * esp.substituto));
    if (u.vol.substituto > 0) { await ctx.say(`${U} já tem um substituto!`); return true; }
    if (u.hp <= custo) { await ctx.say('Mas falhou! (não há HP de sobra)'); return true; }
    u.hp -= custo; u.vol.substituto = custo; up(ctx);
    await ctx.say(`${U} gastou ${custo} de HP e pôs um <b>substituto</b> no seu lugar!`, 'good');
    return true;   // Shed Tail também tem `revezamento`, que `usarGolpe` resolve depois deste retorno
  }

  /* 🧠 Trocar habilidade. Todas passam por `trocarHabilidade`, que guarda a antiga em `abilityAntes` (o caminho do
     Trace, desfeito no `endBattle`) e recusa as que são MECÂNICA do motor (`ABILIDADE_TRAVADA`). */
  if (esp.copiaHabilidade || esp.trocaHabilidade || esp.poeHabilidade) {
    const nova = esp.poeHabilidade || (esp.copiaHabilidade === 'proAlvo' ? u.ability : t.ability);
    // em QUEM a habilidade nova entra: Simple Beam/Worry Seed e Entrainment mexem no ALVO; Doodle no seu lado
    // inteiro; Role Play só em quem usou
    const quem = esp.poeHabilidade || esp.copiaHabilidade === 'proAlvo' ? [t]
      : esp.copiaHabilidade === 'doAlvoProLado' ? [u, ...(ctx.aliadosDe?.(u) || [])] : [u];
    if (!nova || ABILIDADE_TRAVADA(nova)) { await ctx.say('Mas falhou!'); return true; }
    if (esp.trocaHabilidade) {
      if (ABILIDADE_TRAVADA(u.ability) || u.ability === t.ability) { await ctx.say('Mas falhou!'); return true; }
      const minha = u.ability;
      trocarHabilidade(u, t.ability); trocarHabilidade(t, minha);
      await ctx.say(`${U} e ${T} trocaram de habilidade! Agora ${U} tem ${fmt(u.ability)} e ${T} tem ${fmt(t.ability)}.`, 'status');
      return true;
    }
    const mudaram = quem.filter(m => m?.hp > 0 && m.ability !== nova && !ABILIDADE_TRAVADA(m.ability));
    if (!mudaram.length) { await ctx.say('Mas falhou!'); return true; }
    for (const m of mudaram) trocarHabilidade(m, nova);
    await ctx.say(`${mudaram.map(m => ctx.nome(m)).join(', ')} ${mudaram.length > 1 ? 'passaram' : 'passou'} a ter <b>${fmt(nova)}</b>!`, 'status');
    return true;
  }
  // Gastro Acid: a habilidade do alvo é anulada até ele sair de campo (habilidades.hab lê `vol.semHabilidade`)
  if (esp.anulaHabilidade) {
    if (t.vol.semHabilidade) { await ctx.say(`A habilidade de ${T} já está anulada!`); return true; }
    if (ABILIDADE_TRAVADA(t.ability)) { await ctx.say('Mas falhou!'); return true; }
    t.vol.semHabilidade = true; up(ctx);
    await ctx.say(`${fmt(t.ability)} de ${T} foi anulada!`, 'status'); return true;
  }

  /* 🎭 Transform: quem usa vira uma CÓPIA do alvo — tipos, atributos (menos o HP), habilidade, sprite e os 4
     golpes com 5 PP cada. Nada disso mexe em `m.data` direto (aquele objeto vem do cache e é compartilhado por
     toda a espécie): os tipos e o sprite vão por `formaBase`, a mesma caixa que o Castform usa e que o
     `desfazerForma` do `endBattle` já sabe desmontar; os atributos e o moveset vão por `statsAntes`/`movesAntes`
     (`desfazerCopia`). O HP fica o SEU, como nos jogos. */
  if (esp.transforma) {
    if (u.vol.transformado || t.vol.transformado) { await ctx.say('Mas falhou!'); return true; }
    u.vol.transformado = true;
    u.formaBase ||= { types: [...u.data.types], sprite: u.data.sprite, back: u.data.back, art: u.data.art };
    u.data = { ...u.data, types: [...t.data.types], sprite: t.data.sprite, back: t.data.back, art: t.data.art };
    u.statsAntes ||= { ...u.stats };
    u.stats = { ...t.stats, hp: u.stats.hp };
    u.movesAntes ||= u.moves;
    u.moves = (t.moves || []).map(m => ({ ...m, pp: 5, ppLeft: 5 }));
    u.vol.stages = { ...t.vol.stages };
    if (t.ability && !ABILIDADE_TRAVADA(t.ability)) trocarHabilidade(u, t.ability);
    up(ctx);
    await ctx.say(`${U} se transformou em <b>${fmt(t.name)}</b>!`, 'status');
    return true;
  }

  /* 🎭 Instruct: o ALVO repete, agora, o último golpe dele. Não é "copiar": quem age de novo é ele, contra quem
     usou o Instruct. Falha se ele ainda não agiu, se o golpe não é copiável ou se está sem PP. */
  if (esp.repete) {
    const g2 = golpeDeNome(t.vol.ultimo, [t]);
    if (!g2) { await ctx.say(`Mas falhou! (${T} não tem um golpe pra repetir)`); return true; }
    if (g2.ppLeft !== undefined && g2.ppLeft <= 0) { await ctx.say(`Mas falhou! (${T} está sem PP nesse golpe)`); return true; }
    await ctx.say(`${U} manda ${T} atacar de novo!`, 'status');
    await usarCopia(t, u, g2, false, ctx);
    return true;
  }

  /* 🎭 Os golpes de CÓPIA. `de` diz de onde o golpe vem; o resto é igual pra todos, inclusive a falha — quando
     não há nada pra copiar, o golpe diz POR QUÊ em vez de cair no "nada aconteceu". */
  if (esp.copia) {
    const g2 = {
      ultimoDoAlvo: () => golpeDeNome(t.vol.ultimo, [t]),
      ultimoDaLuta: () => golpeDeNome(ctx.campo?.ultimo, todosEmCampo(u, ctx)),
      meusOutros: () => { const l = copiaveis(u).filter(x => x.name !== g.name && (x.ppLeft ?? 1) > 0); return l[rand(0, l.length - 1)] || null; },
      dosAliados: () => { const l = (ctx.aliadosDe?.(u) || []).flatMap(copiaveis); return l[rand(0, l.length - 1)] || null; },
      doCampo: () => { const l = todosEmCampo(u, ctx).flatMap(copiaveis); return l[rand(0, l.length - 1)] || null; },
      escolhidoDoAlvo: () => { const e = t.vol.golpeEscolhido; return primeiro && e && e.cls !== 'status' && podeCopiar(e.name) ? e : null; },
      doTerreno: () => GOLPE_DO_TERRENO[terrenoDoCtx(ctx) ?? 'null']
    }[esp.copia]?.();
    if (!g2) {
      const porque = { ultimoDoAlvo: `${T} ainda não usou nada que dê pra copiar`, ultimoDaLuta: 'ninguém usou nada que dê pra copiar ainda',
        meusOutros: 'não há outro golpe com PP', dosAliados: 'não há companheiro em campo', doCampo: 'não há golpe pra sortear',
        escolhidoDoAlvo: `${T} não vai atacar depois de você neste turno` }[esp.copia];
      await ctx.say(`Mas falhou!${porque ? ` (${porque})` : ''}`); return true;
    }
    if (esp.exigeFlag && !temFlag(g2, esp.exigeFlag)) { await ctx.say(`Mas falhou! (${fmt(g2.name)} não dá pra espelhar)`); return true; }
    /* Mimic e Sketch não USAM o golpe: eles o guardam no próprio slot. Mimic vale a luta (`movesAntes`, desfeito
       no `endBattle`); Sketch é PERMANENTE — é a razão de existir do Smeargle, e por isso grava no save mesmo. */
    if (esp.guardaNoSlot) {
      const i = u.moves.indexOf(g);
      if (i < 0) { await ctx.say('Mas falhou!'); return true; }
      if (esp.guardaNoSlot !== 'permanente') u.movesAntes ||= [...u.moves];
      u.moves = u.moves.map((m, j) => j === i ? { ...g2, pp: esp.guardaNoSlot === 'permanente' ? g2.pp : 5, ppLeft: esp.guardaNoSlot === 'permanente' ? g2.pp : 5 } : m);
      up(ctx);
      await ctx.say(`${U} aprendeu <b>${fmt(g2.name)}</b>${esp.guardaNoSlot === 'permanente' ? ' para sempre!' : ' até o fim da batalha!'}`, 'good');
      return true;
    }
    await usarCopia(u, t, g2, primeiro, ctx, esp.mult || 1);
    return true;
  }

  /* ---- 🎒 ITEM do outro. Sticky Hold (`protegeItem`) barra todos, como no Knock Off que já existia. ---- */
  if (esp.trocaItem || esp.daItem) {
    if (hab(t).protegeItem) { await ctx.say(`${T} não solta o item de jeito nenhum. (${fmt(t.ability)})`); return true; }
    if (esp.daItem) {
      if (!u.item) { await ctx.say('Mas falhou! (você não tem item pra dar)'); return true; }
      if (t.item) { await ctx.say(`Mas falhou! (${T} já segura algo)`); return true; }
      const nome = ITEMS[u.item]?.name || 'o item';
      trocaItemDe(t, u.item); trocaItemDe(u, null); up(ctx);
      await ctx.say(`${U} entregou <b>${nome}</b> para ${T}!`, 'status'); return true;
    }
    if (!u.item && !t.item) { await ctx.say('Mas falhou! (ninguém tem item pra trocar)'); return true; }
    const meu = u.item, dele = t.item;
    trocaItemDe(u, dele); trocaItemDe(t, meu); up(ctx);
    await ctx.say(`${U} trocou de item com ${T}! ${U} ficou com ${dele ? `<b>${ITEMS[dele]?.name || dele}</b>` : 'nada'} e ${T} com ${meu ? `<b>${ITEMS[meu]?.name || meu}</b>` : 'nada'}.`, 'status');
    return true;
  }
  // Recycle: devolve o último item que VOCÊ gastou nesta luta (`vol.itemGasto`, escrito por `gastarItem`)
  if (esp.reciclar) {
    if (u.item || !u.vol.itemGasto) { await ctx.say('Mas falhou! (não há item gasto pra reciclar)'); return true; }
    const id = u.vol.itemGasto; delete u.vol.itemGasto;
    trocaItemDe(u, id); up(ctx);
    await ctx.say(`${U} recuperou a <b>${ITEMS[id]?.name || id}</b>!`, 'good'); return true;
  }
  // Teatime: TODO mundo em campo come a fruta que estiver segurando, queira ou não
  if (esp.horaDoCha) {
    const comeram = [];
    for (const m of todosEmCampo(u, ctx)) {
      if (!m.item?.endsWith('-berry')) continue;
      comeram.push(ctx.nome(m)); await comerFruta(m, ctx, false, true);
    }
    await ctx.say(comeram.length ? `☕ Hora do chá! ${comeram.join(', ')} ${comeram.length > 1 ? 'comeram' : 'comeu'} a fruta.` : 'Mas ninguém tinha fruta pra comer.', comeram.length ? 'good' : 'muted');
    return true;
  }

  /* ---- 🏠 as salas e os "sports": estado do CAMPO, 5 turnos, valendo pros dois lados ---- */
  if (esp.sala) {
    const nomes = { salaInvertida: 'Sala Estranha', salaMaravilhas: 'Sala das Maravilhas', salaMagica: 'Sala Mágica' };
    if (!ctx.campo) { await ctx.say('Mas falhou!'); return true; }
    const ligando = !salaAtiva(ctx.campo, esp.sala);
    ctx.campo[esp.sala] = ligando ? SALA_TURNOS : 0;      // usar de novo DESLIGA, como nos jogos
    /* As duas que agem em cada Pokémon marcam o `vol` de quem está em campo (o desenho da Gravidade): o Wonder
       Room troca os atributos dentro de `calcDamage`, e a Sala Mágica desliga o item dentro de `seg`. */
    if (esp.sala !== 'salaInvertida') {
      const marca = esp.sala === 'salaMaravilhas' ? 'salaMaravilhas' : 'semItem';
      for (const m of todosEmCampo(u, ctx)) { if (ligando) m.vol[marca] = esp.sala === 'salaMaravilhas' ? true : SALA_TURNOS; else delete m.vol[marca]; }
    }
    await ctx.say(`🏠 ${nomes[esp.sala]} ${ligando ? 'se abriu!' : 'se fechou.'}`, ligando ? 'status' : 'muted');
    return true;
  }
  if (esp.sport) {
    if (!ctx.campo) { await ctx.say('Mas falhou!'); return true; }
    if (ctx.campo.sports?.includes(esp.sport)) { await ctx.say('Mas falhou! (já está valendo)'); return true; }
    (ctx.campo.sports ||= []).push(esp.sport);
    await ctx.say(`Golpes de ${TYPE_PT[esp.sport] || esp.sport} ficam mais fracos para todos!`, 'status'); return true;
  }
  if (esp.ionizado) { if (ctx.campo) ctx.campo.ionizado = true; await ctx.say('O ar se enche de carga: golpes Normais viram Elétricos nesta rodada!', 'status'); return true; }
  if (esp.travaFuga) { if (ctx.campo) ctx.campo.travaFuga = 2; await ctx.say('Um campo de força impede qualquer fuga!', 'status'); return true; }
  if (esp.trocaLados) {
    const lados = ctx.campo?.lados, chaves = Object.keys(lados || {});
    if (chaves.length < 2) { await ctx.say('Mas falhou! (não há nada pra trocar de lado)'); return true; }
    const [a, b] = chaves; [lados[a], lados[b]] = [lados[b], lados[a]];
    await ctx.say('Os campos trocaram de lado! Telas e armadilhas foram para o outro lado.', 'status'); return true;
  }

  /* ---- 🔄 os que dependem de trocar de Pokémon: aqui o "substituto" é um COMPANHEIRO em campo ---- */
  if (esp.desejoDeCura || esp.reviver) {
    const amigos = (ctx.aliadosDe?.(u) || []);
    const alvoCura = esp.reviver ? amigos.find(a => a.hp <= 0) : amigos.find(a => a.hp > 0 && (a.hp < a.stats.hp || a.status));
    if (!alvoCura) { await ctx.say(`Mas falhou! (não há companheiro ${esp.reviver ? 'caído pra levantar' : 'pra curar'})`); return true; }
    if (esp.reviver) {
      alvoCura.hp = Math.max(1, Math.floor(alvoCura.stats.hp / 2)); alvoCura.status = null; alvoCura.sleep = 0; delete alvoCura.vol.toxico;
      up(ctx); await ctx.say(`✨ ${ctx.nome(alvoCura)} voltou à luta com metade do HP!`, 'level'); return true;
    }
    alvoCura.hp = alvoCura.stats.hp; alvoCura.status = null; alvoCura.sleep = 0; delete alvoCura.vol.toxico;
    if (esp.devolvePP) alvoCura.moves?.forEach(mv => { mv.ppLeft = mv.pp; });
    u.hp = 0; up(ctx);
    await ctx.say(`${U} se sacrifica: ${ctx.nome(alvoCura)} está curado${esp.devolvePP ? ' e com os PP cheios' : ''}!`, 'good');
    return true;
  }

  /* ---- ⏱ ordem do turno. O motor só PEDE (`ctx.reordenar`), como no `ctx.forcarSaida`: quem tem a fila é quem
     roda a rodada. Sem o gancho (luta de sala) o golpe diz que ali não dá, em vez de fingir. ---- */
  if (esp.reordena) {
    const r = ctx.reordenar ? ctx.reordenar(t, esp.reordena) : undefined;
    if (r === undefined) await ctx.say('Mas falhou! (este golpe não funciona em luta de sala)');
    else if (!r) await ctx.say(`Mas falhou! (${T} já agiu neste turno)`);
    else await ctx.say(esp.reordena === 'proximo' ? `${T} vai agir em seguida!` : `${T} foi empurrado para o fim da fila!`, 'status');
    return true;
  }
  /* Ally Switch: não existem POSIÇÕES em campo aqui, então a tradução é o efeito que ele tem nos jogos — o
     companheiro passa a receber os golpes mirados em você até o fim da rodada. É o mesmo `vol.chamariz` do
     Follow Me; a diferença é quem decide. */
  if (esp.trocaLugar) {
    const amigo = (ctx.aliadosDe?.(u) || []).find(a => a.hp > 0 && !a.vol?.retirado);
    if (!amigo) { await ctx.say('Mas falhou! (não há companheiro pra trocar de lugar)'); return true; }
    amigo.vol.chamariz = true;
    await ctx.say(`${U} trocou de lugar com ${ctx.nome(amigo)}! Os golpes vão nele até o fim da rodada.`, 'good'); return true;
  }

  /* ---- o resto ---- */
  // Curse: Fantasma paga METADE do HP máximo pra sangrar o alvo; quem não é Fantasma se buffa (vem do `meta`)
  if (esp.maldicao) {
    if (!tiposDefensivos(u).includes('ghost')) {
      await mudarEstagios(u, [{ stat: 'speed', change: -1 }, { stat: 'attack', change: 1 }, { stat: 'defense', change: 1 }], ctx, u);
      return true;
    }
    if (t.vol.maldicao) { await ctx.say(`${T} já está amaldiçoado!`); return true; }
    const custo = Math.max(1, Math.floor(u.stats.hp / 2));
    u.hp = Math.max(0, u.hp - custo); t.vol.maldicao = true; up(ctx);
    await ctx.say(`${U} entrega metade do próprio HP (−${custo}) e amaldiçoa ${T}!`, 'status'); return true;
  }
  if (esp.laco) { u.vol.laco = true; await ctx.say(`${U} se prepara para levar alguém junto!`, 'status'); return true; }
  if (esp.rancor) { u.vol.rancor = true; await ctx.say(`${U} guarda rancor: quem o derrubar perde o golpe!`, 'status'); return true; }
  if (esp.tiraPP) {
    const g2 = t.moves?.find(x => x.name === t.vol.ultimo);
    if (!g2 || g2.ppLeft === undefined) { await ctx.say(`Mas falhou! (${T} não usou nada ainda)`); return true; }
    const antes = g2.ppLeft; g2.ppLeft = Math.max(0, g2.ppLeft - esp.tiraPP);
    await ctx.say(`${fmt(g2.name)} de ${T} perdeu ${antes - g2.ppLeft} PP!`, 'status'); return true;
  }
  /* Imprison: copia pro `vol` do alvo os NOMES dos golpes que os dois sabem. É isso que faz o golpe caber sem
     mexer em `regras.motivoBloqueio` (que é puro e recebe um Pokémon só) — a lista viaja com o alvo. */
  if (esp.selaGolpes) {
    const comuns = (u.moves || []).map(x => x.name).filter(n => t.moves?.some(x => x.name === n));
    if (!comuns.length) { await ctx.say('Mas falhou! (vocês não têm golpe em comum)'); return true; }
    t.vol.proibidos = comuns;
    await ctx.say(`${U} selou os golpes que ${T} também sabe: ${comuns.map(n => fmt(n)).join(', ')}!`, 'status'); return true;
  }
  // Heal Block, Embargo e Throat Chop: turnos no `vol`, lidos por regras.heal, segurados.seg e motivoBloqueio
  for (const [chave, campo, texto] of [['semCura', 'semCura', 'não vai conseguir se curar'], ['semItem', 'semItem', 'não vai conseguir usar o item'], ['calaPorTurnos', 'calado', 'não vai conseguir usar golpes de som']]) {
    if (!esp[chave]) continue;
    if (t.vol[campo] > 0) { await ctx.say('Mas falhou! (já está valendo)'); return true; }
    t.vol[campo] = esp[chave];
    await ctx.say(`${T} ${texto} por ${esp[chave]} turnos!`, 'status'); return true;
  }
  if (esp.manto) { u.vol.manto = true; await ctx.say(`${U} se cobre: o próximo golpe de status volta pro dono!`, 'good'); return true; }
  if (esp.furtar) { u.vol.furtar = true; await ctx.say(`${U} está à espreita para furtar um golpe!`, 'good'); return true; }
  if (esp.passaStatus) {
    if (!u.status) { await ctx.say('Mas falhou! (você não tem status pra passar)'); return true; }
    const meu = u.status;
    if (!await aplicarStatus(t, meu, ctx, true, u)) return true;
    if (t.status === meu) { u.status = null; u.sleep = 0; delete u.vol.toxico; up(ctx); await ctx.say(`${U} passou a própria condição para ${T}!`, 'status'); }
    return true;
  }
  // os quatro que mudam o TIPO de quem usa. O tipo novo mora no `vol` (regras.tiposDe), nunca em `m.data`.
  if (esp.tipoDoTerreno || esp.tipoDoMeuGolpe || esp.tipoQueResiste || esp.tipoDoAlvo) {
    let novos = null;
    if (esp.tipoDoTerreno) novos = [TIPO_DO_TERRENO[terrenoDoCtx(ctx)] || 'normal'];
    else if (esp.tipoDoMeuGolpe) { const l = (u.moves || []).filter(x => x.type); novos = l.length ? [l[rand(0, l.length - 1)].type] : null; }
    else if (esp.tipoQueResiste) { const tp = u.vol.ultimoDano?.tipo && tipoQueResiste(u.vol.ultimoDano.tipo); novos = tp ? [tp] : null; }
    else novos = [...tiposDe(t)];
    if (!novos?.length) { await ctx.say(`Mas falhou!${esp.tipoQueResiste ? ' (ninguém te acertou neste turno)' : ''}`); return true; }
    if (u.tera) { await ctx.say(`Mas falhou! (${U} está terastalizado)`); return true; }
    if (tiposDe(u).join() === novos.join()) { await ctx.say('Mas falhou!'); return true; }
    u.vol.tipos = novos;
    await ctx.say(`${U} agora é do tipo ${novos.map(x => TYPE_PT[x] || x).join('/')}!`, 'status'); return true;
  }
  /* 👁 Foresight / Odor Sleuth / Miracle Eye: tiram a IMUNIDADE de tipo do alvo. A marca é lida por
     `regras.eficacia` — a porta única de "esse golpe faz algo?" —, então vale no dano, no motor e na IA de uma vez. */
  if (esp.semImunidade) {
    const ja = t.vol.semImunidade || [];
    const novas = esp.semImunidade.filter(d => !ja.includes(d));
    if (!novas.length) { await ctx.say(`Mas falhou! (${T} já está identificado)`); return true; }
    t.vol.semImunidade = [...ja, ...novas];
    await ctx.say(`${T} foi identificado! As imunidades dele não valem mais contra você.`, 'status'); return true;
  }
  if (esp.miraCerta) { u.vol.miraCerta = true; await ctx.say(`${U} mirou em ${T}: o próximo golpe não vai errar!`, 'good'); return true; }
  if (esp.critoCerto) { u.vol.critoCerto = true; await ctx.say(`${U} se concentrou: o próximo golpe será crítico!`, 'good'); return true; }
  // Spotlight: marca o alvo com o MESMO `vol.chamariz` do Follow Me — os golpes do seu lado passam a ir nele
  if (esp.holofote) { t.vol.chamariz = true; await ctx.say(`${T} ficou em evidência: os golpes vão todos nele!`, 'status'); return true; }
  if (esp.trancar) {
    if (t.vol.octolock) { await ctx.say(`${T} já está trancado!`); return true; }
    t.vol.octolock = true; t.vol.preso = true;
    await ctx.say(`${T} foi trancado! Não consegue mais fugir, e vai perdendo defesa a cada turno.`, 'status'); return true;
  }
  if (esp.poExplosivo) { t.vol.poExplosivo = true; await ctx.say(`${T} ficou coberto por um pó explosivo!`, 'status'); return true; }
  if (esp.eletrifica) { t.vol.eletrificado = true; await ctx.say(`O golpe de ${T} vai sair Elétrico nesta rodada!`, 'status'); return true; }
  /* Stockpile / Spit Up / Swallow: `vol.estoque` vai até 3. O Stockpile sobe Defesa e Def. Esp. pelo `meta`, então
     aqui só a contagem; Spit Up vira dano (100 por carga, em `executar`) e Swallow vira cura. Os dois ZERAM. */
  if (esp.estocar) {
    if ((u.vol.estoque || 0) >= 3) { await ctx.say('Mas falhou! (já guardou o máximo)'); return true; }
    u.vol.estoque = (u.vol.estoque || 0) + 1;
    await ctx.say(`${U} guardou energia! (${u.vol.estoque}/3)`, 'good');
    return false;   // deixa o genérico subir Defesa/Def.Esp. pelo `meta`
  }
  if (esp.engolir) {
    const n = u.vol.estoque || 0;
    if (!n) { await ctx.say('Mas falhou! (não há energia guardada)'); return true; }
    delete u.vol.estoque;
    const cura = Math.floor(u.stats.hp * [0, 1 / 4, 1 / 2, 1][n]);
    if (u.hp >= u.stats.hp) { await ctx.say(`O HP de ${U} já está cheio!`); return true; }
    heal(u, cura); up(ctx); await ctx.say(`${U} engoliu a energia guardada e recuperou HP!`, 'good'); return true;
  }
  return false;
}

// `dest` = quem recebe o efeito (ver golpe.executar): o próprio, o alvo, ou o COMPANHEIRO que alvosDoGolpe escolheu
async function golpeDeStatus(u, t, g, selfT, ctx, primeiro, dest = selfT ? u : t) {
  if (await statusEspecial(u, t, g, especial(g), ctx, primeiro, dest)) return;
  const meta = g.meta || {}; let fez = false;
  if (meta.heal > 0) {
    fez = true;
    if (dest.hp >= dest.stats.hp) await ctx.say(`O HP de ${ctx.nome(dest)} já está cheio!`);
    else { heal(dest, Math.floor(dest.stats.hp * meta.heal / 100)); up(ctx); await ctx.say(`${ctx.nome(dest)} recuperou HP.`, 'good'); }
  }
  if (g.stats.length) { fez = true; await mudarEstagios(mudaOUsuario(meta) ? u : dest, g.stats, ctx, u); }
  if (meta.ailment && meta.ailment !== 'none') {
    fez = true;
    if (Math.random() * 100 < (meta.ailChance || 100)) await aplicarStatus(dest, meta.ailment, ctx, true, u);
  }
  // Teleport não faz nada ALÉM de sair de campo (quem trata é o `revezamento`, logo depois): não é efeito faltando
  if (!fez && !especial(g).revezamento) await ctx.say('Mas nada aconteceu... (este efeito será ajustado em atualizações futuras)', 'muted');
}

/* Tirar um Pokémon de campo SEM desmaiar (Roar, Whirlwind, Dragon Tail, Circle Throw, Red Card, Wimp Out, Emergency Exit).
   O motor não sabe COMO: quem tem a batalha (batalha.forcarSaida no single player) decide o que "sair" quer dizer —
   selvagem foge, treinador manda outro, aliado sai da luta. `ctx.forcarSaida` é opcional: sem ele (multiplayer) devolve
   `undefined`, e quem chamou diz que o golpe não funciona ali. Devolve true/false quando o ctx sabe responder. */
/* Suction Cups (`semSaidaForcada`): quem tem não é arrastado pra fora por golpe alheio — Roar, Whirlwind, Dragon
   Tail, Cartão Vermelho. Fica AQUI, o único ponto por onde o motor pede saída, e não em `batalha.forcarSaida`:
   assim vale igual no single player e em qualquer outro ctx. Saída por vontade própria (`medo`, do Wimp Out) não
   é bloqueada — é a habilidade DELE agindo, não um golpe do outro. */
async function sairDeCampo(m, ctx, motivo) {
  // só a saída EMPURRADA por outro é bloqueada: a por medo (Wimp Out) e o revezamento são escolha de quem sai
  if (motivo === 'forcada' && hab(m).semSaidaForcada) {
    await ctx.say(`${ctx.nome(m)} se agarrou no chão com ${fmt(m.ability)} e não saiu!`, 'status');
    return false;
  }
  return ctx.forcarSaida ? !!(await ctx.forcarSaida(m, { motivo })) : undefined;
}
/* 🔄 Revezamento (U-turn, Volt Switch, Flip Turn, Teleport, Parting Shot): QUEM USOU sai de campo. O dano e o
   efeito do golpe já aconteceram — a troca é a última parte, e falhar nela não desfaz o resto, como nos jogos. */
async function revezar(u, ctx) {
  const r = await sairDeCampo(u, ctx, 'revezamento');
  if (r === undefined) await ctx.say('Mas não deu pra sair de campo aqui. (luta de sala)');
  else if (!r) await ctx.say('Mas não havia ninguém pra cobrir o lugar!');
}

// `primeiro` = u agiu antes de t neste turno (recuo só vale assim)
/* `opcoes.extra` = o mesmo golpe do chefe caindo em OUTRO alvo (o golpe carregado atinge o time inteiro no co-op — mp-motor): não
   conta como uma ação nova do chefe, não cobra recarga nem chama as regras dele de novo. */
export async function usarGolpe(u, t, g, primeiro, ctx, opcoes = {}) {
  /* Follow Me / Rage Powder (`vol.chamariz`): quem chamou a atenção leva o golpe no lugar do companheiro. Trocado
     aqui, no começo, pra TODAS as travas abaixo (Campo Psíquico, Dazzling, Pressure) já valerem contra o alvo de
     verdade — e vale pros dois lados, inclusive na sala, porque é o motor que decide. Golpe de área continua
     pegando todo mundo: isto só troca o alvo principal. */
  if (t !== u) {
    const chamariz = (ctx.oponentesDe?.(u) || []).find(o => o !== t && o.vol?.chamariz && o.hp > 0 && !o.vol?.retirado);
    if (chamariz) t = chamariz;
  }
  await ajustarForma(u, ctx); if (t !== u) await ajustarForma(t, ctx);   // Castform: a forma do tempo de agora, antes de qualquer conta
  const U = ctx.nome(u), hu = hab(u);
  if (!opcoes.extra && u.vol.recarga) { delete u.vol.recarga; await ctx.say(`${U} precisa recarregar!`); return; }  // Hyper Beam & cia.
  if (u.boss && !opcoes.extra) {           // chefe de evento (boss.js): couraça, ponto fraco, golpe telegrafado e fases
    u.boss.soltouTodos = false;
    const r = antesDoChefeAgir(u);
    await aplicarEfeitosChefe(u, r.efeitos, ctx);
    if (r.pular) return;
    if (r.golpe) { g = r.golpe; u.boss.soltouTodos = !!r.todos; }   // mp-motor lê isto pra acertar os outros alvos
  }
  if (hu.preguica && u.vol.folga) { u.vol.folga = false; interromper(u); await ctx.say(`${U} está com preguiça...`); return; } // Truant: folga no turno seguinte a um golpe
  // 💥 Powder: coberto de pó, golpe de Fogo explode na própria cara e não sai
  if (u.vol.poExplosivo && g.type === 'fire') {
    delete u.vol.poExplosivo; interromper(u);
    if (!indireto(u)) { const d = Math.max(1, Math.floor(u.stats.hp / 4)); u.hp = Math.max(0, u.hp - d); up(ctx); }
    await ctx.say(`💥 O pó explode na cara de ${U}! O golpe de Fogo não saiu.`, 'hit'); return;
  }
  const travado = golpeTravado(u);                                                    // carga / fúria: repete sozinho
  if (travado) g = travado;
  /* Dormindo o turno é perdido — MENOS com Sleep Talk e Snore (`soNoSono`), que existem exatamente pra isso e por
     isso FURAM esta trava. O turno de sono continua contando (a conta já rodou acima); o que não acontece é o
     `return`. Fora do sono os dois falham, como nos jogos — e dizem isso, em vez de "nada aconteceu". */
  const soDormindo = especial(g).soNoSono;
  if (u.status === 'sleep') {
    u.sleep -= hu.sonoRapido ? 2 : 1;                                                  // Early Bird
    if (u.sleep > 0 && !soDormindo) { interromper(u); await ctx.say(`${U} está dormindo profundamente.`); return; }
    if (u.sleep <= 0) { u.status = null; u.sleep = 0; up(ctx); await ctx.say(`${U} acordou!`); }
  }
  if (soDormindo && u.status !== 'sleep') { await ctx.say(`${U} usou ${ctx.golpe(g)}! Mas falhou — só funciona dormindo.`); return; }
  // Congelado: 20% de descongelar por turno — MAS golpe com a flag `defrost` (Flame Wheel, Sacred Fire, Flare
  // Blitz, Scald, Pyro Ball…) derrete o gelo de quem usa e sai normalmente, como nos jogos.
  if (u.status === 'freeze') {
    if (temFlag(g, 'defrost') || Math.random() < 0.2) { u.status = null; up(ctx); await ctx.say(`${U} descongelou!`); }
    else { interromper(u); await ctx.say(`${U} está congelado!`); return; }
  }
  if (u.status === 'paralysis' && Math.random() < 0.25) { interromper(u); await ctx.say(`${U} está paralisado e não consegue se mover!`); return; }
  if (u.vol.flinch) {
    u.vol.flinch = false; interromper(u);
    await ctx.say(`${U} recuou e não conseguiu atacar!`);
    // Steadfast: perder o turno recuando sobe a Velocidade (o único jeito de levar algo bom de um recuo)
    if (hu.aoRecuar) await mudarEstagios(u, [{ stat: hu.aoRecuar[0], change: hu.aoRecuar[1] }], ctx, u);
    return;
  }
  // Paixão (Attract / Cute Charm): metade dos turnos ele não consegue atacar. Antes da confusão, como nos jogos.
  if (u.vol.paixao) {
    await ctx.say(`${U} está apaixonado...`);
    if (Math.random() < 0.5) { interromper(u); await ctx.say(`${U} está imobilizado pelo amor e não atacou!`); return; }
  }
  if (u.vol.conf > 0) {
    u.vol.conf--;
    if (u.vol.conf === 0) await ctx.say(`${U} não está mais confuso.`);
    else {
      await ctx.say(`${U} está confuso...`);
      if (Math.random() < 1 / 3) { interromper(u); const d = confDamage(u); u.hp = Math.max(0, u.hp - d); up(ctx); (ctx.tremer || nada)(u); await ctx.say(`Ele se machucou na confusão! (−${d})`, 'hit'); return; }
    }
  }
  /* Travas de escolha (regras.motivoBloqueio): Choice, Colete de Assalto, Taunt, Encore, Disable e Torment. Conferir AQUI
     e não só no menu porque o efeito pode chegar DEPOIS de escolhido o golpe: o inimigo mais rápido que te provoca faz o
     seu golpe de status falhar; e no Encore, como nos jogos, o golpe escolhido é TROCADO pelo repetido. Carga/fúria em
     andamento (`travado`) e Struggle ficam de fora. Falhar não gasta PP. */
  if (!travado && g.name !== 'struggle') {
    const forcado = golpeForcado(u);
    if (forcado && forcado.name !== g.name) g = forcado;
    const bloqueio = motivoBloqueio(u, g);
    if (bloqueio) { await ctx.say(`${U} não consegue usar ${ctx.golpe(g)}: ${bloqueio.texto}!`); return; }
  }
  // Campo Psíquico: golpe de prioridade não passa em quem está no chão
  const terr = terrenoDoCtx(ctx);
  if (TERRENOS[terr]?.semPrioridade && (g.priority || 0) > 0 && u !== t && noChao(t)) {
    await ctx.say(`${TERRENOS[terr].nome} protege ${ctx.nome(t)} de golpes rápidos!`);
    return;
  }
  // Dazzling, Queenly Majesty, Armor Tail: golpe de prioridade não passa (mesma regra do Campo Psíquico)
  if ((g.priority || 0) > 0 && u !== t && !SELF_TARGETS.has(g.target) && hab(t).bloqueiaPrioridade) {
    await ctx.say(`${fmt(t.ability)} de ${ctx.nome(t)} bloqueia golpes rápidos!`);
    return;
  }
  const esp = especial(g);
  if (!esp.protege && !esp.aguentaTurno) u.vol.protSeguidas = 0;
  // no sol forte, Solar Beam e Solar Blade saem na hora (não precisam carregar)
  const solNaCara = esp.carga && !esp.invulneravel && /^solar-/.test(g.name) && climaDoCtx(ctx) === 'sol';
  /* Erva do Poder: pula o turno de carga de QUALQUER golpe de carga, uma vez. Só se gasta se o golpe fosse mesmo
     carregar — no sol o Solar Beam já sai na hora sozinho, e queimar a erva ali seria desperdiçá-la à toa. */
  const ervaDoPoder = esp.carga && !solNaCara && !u.vol.carregando && seg(u).pulaCarga;
  if (ervaDoPoder) { await ctx.say(`A ${ITEMS[u.item]?.name || 'Erva do Poder'} de ${U} fez o golpe sair na hora!`, 'good'); u.item = null; }
  const cargaPulada = solNaCara || ervaDoPoder;
  // golpe de carga, 1º turno: gasta PP, prepara (e some, se for Fly/Dig…) e ataca só no próximo
  if (esp.carga && !cargaPulada && !u.vol.carregando) {
    if (g.ppLeft !== undefined) g.ppLeft = Math.max(0, g.ppLeft - 1 - pressao(u, t, g));
    u.vol.carregando = g; if (esp.invulneravel) u.vol.invul = true;
    await ctx.say(`${U} está se preparando para usar ${ctx.golpe(g)}!`); return;
  }
  if (esp.carga) { delete u.vol.carregando; delete u.vol.invul; }                    // 2º turno: não gasta PP de novo
  else if (!travado && g.ppLeft !== undefined) g.ppLeft = Math.max(0, g.ppLeft - 1 - pressao(u, t, g));  // fúria: só o 1º turno gasta
  if (esp.furia && !u.vol.furia) u.vol.furia = { golpe: g, turnos: rand(2, 3) };
  (ctx.atacar || nada)(u);
  await ctx.say(`${U} usou ${ctx.golpe(g)}!`);
  // Faixa/Óculos/Lenço Escolha: trava no PRIMEIRO golpe de verdade usado (Struggle não conta — é golpe de
  // emergência, sem PP sobrando pra "escolher" nada) até desmaiar/ser revivido (`m.vol` reseta nos dois casos).
  if (seg(u).choice && !u.vol.escolha && g.name !== 'struggle') u.vol.escolha = g.name;
  if (g.name !== 'struggle') u.vol.ultimo = g.name;                                   // Encore, Disable e Torment olham isto
  // Copycat copia o último golpe usado por QUALQUER UM: o campo é o estado compartilhado pelos dois lados, e aqui
  // guarda só o NOME (o objeto sai do moveset de quem o sabe — `golpe.golpeDeNome`), que é dado simples pro save
  // Golpe de CÓPIA não entra nessa memória: além de ser a regra dos jogos (Copycat não copia Copycat), ele
  // sobrescreveria o valor que o próprio Copycat vai ler daqui a três linhas, dentro do mesmo turno.
  if (ctx.campo && podeCopiar(g.name)) ctx.campo.ultimo = g.name;
  if (hu.preguica) u.vol.folga = true;                                                // Truant: o próximo turno é de folga
  // Fake Out e First Impression só valem no primeiro golpe da batalha (vol.golpesDados conta os anteriores)
  const primeiroGolpe = !u.vol.golpesDados;
  u.vol.golpesDados = (u.vol.golpesDados || 0) + 1;
  // Sucker Punch: o alvo tem que ter ESCOLHIDO um golpe de dano neste turno e ainda não ter agido (`primeiro`). Sem isso o golpe
  // era só "prioridade +1 que sempre funciona". `vol.golpeEscolhido` é preenchido por batalha.turn / mp-motor antes de resolver.
  if (esp.soSeAlvoAtaca && u !== t) {
    const escolhido = t.vol.golpeEscolhido;
    if (!primeiro || !escolhido || escolhido.cls === 'status') { await ctx.say('Mas falhou! (só funciona se o alvo for atacar neste turno)'); return; }
  }
  if (esp.soPrimeiroTurno && !primeiroGolpe) { await ctx.say('Mas falhou! (só funciona no primeiro golpe da batalha)'); return; }

  /* Damp: a explosão nem sai. Depois do "usou X!" e de gastar o PP, como nos jogos — o golpe foi tentado. */
  if (esp.autoDesmaio) {
    const abafa = quemAbafa(u, ctx);
    if (abafa) { await ctx.say(`${fmt(abafa.ability)} de ${ctx.nome(abafa)} impede a explosão!`, 'status'); return; }
  }
  /* Golpe de área: `executar` roda uma vez por alvo. Os alvos EXTRAS passam `respingo` pra não cobrar duas vezes
     o que é do usuário e acontece uma vez só por golpe (recuo, Orbe da Vida, cura e a própria queda de atributo).
     Dreno e Moxie ficam de fora da trava de propósito: nos jogos eles contam por alvo atingido. */
  const alvos = alvosDoGolpe(u, t, g, ctx);
  // golpe que EXIGE companheiro (Helping Hand, Coaching, Dragon Cheer) sem ninguém do lado: falha e diz por quê
  if (!alvos.length) { await ctx.say('Mas falhou! (não há companheiro em campo)'); return; }
  let res;
  for (const [i, alvo] of alvos.entries()) {
    if (u.hp <= 0 && i) break;                      // morreu no respingo (Elmo Rochoso, Orbe): não bate mais
    const r = await executar(u, alvo, g, primeiro, ctx, esp, { varios: alvos.length > 1, respingo: i > 0 });
    res ||= r;
  }
  /* ⚔ Saga: 🔮 Selo Arcano e ⚔ Estocada valem pelo PRÓXIMO GOLPE, e é aqui que ele acaba — inclusive quando o
     golpe errou, foi barrado por Protect ou era de status. "O próximo golpe" é o próximo golpe, não o próximo que
     der certo; senão a perícia viraria um buff permanente até acertar. Perícia não passa por aqui (ela não é
     golpe), então a marca nunca é consumida pelo turno em que foi invocada. */
  delete u.vol.selo; delete u.vol.estocada;
  delete u.vol.miraCerta; delete u.vol.critoCerto;   // 🎯 Mind Reader/Lock On e 🔦 Laser Focus valem UM golpe
  if (esp.autoDesmaio && u.hp > 0) { u.hp = 0; up(ctx); (ctx.tremer || nada)(u); await ctx.say(`${U} desmaiou com o esforço!`, 'hit'); }
  if (esp.recarga && res === 'acertou' && u.hp > 0) u.vol.recarga = true;
  if (u.vol.furia && --u.vol.furia.turnos <= 0) {
    delete u.vol.furia;
    if (u.hp > 0) { await ctx.say(`${U} se cansou da fúria...`); await aplicarStatus(u, 'confusion', ctx); }
  }
}

/* O golpe em si, depois de "X usou Y!". Devolve 'acertou' quando o golpe de dano conectou (Hyper Beam só recarrega assim).
   `area.varios` = o golpe pegou mais de um alvo (dano ×MULT_AREA, como nos jogos);
   `area.respingo` = este não é o alvo principal, então o que é do USUÁRIO e vale uma vez por golpe não repete. */
async function executar(u, t, g, primeiro, ctx, esp, area = {}) {
  g = golpeDoClima(g, climaDoCtx(ctx));   // Weather Ball: tipo e poder do tempo (o PP já foi gasto no golpe original)
  g = golpeDaConversaoDeTipo(g, u);       // Aerilate/Pixilate/Refrigerate/Galvanize/Normalize: ANTES do Tera (roda com Weather Ball sem clima ativo)
  g = golpeDoTera(g, u);                  // Tera Blast: tipo de quem usa, se estiver terastalizado
  g = golpeDoBattleBond(g, u);            // Water Shuriken vira fixo (poder 20, 3 acertos) se já é Ash-Greninja
  /* ⚡ Ion Deluge (campo) e Electrify (no alvo): golpe que ia sair Normal sai Elétrico nesta rodada. Entra na
     MESMA fila de reescritas de cima, pela mesma razão — é o golpe que muda, não o dano. */
  if (g.type === 'normal' && (ctx.campo?.ionizado || u.vol?.eletrificado)) g = { ...g, type: 'electric' };
  /* 🎁 Natural Gift e 🤮 Spit Up reescrevem o golpe a partir do que quem usa TEM na mão ou guardou. Ficam aqui
     porque mudam tipo/poder, não o efeito — daí pra baixo são golpes comuns. */
  if (especial(g).presenteDaNatureza) {
    const tipoFruta = Object.entries(FRUTA_DO_TIPO).find(([, [id]]) => id === u.item)?.[0] || TIPO_DA_FRUTA_DE_CURA[u.item];
    if (!tipoFruta) { await ctx.say(`${ctx.nome(u)} não tem fruta nenhuma: o golpe falhou!`); return; }
    g = { ...g, type: tipoFruta, power: PODER_NATURAL_GIFT };
    gastarItem(u);   // a fruta se gasta no golpe, como nos jogos
  }
  if (especial(g).cuspir) {
    const n = u.vol?.estoque || 0;
    if (!n) { await ctx.say('Mas falhou! (não há energia guardada)'); return; }
    delete u.vol.estoque;
    g = { ...g, power: 100 * n };
  }
  if (especial(g).arremessa && !u.item) { await ctx.say(`${ctx.nome(u)} não tem item pra arremessar: o golpe falhou!`); return; }
  const U = ctx.nome(u), T = ctx.nome(t), hu = hab(u), ht = hab(t);
  const selfT = SELF_TARGETS.has(g.target), meta = g.meta || {};
  /* Quem RECEBE o efeito deste golpe de status. Quase sempre é o próprio (`user`, Swords Dance) ou o alvo
     (Thunder Wave) — a exceção são os golpes de companheiro e de apoio (ALVOS_ALIADOS / regras.golpeDeApoio),
     em que `t` já é o companheiro que `alvosDoGolpe` escolheu e o efeito tem de cair NELE. */
  const dest = selfT && !ALVOS_ALIADOS.has(g.target) ? u : t;
  /* Protean / Libero: ao atacar, o tipo DE QUEM USA vira o tipo do golpe (o STAB vem de graça). Uma vez só por
     entrada em campo, como na Gen 9 — e `vol` já zera a cada entrada, então a trava é só o próprio campo.
     O tipo mora em `vol.tipos` (regras.tiposDe), nunca em `m.data`: aquele objeto é compartilhado pela espécie. */
  if (hu.tipoDoProprioGolpe && !u.vol.trocouTipo && !(tiposDe(u).length === 1 && tiposDe(u)[0] === g.type)) {
    u.vol.tipos = [g.type]; u.vol.trocouTipo = true;
    await ctx.say(`${U} virou do tipo ${TYPE_PT[g.type] || g.type} com ${fmt(u.ability)}!`, 'status');
  }
  // Long Reach: os PRÓPRIOS golpes nunca fazem contato, mesmo os que têm a flag `contact` de verdade
  const encostou = fazContato(g) && !hu.semContato;
  if (!selfT && t.vol.protegido) {
    await ctx.say(`${T} se protegeu do golpe!`);
    // barreira que pune contato: só quem encosta de verdade leva (fazContato/regras.js — mesma regra de Static/Elmo Rochoso)
    const pun = t.vol.punicao;
    if (pun && encostou && u.hp > 0) {
      if (pun.estagio) await mudarEstagios(u, [{ stat: pun.estagio[0], change: pun.estagio[1] }], ctx, t);
      if (pun.dano && !indireto(u)) { const d = Math.max(1, Math.floor(u.stats.hp * pun.dano)); u.hp = Math.max(0, u.hp - d); up(ctx); await ctx.say(`${U} se machucou na barreira! (−${d})`, 'hit'); }
      if (pun.status && !u.status) await aplicarStatus(u, pun.status, ctx, true, t);
    }
    return;
  }
  if (!selfT && t.vol.invul) { await ctx.say('Mas errou!'); return; }                 // alvo no ar / debaixo da terra
  /* 🛡 PROTEÇÃO DE LADO (Wide Guard, Quick Guard, Crafty Shield, Mat Block). Cada uma barra uma FAMÍLIA de golpe
     — `regras.GUARDAS_DE_LADO` diz qual —, protege o lado inteiro e vale uma rodada (`passarLado` as zera).
     Fica junto do Protect porque é a mesma pergunta ("esse golpe chega?") e o `return` resolve igual. */
  if (!selfT && u !== t) {
    const deles = ladoDoCampo(ctx, t);
    const alcance = g.target || GOLPE_AREA[g.name];
    const familia = { area: AO.has(alcance) || ALVOS_TODOS.has(alcance), prioridade: (g.priority || 0) > 0, status: g.cls === 'status', dano: g.cls !== 'status' };
    for (const [chave, qual] of Object.entries(GUARDAS_DE_LADO)) {
      if (deles?.[chave] > 0 && familia[qual]) { await ctx.say(`${NOME_LADO[chave]} protege ${T}!`); return; }
    }
  }
  /* 🪞 Magic Coat e 🫱 Snatch: interceptam o golpe de STATUS do outro. O que faltava pra eles caberem era um
     ponto onde o golpe já está decidido mas ainda não resolveu — e `executar` é exatamente isso.
     Magic Coat devolve o golpe pro dono (só o que tem a flag `reflectable` da PokéAPI); Snatch rouba o golpe que
     o outro ia usar EM SI MESMO (flag `snatch`) e usa no lugar. Os dois valem uma vez e se gastam. */
  if (g.cls === 'status') {
    // 🪞 Magic Coat devolve pro dono um golpe mirado em VOCÊ (daí o `u !== t`)
    if (!selfT && u !== t && t.vol.manto && temFlag(g, 'reflectable')) {
      delete t.vol.manto;
      await ctx.say(`${T} refletiu ${ctx.golpe(g)} de volta!`, 'status');
      await golpeDeStatus(t, u, g, false, ctx, primeiro, u);
      return 'acertou';
    }
    /* 🫱 Snatch rouba golpe AUTO-DIRIGIDO (Swords Dance, Recover…), e nesses `u === t` — era justamente a trava
       `u !== t` que fazia o Snatch nunca disparar. A flag `snatch` da PokéAPI diz quais são roubáveis. */
    if (selfT && temFlag(g, 'snatch')) {
      const ladrao = (ctx.oponentesDe?.(u) || []).find(o => o.vol?.furtar && o.hp > 0);
      if (ladrao) {
        delete ladrao.vol.furtar;
        await ctx.say(`${ctx.nome(ladrao)} furtou ${ctx.golpe(g)} de ${U}!`, 'status');
        await golpeDeStatus(ladrao, ladrao, g, true, ctx, primeiro, ladrao);
        return 'acertou';
      }
    }
  }
  // Soundproof/Bulletproof: imunidade por FLAG do golpe, não por tipo — vale pra golpe de dano E de status (Growl,
  // Sing…), por isso checado antes até do golpe de status. Golpe fora da tabela (dados-golpe-flags.js) não tem a
  // flag marcada, então não é bloqueado — mais seguro que fingir saber.
  if (!selfT && ht.imuneFlag && temFlag(g, ht.imuneFlag)) { await ctx.say(`${T} não é afetado graças a ${fmt(t.ability)}!`); return; }
  /* 🪆 SUBSTITUTO. Fica aqui, num ponto só, e **retorna** — é o que faz disto uma mudança pequena em vez de um
     remendo em cada efeito. Como `executar` é a porta única de tudo, voltar daqui já garante de uma vez o que o
     boneco protege nos jogos: status, efeito secundário, queda de atributo, Leech Seed, roubo de item, recuo,
     saída forçada e habilidade de contato (Static, Elmo Rochoso) — nada disso é alcançado.
     Quem ATRAVESSA é quem tem a flag `authentic` da PokéAPI (a flag "ignora substituto": Snore, Heal Bell e os
     golpes de troca de habilidade já vêm marcados) e quem tem Infiltrator (`atravessaTelas`, a mesma habilidade
     que fura tela e salvaguarda). O dano que sobra ao estourar o boneco se PERDE, como nos jogos.
     // ponytail: recuo e dreno não contam o dano feito ao boneco — é o único efeito de QUEM ATACA que este
     // return engole junto. Nos jogos eles contam; aqui custaria repetir o bloco de dano inteiro. */
  if (!selfT && u !== t && t.vol.substituto > 0 && !temFlag(g, 'authentic') && !hu.atravessaTelas) {
    if (g.cls === 'status') { await ctx.say(`O substituto de ${T} bloqueia o golpe!`); return; }
    if (eficacia(hu, g.type, t) === 0) { await ctx.say(`Não afeta ${T}...`); return; }
    if (g.acc != null && Math.random() > chanceAcerto(g, u, t, climaDoCtx(ctx))) { await ctx.say('Mas errou!'); return; }
    const vezes = meta.minHits ? (hu.maxAcertos ? meta.maxHits || meta.minHits : rand(meta.minHits, meta.maxHits || meta.minHits)) : 1;
    let noBoneco = 0;
    for (let i = 0; i < vezes && t.vol.substituto > 0; i++) {
      const r = calcDamage(u, t, g, climaDoCtx(ctx), terrenoDoCtx(ctx), ladoDoCampo(ctx, t));
      const d = Math.min(t.vol.substituto, r.dmg);
      t.vol.substituto -= d; noBoneco += d;
    }
    up(ctx); (ctx.tremer || nada)(t, g.type);
    await ctx.say(`O substituto de ${T} levou o golpe. (−${noBoneco})`, 'hit');
    if (t.vol.substituto <= 0) { delete t.vol.substituto; await ctx.say(`O substituto de ${T} se desfez!`, 'status'); }
    return 'acertou';
  }
  if (esp.soDormindo && t.status !== 'sleep') { await ctx.say(`Não afeta ${T}... (só funciona em quem está dormindo)`); return; }
  if (esp.ohko) {
    if (t.boss) { await ctx.say(`Não afeta ${T}... (chefe de evento)`); return; }
    if (eficacia(hu, g.type, t) === 0) { await ctx.say(`Não afeta ${T}...`); return; }
    if (ht.aguenta) { await ctx.say(`${T} aguentou firme graças a ${fmt(t.ability)}!`); return; }     // Sturdy
    if (Math.random() >= chanceOhko(u, t)) { await ctx.say(t.level > u.level ? 'Mas falhou! (o alvo tem nível maior)' : 'Mas errou!'); return; }
    somarAmeaca(u, t.stats.hp);   // ⚔ nocaute de um golpe: a ameaça é o HP inteiro que ele tirou
    t.hp = 0; up(ctx); (ctx.tremer || nada)(t, g.type); await ctx.say('É um nocaute de um golpe só!', 'crit'); return 'acertou';
  }
  if (!selfT && g.acc != null && Math.random() > chanceAcerto(g, u, t, climaDoCtx(ctx))) { await ctx.say('Mas errou!'); return; }
  // Good As Gold: imune a QUALQUER golpe de status alheio (o próprio ainda pode usar golpe de status normalmente)
  if (g.cls === 'status' && !selfT && u !== t && ht.imuneGolpeStatus) { await ctx.say(`${T} não é afetado graças a ${fmt(t.ability)}!`); return; }
  if (g.cls === 'status') {
    await golpeDeStatus(u, t, g, selfT, ctx, primeiro, dest); up(ctx);
    if (esp.revezamento && u.hp > 0) await revezar(u, ctx);     // Teleport, Parting Shot
    return;
  }

  // imunidades e absorções de tipo por habilidade. Levitate cai quando o alvo foi posto no chão (Gravidade,
  // Smack Down) — a imunidade de TIPO do Voador já cai sozinha em `regras.eficacia`, pelo mesmo `vol.noSolo`.
  if (ht.imuneTipo === g.type && !(g.type === 'ground' && t.vol?.noSolo)) { await ctx.say(`${T} não é afetado graças a ${fmt(t.ability)}!`); return; }
  if (ht.absorve === g.type) {
    await ctx.say(`A habilidade ${fmt(t.ability)} de ${T} absorveu o golpe!`);
    if (ht.cura && t.hp < t.stats.hp) { heal(t, Math.floor(t.stats.hp * ht.cura)); up(ctx); await ctx.say(`${T} recuperou HP.`, 'good'); }
    if (ht.estagio) await mudarEstagios(t, [{ stat: ht.estagio[0], change: ht.estagio[1] }], ctx);
    if (ht.flashFire) t.vol.flashFire = true;
    return;
  }
  // Balão de Ar: quem flutua não é alcançado por golpe Terrestre (o balão só estoura com golpe que ACERTA)
  if (g.type === 'ground' && t.vol?.balao) { await ctx.say(`${T} está flutuando no Balão de Ar!`); return; }
  // 🧲 Magnet Rise / Telekinesis: mesma ideia do balão, só que por turnos
  if (g.type === 'ground' && t.vol?.voando > 0) { await ctx.say(`${T} está flutuando no ar — o golpe passa embaixo!`); return; }
  let ef = eficacia(hu, g.type, t);                          // Tera defende pelo tipo Tera; Scrappy/Mind's Eye ignoram a imunidade
  if (ef === 0) { await ctx.say(`Não afeta ${T}...`); return; }
  // ⚔ Saga, 🔮 Selo Arcano: nenhuma RESISTÊNCIA reduz o golpe selado. Imunidade (ef 0) continua valendo — o selo
  // não inventa um golpe que afeta quem não pode ser afetado; isso seria apagar a tabela de tipos, não reforçá-la.
  if (u.vol.selo && ef < 1) { ef = 1; await ctx.say(`O Selo Arcano rompe a resistência de ${T}!`, 'good'); }
  if (ht.soSuperEfetivo && ef <= 1) { await ctx.say(`${T} não é afetado graças a ${fmt(t.ability)}!`); return; } // Wonder Guard

  /* Endeavor iguala o HP do alvo ao seu. Contra o CHEFE DE EVENTO isso era um atalho que anulava a luta: ele tem
     o HP multiplicado (boss.prepararChefe), então um Endeavor com você quase morrendo o derrubava quase inteiro
     de uma vez — por cima da couraça de energia, das reduções de `danoNoChefe` e das fases, que nem chegavam a
     ser consultadas. Agora o buraco que o golpe abriria vira DANO COMUM e passa pelas mesmas regras de todo
     mundo: a couraça absorve, `aposDanoNoChefe` desgasta e conta as fases. Contra chefe continua sendo muito
     dano de uma vez — só não é mais um botão de vitória. Fora do chefe, nada muda. */
  if (esp.danoIgualHp) {                                                               // Endeavor
    if (t.hp <= u.hp) { await ctx.say('Mas falhou!'); return; }
    const bruto = t.hp - u.hp;
    const feito = Math.min(t.hp, t.boss ? danoNoChefe(t, bruto, g.type, ef) : bruto);
    t.hp = Math.max(0, t.hp - feito); up(ctx); (ctx.tremer || nada)(t, g.type);
    somarAmeaca(u, feito);
    await ctx.say(`${T} perdeu ${feito} HP.`, 'hit');
    if (t.boss) await aplicarEfeitosChefe(t, aposDanoNoChefe(t, feito), ctx);
    return 'acertou';
  }

  /* 💥 Dano FIXO (Sonic Boom, Seismic Toss, Night Shade, Psywave, Super Fang, Nature's Madness, Final Gambit):
     o número vem de `regras.danoFixoDe` e não passa pela fórmula — sem atributo, sem crítico, sem clima. O que
     ele AINDA respeita é a tabela de tipos (a eficácia zero já barrou lá em cima: Night Shade não pega Normal) e
     o chefe de evento, pela mesma razão do Endeavor: dano que fura a couraça seria um botão de vitória. */
  /* 🥊 Bide: dois turnos guardando TUDO o que levou (somado em `vol.bide.total`, no bloco de dano) e no terceiro
     devolve o DOBRO. Trava quem usa, como a carga e a fúria — `golpeTravado` o repete sozinho. */
  if (esp.bide) {
    const b = (u.vol.bide ||= { golpe: g, turnos: 2, total: 0 });
    if (b.turnos > 0) { b.turnos--; await ctx.say(`${U} está guardando energia!`, 'muted'); return; }
    const soma = b.total; delete u.vol.bide;
    if (!soma) { await ctx.say('Mas falhou! (não levou dano nenhum pra devolver)'); return; }
    const feito = Math.min(t.hp, t.boss ? danoNoChefe(t, soma * 2, g.type, 1) : soma * 2);
    t.hp = Math.max(0, t.hp - feito); up(ctx); (ctx.tremer || nada)(t, g.type);
    somarAmeaca(u, feito);
    await ctx.say(`${U} devolve tudo de uma vez! ${T} perdeu ${feito} HP.`, 'hit');
    if (t.boss) await aplicarEfeitosChefe(t, aposDanoNoChefe(t, feito), ctx);
    return 'acertou';
  }
  /* ⚔ Counter / Mirror Coat / Metal Burst: devolvem o dano que você levou NESTE turno (`regras.danoDoContra`,
     sobre `vol.ultimoDano`). Falham quando ninguém te bateu antes de você agir — é o preço deles. */
  if (esp.contra) {
    const devolver = danoDoContra(u, esp);
    if (devolver == null) { await ctx.say(`Mas falhou! (ninguém acertou ${U} com golpe ${esp.contra.classe === 'physical' ? 'físico' : esp.contra.classe === 'special' ? 'especial' : 'nenhum'} neste turno)`); return; }
    const feito = Math.min(t.hp, t.boss ? danoNoChefe(t, devolver, g.type, 1) : devolver);
    t.hp = Math.max(0, t.hp - feito); up(ctx); (ctx.tremer || nada)(t, g.type);
    somarAmeaca(u, feito);
    await ctx.say(`${U} devolve o golpe! ${T} perdeu ${feito} HP.`, 'hit');
    if (t.boss) await aplicarEfeitosChefe(t, aposDanoNoChefe(t, feito), ctx);
    return 'acertou';
  }
  const fixo = danoFixoDe(u, t, esp);
  if (fixo != null) {
    const feito = Math.min(t.hp, t.boss ? danoNoChefe(t, fixo, g.type, ef) : fixo);
    t.hp = Math.max(0, t.hp - feito); up(ctx); (ctx.tremer || nada)(t, g.type);
    t.vol.danoSofrido = (t.vol.danoSofrido || 0) + feito;
    somarAmeaca(u, feito);
    await ctx.say(`${T} perdeu ${feito} HP.`, 'hit');
    if (t.boss) await aplicarEfeitosChefe(t, aposDanoNoChefe(t, feito), ctx);
    return 'acertou';
  }

  /* 🎁 Present: sorteia entre três poderes — ou CURA o alvo em 1/4, que é a piada do golpe. Os pesos são os dos
     jogos (40% / 30% / 10% de dano e 20% de cura). */
  if (esp.presente) {
    const r = Math.random();
    if (r < 0.2) {
      if (t.hp >= t.stats.hp) { await ctx.say(`O HP de ${T} já está cheio!`); return 'acertou'; }
      heal(t, Math.floor(t.stats.hp / 4)); up(ctx);
      await ctx.say(`🎁 O presente era um agrado: ${T} recuperou HP!`, 'muted'); return 'acertou';
    }
    g = { ...g, power: r < 0.6 ? 40 : r < 0.9 ? 80 : 120 };
  }
  /* 👊 Beat Up: um acerto por Pokémon EM PÉ do seu lado, e o poder de cada acerto sai do Ataque BASE de quem
     bate (a fórmula dos jogos). Sozinho é um acerto só — o golpe não falha, só rende pouco. */
  if (esp.surra) {
    const turma = [u, ...(ctx.aliadosDe?.(u) || [])].filter(m => m.hp > 0);
    let somado = 0;
    for (const quem of turma) {
      if (t.hp <= 0) break;
      const golpinho = { ...g, power: Math.floor((quem.data.base?.attack ?? 50) / 10) + 5 };
      const r = calcDamage(u, t, golpinho, climaDoCtx(ctx), terrenoDoCtx(ctx), ladoDoCampo(ctx, t));
      const d = Math.min(t.hp, t.boss ? danoNoChefe(t, r.dmg, g.type, 1) : r.dmg);
      t.hp -= d; somado += d;
    }
    up(ctx); (ctx.tremer || nada)(t, g.type);
    somarAmeaca(u, somado);
    await ctx.say(`A turma inteira caiu em cima! ${turma.length} acerto${turma.length > 1 ? 's' : ''}. ${T} perdeu ${somado} HP.`, 'hit');
    if (t.boss) await aplicarEfeitosChefe(t, aposDanoNoChefe(t, somado), ctx);
    return 'acertou';
  }

  // Aegislash: atacar vira a Forma Lâmina ANTES de calcular o dano (é com o Ataque da Lâmina que o golpe sai)
  if (hu.postura) await trocarPostura(u, true, ctx);
  const hits = meta.minHits ? (hu.maxAcertos ? meta.maxHits || meta.minHits : rand(meta.minHits, meta.maxHits || meta.minHits)) : 1;
  const cheio = t.hp >= t.stats.hp;
  const hpAntesDoGolpe = t.hp;   // Innards Out precisa do HP de ANTES de cair, não do total de dano (multi-acerto)
  // Friend Guard: cada ALIADO vivo de t com a habilidade corta 25% (multiplicativo se houver mais de um)
  const friendGuard = (ctx.aliadosDe?.(t) || []).reduce((m, a) => hab(a).friendGuard ? m * 0.75 : m, 1);
  // Battery (especial ×1,3), Power Spot (qualquer ×1,3), Steely Spirit (Aço ×1,5), Plus/Minus (especial ×1,5):
  // aliado de QUEM ATACA reforça o golpe — mesmo esquema do Friend Guard, só que multiplicando em vez de cortar.
  // `vol.ajuda` = Helping Hand: um companheiro ajudou neste turno (×1,5). Apagado no fim da rodada (fimDaRodada).
  const boostAliado = (u.vol.ajuda || 1) * (ctx.aliadosDe?.(u) || []).reduce((m, a) => {
    const ha = hab(a);
    if (ha.aliadoBoost === 'especial' && g.cls === 'special') m *= 1.3;
    if (ha.aliadoBoost === 'qualquer') m *= 1.3;
    if (ha.aliadoBoost === 'aco' && g.type === 'steel') m *= 1.5;
    if (ha.aliadoBoost === 'plusminus' && g.cls === 'special') m *= 1.5;
    return m;
  }, 1);
  let total = 0, acertos = 0, crit = false, aguentou = false, resistiu = false, faixa = null;
  for (let i = 0; i < hits && t.hp > 0; i++) {
    const r = calcDamage(u, t, g, climaDoCtx(ctx), terrenoDoCtx(ctx), ladoDoCampo(ctx, t));
    let dano = danoNoChefe(t, r.dmg, g.type, ef);   // chefe de evento: couraça, exposição, ponto fraco, anula, Mundo Reverso, adaptação (sem `t.boss` devolve o mesmo)
    if (friendGuard < 1) dano = Math.max(1, Math.floor(dano * friendGuard));            // Friend Guard: nunca zera o golpe
    if (boostAliado !== 1) dano = Math.floor(dano * boostAliado);                       // Battery, Power Spot, Steely Spirit, Plus/Minus
    if (area.varios) dano = Math.max(1, Math.floor(dano * MULT_AREA));                  // golpe de área pegando mais de um
    // ⚔ Saga num ponto só (regras.multSaga): Ruína (+50%), 🧱 Muralha (−50%) e 🕯 Marca (+25%). Fora da Saga é ×1.
    const ms = multSaga(u, t); if (ms !== 1) dano = Math.max(1, Math.floor(dano * ms));
    // 💧 Mud Sport / Water Sport: o tipo marcado no campo sai pela metade pros DOIS lados
    if (ctx.campo?.sports?.includes(g.type)) dano = Math.max(1, Math.floor(dano * 0.5));
    if (ht.aguenta && cheio && i === 0 && dano >= t.hp) { dano = t.hp - 1; aguentou = true; }  // Sturdy
    else if (t.vol.aguenta && dano >= t.hp) { dano = t.hp - 1; resistiu = true; }            // Endure
    else if (seg(t).aguentaCheio && cheio && i === 0 && dano >= t.hp) { dano = t.hp - 1; faixa = t.item; t.item = null; } // Faixa de Foco
    t.hp = Math.max(0, t.hp - dano); total += dano; acertos++; crit ||= r.crit;
    if (r.crit) u.vol.criticos = (u.vol.criticos || 0) + 1;                                  // Sirfetch'd (evolucao.js)
  }
  t.vol.danoSofrido = (t.vol.danoSofrido || 0) + total;                                      // Runerigus (evolucao.js)
  /* ⚔ O que ele levou NESTE turno, pra Counter/Mirror Coat/Metal Burst (`regras.danoDoContra`) e pro Bide. Só
     dano de GOLPE entra — veneno, clima e armadilha não têm quem contra-atacar. Apagado em `fimDaRodada`, e é
     justamente isso que faz o contra-ataque falhar quando ninguém bateu antes de você agir. */
  if (total > 0) {
    t.vol.ultimoDano = { valor: total, classe: g.cls, tipo: g.type };
    if (t.vol.bide) t.vol.bide.total = (t.vol.bide.total || 0) + total;                    // Bide guarda o que levou
  }
  somarAmeaca(u, total);   // ⚔ ameaça (regras.alvoPorAmeaca): quem bate atrai. Acumula sempre; só a Saga LÊ
  up(ctx); (ctx.tremer || nada)(t, g.type);
  if (crit) await ctx.say('Um golpe crítico!', 'crit');
  if (ef > 1) await ctx.say('É super efetivo!', 'good'); else if (ef < 1) await ctx.say('Não é muito efetivo...');
  /* ⚔ Saga — BRECHA: golpe super efetivo e crítico abrem uma cada; o Selo Arcano soma 2. O motor só PEDE
     (`ctx.abrirBrecha`), como no `ctx.forcarSaida`: quem tem Guarda, quem narra e quem desenha é batalha.js.
     Depois do texto de eficácia de propósito — "é super efetivo" antes de "a guarda trinca" é a ordem que se lê. */
  if (total > 0 && ctx.abrirBrecha) {
    const brechas = (ef > 1 ? BRECHA_SUPER : 0) + (crit ? BRECHA_CRITICO : 0) + (u.vol.selo ? BRECHA_SELO : 0);
    if (brechas > 0) await ctx.abrirBrecha(t, brechas);
  }
  if (hits > 1) await ctx.say(`Acertou ${acertos} vez${acertos > 1 ? 'es' : ''}!`);
  await ctx.say(`${T} perdeu ${total} HP.`, 'hit');
  if (t.boss && total === 0 && anulaTexto(t, g.type)) await ctx.say(`🚫 ${anulaTexto(t, g.type)}: o golpe não faz nada!`, 'muted');
  // Levar um golpe de Fogo (ou Scald/Água Fervente e cia., flag `defrost`) descongela quem está congelado. Não é
  // efeito secundário: Shield Dust e Sheer Force não impedem.
  if (t.status === 'freeze' && total > 0 && (g.type === 'fire' || temFlag(g, 'defrost'))) { t.status = null; up(ctx); await ctx.say(`${T} descongelou com o calor do golpe!`, 'status'); }
  if (t.boss) await aplicarEfeitosChefe(t, aposDanoNoChefe(t, total), ctx);   // desgasta a couraça, interrompe a carga, muda de fase
  if (u.boss) {                                                               // Ursaluna Bloodmoon: cura uma fração do que causou
    const h = drenoDoChefe(u, total);
    if (h > 0 && u.hp > 0 && u.hp < u.stats.hp) { heal(u, h); up(ctx); await ctx.say(`🌑 ${U} se cura com o dano causado (+${h} HP).`, 'muted'); }
  }
  if (aguentou) await ctx.say(`${T} aguentou firme graças a ${fmt(t.ability)}!`, 'status');
  if (resistiu) await ctx.say(`${T} aguentou o golpe!`, 'status');
  if (faixa) await ctx.say(`${T} aguentou com 1 de HP usando a Faixa de Foco! (item gasto)`, 'status');
  // itens segurados de quem ataca: Sino-Concha drena, Orbe da Vida cobra HP; Elmo Rochoso machuca quem encostou
  const si = seg(u);
  if (si.drenaDano && total > 0 && u.hp > 0 && u.hp < u.stats.hp) { const h = Math.max(1, Math.floor(total * si.drenaDano)); heal(u, h); up(ctx); await ctx.say(`${U} recuperou ${h} HP com o Sino-Concha.`, 'good'); }
  if (si.recuoPorGolpe && total > 0 && u.hp > 0 && !indireto(u) && !area.respingo) { const d = Math.max(1, Math.floor(u.stats.hp * si.recuoPorGolpe)); u.hp = Math.max(0, u.hp - d); up(ctx); await ctx.say(`O Orbe da Vida cobra o preço: ${U} perdeu ${d} HP.`, 'hit'); }
  if (encostou && seg(t).espetos && u.hp > 0 && !indireto(u)) { const d = Math.max(1, Math.floor(u.stats.hp * seg(t).espetos)); u.hp = Math.max(0, u.hp - d); up(ctx); await ctx.say(`${U} se espetou no Elmo Rochoso de ${T}! (−${d})`, 'hit'); }
  await comerFruta(t, ctx, hu.unnerve); await comerFruta(u, ctx, ht.unnerve);                 // Frutas Oran/Sitrus na hora do aperto (Unnerve trava o OUTRO lado)
  // Moxie, Chilling Neigh, Grim Neigh: derrubar o alvo sobe um atributo de quem derrubou; Beast Boost sobe o MAIOR atributo base (empate: Atk>Def>SpA>SpD>Spe)
  if (t.hp <= 0 && total > 0 && u.hp > 0 && hu.aoNocautear) {
    await ctx.say(`${U} ganhou moral com ${fmt(u.ability)}!`, 'good');
    await mudarEstagios(u, [{ stat: hu.aoNocautear[0], change: hu.aoNocautear[1] }], ctx, u);
  }
  if (t.hp <= 0 && total > 0 && u.hp > 0 && hu.aoNocautearMaior) {
    await ctx.say(`${U} ganhou moral com ${fmt(u.ability)}!`, 'good');
    await mudarEstagios(u, [{ stat: maiorStatBase(u), change: 1 }], ctx, u);
  }
  // Vínculo de Batalha: derrubar o oponente vira Ash-Greninja (virarAshGreninja confere o item e se já não virou)
  if (t.hp <= 0 && total > 0 && u.hp > 0) await virarAshGreninja(u, ctx);
  // Aftermath (só quem encostou) e Innards Out (qualquer nocaute, contato ou não): quem derruba sofre ao derrubar
  if (t.hp <= 0 && total > 0 && encostou && u.hp > 0 && ht.aftermath && !indireto(u) && !quemAbafa(u, ctx)) {
    const d = Math.max(1, Math.floor(u.stats.hp * ht.aftermath)); u.hp = Math.max(0, u.hp - d); up(ctx);
    await ctx.say(`${U} sofreu com ${fmt(t.ability)} de ${T}! (−${d})`, 'hit');
  }
  if (t.hp <= 0 && total > 0 && u.hp > 0 && ht.aoDesmaiarDanoAtacante && !indireto(u)) {
    const d = Math.min(u.hp, hpAntesDoGolpe); u.hp = Math.max(0, u.hp - d); up(ctx);
    await ctx.say(`${U} sofreu o reflexo de ${fmt(t.ability)} de ${T}! (−${d})`, 'hit');
  }

  // Liquid Ooze: o dreno vira DANO em quem drenou, em vez de cura
  if (meta.drain > 0) {
    const h = Math.max(1, Math.floor(total * meta.drain / 100));
    if (ht.dreno === 'inverte') { u.hp = Math.max(0, u.hp - h); up(ctx); await ctx.say(`${fmt(t.ability)} de ${T} vira o dreno ao contrário! ${U} perdeu ${h} HP.`, 'hit'); }
    else { heal(u, h); up(ctx); await ctx.say(`${U} drenou ${h} HP.`, 'good'); }
  }
  else if (meta.drain < 0 && !hu.semDanoRecuo && !indireto(u) && !area.respingo) { // Rock Head e Magic Guard evitam; o total de recuo conta pra Basculegion (evolucao.js)
    const d = Math.max(1, Math.floor(total * -meta.drain / 100)); u.hp = Math.max(0, u.hp - d); u.recuoTotal = (u.recuoTotal || 0) + d; up(ctx); await ctx.say(`${U} sofreu ${d} de dano de recuo.`, 'hit');
  }
  if (meta.heal > 0 && u.hp > 0 && !area.respingo) { heal(u, Math.floor(u.stats.hp * meta.heal / 100)); up(ctx); }

  /* Item do alvo. Três donos do mesmo bloco, porque a regra é idêntica e só muda de onde vem a permissão:
     HABILIDADE Pickpocket (só contato) / Magician (qualquer golpe de dano que acertou) e GOLPE Thief/Covet
     (`esp.roubaItem`, especiais.js). Em todos: só rouba quem está sem item, e Sticky Hold (protegeItem) barra.
     Knock Off (`esp.derrubaItem`) é o caso separado logo abaixo — lá o item se PERDE, então não exige mão vazia. */
  const roubo = hu.roubaItem && (hu.roubaItem === 'ataque' || encostou) ? fmt(u.ability) : esp.roubaItem ? fmt(g.name) : null;
  if (total > 0 && t.hp > 0 && u.hp > 0 && !u.item && t.item && !ht.protegeItem && roubo) {
    const nome = ITEMS[t.item]?.name || 'o item';
    anotarItem(u); anotarItem(t);                 // numa batalha vencida, `batalha.desfazerItens` devolve o que era seu
    u.item = t.item; t.item = null; up(ctx);
    await ctx.say(`${U} roubou <b>${nome}</b> de ${T}! (${roubo})`, 'good');
  } else if (total > 0 && t.item && esp.derrubaItem) {
    // Knock Off: o item não troca de mão, se perde. Sticky Hold barra; quem já segura algo também consegue derrubar.
    if (ht.protegeItem) await ctx.say(`${T} não solta o item de jeito nenhum. (${fmt(t.ability)})`, 'muted');
    else { const nome = ITEMS[t.item]?.name || 'o item'; anotarItem(t); t.item = null; up(ctx); await ctx.say(`${U} derrubou <b>${nome}</b> de ${T}! O item se perdeu${ctx.trocaDePokemon === undefined ? '' : ' (volta se você vencer)'}.`, 'good'); }
  }

  /* 🪨 Smack Down / Thousand Arrows: o alvo é posto no chão de vez (`vol.noSolo: true` — sem origem, pra a
     gravidade passando não o levantar de volta). Daí em diante ele sente o terreno, pisa nas armadilhas e leva
     golpe Terrestre (`regras.noChao`/`eficacia`). Não é efeito secundário: Shield Dust não protege. */
  // 🤹 Fling: o item voou e se perdeu (vai pro `vol.itemGasto`, então o Recycle o traz de volta)
  if (esp.arremessa && u.item) { const nome = ITEMS[u.item]?.name || 'o item'; gastarItem(u); up(ctx); await ctx.say(`${U} arremessou <b>${nome}</b>!`, 'muted'); }
  /* 💀 Destiny Bond e 😤 Grudge: cobram de quem DERRUBOU. Ficam aqui porque é o único ponto que sabe ao mesmo
     tempo quem caiu, quem bateu e com qual golpe — e as duas marcas valem só a rodada (`fimDaRodada`). */
  if (t.hp <= 0 && total > 0 && t.vol.laco && u.hp > 0 && u !== t) {
    delete t.vol.laco; u.hp = 0; up(ctx);
    await ctx.say(`💀 ${T} levou ${U} junto com o Laço do Destino!`, 'hit');
  }
  if (t.hp <= 0 && total > 0 && t.vol.rancor && u.hp > 0 && g.ppLeft !== undefined) {
    delete t.vol.rancor; g.ppLeft = 0;
    await ctx.say(`😤 O rancor de ${T} zerou o PP de ${ctx.golpe(g)}!`, 'status');
  }
  if (esp.poeNoChao && total > 0 && t.hp > 0 && !t.vol.noSolo) {
    const voava = !noChao(t);
    t.vol.noSolo = true; delete t.vol.voando; delete t.vol.balao;
    if (voava) await ctx.say(`${T} foi derrubado no chão!`, 'status');
  }
  // efeitos secundários: Serene Grace dobra a chance; Shield Dust protege o alvo; Sheer Force os apaga (já bateu mais forte lá em cima)
  const chance = p => Math.random() * 100 < p * (hu.chanceSecundaria || 1);
  if (!hu.sheerForce && g.stats.length && chance(meta.statChance || 100)) {
    if (mudaOUsuario(meta) && u.hp > 0 && !area.respingo) await mudarEstagios(u, g.stats, ctx, u);
    else if (!mudaOUsuario(meta) && t.hp > 0 && !ht.semSecundario) await mudarEstagios(t, g.stats, ctx, u);
  }
  if (!hu.sheerForce && t.hp > 0 && !ht.semSecundario) {
    /* `unknown` só é o sorteio do Tri Attack: no Smack Down e no Thousand Arrows a PokéAPI usa o mesmo `unknown`
       (100%) pra dizer "derruba no chão", e sem esta trava todo acerto deles dava status aleatório (#87). */
    const ailSec = meta.ailment === 'unknown' && g.name !== 'tri-attack' ? null : meta.ailment;
    if (ailSec && ailSec !== 'none' && meta.ailChance > 0 && chance(meta.ailChance)) await aplicarStatus(t, ailSec, ctx, false, u);
    if (meta.flinch > 0 && primeiro && !ht.semRecuo && chance(meta.flinch)) t.vol.flinch = true;
    // Stench: golpe que já tem chance própria de recuo não soma outra
    else if (hu.flinchChance && !meta.flinch && primeiro && total > 0 && !ht.semRecuo && chance(hu.flinchChance)) t.vol.flinch = true;
    // Pedra do Rei / Presa Afiada: mesma regra do Stench — só entra se o golpe não tiver recuo próprio
    else if (seg(u).flinchDoItem && !meta.flinch && primeiro && total > 0 && !ht.semRecuo && chance(seg(u).flinchDoItem)) t.vol.flinch = true;
  }
  /* Itens do ALVO que reagem a ter levado o golpe. Ordem: a fruta já cortou o dano lá no cálculo (regras
     `resisteDoItem`), então aqui ela só é consumida e anunciada; o balão estoura com qualquer golpe que acerte;
     a Apólice reage ao super efetivo. Tudo depois do dano, e só se o golpe realmente acertou. */
  if (total > 0) {
    if (frutaDeAperto(t, g.type, ef)) {
      await ctx.say(`${T} comeu a ${ITEMS[t.item]?.name || 'fruta'} e aguentou melhor o golpe!`, 'good');
      t.item = null;
    }
    if (t.vol?.balao) { t.vol.balao = false; t.item = null; await ctx.say(`O Balão de Ar de ${T} estourou!`, 'status'); }
    const pol = seg(t).subeAoLevarSE;
    if (pol && ef > 1 && t.hp > 0) {
      await ctx.say(`A ${ITEMS[t.item]?.name || 'Apólice de Fraqueza'} de ${T} reagiu ao golpe!`, 'good');
      t.item = null;
      await mudarEstagios(t, pol.map(([stat, change]) => ({ stat, change })), ctx, t);
    }
  }
  // reação a ter sido atingido (Steam Engine, Stamina, Weak Armor, Anger Point, Sand Spit…)
  if (total > 0 && t.hp > 0 && ht.aoSerAtingido) await reagirAoGolpe(t, g, crit, ctx);
  // Cotton Down: quem acerta em quem tem a habilidade perde 1 de Velocidade (simplificação: só quem acertou
  // diretamente — no jogo de verdade baixa TODO mundo em campo dos dois lados, mas o motor não expõe essa lista
  // de uma vez só)
  if (total > 0 && t.hp > 0 && u.hp > 0 && ht.algodaoCai) {
    await ctx.say(`O algodão de ${T} flutua sobre ${U}!`, 'status');
    await mudarEstagios(u, [{ stat: 'speed', change: -1 }], ctx, t);
  }
  // contato de verdade (fazContato/regras.js — flag `contact`, não mais o proxy "é físico"): Static, Flame Body,
  // Poison Point, Effect Spore, Gooey; Rough Skin, Iron Barbs
  if (encostou && u.hp > 0) {
    const c = ht.contato;
    if (c && Math.random() * 100 < c.chance) {
      if (c.estagio) {                                                                // Gooey, Tangling Hair: a Velocidade de quem encosta cai
        await ctx.say(`${U} tocou em ${T}...`, 'muted');
        await mudarEstagios(u, [{ stat: c.estagio[0], change: c.estagio[1] }], ctx, t);
      } else if (!u.status && !(c.po && (tiposDefensivos(u).includes('grass') || hab(u).imunePo))) {   // pó não pega Grama nem Overcoat
        const ail = c.sorteio ? sortearPeso(c.sorteio) : c.status;                    // Effect Spore: sono, paralisia ou veneno
        await ctx.say(`${U} tocou em ${T}...`, 'muted'); await aplicarStatus(u, ail, ctx);
      }
    }
    if (ht.contatoDano && !indireto(u)) { const d = Math.max(1, Math.floor(u.stats.hp * ht.contatoDano)); u.hp = Math.max(0, u.hp - d); up(ctx); await ctx.say(`${U} se machucou na ${fmt(t.ability)} de ${T}! (−${d})`, 'hit'); }
    // Mummy / Lingering Aroma (contágio: sua habilidade vira a de quem encostou) e Wandering Spirit (TROCA as duas)
    if (ht.trocaHabilidadeContato && u.ability !== t.ability && !ABILIDADE_TRAVADA(u.ability)) {
      const antiga = u.ability, alvo = t.ability;
      u.abilityAntes ??= antiga; u.ability = alvo;
      if (ht.trocaHabilidadeContato === 'troca') { t.abilityAntes ??= alvo; t.ability = antiga; }
      await ctx.say(`A habilidade ${fmt(alvo)} de ${T} tomou conta de ${U}!`, 'status');
    }
  }
  /* Poison Touch: o golpe de quem tem a habilidade envenena ao ENCOSTAR (Shield Dust protege).
     `toque.qualquer` (Toxic Chain): não precisa encostar, qualquer golpe que acertou serve; `toque.grave` deixa o
     veneno GRAVE (o `vol.toxico`, o mesmo que as toxinas do campo usam). */
  if ((encostou || hu.toque?.qualquer) && hu.toque && total > 0 && t.hp > 0 && !t.status && !ht.semSecundario && Math.random() * 100 < hu.toque.chance) {
    await aplicarStatus(t, hu.toque.status, ctx, false, u);
    if (hu.toque.grave && t.status === hu.toque.status) { t.vol.toxico = 1; await ctx.say(`O veneno em ${T} é grave!`, 'status'); }
  }
  /* Color Change: levar um golpe de dano troca o tipo de quem apanhou pelo tipo DO GOLPE (sem limite por entrada,
     ao contrário do Protean). Mesmo caminho do Soak: `vol.tipos`. */
  if (total > 0 && t.hp > 0 && ht.tipoDoGolpeRecebido && !(tiposDe(t).length === 1 && tiposDe(t)[0] === g.type)) {
    t.vol.tipos = [g.type];
    await ctx.say(`${T} mudou de cor e virou do tipo ${TYPE_PT[g.type] || g.type}!`, 'status');
  }
  /* Cursed Body: 30% de desativar o golpe que acertou. É a MESMA trava do Disable (`vol.desativado`, lida por
     regras.golpesPermitidos), então a IA, as telas e o motor respeitam sem nenhuma regra nova. Não empilha:
     quem já está com um golpe desativado não leva outro. */
  if (total > 0 && u.hp > 0 && ht.corpoMaldito && !u.vol.desativado && u !== t && Math.random() * 100 < ht.corpoMaldito) {
    u.vol.desativado = { golpe: g.name, turnos: TURNOS_TRAVA.disable };
    await ctx.say(`${fmt(g.name)} de ${U} foi desativado pelo ${fmt(t.ability)} de ${T}!`, 'status');
  }
  /* Sair de campo por causa do golpe (o que nos jogos seria trocar de Pokémon). Cada um só acontece se o ctx souber tirar
     alguém de campo (single player) — e na ordem em que valem: o golpe que empurra, o item, a habilidade de quem apanhou. */
  if (esp.forcaSaida && total > 0 && t.hp > 0 && u.hp > 0) await sairDeCampo(t, ctx, 'forcada');           // Dragon Tail, Circle Throw
  if (esp.revezamento && total > 0 && u.hp > 0) await revezar(u, ctx);                                     // U-turn, Volt Switch, Flip Turn
  if (total > 0 && t.hp > 0 && u.hp > 0 && seg(t).cartaoVermelho && u !== t) {                              // Red Card: quem atacou sai; o cartão se gasta
    t.item = null; up(ctx);
    await ctx.say(`${T} mostrou o Cartão Vermelho para ${U}!`, 'status');
    await sairDeCampo(u, ctx, 'forcada');
  }
  // Wimp Out / Emergency Exit: cruzou a metade do HP por causa deste golpe → sai (nos SEUS Pokémon principais não vale)
  if (total > 0 && t.hp > 0 && ht.saiComPoucoHp && hpAntesDoGolpe > t.stats.hp * ht.saiComPoucoHp && t.hp <= t.stats.hp * ht.saiComPoucoHp) {
    await sairDeCampo(t, ctx, 'medo');                                                                      // quem narra é o ctx ("X foge assustado!")
  }
  return 'acertou';
}

// Fim do turno de um Pokémon em pé: queimadura/veneno (grave cresce a cada turno), Leech Seed, e habilidades de fim
// de turno (Speed Boost, Shed Skin)
export async function fimDeTurno(m, ctx) {
  if (m.hp <= 0) return;
  const h = hab(m), clima = climaDoCtx(ctx);
  // Taunt, Encore e Disable contam turnos (regras.passarTravas devolve o que acabou agora)
  const AVISO_TRAVA = { provocado: 'não está mais provocado.', encore: 'não está mais sob Encore.', desativado: 'pode usar o golpe desativado de novo.', voando: 'voltou ao chão.' };
  for (const fim of passarTravas(m)) await ctx.say(`${ctx.nome(m)} ${AVISO_TRAVA[fim]}`, 'muted');
  m.vol.turnosEmCampo = (m.vol.turnosEmCampo || 0) + 1;                                // Slow Start
  if (clima) {
    // areia/granizo castigam quem não é do tipo certo; chuva/sol curam ou machucam quem tem a habilidade certa
    const dano = danoClima(clima, m);
    if (dano) { m.hp = Math.max(0, m.hp - dano); up(ctx); await ctx.say(`${ctx.nome(m)} se machuca com ${CLIMAS[clima].nome.toLowerCase()}. (−${dano})`, 'hit'); }
    const cura = h.curaClima?.[clima];
    if (m.hp > 0 && cura && m.hp < m.stats.hp) { const n = Math.max(1, Math.floor(m.stats.hp * cura)); heal(m, n); up(ctx); await ctx.say(`${ctx.nome(m)} se recupera com o tempo. (+${n}, ${fmt(m.ability)})`, 'good'); }
    const castigo = h.danoClimaProprio?.[clima];
    if (m.hp > 0 && castigo) { const n = Math.max(1, Math.floor(m.stats.hp * castigo)); m.hp = Math.max(0, m.hp - n); up(ctx); await ctx.say(`${ctx.nome(m)} sofre com ${CLIMAS[clima].nome.toLowerCase()}. (−${n}, ${fmt(m.ability)})`, 'hit'); }
    if (m.hp > 0 && h.curaStatusClima === clima && m.status) { m.status = null; m.sleep = 0; delete m.vol.toxico; up(ctx); await ctx.say(`${ctx.nome(m)} se curou com a chuva! (${fmt(m.ability)})`, 'good'); }
    if (m.hp <= 0) return;
  }
  if (h.curaStatusFimTurno && m.status && Math.random() < h.curaStatusFimTurno) {
    m.status = null; m.sleep = 0; delete m.vol.toxico; up(ctx); await ctx.say(`${ctx.nome(m)} trocou de pele e se curou! (${fmt(m.ability)})`, 'good');
  }
  /* Poison Heal: o veneno CURA 1/8 em vez de machucar. Magic Guard: nem veneno nem queimadura tiram HP. */
  const d = h.curaComVeneno && m.status === 'poison' ? 0 : indireto(m) ? 0 : danoResidual(m);
  if (h.curaComVeneno && m.status === 'poison' && m.hp < m.stats.hp) {
    const n = Math.max(1, Math.floor(m.stats.hp * h.curaComVeneno)); heal(m, n); up(ctx);
    await ctx.say(`${ctx.nome(m)} se recupera com o veneno! (+${n}, ${fmt(m.ability)})`, 'good');
  }
  if (d) { m.hp = Math.max(0, m.hp - d); up(ctx); await ctx.say(`${ctx.nome(m)} sofreu com ${m.status === 'burn' ? 'a queimadura' : 'o veneno'}. (−${d})`, 'hit'); }
  if (m.status === 'poison' && m.vol.toxico) m.vol.toxico = Math.min(15, m.vol.toxico + 1);
  if (m.hp > 0 && m.vol.semente != null && !indireto(m)) {
    const s = Math.min(m.hp, Math.max(1, Math.floor(m.stats.hp / 8)));
    m.hp -= s; up(ctx); await ctx.say(`A semente drenou ${ctx.nome(m)}. (−${s})`, 'hit');
    const quem = ctx.monPorRef?.(m.vol.semente);
    if (quem && quem.hp > 0 && quem.hp < quem.stats.hp) { heal(quem, s); up(ctx); await ctx.say(`${ctx.nome(quem)} recuperou ${s} HP.`, 'good'); }
  }
  /* 🪢 Aperto (Bind, Fire Spin & cia.): 1/8 do HP máximo por turno, 4–5 turnos. Magic Guard (`indireto`) não
     sente o dano, mas continua PRESO — nos jogos a habilidade poupa o HP, não solta o abraço. */
  if (m.hp > 0 && m.vol.aperto) {
    if (!indireto(m)) {
      const d = Math.max(1, Math.floor(m.stats.hp * APERTO_FRACAO));
      m.hp = Math.max(0, m.hp - d); up(ctx);
      await ctx.say(`${ctx.nome(m)} se debate, preso. (−${d})`, 'hit');
    }
    if (--m.vol.aperto.turnos <= 0) { delete m.vol.aperto; await ctx.say(`${ctx.nome(m)} se soltou!`, 'muted'); }
    if (m.hp <= 0) return;
  }
  // 👻 Maldição: 1/4 do HP por turno, até o fim da luta (quem lançou pagou metade do próprio HP por isso)
  if (m.hp > 0 && m.vol.maldicao && !indireto(m)) {
    const d = Math.max(1, Math.floor(m.stats.hp / 4));
    m.hp = Math.max(0, m.hp - d); up(ctx);
    await ctx.say(`${ctx.nome(m)} sofre com a maldição. (−${d})`, 'hit');
    if (m.hp <= 0) return;
  }
  // 🐙 Octolock: aperta mais a cada turno — Defesa e Def. Esp. caem
  if (m.hp > 0 && m.vol.octolock) {
    await mudarEstagios(m, [{ stat: 'defense', change: -1 }, { stat: 'special-defense', change: -1 }], ctx);
  }
  // 😱 Pesadelo: 1/4 do HP por turno, e só enquanto o alvo DORME (acordar desfaz sozinho)
  if (m.hp > 0 && m.vol.pesadelo) {
    if (m.status !== 'sleep') { delete m.vol.pesadelo; await ctx.say(`${ctx.nome(m)} acordou — os pesadelos passaram.`, 'muted'); }
    else if (!indireto(m)) {
      const d = Math.max(1, Math.floor(m.stats.hp / 4));
      m.hp = Math.max(0, m.hp - d); up(ctx);
      await ctx.say(`${ctx.nome(m)} se contorce num pesadelo. (−${d})`, 'hit');
      if (m.hp <= 0) return;
    }
  }
  // 🌱 Raiz (Ingrain) e 💧 Véu de Água (Aqua Ring): 1/16 do HP máximo por turno, cada um por conta
  for (const [chave, texto] of [['raiz', 'se alimenta pelas raízes'], ['anel', 'se recupera no véu de água']]) {
    if (m.hp > 0 && m.vol[chave] && m.hp < m.stats.hp) {
      const n = Math.max(1, Math.floor(m.stats.hp / 16)); heal(m, n); up(ctx);
      await ctx.say(`${ctx.nome(m)} ${texto}. (+${n})`, 'good');
    }
  }
  // Campo de Grama: cura quem está no chão
  const terr = terrenoDoCtx(ctx), tCura = TERRENOS[terr]?.cura;
  if (tCura && m.hp > 0 && noChao(m) && m.hp < m.stats.hp) {
    const n = Math.max(1, Math.floor(m.stats.hp * tCura)); heal(m, n); up(ctx);
    await ctx.say(`${ctx.nome(m)} se recupera na grama alta. (+${n})`, 'good');
  }
  // item segurado: Restos curam, Lodo Negro cura Venenoso e machuca o resto (segurados.js)
  const di = fimDeTurnoDoItem(m, tiposDefensivos(m));
  if (di > 0 && m.hp > 0) { heal(m, di); up(ctx); await ctx.say(`${ctx.nome(m)} recuperou ${di} HP com ${nomeDoItem(m)}.`, 'good'); }
  else if (di < 0 && m.hp > 0 && !indireto(m)) { m.hp = Math.max(0, m.hp + di); up(ctx); await ctx.say(`${nomeDoItem(m)} machucou ${ctx.nome(m)}. (${di})`, 'hit'); }
  // Orbe de Fogo/Tóxico: tenta se auto-infligir o status a cada fim de turno sem status (aplicarStatus já cobre
  // imunidade de tipo — Fogo não queima, Venenoso/Aço não envenena); 'toxic' é veneno GRAVE, como o golpe Toxic.
  const ailOrbe = statusDoItem(m);
  if (ailOrbe && m.hp > 0 && await aplicarStatus(m, ailOrbe, ctx, false, null) && seg(m).statusFimTurno === 'toxic') m.vol.toxico = 1;
  if (m.hp > 0 && h.fimTurno) await mudarEstagios(m, [{ stat: h.fimTurno, change: 1 }], ctx);
  // Moody: todo fim de turno, +2 num atributo sorteado e −1 em outro (nunca o mesmo — tira `sobe` da lista ANTES
  // de sortear `desce`, então não precisa sortear de novo até sair diferente, o que travaria pra sempre com
  // Math.random mockado num valor fixo, como em teste)
  if (m.hp > 0 && h.moody) {
    const stats = Object.keys(m.vol.stages);
    const sobe = stats[rand(0, stats.length - 1)];
    const restantes = stats.filter(s => s !== sobe);
    const desce = restantes[rand(0, restantes.length - 1)];
    await ctx.say(`A instabilidade de ${ctx.nome(m)} muda seus atributos!`, 'status');
    await mudarEstagios(m, [{ stat: sobe, change: 2 }, { stat: desce, change: -1 }], ctx, m);
  }
  /* Bad Dreams (Darkrai): no fim do turno, quem está DORMINDO do outro lado perde 1/8 do HP máximo. Pede a lista
     do outro lado — `ctx.oponentesDe`, o mesmo gancho do `aliadosDe` do Friend Guard, presente nos dois ctx.
     Magic Guard do adormecido segura o dano (é dano indireto). */
  if (m.hp > 0 && h.pesadelo) {
    for (const o of (ctx.oponentesDe?.(m) || [])) {
      if (o.status !== 'sleep' || o.hp <= 0 || indireto(o)) continue;
      const n = Math.max(1, Math.floor(o.stats.hp * h.pesadelo));
      o.hp = Math.max(0, o.hp - n); up(ctx);
      await ctx.say(`${ctx.nome(o)} tem pesadelos com ${ctx.nome(m)}. (−${n})`, 'hit');
    }
  }
  /* ⏳ Os que resolvem no fim do turno SEGUINTE, e por isso contam ao fim de cada um. Ficam juntos aqui, depois
     do dano e da cura, porque é essa a ordem dos jogos: o desejo cura DEPOIS dos restos, e o bocejo só pega quem
     chegou vivo ao fim do turno. A 💀 Canção Final vem por último — ela derruba sem olhar HP. */
  if (m.hp > 0 && m.vol.desejo && --m.vol.desejo.turnos <= 0) {
    const n = m.vol.desejo.cura; delete m.vol.desejo;
    if (m.hp < m.stats.hp) { heal(m, n); up(ctx); await ctx.say(`🌟 O desejo de ${ctx.nome(m)} se realiza! (+${n})`, 'good'); }
  }
  if (m.hp > 0 && m.vol.bocejo && --m.vol.bocejo <= 0) {
    delete m.vol.bocejo;
    await aplicarStatus(m, 'sleep', ctx, true, null);
  }
  if (m.hp > 0 && m.vol.cancaoFinal && --m.vol.cancaoFinal <= 0) {
    delete m.vol.cancaoFinal; m.hp = 0; up(ctx);
    await ctx.say(`💀 A canção se completou: ${ctx.nome(m)} desmaia!`, 'hit');
    return;
  }
  if (m.hp > 0 && m.vol.cancaoFinal) await ctx.say(`💀 A canção ecoa em ${ctx.nome(m)}: ${m.vol.cancaoFinal} turno(s).`, 'muted');
  await comerFruta(m, ctx);
  await ajustarForma(m, ctx);
}
/* Frutas que o Pokémon come sozinho (Oran, Sitrus, Lum): checadas no fim do turno e logo depois de levar dano.
   `travado` = true quando quem ele acabou de trocar golpe tem Unnerve (golpe.executar manda `hu.unnerve`/
   `ht.unnerve` do OUTRO lado) — simplificação: só vale nessa troca direta, não no fim de turno (que não sabe
   quem é "o oponente" de cada Pokémon sem uma lista de lados pronta). */
export async function comerFruta(m, ctx, travado = false, forcar = false) {
  if (travado) return;
  // `forcar` = ☕ Teatime: come a fruta queira ou não, mesmo sem a condição dela ter chegado (frutaAgora diz não)
  const f = forcar ? SEGURADOS[m?.item] : frutaAgora(m);
  if (!f) return;
  const h = hab(m), nome = nomeDoItem(m);
  m.item = null;
  if (f.curaStatus) { m.status = null; m.sleep = 0; delete m.vol.toxico; up(ctx); await ctx.say(`${ctx.nome(m)} comeu a ${nome} e se curou!`, 'good'); }
  else {
    const cura = h.ripen ? f.cura * 2 : f.cura;   // Ripen: a fruta de cura recupera o DOBRO
    heal(m, cura); up(ctx);
    await ctx.say(`${ctx.nome(m)} comeu a ${nome} e recuperou ${cura} HP.`, 'good');
  }
  // Cheek Pouch: comer QUALQUER fruta recupera mais HP, mesmo as que não curam HP nenhum (Lum)
  if (h.curaBerryExtra && m.hp > 0 && m.hp < m.stats.hp) {
    const extra = Math.max(1, Math.floor(m.stats.hp * h.curaBerryExtra));
    heal(m, extra); up(ctx);
    await ctx.say(`${fmt(m.ability)} de ${ctx.nome(m)} recupera mais ${extra} HP!`, 'good');
  }
}
