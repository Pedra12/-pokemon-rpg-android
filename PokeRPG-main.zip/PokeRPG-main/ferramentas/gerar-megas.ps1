# Gera js/dados-megas.js a partir da PokéAPI: as formas de Mega Evolução e de Reversão Primitiva.
# Rode com:  powershell -File ferramentas/gerar-megas.ps1
#
# Por que é uma tabela e não uma busca em tempo real: `loadSpecies` (api.js) guarda só a forma padrão da espécie,
# então o jogo não tem como saber sozinho que Charizard tem duas Megas. Tabela estática também funciona offline
# e dá pra testar.
# A forma em si (status, tipos, habilidade, sprite) continua vindo da API pelo nome — aqui só fica o índice.
#
# Grava SEM BOM: `Set-Content -Encoding utf8` no PowerShell 5.1 escreve BOM, e BOM quebra parser (foi o que
# derrubou o deploy do Supabase).

$ErrorActionPreference = 'Stop'
$lista = (Invoke-RestMethod "https://pokeapi.co/api/v2/pokemon?limit=20000" -TimeoutSec 120).results
# -mega-z: as Megas de Legends Z-A de Absol, Garchomp e Lucario (segunda opção ao lado da Mega comum, como o X/Y do Charizard)
$formas = $lista | Where-Object { $_.name -match '(-mega(-[xyz])?|-primal)$' }
if ($formas.Count -lt 40) { throw "veio pouca coisa da PokeAPI ($($formas.Count) formas)" }

<#
  Mesmo cuidado de gerar-mapas.ps1 (2ª auditoria, 30/09/2026): nome vindo da PokéAPI virando literal de
  JavaScript que vai pra todo jogador (js/dados-megas.js é importado por js/dados.js). Uma apóstrofe upstream
  fecha o literal — no melhor caso derruba o jogo com erro de sintaxe, no pior executa código no navegador de
  quem joga. Nome de forma/espécie é sempre minúsculo com hífen: fora disso o gerador FALHA aqui em vez de emitir.
#>
function JsStr($s) {
  $t = [string]$s
  if ($t -notmatch "^[a-z0-9-]+$") { throw "nome inesperado da PokeAPI (nao vou emitir isso): '$t'" }
  "'" + $t + "'"
}
# Rótulo montado por nós (Rotulo) — tem espaço e maiúscula, então escapa em vez de exigir o padrão.
function JsTexto($s) { "'" + ([string]$s -replace '\\', '\\' -replace "'", "\'" -replace "`r|`n", ' ') + "'" }

# nome de exibição: "Mega Charizard X" / "Groudon Primitivo"
function Rotulo($especie, $forma) {
  # os parênteses em volta do -replace são obrigatórios: sem eles o PowerShell lê como 2 argumentos do método
  $base = (Get-Culture).TextInfo.ToTitleCase(($especie -replace '-', ' '))
  if ($forma -match '-primal$') { return "$base Primitivo" }
  if ($forma -match '-mega-x$') { return "Mega $base X" }
  if ($forma -match '-mega-y$') { return "Mega $base Y" }
  if ($forma -match '-mega-z$') { return "Mega $base Z" }
  return "Mega $base"
}

# A ESPÉCIE vem da API, não de cortar o sufixo do nome. Cortar erra em forma de forma: 'meowstic-male-mega' daria
# 'meowstic-male', que não é espécie nenhuma — e o jogo casa pelo `speciesName` ('meowstic'). O GraphQL da PokéAPI
# está com um retrato antigo (não tem as Megas novas), então é o REST mesmo, uma requisição por forma.
$dados = @()
foreach ($f in $formas) {
  $p = Invoke-RestMethod $f.url -TimeoutSec 60
  $dados += [pscustomobject]@{ nome = $p.name; id = $p.id; especie = $p.species.name; base = ($p.name -replace '-(mega(-[xyz])?|primal)$', '') }
  Start-Sleep -Milliseconds 60   # não afogar a PokéAPI
}

$porEspecie = [ordered]@{}
foreach ($g in ($dados | Group-Object especie)) {
  # Preferir as formas CANÔNICAS (base == espécie): é o X/Y do Charizard e do Mewtwo, escolha de verdade pra quem
  # joga. Quando a espécie só tem Mega de uma forma específica (Meowstic macho/fêmea, Tatsugiri curly/droopy/
  # stretchy), fica só a primeira: o jogo não guarda gênero nem forma cosmética, então oferecer três "Mega
  # Tatsugiri" idênticas na tela seria escolha falsa.
  $canonicas = @($g.Group | Where-Object { $_.base -eq $g.Name })
  $usar = if ($canonicas.Count) { $canonicas } else { @($g.Group | Select-Object -First 1) }
  $itens = foreach ($d in $usar) {
    $primal = if ($d.nome -match '-primal$') { ', primal: true' } else { '' }
    "{ forma: $(JsStr $d.nome), id: $($d.id), nome: $(JsTexto (Rotulo $g.Name $d.nome))$primal }"
  }
  $porEspecie[$g.Name] = @($itens)
}

$linhas = foreach ($e in $porEspecie.Keys) { "  $(JsStr $e): [" + ($porEspecie[$e] -join ', ') + "]," }
$corpo = ($linhas -join "`n").TrimEnd(',')

$saida = @"
/* GERADO por ferramentas/gerar-megas.ps1 a partir da PokeAPI - nao editar a mao (rode o script de novo).
   Formas de Mega Evolucao e de Reversao Primitiva, por especie ($($porEspecie.Count) especies, $($formas.Count) formas).
   Charizard, Mewtwo e Raichu tem duas (X e Y), e Absol, Garchomp e Lucario tem a Mega comum e a Z: por isso o valor e sempre uma LISTA.
   So o indice mora aqui; status, tipos, habilidade e sprite da forma vem da API pelo nome (campo forma), como
   qualquer outro Pokemon - e sao pre-carregados no comeco da batalha pra nao esperar rede no meio do turno. */
export const MEGAS = {
$corpo
};
export const megasDe = especie => MEGAS[especie] || [];
export const temMega = especie => !!MEGAS[especie];
// Groudon e Kyogre nao "megaevoluem": o nome da mecanica deles e Reversao Primitiva (mesma mecanica, outro nome)
export const ehPrimal = forma => !!forma?.primal;
"@

$destino = Join-Path $PSScriptRoot '..\js\dados-megas.js'
[System.IO.File]::WriteAllText($destino, $saida, (New-Object System.Text.UTF8Encoding $false))
Write-Host "ok: $($formas.Count) formas em $($porEspecie.Count) especies -> js/dados-megas.js"
