# Como cada coisa foi construída

Narrativas de implementação tiradas do `CLAUDE.md` em 29/09/2026 (ver docs/historico.md pro mesmo motivo). O
CLAUDE.md guarda a REGRA (o que não pode quebrar); aqui fica o COMO e o PORQUÊ: o que foi considerado, o que foi
simplificado de propósito e o que ficou de fora. Consulte ao mexer na área.

## Índice
- 🔒 Pokémon de missão (08/10/2026)
- 🏋 Itens de treino (EVs, IV, habilidade) + a loja no celular (04/10/2026)
- Ovos e criação no esconderijo (02/10/2026)
- Gênero (02/10/2026)
- Congelamento: o que faltava (02/10/2026)
- Golpes de peso e de atributo trocado (02/10/2026)
- Evento semanal, chefes e Arena
- Loja de preparo, Hall da Fama e Sala de Raide
- Habilidades: as 7 levas
- Gimmicks (Mega, Tera, Z-Move, Gigantamax) e as do inimigo/co-op
- Itens no multiplayer · Reordenar golpes · Vínculo de Batalha
- A revisão do multiplayer (29/09/2026)
- A auditoria de segurança (29/09/2026)
- Sprites, animações e microinterações
- Som: cries e música procedural (30/09/2026)
- Troca de tipo, Endeavor no chefe e a leva de itens de 30/09/2026
- Anúncios e privacidade

---

## 🔒 Pokémon de missão (08/10/2026)

Pedido do usuário: *"quero que o Gholdengo seja um pokemon de missão, somente após um valor muito alto de gold em
todas as suas runs, desbloqueia ele"* — mais "pense em outros pokemons que só desbloqueiam com missões". A ideia é
ter espécie que **não existe no mundo** até a conta pagar um preço de carreira.

### O que é
`dados.ESPECIES_MISSAO`, uma linha por espécie: `{ id, icone, gen, nome, campo, alvo, desc }`.

| Pokémon | Missão | Campo medido |
|---|---|---|
| 🪙 Gholdengo | ₽100.000.000 somando o PICO de cada jornada | `dinheiroCarreira` (novo) |
| 👻 Spiritomb | 180.000 derrotados | `abates.total` |
| ⚙️ Melmetal | 50.000 derrotados do tipo Aço | `abates.tipoAlvo.steel` |
| 🥀 Shedinja | 100 ovos chocados | `ovosChocados` |
| ✨ Arceus | as 9 Gens fechadas no Roguelike | `gensRoguelike` |

Os alvos de Spiritomb (1.080 → 180.000) e Melmetal (1.000 → 50.000) foram subidos pelo usuário na mesma conversa:
o primeiro número era "dez por alma presa na pedra", bonito e pequeno demais pra uma missão de carreira.

### Por que a máquina das badges, e não uma nova
Uma missão de conta é literalmente "um campo do progresso permanente com um alvo" — que é a definição de
`badges.medirPorDado`. Então `missoesDeEspecie(ctx)` roda a MESMA medida sobre o MESMO `contextoBadges`, e sai de
graça: a garantia de que **nunca encolhe** (progresso-conta, união por chave de jornada), o `MEDIDAS` como lista do
que dá pra medir, e um teste que recusa `campo` fora dela (missão impossível em silêncio é o pior defeito possível
numa conquista de carreira). O único campo novo é `dinheiroCarreira` — a soma de `maxDinheiro` por jornada, a
mesma fonte que o saldo da Arena já usava (ele tira 10% disto).

**Por que o PICO e não o total que passou pela mão**: o livro-caixa guarda `maxDinheiro` (o maior saldo da jornada),
não o faturamento. Inventar o total exigiria um contador novo no save e uma migração que não alcança quem já jogou.
₽100 milhões sobre o pico é ~35 jornadas muito bem jogadas (uma run boa chega a ₽3 milhões, número do usuário).

### Um corte só
O portão é `mapas.rotaNaJornada`, a porta única da rota na jornada (`estado.zone`/`rotasAtuais`): tirar a espécie do
`pool` ali filtra de uma vez o sorteio, a taxa mostrada na tela, a Pokédex da rota e a caça shiny — nenhuma tela
promete um bicho que o sorteio não entrega (foi o bug #74/#75, com outro assunto). Ela devolve o MESMO objeto
quando não há nada a cortar, porque isso roda a cada render. `mapas.especiesDaGen` (de onde sai a equipe dos
treinadores) corta sempre: Pokémon de missão não é bicho de estimação de ninguém, nem depois de liberado.

Quem a rota consulta é **`S.liberadas`**, a foto que `criacao.iniciarJornada` tira da conta — não a carreira ao
vivo. Dois motivos: ler a carreira a cada render custa (localStorage + soma de todas as jornadas), e a vantagem de
conta valer na jornada SEGUINTE é a convenção que as badges já criaram. Save antigo não tem o campo e por isso joga
com tudo trancado até a próxima jornada.

Não passa por `G.semVantagens`: jogar sem vantagens tira item e dinheiro de presente, não tira **conteúdo** do
mundo — quem só joga assim nunca encontraria a espécie.

### O que foi decidido e por quê
- **O desbloqueio devolve a espécie às ROTAS, não à tela de criação** (opção escolhida pelo usuário). Dali em diante
  o desbloqueio normal do Roguelike (derrotar 10 / amizade 5 / evoluir) é que a torna jogável — zero regra nova, e
  a missão continua sendo um marco e não um atalho.
- **A missão é pública, inclusive o sprite.** Badge tem `oculta`; aqui nada é escondido: uma missão secreta de 180
  mil derrotados nunca seria tentada. O segredo não é o Pokémon, é o esforço.
- **A Pokédex completa daquela Gen espera a missão** (`pokedex-conta.gensCompletas` varre a faixa de ids). É
  consequência consciente, e virou a narrativa: a espécie é o último selo da região. Gen 4 tem duas (Spiritomb e
  Arceus) por escolha do usuário.
- **Nada é gravado no progresso permanente.** A conta é refeita do `ctx` a cada vez — missão cumprida não se desfaz
  porque a FONTE não encolhe, não porque alguém marcou um booleano. Menos estado, menos migração.

### O que ficou de fora
Prêmio extra pela missão (item, dinheiro): a espécie é o prêmio. Aviso na hora exata em que a missão fecha no meio
de uma run: o lugar de descobrir é a tela 🏅 Conquistas e a linha de log no começo da jornada seguinte, que é
quando o desbloqueio passa a valer de verdade.

---

## Ovos e criação no esconderijo (02/10/2026)

Pedido do usuário: "pokémons que estão no esconderijo podem aleatoriamente breedar, dando o pokemon que seria a
mistura, **mas secretamente**; os passos para chocar um ovo, leve em consideração as explorações". Mais as duas
conquistas: 100 ovos chocados → toda run começa com ovo de pseudo-lendário; 1.000 → ovo de lendário ou mítico.

**Por que caiu no esconderijo**: até aqui ele era um depósito — quem estava lá não lutava, não ganhava XP e não
fazia absolutamente nada. Criar dá uma razão pra ter 30 parceiros guardados em vez de 2.

### Onde cada parte mora
- **`js/ovos.js`** (novo, PURO, testado em `tests/ovos.test.js`): as constantes, `passosParaChocar`, `acharPar`,
  `tentarCruzar`, `ivsHerdados`, `golpeHerdado`, `criarOvo`, `ovoDeBadge`, `andarOvos`, `tirarOvo`. Mesmo molde do
  `esconderijo.js`: recebe o save, devolve o save mexido, sem DOM e sem rede.
- **`amizade.cuidarDosOvos`** = a parte com rede e narração (chocar de verdade precisa de `resolvePokemon`,
  `makeMon`, `loadGrowth`). Ficou em `amizade.js` em vez de um arquivo novo porque é exatamente o que o
  `recrutar` de lá já faz — `acolher`, `registrar`, `say` — e o grafo já permitia (`amizade` está acima de
  `pokemon`).
- **`mundo.explore`** chama com `try` próprio: ovo é bônus, não pode custar a exploração de ninguém.
- **`render.blocoOvos`** desenha a barra no painel de Aliados. **Nunca interpola `ovo.especie`** — é o segredo.
- **`render.fichaGuardado`** (08/10/2026) é a ficha de quem está guardado, pedido do usuário: "quero ver as
  informações dos pokés que estão no esconderijo, pra escolher qual pegar de lá com mais precisão" — e, como o
  filhote herda 3 IVs do melhor dos dois pais, isso é também a tela de escolher o CASAL. Reusa as mesmas peças do
  cartão de aliado (`tabelaStats`, `natureLabel`, `blocoEvolucao`, `blocoHabilidade`, `listaGolpes`), só em
  **leitura**: `listaGolpes(A)` **sem `quem`** já cai no modo sem ▲▼, e `blocoItem` ficou FORA de propósito — o
  `data-quem` dos botões de item aponta pra `S.aliados[i]`, e o índice do esconderijo é de outro bicho (mexer
  daqui trocaria o item do aliado errado). O item segurado aparece como texto. **A chave de `G.abertos` virou
  TEXTO** (`"0"` = aliado, `"g0"` = esconderijo): os dois índices começam em 0, e o `+i` de antes misturava os dois
  `<details>`.

### A leva de criação (08/10/2026) — os "buracos conscientes" que o usuário pediu pra fechar
A seção acima listava o que ficou de fora da primeira versão. O usuário leu a lista e escolheu cinco: Pedra Eterna,
Nó do Destino, Ditto, "o problema dos sem gênero" e golpes-ovo, mais a forma regional do filhote. O que entrou:

| Item | Onde | Regra |
|---|---|---|
| **Pedra Eterna** | `ovos.naturezaHerdada` + `ITENS_CRIACAO` | Quem segura passa a natureza. Os dois segurando = sorteio entre as duas (regra da Gen 5+). `null` = sorteio normal, e `makeMon` nem recebe a opção |
| **Nó do Destino** | `ovos.quantosIvsHerdados` | `IVS_HERDADOS` (3) → `IVS_COM_NO` (5). Um dos dois basta, os dois **não acumulam**. Sobe QUANTOS, nunca QUAIS: os Power Items continuam fora |
| **Ditto** | `ovos.parCompativel`/`acharPar` | Reconhecido pelo **grupo-ovo** `ditto`, nunca pelo nome da espécie. Cruza com qualquer um que ponha ovo; Ditto × Ditto não; `no-eggs` nem com ele |
| **Sem gênero** | a mesma função | Era "nunca cruza"; virou "só com Ditto", que é a regra dos jogos. Nenhuma linha nova: cai do caso do Ditto |
| **Golpe-ovo** | `ovos.golpeOvo` | Lista do `learnset.extras` do FILHOTE (`metodo: 'egg'`), que já está em cache — zero busca nova pra saber quais são |
| **Forma regional** | `amizade.talvezPorOvo` | Mãe que é forma (`data.name !== speciesName`) → `mapas.formaRegionalDaGen(base, gen)`. O `especie` do ovo passa a poder ser um id de FORMA |

Decisões que valem registrar:
- **Os dois itens não são `ITENS_SEGURADOS`.** Ali todo item tem de ter linha em `segurados.SEGURADOS` (o teste cobra —
  foi o que pegou a Pedra do Rei), e estes não fazem nada em batalha. Tabela própria `ITENS_CRIACAO` + divisão
  própria na loja/mochila (🥚 Criação, antes de 🎒 Para segurar em `CATEGORIAS_ITEM`, porque eles TÊM a marca
  `segurado`). É a exceção consciente ao "`seg(m)` é a porta única do item": lá se lê EFEITO, aqui se lê
  IDENTIDADE (`segura(m, id)`, um ajudante só, dentro de `ovos.js`).
- **O golpe-ovo é resolvido no CHOCO, não ao pôr o ovo.** Ao chocar já se carregou o `data` do filhote, e a lista de
  golpes-ovo vem dentro dele: a única busca nova é o `loadMove` do golpe escolhido, com `catch` — falhou, o
  filhote nasce sem ele. Resolver na postura custaria `loadPokemon(base)` numa exploração em cada 20, pra guardar
  um dado que já estaria em mãos na outra ponta. O que o ovo guarda é `pais`: só os NOMES dos golpes dos dois, pro
  confronto com a lista (os pais podem ter sido despedidos nas 400 explorações até o choco).
- **`CHANCE_GOLPE_OVO` existe porque a regra fiel seria invisível.** Nos jogos, quem põe um golpe-ovo num pai é
  outra criação (ou a Erva Espelho); aqui os pais são selvagens recrutados, e o moveset de um selvagem são os 4
  golpes mais recentes POR NÍVEL — que por definição nunca incluem golpe-ovo. A regra dos jogos vem primeiro e
  sempre; `CHANCE_GOLPE_OVO = 0` desliga o caminho de casa num lugar só.
- **Com Ditto, `acharPar` devolve `ditto: true`.** Dois usos: a espécie vem do outro (ele nunca é `mae`) e o golpe
  herdado também (`amizade` troca o doador). Sem isso todo filhote de Ditto nasceria sabendo Transform.
- Continuam de fora, agora por escrito: **Power Items** (escolher qual IV), **Masuda** (não há idioma de cartucho),
  **Incenso/Chaveiro Oval/Poké Pensão** e lista de golpe-ovo por "qual pai pode ensinar o quê".

### Decisões (perguntadas ao usuário em 02/10/2026)
| Pergunta | Resposta | Consequência no código |
|---|---|---|
| Nível do filhote | **Nv. 5**, fiel aos jogos | `NIVEL_CHOCAR`. Filhote mid-run é investimento, não reforço |
| Passos | **100 no mínimo**, com **categorias** de ovo, **3 em paralelo** | `PASSOS_MIN` 100, `PASSOS_MAX` 400, `MAX_OVOS` 3, categoria pelo `hatchCounter` |
| A "mistura" | **espécie base da mãe + golpe e IVs do pai** | `arvore.name` (raiz da árvore de evolução), `golpeHerdado`, `ivsHerdados` |
| Pares | **só gênero oposto** → **revertido no dia seguinte** | ver abaixo |

### As categorias de ovo
Os jogos têm ciclos de choco (`hatch_counter` da PokéAPI): Magikarp 5, Dratini e Beldum 40, lendário 120. Isso virou
`passosParaChocar = clamp(ciclos × 5, 100, 400)` → **100 · 200 · 400 explorações**. O campo entrou em
`api.loadSpecies` por `valido` (não por chave nova, pra não jogar fora mapa baixado), e **`VERSAO_DOWNLOAD` subiu pra
4**: é um campo que muda uma REGRA em jogo, e sem ele todo ovo cai no piso de 100 — o de lendário chocaria como um de
Magikarp, no avião, sem ninguém notar. `CICLOS_PADRAO` = 20 é o que vale quando o dado não veio.

### Os grupos-ovo (a volta atrás, 02/10/2026)
A primeira versão perguntou e o usuário escolheu **só gênero oposto**, pra não custar um campo novo no cache. No dia
seguinte, vendo o resultado: *"o sem Grupos-ovo acabou prejudicando mesmo, vamos colocar"*. Então o par agora é
**gênero oposto + um grupo-ovo em comum** (`ovos.parCompativel`), com `eggGroups` entrando em `api.loadSpecies` pelo
`valido` de sempre e **`VERSAO_DOWNLOAD` pra 5**.

Três detalhes que a regra obrigou:
- **`no-eggs` não cruza com ninguém**, nem com outro `no-eggs`. É o grupo de lendário, mítico, bebê — e de
  Nidoqueen, o caso que mais surpreende quem não conhece (confirmado contra a PokéAPI: ela realmente não bota).
- **Grupo desconhecido também não cruza.** É o contrário do que o resto do jogo faz com dado que falta (lá a regra
  mais calada é a que vale, ver `genderRate` = −1), e aqui é de propósito: sem o dado, o certo é **não aparecer ovo**,
  não aparecer ovo errado. Quem está nessa situação é exatamente quem o `VERSAO_DOWNLOAD` manda baixar de novo.
- **A busca saiu de dentro do caminho quente.** Saber os grupos exige a ficha de espécie de até 30 Pokémon do
  esconderijo. Então `tentarCruzar` virou `podeCruzar` (vaga + sorteio, puro e barato) + `acharPar(lista, grupos)`:
  a busca só acontece DEPOIS do sorteio passar, 1 exploração em 20 em vez de todas. Na prática é cache em memória,
  porque `makeMon` já busca essa mesma ficha pra sortear o gênero de todo mundo que nasce.

Ditto continua fora e **de graça**: ele não tem gênero, então a regra de gênero oposto já o exclui sem uma linha de
código. Nos jogos ele cruzaria com quase todo mundo; entraria como exceção explícita, se for pedido.

### O segredo
O ovo guarda `especie` no save, mas **nenhuma tela lê esse campo**: `blocoOvos` mostra "🥚 Ovo misterioso" e a barra.
O `de` (nomes dos pais) também só aparece na hora do nascimento — dizer "filho da Nidorina" antes de abrir seria
contar a espécie. Quem quiser trapacear abrindo o `localStorage` consegue; o alvo aqui é a experiência, não o DRM.

### O que ficou de fora de propósito
- **Ditto**: ver acima — excluído de graça pela regra de gênero.
- **Lista de golpes-ovo legais**: o herdado é qualquer um dos 4 do pai, então um filhote Nv. 5 pode nascer com
  Hyper Beam. Marcado com `ponytail:` no código — filtrar por poder resolve num lugar só, se desequilibrar.
- **Forma regional na raiz**: a raiz da árvore é a forma original, então um Sandslash de Alola põe um Sandshrew de
  Kanto. Também marcado no código.
- **Ditto, Incenso, Chaveiro Oval, Poké Pensão, EVs/natureza herdados, Destiny Knot**: nada disso existe.
- **Ovo não anda em batalha nem no multiplayer**: o passo é a exploração, e só.

### A contagem das duas badges
`S.ovosChocados` sobe ao nascer → entra em `regras.estatisticasDaJornada` (a LISTA BRANCA do resumo; campo não
citado lá morre com a jornada) → `progresso-conta.bancar` grava em `porJornada[id].ovosChocados` → `contextoBadges`
SOMA todas as jornadas. Vem do progresso permanente, que nunca encolhe: apagar a carreira não desfaz ovo chocado.

As badges `ovos100`/`ovos1000` são as **únicas cuja recompensa é um ovo** (`recompensa.ovo`), então `vantagensDe`
ganhou `out.ovos`. Quem sorteia a espécie é `criacao.iniciarJornada` — é ela que conhece o mapa: pseudo-lendário sai
de `dados.PSEUDO_LENDARIOS` (lista à mão: "pseudo-lendário" é consenso da comunidade, não dado da PokéAPI) e
lendário/mítico de `mapas.especiesLendarias()`, **derivado das marcas `l`/`m` dos pools** — mapa novo entra sozinho.
Esse caminho **não toca a rede**: os ciclos do ovo de badge são fixos (`CICLOS_PSEUDO` 40, `CICLOS_LENDARIO` 120),
porque uma busca a mais na criação da jornada é uma jornada a menos quando a rede falha.

O teste de `badges.test.js` cobre o elo inteiro (badge → `vantagensDe().ovos`) pelo mesmo motivo do "Potencial
máximo": a recompensa não é item nem dinheiro, então um elo solto no meio não daria erro em lugar nenhum — só
deixaria de dar o prêmio em silêncio.

**Nota de equilíbrio, registrada de propósito**: 100 ovos × ~100–400 explorações cada é um alvo muito longo, e 1.000
é ordem de grandeza de "talvez nunca" (como o milhão de dano). Os números são os pedidos pelo usuário; se um dia
parecerem inalcançáveis, os botões são `CHANCE_OVO` e `MAX_OVOS`, não o alvo da badge.

---

## Gênero (02/10/2026)

Pedido do usuário: "os pokémons não constam com gênero, temos que adicionar isso pois tem habilidades e moves que
se importam com isso". Era dado morto até então — nenhuma mecânica de gênero existia no jogo, e as que existiam
funcionavam **errado em silêncio**: Captivate baixava a At.Esp. de qualquer um (os −2 são `stat_changes` comuns,
e o motor não tinha nada contra o que conferir) e a evolução ignorava a exigência de gênero, então um Combee macho
virava Vespiquen. Attract caía no "este efeito será ajustado em atualizações futuras", porque `infatuation` não
tinha entrada em `AIL_MSG`.

### De onde o dado vem

A PokéAPI não põe gênero no Pokémon, põe `gender_rate` na **espécie**: −1 sem gênero, 0 sempre macho, 8 sempre
fêmea, 1–7 chance de FÊMEA em oitavos. Isso entrou em `api.loadSpecies` como `genderRate`.

Duas decisões aqui:

- **Entrou por `valido`, não por chave nova.** `cached('sp2:', …, v => typeof v?.genderRate === 'number')`. Trocar
  pra `'sp3:'` jogaria fora toda espécie já baixada pra jogar offline; com o `valido`, o registro velho é usado
  enquanto a rede não responde e trocado pelo novo na primeira vez que ela responder. Mesmo caminho do
  `learnset.extras`.
- **A busca da espécie vai no mesmo `Promise.all` dos golpes** (`pokemon.makeMon`). Não é uma espera nova: a função
  já aguardava os 4 golpes, e a espécie já está no cache de quem baixou o mapa (`offline.baixarGen` busca espécie
  desde a v2). Se falhar, o fallback é **−1 (sem gênero)**, de propósito o mais calado dos dois erros: um ♂ errado
  num Voltorb seria visível E faria Attract funcionar onde não devia.

O sorteio é `regras.sortearGenero(taxa, nome, sorte)`, puro e testado, chamado **uma vez no nascimento**. `m.genero`
é congelado: nada reescreve depois, nem a evolução (que só troca `id`/`data`). `loja-conta.reidratarHall` passa
`opt.genero` pra não re-sortear — o mesmo Pokémon do Hall entrando macho numa raide e fêmea na seguinte seria
visível e sem explicação.

**Forma presa a um gênero.** Meowstic-Female, Basculegion-Male e Oinkologne-Male são formas de espécies com taxa 4:
o sorteio daria um "Meowstic-Female macho". O **nome da forma manda** (`/-female$/`, `/-male$/`). A forma padrão
dessas espécies não traz sufixo, então o macho continua saindo do sorteio — fica certo nos dois casos sem precisar
de uma tabela de exceções.

### O que lê o gênero

Duas funções puras são o único jeito de comparar: `mesmoGenero(a, b)` e `generoOposto(a, b)`. **Sem gênero nunca
casa com nada** — as duas respondem `false` pra quem não tem e pra save de antes disto existir, então o efeito
falha em vez de chutar um gênero.

- **Attract** (`ailment: infatuation`) e **Cute Charm** (`contato: { status: 'infatuation', chance: 30 }`): a
  checagem está em **`golpe.aplicarStatus`**, no único lugar por onde todo status passa — a habilidade não precisou
  de gancho novo, é uma linha na tabela. Paixão vive no `vol` (como a confusão), então morre ao entrar/sair de campo
  e no fim da batalha: **nunca vaza pro save**. Metade dos turnos o apaixonado não ataca, conferido antes da
  confusão como nos jogos. Oblivious e Aroma Veil ganharam `'infatuation'` no `imuneStatus` que já tinham.
- **Captivate**: `especiais.captivate = { generoOposto: true }`. Os −2 de At.Esp. continuam genéricos; o que a
  tabela acrescenta é a trava, conferida no topo de `statusEspecial`.
- **Rivalry**: gancho `rivalidade` em `calcDamage` — ×1,25 contra o mesmo gênero, ×0,75 contra o oposto, ×1 se um
  dos dois não tem.
- **Evolução**: `slimEvo` passou a guardar `gender` de cada caminho (1 = só fêmea, 2 = só macho) e `detalheCumprido`
  confere contra `M.genero`. Isso fechou um buraco listado como "não suportado": Vespiquen, Salazzle, Froslass e
  Wormadam só saem de fêmeas, Mothim só de machos. Ninguém fica sem evolução porque as duas pontas existem na mesma
  árvore (Burmy fêmea → Wormadam, macho → Mothim).
- **IA** (`notaDoGolpe`): Attract vale `IMPOSSIVEL` contra quem não é do gênero oposto ou já está apaixonado, e
  Captivate idem — senão o inimigo gastaria o turno num golpe inerte.

### O que isso obrigou a mexer

- **`v: 3` na árvore de evolução.** A chave do cache (`'evo2:'`) ficou, o `valido` virou `v => v?.v >= 3`, e
  `progressao.arvoreDe` passou de `=== 2` pra `>= 3`. Mesma lógica da espécie: nada é jogado fora, a árvore velha
  serve offline e é refeita online.
- **`VERSAO_DOWNLOAD` 2 → 3.** A lista de buscas do `baixarGen` é a MESMA — mudou o *conteúdo* de duas delas. Quem
  baixou na v2 tem registro sem `genderRate` e sem `gender`, e no avião isso é todo mundo sem gênero (Attract e
  Rivalry inertes). O `valido` conserta online; a marca nova é o que avisa na tela de Ajustes que vale baixar de
  novo.
- **`fotoDoMon` leva `genero`** (mp-motor): as 4 mecânicas são as do motor único, então faltava só mandar o dado
  pela rede. `mp-sanear` varre por TIPO, e `'m'`/`'f'` é texto — não precisou de linha nova lá.
- **O ♂/♀ sai de uma COMPARAÇÃO, nunca de interpolar `m.genero`** (`render.sexo`): na sala esse campo vem de outro
  jogador, e `${m.genero}` dentro do HTML seria a mesma classe de furo da auditoria de 30/09.

### O que ficou de fora

- **A paixão não acaba quando quem causou sai de campo**, como nos jogos. No seu lado ninguém troca de Pokémon, e
  o `vol` do inimigo que entra já nasce limpo — o único caso real é você ficar apaixonado depois de o inimigo
  trocar, e aí a paixão dura a batalha. Guardar quem causou pra isso seria um campo no `vol` por um caso de borda.
- **Não existe tela de "proporção de gênero"** nem gênero na Pokédex: o símbolo na plaquinha, na ficha e no cartão
  da sala é o que muda decisão em jogo.
- **Forma padrão macho continua no sorteio** (ver acima): um Indeedee macho de verdade é o que sai, mas a espécie
  também sorteia fêmea pra forma padrão, que nos jogos seria outra forma. Caso de borda de 4 espécies.

---

## Congelamento: o que faltava (02/10/2026)

Relato do jogador: "o status congelado parece não estar funcionando". A primeira coisa foi reproduzir num script
de Node com o motor de verdade (`usarGolpe` + um `ctx` de teste) em vez de confiar na leitura: **a aplicação e a
trava funcionavam** — Ice Beam congela, o congelado perde a vez, 20% de sair por turno. O que faltava eram as
três INTERAÇÕES, e são elas que fazem o status parecer quebrado em jogo, porque são o que o jogador espera:

1. **Golpe de Fogo não descongelava o alvo.** Lança-Chamas num inimigo congelado deixava o gelo intacto.
   Consertado em `executar`, logo depois do dano — e de propósito **fora** do bloco de secundários (`!hu.sheerForce
   && !ht.semSecundario`): descongelar não é efeito secundário, Shield Dust e Sheer Force não impedem nos jogos.
2. **Golpe `defrost` não descongelava quem usa.** Flame Wheel, Sacred Fire, Flare Blitz, Scald, Fusion Flare,
   Steam Eruption, Burn Up, Sizzly Slide, Pyro Ball e Scorching Sands existem justamente pra sair do gelo, e o
   congelamento travava os dez. A lista **não foi digitada à mão**: a flag `defrost` já estava em
   `dados-golpe-flags.js` (gerado do repositório-fonte da PokéAPI) e `regras.temFlag` já era importada em
   `golpe.js` — o conserto é uma condição a mais no `if` que já existia.
3. **Sol forte não impedia o congelamento.** Uma guarda em `aplicarStatus`, junto das outras (Salvaguarda, Flower
   Veil, Leaf Guard, terreno), antes da imunidade de tipo.

Quem descongela por Fogo usa `g.type === 'fire' || temFlag(g, 'defrost')`: o tipo cobre todo golpe de Fogo, a flag
cobre Scald/Steam Eruption/Scorching Sands, que são de Água/Chão e derretem mesmo assim.

**Ficou de fora:** Tri Attack. A PokéAPI devolve `ailment: 'unknown'` pra ele (o status é sorteado entre queimar,
congelar e paralisar), então `aplicarStatus` cai no `!AIL_MSG[ail]` e não faz nada — em silêncio, porque o
secundário chama com `avisar: false`. Resolver pede uma entrada em `especiais.js` com sorteio, não é regressão
desta leva. `tests/congelado.test.js` fixa o sorteio nos dois lados do limiar (0.1 descongela, 0.99 não), nunca
por amostragem.

## Golpes de peso e de atributo trocado (02/10/2026)

Um levantamento do jogador: "Heavy Slam, Psyshock e Body Press funcionam?" Não funcionavam, e de duas maneiras
diferentes — a segunda bem pior que a primeira.

**Poder variável que a PokéAPI não calcula.** Low Kick, Grass Knot, Heavy Slam, Heat Crash, Wring Out e Crush Grip
vêm da API com `power: null`, e `calcDamage` fazia `move.power || 60`: **todos batiam com poder fixo 60**, o Low Kick
contra um Snorlax igual ao Low Kick contra um Caterpie. Entraram como fórmulas em `regras.poderEspecial`
(`pesoDoAlvo`, `pesoRelativo`, `hpDoAlvo`), mais `estagios`/`estagiosDoAlvo` para Stored Power, Power Trip e
Punishment — esses três tinham poder na tabela, mas o poder BASE, sem os +20 por degrau.

O peso não existia no jogo: `api.slimPokemon` descartava o `weight` da API. Ele entra agora **em hectogramas, como
a API manda** (`pesoKg` divide por 10 na hora de usar) — converter na entrada criaria duas unidades em circulação.
Quem já tinha a espécie no cache tem um registro sem o campo; é exatamente o caso que o `valido` de `cached()` existe
pra resolver (o precedente é o `learnset.extras`), então `loadPokemon` passou a exigir `typeof v.weight === 'number'`
e troca o registro na primeira busca online. **Não subimos `VERSAO_DOWNLOAD`**: nenhuma busca nova entrou no
`baixarGen`, só um campo a mais no mesmo JSON. O preço é que quem está offline com uma Gen antiga baixada continua
sem o peso — e aí as fórmulas devolvem `null` de propósito, caindo no poder da tabela. É melhor que tratar peso
ausente como zero, que daria Heavy Slam de poder 120 contra tudo.

**O par de atributos errado — esse não "não funcionava", funcionava diferente em silêncio.** `calcDamage` escolhia
Ataque/Defesa só pelo `cls` do golpe. Então Psyshock, Psystrike e Secret Sword (especiais que nos jogos batem na
Defesa FÍSICA) atingiam a Defesa Especial; Body Press usava o seu Ataque, quando a razão de ele existir é bater com
a Defesa; e Foul Play usava o SEU Ataque em vez do do alvo. Nenhum deles mostrava "efeito será ajustado em
atualizações futuras", porque dano saía — só o número errado. Três campos novos em `especiais.js` (`atkDe`,
`atkDoAlvo`, `defDe`) e o par de `effStat` em `calcDamage` passou a consultá-los.

Como tudo caiu em `calcDamage` e em `poderEspecial`, veio de graça: o motor único (`golpe.js`), o multiplayer
(`mp-motor` chama o mesmo `usarGolpe`) e **a IA do inimigo**, que estima dano por `notaDoGolpe` → `calcDamage` e
agora entende que o Heavy Slam dela vale mais contra um alvo leve.

**Ficou de fora:** Avalanche e Revenge (dobram se você levou dano ANTES no turno) — precisam de um registro novo no
`vol` alimentado pelos dois motores, não é uma fórmula pura. Autotomize também não existe, então nada altera o peso
durante a batalha.

O teste de contrato de `tests/especiais.test.js` ("só comportamentos que o motor conhece") pegou cada fórmula e cada
campo novo antes de eu rodar o resto — é pra isso que ele está lá. O teste da troca de atributo compara o golpe com
um de referência do mesmo poder mexendo só no atributo que deveria pesar, em vez de travar um número de dano.

---

## Evento semanal, chefes e Arena

- **Evento semanal** (`evento.js` calendário/elegibilidade/espera de 8 h, `boss.js` regras do chefe, testes em `tests/evento.test.js` e `tests/boss.test.js`):
  `EVENTOS[semana % n]`, semana = segunda→domingo UTC contada de `INICIO` (21/09/2026); só `DIFICULDADES[x].eventoSemanal` (Roguelike/Hardcore) e só na Gen do chefe.
  Aparece na rota FINAL (`z.lendarios`, mesma trava de nível) em `render.blocoEvento` e como sprite com brilho na escolha de Gen (`criacao.renderGens`); botão
  `data-act="evento"` → `mundo.desafiarEvento` → `batalha.startEvento`. A espera fica só no navegador (`evento.TENTATIVA_KEY`) — dá pra burlar pelo relógio; servidor
  valida depois. **O chefe é um Pokémon comum com `E.boss`** (dados puros: vai no save e, no futuro, na rede) e as regras entram em `golpe.js` por 4 ganchos:
  `danoNoChefe` (couraça reduz/Ruptura aumenta, no laço de dano), `aposDanoNoChefe` (desgasta couraça, interrompe carga, fases → efeitos `{dizer,estagios,curaStatus}`
  aplicados por `aplicarEfeitosChefe`), `antesDoChefeAgir` (início de `usarGolpe`: carrega/solta o Eternabeam, que já tem `recarga` em `especiais.js`) e a imunidade
  a status em `aplicarStatus`. Todos os números em `boss.AJUSTES` — a dificuldade se calibra jogando (chute inicial: HP ×5, atributos ×1,3, couraça 16% do HP, ciclo de 4).
  `EVENTO_SEM_PERMADEATH` (evento.js): perder pro chefe não encerra a run nem perde aliado. Vitória → `carreira.registrarVitoriaDeEvento` grava
  `progresso.eventos[id] = {primeiraEm, vitorias, semanas}` + espécie em `progresso.especies` (razão `evento`) — `mesclarProgresso` faz união. Badge `evento-<id>` (grupo `Eventos`,
  `badges.js`); a exibida ao lado do nome é `nuvem.badgeExibida` (localStorage + `perfis.badge_exibida`, migração `20260925120000_badge_exibida.sql`; sem a coluna segue local).
  **Calendário**: `INICIO` = segunda 28/09/2026 00:00 de Brasília (03:00 UTC); a semana vira toda segunda 00:00 BRT (`FUSO_MS`); antes de `INICIO` `eventoDaSemana` é `null` e
  `situacaoDoEvento` devolve `motivo:'em-breve'`. `agenda(agora, 3)` alimenta a tela inicial (`criacao.renderAgendaEvento`). Pra TESTAR antes da data: no console,
  `localStorage.setItem('pokerpg-evento-agora', Date.UTC(2026,8,28,12))` (`evento.RELOGIO_KEY`; qualquer chamada usa `agoraDoEvento()`, nunca `Date.now()` direto).
  **Chefe de Raide não é bicho de rota** (03/10/2026, pedido do usuário): `dados.SO_NO_SANTUARIO` tira do pool de encontro de toda rota 1–10 quem é chefe na própria FORMA NORMAL —
  hoje Arceus (saía como mítico de 0,068% na Estrada Vitória da Gen 4) e Regigigas. Os outros 14 chefes aparecem numa forma alternativa (Mega Rayquaza, Eternamax, Primal), então a
  forma NORMAL deles pode continuar como lendário da rota final; foi o próprio usuário quem apontou essa distinção. O Santuário (`posVitoria`) mantém todo mundo, senão a Pokédex da
  Gen só fecharia vencendo o chefe da semana. A lista é à mão porque `evento.js` importa `dados.js` (importar de volta seria ciclo); `tests/evento.test.js` deriva de `EVENTOS` quem é
  chefe em forma normal e falha se um ficar num pool. **Chefe novo cuja forma é a normal = uma linha em `SO_NO_SANTUARIO`.**
  **Vários chefes**: `boss.CHEFES[id]` guarda a config (couraça e/ou `pontoFraco`, canhão, fases, ciclo); `E.boss.id` escolhe. Eternatus = couraça + Ruptura; Mega Rayquaza = ponto fraco
  rotativo (`danoNoChefe(t, dano, tipo)` recebe o TIPO do golpe) + Dragon Ascent (`expostoAposCanhao`). Chefe novo = uma linha em `EVENTOS` (evento.js) + uma em `CHEFES` (o teste confere as duas).
  **Co-op** (`multiplayer.iniciarBatalhaMP('evento')`, botão `botaoEventoMP`): `fotoDoMon` leva `boss`; HP por `jogadoresEfetivos(jogadores, porJogador)`; o golpe carregado devolve `todos` →
  `u.boss.soltouTodos` e o `mp-motor` chama `usarGolpe(..., {extra:true})` nos outros alvos (sem nova ação, sem recarga). **Revive**: ação `revive` → `registrarRevive` (anfitrião) →
  `mp-motor.reviverNoEvento` muta o estado NA HORA (o Pokémon já escolhe no turno); `b.revivesUsados[dono]` viaja no estado e cada cliente desconta o Revive da PRÓPRIA mochila em
  `consumirRevives` (o anfitrião não sabe a mochila dos outros). Sem fuga no evento (`s.evento`). Cada participante registra a tentativa de 8 h ao ver o 1º estado (`sala.tentativaEvento`)
  e recebe o prêmio em `premiarEventoMP` só se a SUA run é Roguelike/Hardcore. A insígnia exibida vai no payload de presença (`meuPayload().badge`) e, nas listas persistentes, pelas RPCs `meus_amigos()` e `ranking()` (coluna `badge_exibida`, migração
  `20260925130000_badge_nas_listas.sql`, que exige a `20260925120000_badge_exibida.sql` antes). O servidor só devolve a insígnia se `progresso.dados->'eventos'` contém o evento
  (`badge_exibivel(uuid)`) — não é à prova de fraude (o progresso é gravado pelo jogo), mas impede escolher no perfil algo que nunca foi conquistado. O cliente desenha com
  `conta.htmlInsigniaDe(id)` (topo, amigos, ranking, sala); versão antiga do banco só não traz o campo e nada quebra. ~~**Falta**: os outros chefes e os itens.~~ **✅ COMPLETO** (conferido em 29/09/2026 rodando o código: `EVENTOS.length` = 14, `Object.keys(boss.CHEFES).length` = 14 — hoje 16 e 16, com Arceus e Regigigas, itens com `raide` em `ITEMS` = 10). Os 14 chefes estão em "Os 14 chefes" e os 10 itens em "Itens de raide", as duas seções logo abaixo.
  **⚠️ TEMPORÁRIO (pedido do usuário, beta testers, 28/09/2026): `evento.BETA_SEM_ESPERA = true` remove a espera de
  8h entre tentativas** — Arena, run e sala. Implementado SEM tocar `COOLDOWN_MS`/`esperaRestante` (que continuam
  puros e testados com os números reais): a flag entra só em `evento.ultimaTentativaEfetiva()` (finge "nunca
  tentou" quando ligada) e no parâmetro PADRÃO de `situacaoDoEvento` — os testes chamam `situacaoDoEvento` sempre
  com `ultima` explícito, então não veem a flag e continuam garantindo a regra de verdade. `arena.js` troca as duas
  chamadas de `esperaRestante(ultimaTentativa()...)` por `ultimaTentativaEfetiva()` pelo mesmo motivo. **Pra
  reverter**: só `BETA_SEM_ESPERA = false` em `evento.js` — nada mais precisa mudar. Textos que mencionavam "8
  horas" de forma incondicional (`mundo.desafiarEvento`, `criacao.renderAgendaEvento`, `ajuda-chefes.js`,
  `arena.htmlLobby`) agora checam a flag e mostram "🧪 Modo beta: sem espera" em vez de mentir sobre o cooldown.
  **Convite pra jogar em grupo a partir da Arena** (mesmo pedido): a Arena (`arena.js`) é só single-player (Hall da
  Fama, sem outros jogadores — nunca foi multiplayer de verdade). O usuário queria chamar gente de dentro dela;
  como as duas telas são sistemas bem diferentes (Arena não usa sala/rede, co-op usa), a solução foi um cartão
  "👥 Jogar em grupo" no topo do lobby da Arena com um botão `data-act="mp"` que leva direto pra tela de
  Multiplayer — de lá, sala co-op já suportava isso (`MAX_JOGADORES` = 6, `porJogador` 1–3) sem precisar de
  nenhuma mudança de código, só não estava óbvio que o caminho existia.
- **Perfil de amigo** (`perfil-amigo.js` tela, `perfil-dados.js` contas puras; testes em `tests/perfil-amigo.test.js`): botão `data-act="amigo-perfil"` na lista de amigos (e "Ver meu perfil" na Conta) →
  `nuvem.perfilDoAmigo` → RPC `perfil_do_amigo(uuid)` (migração `20260925150000_perfil_do_amigo.sql`, SECURITY DEFINER): só devolve se a amizade está `aceita` (ou é o próprio) e só o que já é público no jogo
  (apelido, ícone, `badge_exibivel`, criado_em, ids dos chefes vencidos, contagem de espécies, números agregados das `jornadas` e as 5 últimas) — sem e-mail, código de amigo ou mochila (o teste confere o texto do SQL).
  **Não** mostra as badges de conta de caçada/coleção/etc.: elas são calculadas NO CLIENTE a partir do progresso+carreira, e mandar isso tudo do servidor seria pesado; ideia futura: um resumo já calculado.
  Sem a migração a tela mostra o erro e diz qual arquivo rodar. Ordem das migrações do dia 25/09: 120000 (badge_exibida) → 130000 (badge nas listas) → 140000 (relatos) → 150000 (perfil do amigo).
- **Arena do Chefe + Hall da Fama** (`hall.js` puro, `arena.js` tela/loop, `ajuda-chefes.js` texto; testes em `tests/hall.test.js`): `encerrarJornada` chama `carreira.registrarNoHallDaConta(S, resumo)` ANTES de zerar `G.S`
  (só modos com `eventoSemanal`) e passa os itens de raide da mochila pro inventário da conta (`evento.darItensDeRaide`, localStorage `pokerpg-raide-v1`, NÃO sincroniza). O Hall vive em `progresso.hall[jornadaId]`
  (entrada compacta: espécie/id, nível, IVs, EVs, natureza, habilidade, NOMES dos golpes; `podarHall` mantém `HALL_MAX`=30; `mesclarProgresso` faz união). **A Arena NÃO usa `G.S`**: roda o motor do co-op
  (`mp-motor`) localmente — lado A = Hall reidratado (`makeMon` + `loadMove`), lado B = chefe (`prepararChefe(E, jogadoresEfetivos(1, n))`) — então não pode mexer no save de uma run em andamento. Por isso não tem item
  segurado, Mega/Tera/Z/Gigantamax nem Revive (o motor do co-op não os tem). Tentativa de 8 h, vitória (`registrarVitoriaDeEvento`) e prêmio de itens de raide iguais ao resto do evento; dinheiro/Rare Candy só dentro de
  uma run. Entradas antigas (jornadas terminadas antes deste recurso) NÃO estão no Hall: só valem as que terminam depois. Ideia de expansão: chefe na Arena em grupo (a base do co-op já serve).
- **Os 16 chefes** (`evento.EVENTOS`, fábrica `ev()`; regras em `boss.CHEFES`, mesma `id`): a ordem do array É o calendário (semana N = `N % 16`). Mecânicas novas além de couraça/ponto fraco/canhão/fases:
  `climaFixo` (`aplicarClimaDoChefe` usa o clima fixo de `novoCampo`; Groudon sol, Kyogre chuva), `anula {tipos}` (dano 0 + texto em `golpe.js`), `inverso {acoes}` (Mundo Reverso: `danoNoChefe(t, dano,
  tipo, ef)` divide pelo ef² do motor, com teto ×4), `adapta {reducao}` (guarda `b.ultimoTipo` DENTRO de `danoNoChefe`), `dreno` (`drenoDoChefe` em `executar`), `regenera` (efeito `{cura}` em
  `antesDoChefeAgir`), `habilidade` (habilidade da tabela do motor: Calyrex `grim-neigh`, Necrozma `neuroforce`, Zacian `intrepid-sword`, Regigigas `slow-start`),
  `pontoFraco.sorteia` (Arceus: o tipo da vez é SORTEADO entre os 17 Pratos — `dados.PLACA_DO_TIPO` sem o Normal — e nunca repete o atual; a troca devolve
  o efeito `{pratos: tipo}`, que é PEDIDO DE ANIMAÇÃO: `ctx.pratos` → `ui.trocarPratos` no single player, ignorado por quem narra sem DOM. Com 17 tipos no
  bolo acertar a janela é raro, então `contra` subiu pra 0,65 e `mult` pra ×2; as telas trocam o rótulo por `🏛 Prato da vez` lendo `resumoDoChefe().prato`). **O golpe carregado NÃO pode ser golpe de carga do motor**
  (`especiais.carga`, ex.: Freeze Shock — viraria "preparando" de novo); o teste confere. `EVENTO_SEM_PERMADEATH` vale pra todos. **Simplificações a lembrar**: as duplas (Zacian+Zamazenta,
  Dialga+Palkia) viraram UM chefe cada; Mewtwo troca pro "modo X" só como bônus de atributo (fase 2) — não há troca de forma/sprite; Kyurem não ignora habilidades do jogador.
- **Itens de raide** (`dados.ITEMS[x].raide`, `boss.usarItemDeRaide`): 10 consumíveis, UM de cada tipo por luta (marca
  em `E.boss.raide`), só valem com `E.boss`: `cristal-de-ruptura`, `selo-de-interrupcao`, `escudo-astral` (os 3
  originais) + `cinza-vulcanica`, `escama-abissal`, `prisma-de-luz`, `espelho-reverso`, `relogio-de-areia`,
  `fragmento-tera`, `celula-zygarde` (28/09/2026, ver abaixo).
  Single player: `itens.useItem` → `usarRaide` (gasta o turno). Co-op: ação livre `raide` → `multiplayer.registrarRaide` (anfitrião) → `mp-motor.usarRaideNoEvento`; `b.raideUsados[dono][tipo]` viaja no estado e
  `consumirRevives` desconta da PRÓPRIA mochila. Escudo Astral = `b.canhaoMult` (0,5) consumido no próximo golpe carregado; `canhaoUltimoMult` faz os outros alvos do co-op levarem o mesmo corte.
  Vêm de prêmio: `evento.ev()` dá 2 de um dos 3 originais + 1 de um dos 14 novos (7 consumíveis + 7 segurados), girando cada grupo no próprio módulo.
  **✅ FEITO (28/09/2026) — os 14 itens do backlog aprovado.** `usarItemDeRaide(E, tipo, ladoJogador)` ganhou um
  3º parâmetro (os 3 originais ignoram): `cinza`/`abissal` escrevem `ladoJogador.resisteRaide = {tipo, turnos:3}`
  (novo campo em `regras.LADO_VAZIO`, decrementado em `passarLado`, lido por `regras.multResisteRaide` em
  `calcDamage` — igual a `multTelas`); `prisma` reusa `exporChefe` (a MESMA Ruptura, mas com `cfg.pontoFraco`
  como porta em vez de `cfg.coura` — dá contra-jogo pra lutas sem couraça); `espelho` é uma inversão de tabela
  TEMPORÁRIA e independente do `b.reverso` do Giratina (`b.espelhoAcoes`, decrementado em `antesDoChefeAgir`,
  checado em `danoNoChefe` junto com `b.reverso`); `celula` liga `b.semRegen` (checado onde `cfg.regenera` cura,
  em `antesDoChefeAgir`), só funciona em chefe com essa mecânica (hoje só Zygarde Completo). **`relogio` e
  `fragmento` não sabem QUAL Pokémon usou nem se o Tera já saiu** — isso mora no estado de cada motor, não no do
  chefe — então `usarItemDeRaide` devolve marcadores (`{estagios:[['speed',2]]}`, `{recarregaTera:true}`) que os
  TRÊS chamadores resolvem: `itens.usarRaide` (`changeStats(S.player,...)` + `G.B.teraUsada=false`),
  `mp-motor.usarRaideNoEvento` (aplica direto em `vol.stages` do PRINCIPAL de quem usou — sem `ctx` de narração
  nessa ação livre, então Clear Body/Simple/Contrary não entram nesse +2 específico — e reseta
  `estado.gimmicksUsados[dono].tera`) e a Arena (`arena.arenaRaide` já chama o MESMO `usarRaideNoEvento` do
  co-op, então herda de graça). **7 itens SEGURADOS novos** (`dados.ITENS_RAIDE_SEGURADOS`, sem `price` — só vêm
  de prêmio, nunca da loja; `segurados.IDS_SEGURADOS` agora soma as duas tabelas): `nucleo-eternamax`
  (`danoTipo` + `multStat`, gancho `danoTipo` NOVO em segurados.js — dano por tipo do PRÓPRIO golpe, igual ao
  `danoTipo` de habilidades.js mas pro item), `escama-do-ceu`/`cristal-psiquico`/`cristal-gelido` (`resisteTipo`,
  gancho NOVO — dano RECEBIDO daquele tipo, novo `regras.resisteDoItem` chamado em `calcDamage` do lado de quem
  DEFENDE, mesmo espírito de `ht.resiste` das habilidades), `redea-espectral`/`emblema-da-coroa`/`presa-da-lua`
  (ganchos que já existiam: `multStat`/`multDano`/`drenaDano`). **Simplificações assumidas** (documentado no
  próprio código): Rédea Espectral vira só +20% Velocidade (sem a prioridade no 1º turno do design original —
  exigiria threading de "é o turno 1" nos dois motores de ordenação); Emblema da Coroa vira +15% de dano fixo
  (sem depender de "lutar acompanhado" — mesma classe de problema que fez a habilidade Friend Guard ficar de
  fora da 5ª leva: `calcDamage` não recebe o roster de aliados do atacante).

---

## Loja de preparo, Hall da Fama e Sala de Raide

- **Loja de preparo da Arena** (28/09/2026, `progresso-conta.js` + `carreira.js` + `arena.js` — revisada no MESMO
  dia, ver abaixo): saldo de conta em dinheiro, só usável ali — `FRACAO_SALDO_ARENA` (10%) de `maxDinheiro` de
  CADA jornada bancada (`porJornada[id].maxDinheiro`, campo novo nessa entrada), somado pra sempre e nunca encolhe
  (mesmo princípio do resto de `progresso-conta.js`). `saldoArenaGanho`/`saldoArenaDisponivel`/`gastarSaldoArena`
  são puras e testadas; `gastoArena` mescla pelo MAIOR valor entre os dois lados (é gasto, não conquista — perder
  o controle de quanto já foi gasto deixaria comprar de graça). `carreira.saldoArenaDaConta`/`gastarSaldoArenaDaConta`
  fazem a ponte com `localStorage`.

  **✅ CORRIGIDO — bug real relatado pelo usuário: "itens equipáveis e itens de uso dentro da Raid não estão
  funcionando, não tem lugar pra selecionar eles pra usar".** Causa raiz: `progresso-conta.bancar()` pula
  jornadas cujo id JÁ está em `porJornada` (`if (p.porJornada[j.id]) continue`) — certo pra não reprocessar à toa,
  mas isso também pulava o BACKFILL de `maxDinheiro`: quem já tinha a conta com jornadas bancadas ANTES desse
  campo existir (ou seja, qualquer conta com carreira anterior a hoje) ficava com `maxDinheiro` sempre ausente
  nessas entradas — `saldoArenaGanho` somava zero pra sempre, então TODO botão de comprar ficava "Saldo
  insuficiente" desabilitado, e sem nada comprado não havia nada pra equipar nem usar (a seção "🎽 Equipar item"
  também mostra a mensagem de "compre primeiro" quando `donos.length === 0`). Corrigido: `bancar()` agora, pra
  jornada JÁ bancada, atualiza só o campo que falta (`Math.max` — nunca encolhe) em vez de pular a entrada
  inteira. Autocorretivo: `atualizarProgresso()` já roda (e salva) a cada vez que a tela da Arena é aberta, então
  o saldo se ajusta sozinho na próxima visita, sem precisar de migração à parte. `tests/progresso-conta.test.js`
  ("bancar preenche maxDinheiro de jornada JÁ bancada antes desse campo existir") trava a regressão.

  **Revisão do que a loja vende (mesmo dia, pedido do usuário: "não era pra comprar item de raide, e sim cura,
  revive, stat e itens de segurar").** A primeira versão vendia os 10 itens de raide — **errado**, esses
  continuam só de prêmio (`ITENS_DE_RAIDE`, exibidos como lista comum no lobby, sem botão de comprar). `htmlLoja`
  agora vende, pelo MESMO preço da loja normal (`ITEMS[id].price`, pago com saldo em vez de dinheiro de run):
  `CURA_ARENA` (16 itens: Potion…Full Restore, curas de status, Ether/Max Ether, **Revive e Max Revive juntos** —
  o pedido incluía revive explicitamente), `STATS_ARENA` (os 5 X-itens) e os 13 `ITENS_SEGURADOS` clássicos
  (Restos, Orbe da Vida…). **Pratos do Arceus e os 7 segurados de prêmio de raide NÃO entram** (continuam
  exclusivos de badge/prêmio — não é o que foi pedido, e manteria a exclusividade que acabou de ser desenhada
  pra eles). Cura/stat se compram QUANTAS vezes o saldo permitir (se gastam no uso, sem teto de estoque — como
  a loja normal); item de segurar se compra **UMA vez só** (botão desliga com `inventarioRaide()[id] > 0`) porque
  não se GASTA equipando, só ocupa um slot — ver abaixo.

  **Equipar item de segurar** (`htmlEquipar`, entre "Seu Hall da Fama" e a Loja): pra cada Pokémon selecionado
  pra luta, um `<select data-arena-equipar>` lista os segurados que a conta já possui; a escolha fica em
  `equipamento[chave do Hall]` (memória, não localStorage — resetado em `arenaFim`), aplicada em `M.item` só na
  hora de `reidratar()` (montar o Pokémon pra luta). Um item físico não pode estar em dois Pokémon ao mesmo
  tempo: escolher o mesmo id pra outro automaticamente tira de quem tinha antes (`arenaEquipar`), e o `<option>`
  avisa "(tira de Fulano)". **Simplificação assumida**: equipar NÃO gasta o item do estoque — a Arena não tem
  onde guardar "quem está com o quê" entre tentativas (o Hall não tem campo de item, diferente da run), então a
  saída mais simples é: comprado uma vez, reutilizável em toda luta futura, pra sempre. Isso vale até pra itens
  que no jogo normal se GASTAM na batalha (Faixa de Foco, as frutas) — na Arena eles nunca desaparecem de
  verdade, mais generoso que numa run de verdade, mas evita construir um sistema de "empréstimo por luta" só
  pra cá. `main.js` liga o `change` do `<select>` (`data-arena-equipar`) — não existe handler genérico de
  `data-act` pra `change`, então entrou como um `if` a mais no listener de `change` já existente (ao lado de
  `data-ranking-especie`).

  **✅ CORRIGIDO (28/09/2026) — segundo bug real, relatado de novo pelo usuário: "os itens equipáveis e
  consumíveis não estão funcionando, não consigo equipar".** Diferente do primeiro bug (saldo travado em ₽0):
  desta vez o saldo descontava certinho na compra, mas **o item nunca entrava no inventário** — confirmado
  reproduzindo o fluxo inteiro com jsdom (seleção do Hall → compra → checar `pokerpg-raide-v1`): depois de
  `arenaComprarSegurado('leftovers')`, o saldo caía mas `inventarioRaide()` continuava `{}`. Causa raiz:
  `evento.darItensDeRaide()` tinha uma lista própria, `IDS_DE_RAIDE = ['cristal-de-ruptura', 'selo-de-interrupcao',
  'escudo-astral']` — os TRÊS itens de raide originais, de ANTES da Loja de preparo existir — e rejeitava em
  silêncio qualquer id fora dela. Ninguém atualizou essa lista quando a Loja passou a comprar Potion, X Attack,
  Restos, Orbe da Vida etc. pela MESMA função: `arenaComprarComum`/`arenaComprarSegurado` chamavam
  `darItensDeRaide({[id]:1})` normalmente, a função rodava sem erro, só que o `if (IDS_DE_RAIDE.includes(k) ...)`
  descartava a entrada — sem exceção, sem aviso, o dinheiro simplesmente sumia. Isso também afetava o prêmio
  semanal da Arena (`arena.finalizar`) e o repasse da mochila da run pro Hall ao terminar uma jornada (`fim.js`
  linha ~40): qualquer um dos 14 itens de raide mais novos (além dos 3 originais) sofria o mesmo descarte.
  **Corrigido**: a validação interna virou `ITEMS[k]` (o id existe de verdade) em vez da lista de 3 — cada
  chamador já cura o que manda (as listas `CURA_ARENA`/`STATS_ARENA`/`ITENS_SEGURADOS` em `arena.js`, o filtro
  `ITEMS[k]?.raide` em `fim.js`/`arena.finalizar`), então não precisa de uma segunda whitelist redundante e
  desatualizável dentro da função. `IDS_DE_RAIDE` foi removida (não sobrava uso nenhum fora desta função).
  `tests/hall.test.js` reescrito pra travar exatamente este caso (`potion`/`leftovers`, fora dos 3 originais,
  precisam entrar).

  **✅ FEITO (28/09/2026) — `js/loja-conta.js`: Loja de preparo + Hall da Fama extraídos, compartilhados com o
  Multiplayer.** Junto do segundo bug acima, `arena.js` tinha a ÚNICA implementação de "comprar com o saldo da
  conta" e "reconstruir um Pokémon do Hall fora de uma run" — exatamente o tipo de duplicação que already causou
  o bug (duas listas de validação que podem desalinhar). Extraído pra `js/loja-conta.js` (tem rede —
  `loadPokemon`/`loadMove` — mas sem DOM, quem desenha continua sendo a tela): `comprarComumConta`/
  `comprarSeguradoConta` (a compra em si), `htmlLojaConta`/`htmlEquiparConta` (o HTML, genérico — quem chama passa
  os `data-act`/`data-*` de cada tela) e `reidratarHall` (a reconstrução do Pokémon). `arena.js` foi reescrito
  pra usar isso (mesmo comportamento, confirmado com o mesmo repro de jsdom do bug acima).

  **✅ FEITO (28/09/2026) — ☄ Sala de Raide: enfrentar o chefe da semana em grupo sem run nenhuma
  (`js/multiplayer.js`).** Pedido do usuário: "pra iniciar uma raide multiplayer eu preciso criar um save novo,
  isso não está certo" — verdade: `iniciarBatalhaMP` sempre exigiu `temRun()` pro modo co-op inteiro (`if
  (!temRun()) throw new Error('Co-op é jogar a run de alguém...')`), incluindo a luta do chefe da semana em
  grupo. Um TERCEIRO valor de `sala.config.modo` (além de `'coop'`/`'pvp'`): **`'raide'`** — nenhum jogador
  precisa de run, cada um leva de 1 a `MAX_TIME_HALL` (3) Pokémon do PRÓPRIO Hall da Fama (mesma fonte da Arena,
  `carreira.hallDaConta()`) e compra/equipa da PRÓPRIA Loja de preparo (`js/loja-conta.js`, acima) — tudo local,
  sem afetar os outros jogadores. **Seleção vira "foto" pela MESMA `fotoDoMon` de sempre**: `sala.hallSel`
  (seleção + equipamento, só meu) alimenta `atualizarHallMons()` (async — busca na PokéAPI via `reidratarHall`)
  que guarda o resultado em `sala.hallMons`; `minhasFotos()` ganhou um terceiro ramo (antes do `convidado`) que
  usa `sala.hallMons` quando `sala.config.modo === 'raide'` — o resto do jogo (montarLado, mp-motor, presença)
  nunca soube a diferença, porque uma "foto" de Hall é só mais uma foto. **"Pronto"**: `sala.pronto` (booleano,
  local) entra no payload de presença (`meuPayload().pronto`); `todosProntosParaRaide()` (`sala.membros.every(m
  => m.pronto && m.mons?.length)`) trava o botão "☄ Começar a Raide" do anfitrião — pedido explícito do usuário
  ("quando todos derem pronto, a Raid começa"). **Construção do chefe SEM run**: dentro de `iniciarBatalhaMP`,
  um `if (cfg.modo === 'raide')` que chama `eventoDaSemana(agoraDoEvento())` DIRETO (nada de
  `situacaoDoEvento({dificuldade, gen})`, que exige a run do anfitrião) e seta `tipo = 'evento'` — o resto do
  turno inteiro (ESPERTEZA.chefe, revive, itens de raide, clima fixo do chefe, cooldown de 8h por jogador) é
  **reaproveitado de graça**, porque tudo isso já era condicionado só a `sala.tipo === 'evento'`/`b.evento`, nunca
  a "tem run". **Resultado não mexe em run nenhuma**: `raideSemRun()` (`sala.config.modo === 'raide'`, sincronizado
  a todo mundo pela própria `sala.config` que já viaja no broadcast `'lobby'` — não precisou de um campo novo no
  estado da batalha) guarda `aplicarCoop` (desvia pra `aplicarRaideSemRun`, que nunca toca `G.S` e nunca é
  permadeath) e os pontos que liam `G.S.bag` durante a luta (`consumirRevives`, `consumirItensComuns`,
  `raideDisponiveis`, `itensComunsDisponiveis`, `podeReviver`, `gimmicksDisponiveisMP`, `centroNaSala`) — sem
  isso, um jogador que TAMBÉM tivesse uma run aberta enquanto jogava a Sala de Raide teria itens/gimmicks da
  RUN aplicados num Pokémon do HALL, ou a run debitada por engano. **Prêmio**: `aplicarRaideSemRun`/
  `premiarRaideSemRun` espelham exatamente `arena.finalizar` (mesma função `registrarVitoriaDeEvento` +
  `darItensDeRaide` da conta) — dinheiro/Rare Candy nunca saem daqui, só de dentro de uma run de verdade.
  **Simplificação assumida**: sem Mega/Tera/Z-Move/Gigantamax na Sala de Raide (mesma limitação da Arena — o
  motor do co-op fora de uma run não tem isso) e sem balancear/zona (Hall sempre no nível real, como a Arena).
  O caminho ANTIGO (co-op dentro da run do anfitrião, botão `☄ Chefe da semana` no modo Co-op) continua existindo
  do lado do modo `'raide'` na mesma lista — quem prefere lutar com o Pokémon da run de verdade (XP/dinheiro reais)
  ainda pode.

  **✅ FEITO (28/09/2026) — itens DURANTE a luta na Sala de Raide** (prioridade pedida pelo usuário logo depois
  da leva acima; antes só dava pra escolher/equipar no lobby). `minhaMochila()` (novo, único ponto de decisão) —
  `raideSemRun() ? inventarioRaide() : G.S.bag` — substitui os vários `if (!temRun()...)` espalhados;
  `raideDisponiveis`/`botoesRaide`, `itensComunsDisponiveis`/`botoesItemComum` e `podeReviver` leem daqui em vez
  de checar a run direto. **Revive na Raide usa `mp-motor.reviverCompanheiro`, não `reviverNoEvento`**: a regra de
  sempre (`registrarRevive`, host) exige o TIME INTEIRO caído; `reviverCompanheiro` (a mesma função que a Arena já
  usa) deixa reviver com o time ainda lutando, contanto que tenha pelo menos um de pé — por isso o botão
  `botoesReviver()` (extraído, usado nos TRÊS estados da tela: sem ninguém de pé, esperando os outros, e no seu
  turno normal) aparece bem mais cedo na Raide do que fora dela. **Aceita Max Revive**: o cliente manda
  `acao.pct` (100 se tiver Max Revive no inventário de conta, preferido sobre o normal — mesma prioridade da
  Arena); `reviverCompanheiro` ganhou `estado.revivesTipos[dono]` (lista, mesma ordem de `revivesUsados` — que é
  só um contador, não diferencia QUAL item) pra `consumirRevives` (cliente) saber exatamente qual dos dois
  descontar do inventário de conta a cada uso. `tests/evento-coop.test.js` trava o `revivesTipos`. **Sem mudança
  no motor de verdade**: `usarItemComumMP`/`usarRaideMP` continuam mandando a MESMA ação de sempre
  (`{tipo:'item'|'raide', ...}`) pro `mp-motor.resolverTurnoMP`/`usarRaideNoEvento` — eles nunca souberam de bag
  nenhuma, só o Pokémon; a única coisa que mudou foi QUAL mochila o CLIENTE lê pra mostrar o botão e descontar
  depois.

  **✅ FEITO (28/09/2026) — chat da sala.** Pedido do usuário ao descrever o fluxo completo da Sala de Raide do
  jeito que ele imaginava: criar a sala, chamar amigos/passar código, cada um escolher os 3 do Hall da Fama,
  comprar e equipar, **poder escrever num chat pra quem está na sala**, e só começar quando todos confirmarem
  "pronto". Investigado antes de mexer: tudo o resto da descrição **já existia** (convite por amigo/código,
  seleção do Hall com `MAX_TIME_HALL`=3, Loja de preparo, `todosProntosParaRaide()` travando o botão de começar)
  — só o chat faltava. Broadcast novo no MESMO canal da sala (`pokerpg-sala-<código>`, ao lado de
  `estado`/`acao`/`fim`/`lobby`/`sincronizar`): evento `'chat'`, payload `{de, nome, icone, texto, t}`, sem
  persistir em lugar nenhum — só `sala.mensagens` (memória, até 100 linhas, some ao sair da sala). Não é exclusivo
  da Raide: mora em `telaSala()`, então vale em QUALQUER modo (coop/pvp/raide) e em QUALQUER estado (lobby ou já
  lutando) — a mesma sala serve pra combinar estratégia no meio de um turno. **Cuidado que motivou ficar FORA de
  `#mp-topo`/`#mp-acoes`**: essas duas divs são recriadas inteiras (`innerHTML =`) por `renderSala()`, chamada a
  cada troca de presença e a cada pulso do anfitrião (`PULSO_MS`, ligado o tempo todo em luta) — se o campo de
  texto morasse ali dentro, digitar uma frase enquanto alguém entra na sala apagaria o que já foi escrito no meio
  da digitação. Por isso o chat ganhou sua própria seção em `telaSala()` (criada uma vez só) e `renderChat()` só
  escreve dentro de `#mp-chat-msgs`, nunca no campo de texto. `enviarChatMP()` lê e LIMPA `#mp-chat-input`
  direto (mesmo padrão de outros pontos do arquivo que já leem DOM sem passar por main.js, ex. `#mp-relogio`),
  soma a própria mensagem no `sala.mensagens` NA HORA (o broadcast do Supabase não devolve pro remetente,
  `broadcast:{self:false}` em `nuvem.canalSala`) e só then manda pra rede — sem isso quem escreve não veria a
  própria mensagem até alguém responder. Tecla Enter no campo funciona pelo MESMO padrão do resto do jogo
  (`main.js`, listener de `keydown` por `e.target.id`, igual `#mp-codigo`/`#q`/`#icone-busca`).

  **Usar item comum em batalha** (`arenaUsarItem`): ocupa a vez de quem usar, exatamente como no multiplayer —
  `botoesItemComum` filtra `inventarioRaide()` por `!SEM_BATALHA_MP.some(...)` (exportado de `multiplayer.js`
  pra não duplicar a lista) e `regras.itemTemEfeito`, e a escolha vira `{ref, tipo:'item', item:id}` — o MESMO
  formato de ação que `mp-motor.resolverTurnoMP` já processa (passo "0b" do motor, existia desde "Itens no
  multiplayer" abaixo); **nenhuma linha nova no motor foi precisa** pra isso funcionar na Arena. Depois do turno
  resolver, `resolverTurno()` desconta da Loja de preparo os ids que tinham `tipo:'item'` em `arena.escolhas`.

  **Reviver um caído** (`arenaReviver`, ação LIVRE — não ocupa a vez de ninguém): `mp-motor.reviverCompanheiro`
  é uma generalização de `reviverNoEvento` (o Revive de grupo do multiplayer) SEM a exigência de "o time inteiro
  caiu" — essa exigência nunca abriria na Arena, que só tem UM `dono` em `lados.A` (pra ele, "o time caiu" e
  "ele não tem mais ninguém de pé" são a MESMA condição, e a luta já teria terminado antes de dar chance de
  reviver). `reviverCompanheiro` é, na prática, a regra NORMAL de Revive de uma run de verdade (qualquer aliado
  caído, a qualquer momento, se você tem o item) — restaura paridade, não inventa poder novo; continua com o
  mesmo teto `MAX_REVIVES` (3) por luta. Ganhou um 4º parâmetro `pct` (50 = Revive, 100 = Max Revive — `arenaReviver`
  prefere Max Revive se tiver os dois em estoque). Testado em `tests/evento-coop.test.js` com um helper `timeSolo`
  novo (3 Pokémon do MESMO dono, diferente de `luta()` que modela multiplayer — 1 Pokémon por jogador).

---

## Habilidades: as 7 levas

- **Item 8 — habilidades**: seis levas feitas. A regra que vale: só entra habilidade com gancho FIEL —
  mapear no gancho errado deixaria a habilidade mais forte que o original, e a ficha promete "✓ ativa em batalha".
  A **4ª leva** (41 novas + 13 parciais completadas) criou ~24 ganchos, todos documentados no topo de
  `habilidades.js` e validados em `tests/habilidades.test.js` (a lista `ganchos` do teste precisa ganhar o nome de
  todo gancho novo; o teste também confere tipo/status/atributo/família de cada um). Onde mora cada um:
  `calcDamage`/`effStat`/`chanceAcerto` em `regras.js` (`danoTipo`, `danoTipoClima`, `golpesFamilia` — lista de nomes
  em `FAMILIAS_GOLPE`, porque a PokéAPI não marca soco/mordida/corte —, `recuo`, `superEfetivoCausado`,
  `critContraStatus`, `abaixoDeMetade`, `soStatus`, `ignoraEstagios`, `limitaStatus`) e `golpe.js` (`mudarEstagios`:
  `inverteEstagios`/`dobraEstagios`/`espelhaQueda`/`aoSerBaixado`; `executar`: `aoSerAtingido` via `reagirAoGolpe`
  — UMA reação por golpe, mesmo com vários acertos —, `aoNocautear`, `toque`, `contato` com `sorteio`/`estagio`/`po`;
  `usarGolpe`: `pressao`, `preguica` (`vol.folga`), `bloqueiaPrioridade`; `fimDeTurno`: `curaComVeneno`;
  `semDanoIndireto` é o helper `indireto(m)`, checado em todo dano que não vem de golpe direto).
  **`golpe.aoEntrarEmCampo(entrantes, oponentesDe, ctx)`** é a regra ÚNICA de entrada em campo (Intimidate com
  `imuneIntimidacao`/`intimidaSobe`, clima, terreno, `estagioAoEntrar`, Download `analisa`): `batalha.intimidar`
  (single player) e `mp-motor` (turno 1) só a chamam — antes o multiplayer não tinha Intimidate nem `estagioAoEntrar`.
  Ficaram de fora, documentadas no fim da tabela: Sticky Hold (nenhum golpe rouba item), Regenerator/Natural Cure
  (agem ao trocar), Beast Boost, Analytic, Mold Breaker & cia. **Cuidado ao editar a tabela**: o teste que detecta
  habilidade duplicada varre o bloco com uma regex — não escreva `nome: {` dentro de comentário da tabela.
  **5ª leva** (trabalho noturno autônomo, 27/09/2026 — ver `feedback_autorizacao_raspberry_pi`): 6 habilidades,
  6 ganchos novos (`multMaiorStatClima`, `multMaiorStatTerreno`, `prendeTipo`, `anticipa`, `sincroniza`,
  `flinchChance`), escolhidas por já terem hook DISPONÍVEL no motor de hoje (clima/terreno, `consegueFugir`,
  `aoEntrarEmCampo`, `aplicarStatus` com `fonte`, o cálculo de recuo em `executar`) — não abriram mecânica nova.
  **Protosynthesis/Quark Drive**: reforçam o MAIOR atributo BASE (empate: Atk>Def>SpA>SpD>Spe), ×1,3 ou ×1,5 se o
  maior for Velocidade (regra FIXA dos jogos — por isso o multiplicador não mora na tabela de habilidades, é
  `regras.multMaiorStat`, só o gatilho de clima/terreno mora lá). `regras.maiorStatBase(m)` lê `m.data.base`.
  **Simplificação assumida**: só o gatilho de clima("sol")/terreno(Elétrico) está aqui — Booster Energy (item que
  ativa a mesma coisa fora do clima/terreno certo) ainda não existe no jogo. **Magnet Pull**: `consegueFugir` ganhou
  o parâmetro `preso` (regras.js não sabe de habilidade — `batalha.js`/`mp-motor.js` resolvem `hab(inimigo).prendeTipo`
  e mandam o booleano pronto); Run Away segue ignorando até isso. **Anticipation**: só narra (sem stat/estágio
  nenhum) se algum oponente tiver golpe super efetivo, OHKO ou autodestrutivo — `golpe.aoEntrarEmCampo`, reaproveita
  `especial(g).ohko`/`autoDesmaio` e `typeEff`. **Synchronize**: `aplicarStatus` já recebia `fonte` (pra Salvaguarda);
  ao aplicar burn/paralysis/poison com sucesso, se há `fonte` viva sem status, devolve o MESMO status pra ela com uma
  chamada recursiva passando `fonte: null` — é isso que impede ida-e-volta infinita se os dois tiverem a habilidade.
  Sono/congelamento não sincronizam (fiel aos jogos). **Stench**: 10% de recuo extra em golpe de dano que ainda não
  tem `meta.flinch` própria (senão dobraria a chance à toa).
  **6ª leva** (28/09/2026): 3 habilidades — Sheer Force, Unnerve, Friend Guard —, mais trabalhosas que a 5ª
  (cada uma abriu um gancho/contrato novo, não só reaproveitou hook pronto). `regras.temSecundario(move)` decide
  se o golpe TEM efeito secundário nativo (estágio, status ou recuo por chance — olha `move.stats`/`move.meta`
  direto, sem saber de habilidade); **Sheer Force** usa ela pra bater ×1,3 em `calcDamage`, e `golpe.executar`
  guarda os TRÊS blocos que aplicam efeito secundário (estágio no golpe, status, flinch) com `!hu.sheerForce` —
  time bate mais forte, mas perde o efeito, exatamente como nos jogos. **Unnerve**: `golpe.comerFruta(m, ctx,
  travado)` ganhou um 3º parâmetro — `executar` manda `hu.unnerve`/`ht.unnerve` do lado de FORA na troca direta de
  golpe (`comerFruta(t, ctx, hu.unnerve)`, i.e. quem ataca trava a fruta de quem apanha). **Simplificação
  assumida**: só vale nessa troca direta (é onde os dois lados já estão em mãos, sem precisar de lista de lados) —
  o `comerFruta` chamado no FIM DE TURNO (`fimDeTurno`, pra cada Pokémon do campo) não checa Unnerve do oponente,
  porque esse call site não sabe "quem é o oponente de m" sem uma função de lado pronta. **Friend Guard**
  precisou de um contrato NOVO nos dois `ctx`: `aliadosDe(m)` (lista de aliados VIVOS de `m`, sem ele mesmo) —
  `efeitos.CTX.aliadosDe` (single player: seu lado é `ladoJogador()`, o do inimigo é só `[G.B.enemy]`, porque
  você só enfrenta um por vez) e o `ctx` que `mp-motor.resolverTurnoMP` monta (`vivosMP(s.lados[ladoDe(s,
  m.ref)])`). `golpe.executar` calcula o multiplicador ANTES do laço de acertos (`(ctx.aliadosDe?.(t) ||
  []).reduce(...)`, multiplicativo se houver mais de um aliado com a habilidade) e aplica em `dano` antes dos
  checks de Sturdy/Endure/Faixa de Foco — igual aos jogos, a redução conta pra decidir se aguenta ou não.
  `ctx.aliadosDe` é OPCIONAL (`?.`): um ctx de teste ou futuro que não implemente simplesmente não tem Friend
  Guard, em vez de quebrar. **Ficaram de fora** (mais complexas ainda, precisam de mais projeto): Mold Breaker
  (ignora habilidade do ALVO — precisaria auditar todo gancho de imunidade/defesa do motor pra saber quais
  "furar"), Damp (bloquear autodestruição do OUTRO lado — cross-side igual Friend Guard, mas em cima de uma
  mecânica, autoDesmaio, que ainda não devolve controle pro motor decidir "deixar acontecer ou não"). (Aftermath
  ganhou o gancho "ao desmaiar por contato" que faltava aqui na 7ª leva, abaixo.)
  **7ª leva** (28/09/2026, pedido do usuário: "coloque todas as habilidades pokémons que ainda não estão
  configuradas") — a maior leva até aqui: 43 habilidades novas (165→208 de 314 reais; a contagem "307" das notas
  antigas estava errada, a certa é `abilities.csv` filtrado por `is_main_series`). Pesquisado direto do CSV-fonte
  da PokéAPI (o mesmo usado pelas flags de golpe) pra achar TODA habilidade real que faltava, sem depender do
  `docs/auditoria-batalha.md` (confirmado de novo: desatualizado). Ganchos novos (documentados no topo de
  `habilidades.js`): `multFlag`/`resisteFlag` (dano por FLAG do golpe — Tough Claws, Mega Launcher, Punk Rock),
  `converteTipo` (Aerilate/Pixilate/Refrigerate/Galvanize/Normalize, `regras.golpeDaConversaoDeTipo` — roda ANTES
  do Tera/Battle Bond em `executar`, senão Weather Ball sem clima ficaria Normal em vez de virar o tipo
  convertido), `evasaoConfuso` (Tangled Feet), `acaoRapida`/`sempreLento` (Quick Draw/Stall, a MESMA fila de
  prioridade da Garra Rápida — `regras.ordenarAcoes` ganhou o degrau `lento`, sempre por último dentro da própria
  prioridade), `prankster`/`prioridadeVoador`/`prioridadeCura` (`regras.prioridadeEfetiva`, soma com a prioridade
  nativa do golpe), `prendeQualquer` (Shadow Tag/Arena Trap, resolvido em batalha.js/mp-motor ao lado do Magnet
  Pull que já existia), `semContato` (Long Reach: `encostou = fazContato(g) && !hu.semContato`, variável nova que
  substituiu as 4 chamadas cruas de `fazContato(g)` no meio do golpe — Elmo Rochoso, o bloco de contato inteiro e
  Poison Touch), `aliadoBoost` (Battery/Power Spot/Steely Spirit/Plus-Minus, reforça o golpe de um ALIADO —
  mesmo padrão do Friend Guard só que multiplicando em vez de cortar), `aoNocautearMaior` (Beast Boost, usa
  `regras.maiorStatBase` em vez de um atributo fixo), `aftermath`/`aoDesmaiarDanoAtacante` (Aftermath só com
  contato, Innards Out com qualquer nocaute — os dois usam `hpAntesDoGolpe`, o HP do alvo capturado ANTES do
  laço de acertos, pra saber quanto ele tinha ao cair), `dreno:'inverte'` (Liquid Ooze inverte o bloco de
  `meta.drain`), `roubaItem`/`protegeItem` (Pickpocket só contato, Magician qualquer golpe de dano, Sticky Hold
  bloqueia os dois), `imuneGolpeStatus` (Good As Gold, checado ANTES de despachar pra `golpeDeStatus`),
  `podeEnvenenarQualquer` (Corrosion ignora a imunidade de TIPO ao veneno em `aplicarStatus`, mas não a de
  habilidade — Immunity continua protegendo), `protegeAliadoStatus` (Flower Veil, novo helper
  `protegidoPorFlores(m, ctx)` — Grama no lado de quem tem a habilidade, ela mesma incluída, não perde atributo
  nem pega status de fora, em `mudarEstagios` E `aplicarStatus`), `copiaHabilidadeAoEntrar` (Trace, em
  `aoEntrarEmCampo`), `avisaGolpeForte`/`revelaItem` (Forewarn/Frisk, só narração), `moody` (em `fimDeTurno`;
  sorteia o atributo que SOBE, tira ele da lista e só então sorteia o que DESCE — nunca sorteia de novo até dar
  diferente, que travaria pra sempre com `Math.random` mockado num valor fixo, como em teste), `ripen`/
  `curaBerryExtra` (Ripen dobra a cura, Cheek Pouch cura extra com QUALQUER fruta — os dois em `comerFruta`),
  `semItemEmBatalha` (Klutz: `segurados.seg(m)` — o ÚNICO ponto por onde toda leitura de item passa — devolve
  `{}` inteiro quando a habilidade está ligada, então nenhum gancho de item precisou saber de Klutz),
  `algodaoCai` (Cotton Down), `trocaHabilidadeContato` (Mummy/Lingering Aroma = contágio, a sua vira a de quem
  encostou; Wandering Spirit = TROCA as duas). **Trace e a troca/contágio de habilidade compartilham o mesmo
  desfazer** (`golpe.desfazerTrace`, chamado em `batalha.endBattle` pra TODO o lado do jogador — sem isso a
  habilidade roubada/copiada ficava pra sempre no save) e a MESMA trava (`ABILIDADE_TRAVADA`, hoje só
  `stance-change`): nem Trace copia Mudança de Postura de um Aegislash oponente, nem Mummy consegue apagar a
  Mudança de Postura de um Aegislash que ataca — ela é a única habilidade da tabela que mexe com mecânica PRÓPRIA
  do motor (a troca de forma), então é a única que precisa dessa proteção; qualquer outra habilidade copiada sem
  gancho aqui simplesmente não faz nada, sem risco. No multiplayer `m.ability` muda só na CÓPIA de rede
  (`fotoDoMon`), descartada no fim da luta — só o single player precisa desfazer. **Ficou de fora, com razão
  anotada em `habilidades.js`**: Regenerator/Natural Cure (agem ao TROCAR de Pokémon, que você nunca faz), Mold
  Breaker & cia. (furar a habilidade do alvo em TODO cálculo do motor), Stakeout/Dancer (pedem um estado de turno
  — "acabou de entrar", "outro usou golpe de dança" — que o motor não rastreia), Neutralizing Gas (suprimiria
  TODO mundo em campo, invasivo demais), as formas dinâmicas de espécie única (Ice Face, Gulp Missile, Schooling,
  Shields Down, Hunger Switch, Zen Mode, Power Construct, Comatose, Disguise), Screen Cleaner e Mimicry (ficaram
  pra uma leva futura, sem gancho novo hoje) e Gorilla Tactics (a trava de golpe único hoje só olha item,
  `seg(m).choice`, em TRÊS telas — render.js, arena.js, multiplayer.js —, e mexer nas três sem poder testar
  visualmente numa sessão sem navegador era risco alto demais pra esta leva).
  **8ª leva** (04/10/2026, pedido do usuário: "termine as habilidades restantes") — 32 habilidades novas
  (217→249 de 314). O corte desta leva foi por CUSTO, não por ordem de lista: entrou tudo que cabia em linha de
  tabela com gancho existente ou em um gancho pequeno e localizado; ficou fora o que exigiria mecânica de troca
  de Pokémon, forma dinâmica ou mudança em regra lida por várias telas (os quatro motivos estão escritos no fim
  da tabela em `habilidades.js`, substituindo o comentário antigo — que já estava errado, porque listava Stakeout
  e Screen Cleaner como pendentes quando o primeiro já existia).
  **Sem código novo** (só linha de tabela, provando que os ganchos antigos pagam juros): Fluffy e Aura Guard
  (`resisteFlag` de contato + `resiste.fire` dobrado), Fire Mane (`danoTipo`), Dragonize (`converteTipo`),
  Eelevate (`imuneTipo: 'ground'` — e `regras.noChao` lê daí, então as armadilhas de chão já vêm de graça),
  Tera Shell (`hpCheio: 0.5`), As One nas duas versões (`unnerve` + `aoNocautear`, as duas metades já existiam).
  **Ganchos novos em `regras.calcDamage`**: `ruina` (os quatro Tesouros da Ruína — num 1×1 "baixar 25% de um
  atributo de todo mundo menos o meu" É multiplicar o dano deste golpe, então saiu em duas linhas, uma pra quem
  ataca e uma pra quem defende; com aliado em campo o aliado não sente, e isso está anotado), `aura`/`anulaAura`
  (Dark/Fairy Aura valem pros DOIS lados, então basta um dos dois do golpe ter; Aura Break inverte pra ×0,75) e
  `eficacia(hu, tipo, alvo)` — função nova, hoje só pra `ignoraImunidade` (Scrappy/Mind's Eye), que vale **só
  quando a eficácia é ZERO**: filtrar o tipo do alvo sempre baixaria um Sombrio em Gengar sem motivo. Os quatro
  pontos que decidem "o golpe faz algo?" passam a ler essa função (dano, motor, OHKO e a IA em `notaDoGolpe`).
  **Ganchos novos em `golpe.js`**: `semSaidaForcada` (Suction Cups, dentro de `sairDeCampo` — o único ponto por
  onde o motor PEDE saída, então vale igual em todo ctx, e `motivo: 'medo'` do Wimp Out continua passando, porque
  ali quem sai é por vontade própria), `aoRecuar` (Steadfast), `corpoMaldito` (Cursed Body reusa a trava do
  Disable, `vol.desativado`, então IA/telas/motor respeitam sem regra nova), `tipoDoProprioGolpe` (Protean/Libero
  — uma vez por entrada em campo, como na Gen 9, e a trava é o próprio `vol`, que já zera ao entrar) e
  `tipoDoGolpeRecebido` (Color Change, sem limite), os dois gravando em `vol.tipos`, o MESMO lugar do Soak —
  nunca em `m.data`, que é compartilhado pela espécie; `atravessaTelas` (Infiltrator, lido em `multTelas` E na
  Salvaguarda de `aplicarStatus` — é uma habilidade, dois pontos), `venenoConfunde` (Poison Puppeteer),
  `toque.qualquer`/`toque.grave` (Toxic Chain: mesmo gancho do Poison Touch, agora sem precisar encostar e com
  veneno grave), `pesadelo` (Bad Dreams) e cinco de ENTRADA em campo: `zeraEstagiosAoEntrar` (Curious Medicine),
  `limpaTelas` (Screen Cleaner), `curaAliadoAoEntrar` (Hospitality), `copiaEstagiosDoAliado` (Costar) e
  `estagioInimigoAoEntrar` (Supersweet Syrup, uma vez por batalha).
  **`ctx.oponentesDe` é novo nos DOIS ctx** (`efeitos.CTX` e o que `mp-motor` monta): o Bad Dreams precisa da
  lista do outro lado no fim do turno, e `aoEntrarEmCampo` recebia a sua por parâmetro mas `fimDeTurno` não tinha
  como saber. Mesmo movimento do `aliadosDe` na 6ª leva — gancho faltando num dos ctx = habilidade inerte lá.
  **Gluttony foi RECUSADA de propósito**: as duas frutas de HP do jogo (Oran e Sitrus) já comem em 50%, que é
  exatamente o limiar que a habilidade adiantaria — ligar ela seria prometer efeito e não entregar nenhum. O
  primeiro rascunho tinha um parâmetro `guloso` em `segurados.frutaAgora`; ele saiu junto, pra não deixar código
  morto fingindo que a habilidade existe.
- ✅ FEITO (28/09/2026) — **"Flags" de golpe** (Contato, Som, Projétil/Bola e mais). A PokéAPI pública
  (`pokeapi.co/api/v2`) não expõe isso, mas o repositório-fonte que a GERA tem, em CSV puro sem chave nenhuma:
  `move_flags.csv` (21 flags), `move_flag_map.csv` (golpe → flag, por id) e `moves.csv` (id → nome kebab-case,
  o mesmo já usado em `regras.FAMILIAS_GOLPE` e em todo golpe do jogo). `ferramentas/gerar-golpe-flags.mjs` (Node,
  roda no Raspberry Pi) baixa os três e gera `js/dados-golpe-flags.js`: `GOLPE_FLAGS` (748 golpes mapeados) +
  `FLAGS_VALIDAS` (as 21, pra validar typo em `imuneFlag` novo — ver abaixo). **Sharpness/"cortante" continua
  fora** (é flag da Gen 9, mais nova que esse dado-fonte) — `FAMILIAS_GOLPE.corte` segue sendo a única fonte pra
  corte. **Gen 9 tem buraco no dado-fonte**: `torch-song`/`alluring-voice`/`psychic-noise` (sonoros nos jogos de
  verdade) EXISTEM em `moves.csv` mas não têm nenhuma flag em `move_flag_map.csv` — o gerador não inventa, então
  esses golpes ficam sem a flag `sound` até o repositório-fonte atualizar (Soundproof não os bloqueia).
  **Ganho 1 — corrigido o proxy de contato**: `regras.fazContato(move)` usa a flag `contact` de verdade quando o
  golpe está mapeado (Earthquake é físico e NÃO faz contato — o proxy antigo, `move.cls === 'physical'`, errava
  esse caso) e só cai pro proxy antigo se o golpe não estiver na tabela (plano B, nunca "sem contato" à toa).
  Trocado nos 4 pontos de `golpe.js` que liam `g.cls === 'physical'` como "fez contato": a barreira que pune
  contato (King's Shield e cia.), o Elmo Rochoso, o bloco de Static/Rough Skin/Effect Spore/Gooey/Iron Barbs e o
  Poison Touch. **Ganho 2 — duas habilidades novas**: `soundproof: { imuneFlag: 'sound' }` e
  `bulletproof: { imuneFlag: 'ballistics' }` (`habilidades.js`) + o gancho `imuneFlag` em `golpe.executar` —
  checado ANTES até do golpe de status (diferente de `imuneTipo`, que só vale pra dano): Soundproof bloqueia
  Growl tanto quanto Hyper Voice, porque a imunidade é da FLAG, não de ser golpe de dano. **Não mexido**: a
  generalização do pólen (`contato.po`/`imunePo`, hoje hardcoded pra Overcoat/Grama) — ficou de fora desta leva
  por escolha (`AskUserQuestion`: o usuário pediu dados + contato + as duas habilidades novas, não a
  generalização do pólen). `tests/regras.test.js` (cobertura da tabela, `temFlag`, `fazContato` com casos reais)
  e `tests/habilidades.test.js` (Soundproof/Bulletproof em batalha, `imuneFlag` validado contra `FLAGS_VALIDAS`).
  **Dois testes existentes precisaram de ajuste**: "Rough Skin"/"Poison Touch" simulavam golpe especial fazendo
  `golpe({ cls: 'special' })` em cima do Tackle padrão (nome continuava "tackle", só a classe mudava) — com a
  flag de verdade, Tackle tem `contact` INDEPENDENTE da classe simulada no teste, e os dois passaram a "encostar"
  de novo; trocado pra `golpe({ name: 'ember', cls: 'special' })`, um golpe especial de verdade sem a flag.

---

## Gimmicks: Mega, Tera, Z-Move, Gigantamax

### 2. ✅ FEITO — Cada Gen é uma jornada
Implementado em atalha.vencerGen (a pergunta), 
egras.pontuacao + multContinuacao (a penalidade) e supabase/migrations/ (o servidor recalcula e RECUSA a jornada se a conta não bater — mudou num lado, muda no outro; 	ests/schema.test.js trava isso). S.continuacoes conta quantas vezes a jornada seguiu; estatisticasDaJornada leva isso e campeaoDe pro resumo. A tela de fim já propõe o mapa seguinte (G.gen).

#### O desenho acordado era:
Hoje, fora do Roguelike, vencer os lendários deixa **seguir com o mesmo Pokémon** pro mapa seguinte, com os níveis escalados (foi assim que um testador chegou a Hoenn começando no nível 90). Passa a ser:
- **Padrão**: fechar a Gen **encerra e pontua a jornada**; o Pokémon **se aposenta** (fica registrado na carreira como campeão daquela Gen) e você começa uma **jornada nova** no mapa seguinte, escolhendo outro Pokémon, **no nível 5 e com o mapa nos níveis normais** (2–62). Nada de mochila, dinheiro ou aliados atravessa.
- **Alternativa** (a de hoje): seguir com o mesmo Pokémon em nível alto, oferecida ali no fim e valendo **menos pontos no ranking**.

### 3. ✅ FEITO — Badges com vantagem permanente
Implementado em `js/badges.js` (59 badges numa tabela única, puro, `tests/badges.test.js` — contagem conferida em 08/10/2026: Tipos 18, Eventos 16, Caçada 4, Laços 5, Coleção/Parceiros/Coragem/Rayquaza 3 cada, Gimmicks 2, Maestria 2) e ligado na criação
(`criacao.renderVantagens`, `vantagensDe`) e na tela 🏅 Conquistas. Cada badge é medida do **progresso
permanente** (nunca do histórico, que o jogador pode apagar — `contextoBadges` monta o `ctx` a partir de
`progresso-conta.js`) e paga uma vantagem na PRÓXIMA jornada: itens (empilham) e/ou dinheiro inicial (soma),
aplicados em `criacao.iniciarJornada` (`money: 500 + v.dinheiro`). **Interruptor na criação** (`G.semVantagens`)
deixa jogar sem elas por `regras.BONUS_SEM_VANTAGENS` (+10%) na pontuação final (`pontuacao()`, e o mesmo peso
no SQL — mudou aqui, muda em `supabase/migrations/`). **Rayquaza são DUAS badges separadas**, como pedido
explicitamente pra não bugar: `rayquaza-shiny` (recrutar um shiny) e `rayquaza-mega` (1.000 golpes finais sendo
ele) contam sozinhas, em qualquer ordem; uma terceira (`rayquaza-lenda`) só fecha quando as duas estão prontas
e é a única que dá o prêmio grande (loja de graça pra sempre, `S.lojaGratis` em `regras.precoItem`).

**🧬 Potencial máximo (01/10/2026) — IVs perfeitos, e o botão do admin.** Pedido do usuário: um botão pra a conta
admin sempre nascer com IVs 31, e **a mesma coisa liberável por qualquer jogador** através de uma conquista "bem
complexa". Virou **uma badge** (`ivs-perfeitos`, grupo Maestria) em vez de uma conquista de `conquistas.js` ou de um
interruptor de admin, por três razões: badge já é o canal de "vantagem na PRÓXIMA jornada", já é medida do progresso
permanente, e já é desligada pelo `G.semVantagens` — e esse último ponto é o que importa de verdade, porque IVs
perfeitos **somados** ao bônus de +10% de "jogar sem vantagens" seria o melhor dos dois mundos no ranking. É a
segunda badge na história do arquivo a pagar uma REGRA em vez de item/dinheiro (a primeira foi a loja grátis do
Rayquaza), e o comentário no topo de `badges.js` sobre "vantagens de regra ficam pra depois" vale menos do que o
pedido explícito.

A medida é **1.000.000 de dano causado pelos SEUS golpes** somando a carreira inteira (`ALVOS.dano`). O contador
(`conquistas.registrarDano`) mora **dentro de `S.registro.abates`**, como um número solto ao lado de `total`, e isso
é de propósito: `estatisticasDaJornada` copia `abates` inteiro pra carreira, então o campo sobrevive ao fim da
jornada **sem precisar entrar em lista branca nova** — foi exatamente o que derrubou `abates` e `shiniesAmigos`
quando nasceram. As duas listas brancas que ele PRECISOU atravessar são as de `progresso-conta.js` (`bancar` e
`totaisDe`), que enumeram campo por campo.

Onde conta: `batalha.turn`, no único ponto que já tinha o HP do inimigo antes e depois de um golpe seu
(`hpAntes - E.hp`, a mesma linha que decide `B.abate`). Então **dano do aliado não entra** (mesma regra do golpe
final), nem veneno, armadilha ou recuo, nem o modo Fácil (`MODO_NAO_CONTA`), e inimigo curado no meio do turno não
vira dano negativo (`!(d > 0)`). Aplicado em `criacao.iniciarJornada` via `makeMon(..., { ivs: IVS_MAX })`
(`pokemon.IVS_MAX`, congelado e compartilhado — nada no jogo escreve em `mon.ivs` depois de criado).

**O botão do admin não é um atalho paralelo**: `dev.liberarIvsPerfeitos` só põe o contador de dano no alvo dentro da
entrada `__teste__` do livro-caixa, igual ao que `liberarMegas` faz com a Pedra Mega. Assim o botão testa o caminho
de verdade e 🧹 Limpar devolve a conta ao estado real. **Ficou de fora**: aliados recrutados continuam com IVs
sorteados (a badge é sobre o Pokémon que VOCÊ é) — revisto em 08/10/2026 pela badge irmã, abaixo — e as outras 6
construções de "IV 31" espalhadas por `batalha.js`/`arena.js`/`multiplayer.js` não foram trocadas por `IVS_MAX`: é
código que funciona, e a dedução valeria um diff maior do que o ganho. **As 3 de `batalha.js` foram trocadas em
08/10/2026**, porque a badge irmã já precisava importar `IVS_MAX` ali — as de `arena.js`/`multiplayer.js` seguem.

**🌿 Rotas em potencial máximo (08/10/2026) — os IVs 31 do outro lado do campo.** Pedido do usuário: "uma missão
para que todos os pokés das rotas venham com os IVs no máximo". Virou **badge**, e não missão, por uma razão de
estrutura e não de gosto: prêmio de missão (`dados.MISSOES_GLOBAIS`) é `{ dinheiro?, itens? }` e cai **nesta**
jornada (`missoes.verificarMissoes` credita na hora), enquanto mudança de REGRA é exatamente o que badge existe
pra pagar, e sempre na jornada SEGUINTE. Transformar prêmio de missão em regra pediria um canal novo de vantagem
dentro de `missoes.js`, paralelo ao de `vantagensDe` — dois caminhos pra mesma coisa, e o que a próxima regra
usasse seria sorteio.

**A medida é 500 aliados recrutados na carreira** (`ALVO_AMIGOS_MAX`, 5× o alvo da badge "Líder da matilha", que
usa o mesmo contador). Medir AMIZADE é a escolha de design: o selvagem da rota é de onde sai todo aliado (petisco,
`amizade.oferecer`) e, por eles, todo ovo (`ovos.js` cruza o casal do esconderijo), então quem recrutou 500 ao
longo da carreira passa a recrutar **perfeitos**. O contador já existia em `contextoBadges.amigos` (soma de
`porJornada[].amigos`, do progresso permanente, que nunca encolhe) — **nenhum campo novo** e nenhuma entrada em
`MEDIDAS`, que é pra badge criada pelo editor, não pra badge de fábrica.

**Aplicado num ponto só**: `batalha.novoOponente`, a porta ÚNICA do selvagem — encontro comum, acompanhante de
grupo (⚔ Saga) e lacaio do Alfa saem todos dali, o mesmo motivo por que o item segurado do selvagem já era posto
lá. A flag mora em `S.ivsSelvagens`, gravada por `criacao.iniciarJornada` ao lado de `S.lojaGratis` (vantagem de
regra tem de sobreviver ao F5: a badge é conferida na CRIAÇÃO, não a cada encontro). `G.semVantagens` desliga,
como em todas — IVs perfeitos dos dois lados somados ao bônus de pontuação do desafio puro seria o melhor dos dois
mundos, o mesmo raciocínio da badge de cima.

**O custo está na descrição, de propósito.** A badge deixa o selvagem que te ENFRENTA perfeito também, e isso não
é efeito colateral que dê pra separar: é o mesmo Pokémon antes e depois do petisco. Esconder isso faria o jogador
descobrir na pancada uma vantagem que ele conquistou — então o texto da badge, o `log` da criação, o README e o
patch note dizem os dois lados. **Ficou de fora**: equipe de treinador (`novoOponenteTreinador`), porque aquele
Pokémon é do treinador e não da rota, e metade dela nem sai do pool; Alfa, lendário e chefe de rota, que já eram
31. É uma linha em `novoOponenteTreinador` se o usuário quiser estender.

**De quebra, um defeito achado no caminho**: `tela-conquistas.secaoBadges` só sabia descrever prêmio de item,
dinheiro e loja grátis, então "Potencial máximo" — a badge mais longa do jogo — aparecia na lista com **"Dá: —"**.
Duas linhas no `premio()`, e vale pras duas.

**Pratos do Arceus (28/09/2026) — revisão do item por tipo.** As 18 badges "Especialista em X" (`ALVO_TIPO` =
1.000 abates daquele tipo, mesmo número do Mega/Vínculo) davam originalmente uma pedra de evolução (quando o
tipo tinha uma) ou o petisco de afinidade (quando não tinha) — pedido do usuário pra trocar: pedra de evolução é
vantagem fraca pra quem já escolheu o Pokémon, e petisco de afinidade é item de CAPTURA, não faz sentido como
prêmio de vantagem em batalha. Viraram os **18 Pratos do Arceus + Lenço de Seda** (`dados.ITENS_VANTAGEM_TIPO` +
`dados.PLACA_DO_TIPO`, item real dos jogos nunca implementado aqui antes): cada um dá **+20% de dano nos golpes
daquele tipo** enquanto segurado, reaproveitando o gancho `danoTipo` que já existia (`segurados.js`, criado pro
Núcleo Eternamax) — gerado direto de `PLACA_DO_TIPO` num `Object.fromEntries`, então nunca desalinha qual prato é
de qual tipo. **Normal é a única exceção real**: nos jogos o Arceus não tem Prato Normal (a forma base dele já É
Normal, sem prato nenhum equipado), então usa o Lenço de Seda. `badges.premioDoTipo` só lê `PLACA_DO_TIPO[t]`
agora — as tabelas antigas `PEDRA_DO_TIPO`/`PETISCO_DO_TIPO` saíram. Sem `price`: só vêm da badge, não se compram.

**Backlog anotado (28/09/2026): Arceus deveria ser um chefe de raide** — ver "Próximos passos combinados" acima.

### 4. ✅ FEITO — Mega Evolução
Tabela gerada em `js/dados-megas.js` (95 formas, 89 espécies — `ferramentas/gerar-megas.ps1`; 6 espécies têm 2 formas: Charizard e Mewtwo X/Y, e as Mega Z de Absol, Garchomp, Lucario e Raichu. O texto antigo dizia "96 formas, 93 espécies" e contradizia o "89 Megas" mais abaixo neste arquivo — conferido rodando em 29/09/2026), mecânica em `js/mega.js`.
Decisões fechadas com o usuário: **só o jogador** megaevolui (aliado nunca); **uma por batalha** e **não gasta o turno**;
**Alfa, lendários e treinadores** também megaevoluem, ao cair a **metade do HP** (`HP_MEGA_INIMIGO`); **Primal**
(Groudon/Kyogre) entra na mesma mecânica com outro nome. As formas são PRÉ-CARREGADAS em `iniciar()` — buscar no meio
do turno é o que a Mudança de Postura do Aegislash evitou. `desfazerMega` roda pra toda a equipe em `endBattle`:
sem isso o Pokémon fica Mega pra sempre, porque `M.data` vai junto no save. `megasDoJogador()` mora em `mega.js`
(não em `batalha.js`) porque `render.js` também precisa dela e não pode importar `batalha.js` — daria ciclo.

### 5. ✅ FEITO — Terastalização
`js/tera.js` (gatilho) + `regras.tiposDefensivos`/`regras.multStab` (a conta, pura e testada). A conquista é por
TIPO, não por espécie: você escolhe na hora entre os tipos já liberados. Mesma economia da Mega — uma por batalha,
não gasta o turno, desfaz em `endBattle`. Diferente da Mega, **não troca `M.data`**: guarda só `M.tera`, e quem lê
são as regras — por isso desfazer é uma linha. `render.badgesDeTipo` mostra o tipo Tera no lugar dos originais
(mostrar os antigos faria a pessoa calcular a fraqueza errada). O inimigo terastaliza (Alfa/lendário/treinador, tipo sorteado) — ver "Gimmicks do inimigo e do co-op".

### 7. ✅ FEITO — Gigantamax
`js/dynamax.js` + `regras.poderMax`/`MULT_HP_DYNAMAX`/`TURNOS_DYNAMAX`. **Única gimmick sem item** (25 jornadas já
é o preço). Dobra o teto de HP e o HP atual por 3 turnos; `passarDynamax` roda na virada da rodada e
`desfazerDynamax` também em `endBattle` — sem isso o teto dobrado ia junto no save, pra sempre. A volta guarda
`hpMaxAntes` e reaplica a PROPORÇÃO: recalcular pela base perderia o dano sofrido enquanto gigante. Tabela do Max
mais modesta que a do Z de propósito (o Z é um tiro; o Max vale 3 turnos). **Inimigo gigantamaxa só se for de
TREINADOR** (`dynamax.inimigoPodeGmax` — o "treinador" dos Lendários da rota final, Alfa, evento e selvagem não; ver
"Gimmicks do inimigo e do co-op" abaixo). **Bug real corrigido**: `carreira.conquistasDaConta` passava `runs: {}`, então
`podeGigantamax` dava `false` pra qualquer espécie e o botão 🔴 nunca aparecia numa batalha (só a tela de Conquistas lia
`runsDeNivelDe`). Hoje `conquistasDoProgresso(jornadas, registroAtual, progresso)` (pura, em `carreira.js`) é a fonte única.

### 6. ✅ FEITO — Z-Move
`js/zmove.js` (elegibilidade) + `regras.poderZ` (a conversão, pura e testada, aplicada em `calcDamage` quando
`vol.zAtivo`). **Não é transformação: É o turno** — `usarZ` termina chamando `turn({..., z:true})`, o flag é ligado
ali e apagado no `finally` do mesmo turno (um Z que vazasse dobraria dano de graça). Precisa do **Cristal Z**
segurado (₽12.000, preço do usuário); a loja o mostra via `temZConquistado`, que **não depende de batalha** — a
primeira versão usava `zDisponiveis` e o cristal nunca aparecia à venda, porque loja é fora de combate.
Inimigo **terastaliza** igual à Mega (Alfa/lendário/treinador, metade do HP), mas só **uma virada por luta**:
quem megaevoluiu não terastaliza também.

### Gimmicks do inimigo e do co-op (25/09/2026)
Decisões do usuário. **Inimigo** (`batalha.js`): só Pokémon de **treinador** gigantamaxa (`gmaxDoInimigo`, mesmo gatilho
`HP_MEGA_INIMIGO`); só **treinador e Alfa** usam **Z** (`zmove.inimigoTemZ` sorteia UMA vez em `iniciar` → `B.zInimigo`:
treinador sempre, Alfa `CHANCE_Z_ALFA`=20%; `inimigoUsaZAgora` decide por turno, `CHANCE_Z_TURNO`=35%, uma vez por luta,
só golpe de dano; a marca `E.vol.zAtivo` é apagada no `finally` logo depois do golpe). **Uma virada por luta**
(`jaViradou(B)`: Mega, Tera OU Gigantamax); quem não tem Mega sorteia Tera×Gigantamax (`viradaSorteada`, guardado em
`B.viradaInimigo` — só treinador tem os dois; o resto é sempre Tera). `passarDynamax(E)` roda no fim da rodada junto do
lado do jogador. **Bug real corrigido**: `megaDoInimigo` marcava `megaInimigoUsada` quando o inimigo (nível ≥ 40) não
tinha forma Mega, o que bloqueava o Tera de quase todo mundo; agora só marca quando megaevolui de fato.
**Co-op** (`mp-motor.js` + `multiplayer.js`): a ação de golpe leva `gimmicks: [{tipo:'mega', forma, id, name, types, base,
sprite, back, ability} | {tipo:'tera', valor} | {tipo:'gmax'} | {tipo:'z'}]`. A tela de quem joga confere conquista +
item (Pedra Mega/Cristal Z) da PRÓPRIA conta (`gimmicksDisponiveisMP`); o anfitrião confia no que chega e o motor puro só
aplica as regras da luta (`aplicarGimmicksMP`): só o PRINCIPAL (`slot 0`) de quem tem run (não convidado, não aliado), não
PvP, uma de cada por luta e por jogador em `estado.gimmicksUsados[dono]`. Mega, Tera e Gigantamax entram antes dos golpes
(não gastam o turno); Z marca o golpe do turno (`zRefs`). A Mega manda os dados da forma na ação (o motor não tem rede) —
`mega.aplicarForma(M, forma, data, habilidade?)` é a troca pura, usada por `megaevoluir` e pelo motor; a espécie
(`data.speciesName`) NÃO muda, é por ela que o resultado volta pra run. As fotos são descartadas no fim, então nada disso
persiste na run (o resultado volta por FRAÇÃO de HP). O Alfa do co-op pode carregar Z (`opcoes.alfa` → `estado.zIA`,
`zIAUsado`); Mega/Tera de Alfa no co-op **não existem** (só single player). UI: `alternarGimmickMP` (liga/desliga em
`sala.gimmicksSel`, resetado a cada turno), com o Z ligado só os golpes elegíveis ficam clicáveis. `aplicarCoop` agora chama
`registrarAbate({porMim:false})` por derrotado (espécie + total; Tera/Z pedem golpe final seu e ficam só no single player).
**Auditoria das conquistas da Mega** (`tests/gimmicks-coop-inimigo.test.js`): toda espécie de `MEGAS` libera com 1.000 abates,
não com 999, e habilita a forma com a pedra (Rayquaza: Dragon Ascent). Lacuna conhecida: as formas **Mega Z** (Absol,
Garchomp, Lucario) — RESOLVIDA: o gerador agora casa `-mega-z` também (Absol, Garchomp e Lucario têm 2 formas: comum + Z).
**Tera e Gigantamax do inimigo só de nível 30+** (`mega.NIVEL_TERA_GMAX_INIMIGO`/`inimigoTeraGmaxLiberado`, nível do INIMIGO = o da rota);
a Mega dele segue com o piso próprio de 40.
**Carteira** (`render.atualizarCarteira`): `#top-dinheiro` é uma pílula 💰 fora do menu ☰ com `+₽/−₽` (`.dinheiro-delta`, some por
animação; elemento vazio = tela anterior limpou o topo → sem delta falso), `.carteira-mini` dentro do `turnoBar` (a parte que não rola na
batalha do celular) e `.carteira-loja` no topo da loja.
**Imagens nos relatos** (`imagens-relato.js` puro + `relatos.js` + `nuvem.enviarRelato(relato, imagens)`): máx. 2 imagens, 2 MB cada (`MAX_IMAGENS`,
`MAX_BYTES_IMAGEM`, igual ao `file_size_limit` do bucket privado `relatos-imagens` na migração `20260925160000_relatos_imagens.sql`); o navegador
comprime (lado maior 1600 px, JPEG 85%) antes de subir; a linha do relato guarda só os caminhos em `relatos.imagens` — o campo SÓ entra no insert
quando há imagem (relato sem imagem funciona sem a migração). Offline: as imagens vão pra fila em data URL se couberem (`MAX_BYTES_FILA` 1,5 MB),
senão o relato segue sem elas e a tela avisa (`semImagens`). Fila: campos `imagensFila`/`semImagens` são só dela e saem antes do insert.

### Pedra Mega, rastreio de conquista e cenário (24/09/2026)
- **Pedra Mega** (`dados.ITEM_PEDRA_MEGA`, ₽15.000 — preço escolhido pelo usuário): conquistar a Mega libera a
  COMPRA da pedra, não a Mega. É item segurado; a loja só a mostra se a espécie do jogador tem a Mega conquistada
  (`soComMega`). **Rayquaza não usa pedra** — precisa saber `dragon-ascent`. O lado inimigo passa `ignorarPedra`
  (Alfa não tem inventário). Quando falta a pedra, a tela DIZ o que falta em vez de esconder o botão.
- **`js/rastreio.js`**: fixar UMA conquista de conta por jornada (`G.S.rastreada`), com HUD no painel de Missões
  e recompensa paga NA RUN (`G.S.rastreadaPaga` evita pagar duas vezes). A checagem mora em `verificarMissoes`
  porque é o único ponto que roda depois de todo turno e de todo item.
- **`js/cenario.js`**: clima da cena de batalha deduzido do TEXTO da rota (nome+descrição) contra uma lista de
  palavras, com `z.tema` tendo prioridade. Sem tabela por rota, então rota nova entra sozinha. Puro e testado —
  o teste falha se tudo cair no `padrao`, que é como essa lista morreria em silêncio.


---

## Itens no multiplayer, reordenar golpes e Vínculo de Batalha

### Itens no multiplayer (28/09/2026)
Pedido do usuário: itens segurados e itens comuns (mochila) precisam funcionar na Raide (e no resto do
multiplayer). Duas partes bem diferentes:

**Itens segurados (passivos)**: a causa raiz era simples — `mp-motor.fotoDoMon` nunca incluía `item`, e
`segurados.seg(m) = SEGURADOS[m?.item] || {}` lê exatamente esse campo. Como `golpe.js`/`regras.js` SÃO o motor
único (single player e multiplayer chamam as MESMAS `usarGolpe`/`calcDamage`/`effStat`/`fimDeTurno`), bastou
acrescentar `item: M.item || null` em `fotoDoMon` — **nenhuma linha nova de dano/cura precisou ser escrita**.
Restos, Orbe da Vida, Faixa de Foco, Sino-Concha, Elmo Rochoso e o Vínculo de Batalha (Ash-Greninja, que também só
lia `m.item` no motor único) passaram a funcionar de graça. Testado direto (`tests/mp-motor.test.js`): Orbe da
Vida bate mais forte E cobra HP, Restos cura no fim do turno, tudo via `resolverTurnoMP` de verdade.
**Item que se GASTA** (`aguentaCheio`, Faixa de Foco) muta só a cópia de rede (`fotoDoMon`), não `G.S.player`
diretamente — por isso `finalizar()`/`aplicarCoop` agora sincronizam `item` de volta pra run igual já faziam com
HP/status/PP (`final[...].item`, `M.item = f.item`), senão o jogador ganharia uma Faixa de Foco de graça a cada
luta de sala. **Arena (Hall da Fama) resolvido de outro jeito (28/09/2026)**: o Hall continua sem guardar o item que o Pokémon
segurava ao se aposentar (`hall.js` sem esse campo), mas não precisou — a Loja de preparo da Arena (ver acima)
tem sua PRÓPRIA "mochila" de conta, e o jogador ESCOLHE o que equipar em cada Pokémon do time a cada tentativa
(`arena.equipamento`), independente do que ele carregava na run original.
**PvP não sincroniza nada de volta** (nunca sincronizou HP/PP também), então não tem risco de duplicar item ali.

**Itens comuns (Potion, X Attack, curas de status, Éter...)**: MUITO diferente de item segurado — é uma ESCOLHA DE
TURNO (ocupa a vez, como golpe/fugir), não um efeito passivo. Nova ação `{tipo:'item', ref, item}` em
`mp-motor.resolverTurnoMP` (passo "0b", antes dos golpes — mesma prioridade dos jogos): `aplicarItemComum`
replica heal/healPct/cure/ether/stage do `itens.useItem` do single player, mas SEMPRE no próprio Pokémon que usou
(sem "usar em qual aliado?" — cada jogador só vê a PRÓPRIA mochila numa sala, então perguntar não faria sentido).
`itemTemEfeito`/`heal`/`mudarEstagios` são as MESMAS regras/motor de sempre. Fica registrado em
`estado.itensUsados[dono]` (lista que só cresce) pro cliente descontar da mochila depois — mesmo padrão de
`revivesUsados`/`raideUsados`, só que como o Revive/raide já usam um contador por tipo e este é lista simples
(pode repetir o mesmo item várias vezes), `multiplayer.consumirItensComuns` usa o TAMANHO da lista já visto
(`itensComunsConsumidos`) em vez de comparar por tipo. **Diferente de Revive/raide, item comum vale em QUALQUER
luta de sala** (explorar junto, Alfa, chefe da semana) — não é exclusivo do evento, então não checa `b.evento`.
Cliente manda a ação como QUALQUER escolha de turno (`escolher()`, não `registrarAcao` direto de ação livre) —
`multiplayer.usarItemComumMP`/`itensComunsDisponiveis` (filtra por `SEM_BATALHA_MP`: as categorias que já têm
caminho próprio ou não fazem sentido em batalha). UI: `botoesItemComum()`, um `<details>` recolhível (pode ter
bem mais que os 3 itens de raide) ao lado dos botões de raide.


### Reordenar golpes (28/09/2026)
Pedido do usuário: mudar a ordem dos golpes na lista, sem gastar turno, tanto na run quanto na Raide.
`regras.moverGolpe(moves, i, dir)` é a única regra (pura, testada): troca a posição `i` com a vizinha `i+dir`,
devolve um array NOVO (não muta) — o PP usado mora dentro de cada objeto de golpe (`ppLeft`), então viaja junto
com o golpe na troca, sem lógica extra. Três UIs diferentes chamam ela:
- **Single player**: botões ▲▼ dentro de `render.listaGolpes(M, quem)` (ficha, `data-act="golpe-mover"` +
  `data-quem`/`data-v`/`data-dir` em main.js) — como a ficha usa o MESMO array `M.moves` que a tela de batalha
  (`renderActions`) lê pra montar os botões de ataque, reordenar na ficha já reordena os botões de ataque também,
  sem precisar duplicar UI lá. Os botões ficam DENTRO do `<summary>` do golpe (junto do nome) — clicar neles
  também abriria/fecharia o `<details>` (é o comportamento nativo do navegador pra qualquer clique no summary);
  `onclick="event.preventDefault()"` no botão evita isso SEM `stopPropagation()` (o clique precisa continuar
  borbulhando até o listener delegado em main.js, senão o `data-act` nunca dispara).
- **Arena** (`arena.arenaGolpeMover`): local, muta direto `proximoSemEscolha().moves` e re-renderiza — a Arena não
  tem rede, é só o motor local.
- **Multiplayer** (`multiplayer.moverGolpeMP`): **não pode ser só local** — o estado da batalha é autoritativo do
  anfitrião (`sala.batalha`), e a escolha de golpe manda um ÍNDICE (`{tipo:'golpe', golpe: i}`); se cada cliente
  reordenasse só a PRÓPRIA cópia, o índice enviado depois bateria num golpe ERRADO na cópia do anfitrião (que não
  reordenou). Por isso `golpe-mover` é uma "ação livre" como Revive/item de raide (`registrarGolpeMover` em
  `registrarAcao`, mesmo padrão de `registrarRevive`/`registrarRaide`): o ANFITRIÃO muta o Pokémon canônico e
  reenvia o estado (`publicarEstado`), pra todo mundo ver a MESMA ordem antes de escolher. Guardado contra
  `sala.resolvendo` como os outros dois.
- Em Arena e Multiplayer, `.mv` (botão de atacar) não pode ficar DENTRO de outro `<button>` de reordenar (HTML
  inválido) — cada golpe vira um wrapper `.mv-cel` com o botão de atacar e o `<span class="mv-ordem">` lado a lado.

### Vínculo de Batalha / Ash-Greninja (27/09/2026)
Pedido do usuário ("dá pra adicionar o Ash-Greninja?"): checado antes de implementar que `greninja-ash` (id 10117)
e a habilidade `battle-bond` existem de verdade na PokéAPI. **Mas `battle-bond` NÃO é uma habilidade normal do
Greninja** (a API só lista `torrent`/`protean` pra ele — bate com os jogos: historicamente só um Greninja de
evento/história tinha essa habilidade). Por isso **não** entrou como habilidade sorteável em `pokemon.makeMon`:
vira **item segurado exclusivo**, `dados.ITEM_VINCULO` (`vinculo-de-batalha`, ₽15.000), no MESMO padrão de Pedra
Mega/Cristal Z — checado DIRETO pelo id em `golpe.js` (`m.item === ITEM_VINCULO`), não pela tabela genérica de
`segurados.js` (que exige `Object.keys(SEGURADOS)` bater com `IDS_SEGURADOS` = só os 13 itens de `ITENS_SEGURADOS`).
**A conquista é própria, não reaproveita a da Mega** (`conquistas.ALVOS.vinculo` = 1000, mesmo número da Mega —
escolha do usuário; `ESPECIES_VINCULO = ['greninja']`, lista separada de `dados-megas.MEGAS` porque Greninja não
tem Mega neste jogo): filtrar pela lista de Megas teria deixado o Greninja de fora da conta.
`golpe.virarAshGreninja(m, ctx)` segurando o item + derrubar um oponente troca `id/name/data` inteiro (igual à
Mega — Ash-Greninja tem atributos-base diferentes de verdade, diferente do Castform que só muda tipo/sprite) e
chama `recalc`; `desfazerAshGreninja` roda em `endBattle` junto com Mega/Tera/Dynamax/Forma. `greninja-ash` é
PRÉ-CARREGADO no início da luta (`batalha.iniciar` → `golpe.preCarregarAshGreninja`) se alguém do lado do jogador
entra segurando o item — mesmo cuidado da Mega, nada de buscar no meio do turno. **Water Shuriken** ganha
tratamento especial igual ao Weather Ball/Tera Blast (`regras.golpeDoBattleBond`: poder fixo 20, SEMPRE 3
acertos — a versão normal é 2–5 aleatório): plugado no motor único (`golpe.executar`, vale nos dois lados e no
co-op) e nos botões de golpe das duas telas. Validado com dados reais da PokéAPI (fora da suíte de testes, que
não toca rede — mesmo recorte que `mega.megaevoluir`): a transformação, o Water Shuriken reforçado e o desfazer
no fim da luta rodaram de ponta a ponta contra a API de verdade antes de ir pro commit.


---

## A auditoria de segurança (29/09/2026)

Pedido do usuário: "auditoria de segurança contra invasão, ataque cibernético e roubo de ideias — e corrigir o
que aparecer". O `/security-review` do Claude Code olha o DIFF do branch, e o branch estava limpo: não serviria
de ponto de partida. A varredura foi feita à mão, na ordem do escopo que o `CLAUDE.md` já listava.

### O achado grave: a sala do multiplayer acreditava em tudo

O canal Realtime de uma sala é um **broadcast com a chave anônima**. Quem está na sala publica o que quiser, e o
Supabase **não assina o remetente** — não existe "veio do anfitrião" que dê pra provar. Até aqui a sala tratava o
pacote como se fosse dado próprio: `aoReceberEstado` fazia `sala.batalha = p.batalha` e a tela desenhava aquilo.

O que isso permitia, na prática, pra qualquer um na sala (e a sala se entra com 4 caracteres):

1. **Rodar JavaScript na página de todo mundo.** O HTML da sala escapava os TEXTOS — `esc(m.nome)`, `esc(vez.nome)`,
   o chat — mas **número era número por fé**: `Nv. ${m.level}`, `${m.hp}/${m.stats.hp}`, `Turno ${b.turno}`. Um
   `level` valendo `<img src=x onerror=…>` executava. Pior: o endereço da sprite ia **dentro** de
   `onerror="this.onerror=null;this.src='AQUI'"`, onde uma apóstrofe no meio do endereço já fecha a string e emenda
   código. E a sessão do Supabase mora no `localStorage` (padrão do `supabase-js`), então o alcance disso **não é a
   sala: é a conta** — jornadas, saves, progresso, perfil, lista de amigos.
2. **Estragar o save do outro em silêncio.** `aplicarCoop` faz `S.money += r.dinheiro` com o número que veio do
   pacote. Com `"500"` em vez de `500`, o dinheiro da run vira a string `"100500"` — e isso é gravado no save e
   sobe pra nuvem, onde nenhuma tela entende mais aquele campo. Nem precisa de má intenção: bastava um bug.
3. **Deixar a tela em branco.** `p.batalha.turno` num pacote sem `batalha` estoura DENTRO do ouvinte do canal,
   onde ninguém pega o erro — exatamente o tipo de falha que o `CLAUDE.md` chama de "o pior bug".

### A correção: `js/mp-sanear.js`

Um módulo puro, **sem nenhum import** (é o chão do grafo: `render.js` também depende dele), com uma porta por
evento do canal — `estadoDaRede`, `fimDaRede`, `pingDaRede`, `chatDaRede`, `lobbyDaRede`, `acaoDaRede`,
`membroDaRede`. Cada porta devolve o pacote saneado **ou `null`**, e `null` quer dizer "joga fora e anota no
diagnóstico", nunca "usa como veio".

**O que foi considerado e recusado: lista de campos permitidos.** O estado da batalha tem dezenas de campos, em
seis níveis de aninhamento, e cresce a cada mecânica nova — uma lista dessas nasce certa e fica errada na semana
seguinte, do jeito mais perigoso (o campo novo passa sem conferência). `saneado()` desce o pacote inteiro e troca
cada folha pela versão segura **do mesmo tipo**: número finito ou 0, texto sem `< > "` e curto, endereço de
imagem só se for `https` de um dos dois servidores de sprite. Só existe tipo de JSON ali (o broadcast chega
decodificado), então a varredura é total por construção. Campo novo já nasce coberto.

Duas exceções ao "por tipo", e as duas doeram:

- **`CAMPOS_NUMERICOS`** (por nome de chave: `hp`, `level`, `xp`, `dinheiro`, `frac`, `ppLeft`…). Tirar o `<` de
  um texto resolve o XSS mas **não** resolve o save estragado: `S.money += "500"` continua concatenando. Esses
  campos são forçados a número. `id` ficou **de fora de propósito** — na presença o `id` do jogador é um uuid, e
  forçar número ali arrebentaria a sala inteira; o ícone, que é o id numérico de verdade, é tratado à parte em
  `membroDaRede`.
- **`urlDeImagem`** não se contenta com a lista de hosts. **`new URL()` não limpa o caminho**: ela aceita
  `https://cdn.jsdelivr.net/…/1';alert(1)//.png`, com host legítimo, e devolve a apóstrofe intacta no `href`.
  Esse foi o **furo do primeiro conserto desta própria auditoria** — bastava o `id` do Pokémon vir torto pra
  `SPR_ANIM(m.id)` montar sozinha um endereço com código dentro, e o filtro de host aprovava. Agora também
  recusa `' " < > \` e espaço, que não existem em endereço de sprite nenhum (conferido contra os 12
  construtores de `dados.js`, com 0 recusas indevidas).

O render ganhou a segunda linha de defesa no mesmo passo: `esc()` nos números (`mp-cartao.js`, `mp-telas.js`),
`urlDeImagem` nos três endereços de `render.js:imgMon` e no ícone de `conta.js:htmlIcone`, `esc()` no `fmt(t)` de
`badge`. Depender de `esc()` em 40 lugares foi justamente o que falhou; depender dos dois é o que segura.

**`doAnfitriao` é honesto sobre o que não é.** Estado, fim, lobby e pulso passaram a levar `de: meuId()`, e o
outro lado confere contra o anfitrião da presença. Isso **não é autenticação** — broadcast não tem remetente
assinado, e quem quiser mentir copia o id do anfitrião, que está visível na presença. Vale porque pega o engano
honesto (dois anfitriões depois de uma reconexão bagunçada) e a forja ingênua, e porque custa uma linha. Pacote
**sem** `de` passa: é a versão antiga do jogo, e derrubar a sala de quem ainda não atualizou seria pior que o
problema. Quem protege de verdade é o saneamento.

### No banco: dois furos de abuso, nenhum de vazamento

Nenhuma tabela vazava dado de ninguém. O que estava aberto era **encher o projeto de graça**, que no plano
gratuito é o jogo sair do ar:

- **Bucket `relatos-imagens`.** A política de envio era só `bucket_id = 'relatos-imagens'`, aberta a `anon`
  (relato sem conta é promessa da tela). Qualquer um mandava 2 MB por requisição, em caminho qualquer, pra
  sempre — ~500 requisições enchem 1 GB. Agora o caminho tem de começar pela pasta de quem envia e existe um
  teto por hora. **Detalhe que quase virou proteção de mentira**: a contagem do teto **precisa** ser
  `SECURITY DEFINER`. Contando `storage.objects` direto na política, a contagem passa pelo RLS do papel `anon` —
  que não tem policy de SELECT nesse bucket — e dá **sempre 0**, um teto que nunca fecha. Foi o primeiro jeito
  que eu escrevi.
- **`registrar_visitante_anonimo`.** Aceitava qualquer texto de até 40 caracteres, aberta a `anon`: linha sem fim,
  uma por id inventado. Ganhou checagem de formato e teto por hora (com índice em `primeira_vez`, senão o teto
  vira varredura da tabela a cada boot).

O teto de upload sozinho é **quebra-molas, não tranca**: sem conta não existe a quem amarrar o envio, então
nenhum teto vale — um atacante decidido continuava subindo 20 arquivos de 2 MB por hora, de graça, pra sempre.
Era decisão de produto (a tela promete "não precisa de conta"), e o usuário escolheu a tranca: **anexar imagem
exige conta** (`20260929210000_imagem_de_relato_so_com_conta.sql`; `anon` saiu da política, o caminho tem de
começar pelo id de quem envia, e o teto por hora ficou como o que sobra se uma conta for usada pra abuso ou
roubada). **Enviar relato continua sem conta** — isso é promessa da tela e não foi tocado.

Do lado do jogo a regra é cobrada em **três camadas**, e não por paranoia: é pra ninguém descobrir a regra só
quando o envio falha. A tela não desenha o seletor sem conta (e **diz o motivo, com o botão de entrar ao lado** —
espaço que some sem explicação parece funcionalidade faltando, não regra); `adicionarArquivos` recusa também o
Ctrl+V, que não passa por botão nenhum; e `subirImagensRelato` devolve **`null`, não `[]`**.

Essa distinção entre `null` e `[]` é o detalhe que evita um bug chato: a **fila offline** pode ter um relato
guardado com print de antes desta regra (ou guardado com conta e enviado depois de sair dela). Se o envio
simplesmente tentasse e falhasse, o relato ficaria **preso na fila pra sempre**, tentando de novo a cada abertura
da tela, e o texto da pessoa nunca chegaria. Com `null`, quem chama sabe diferenciar "não tinha imagem" de "não
pude subir": o texto vai, a imagem fica de fora, e a tela avisa quantas caíram — com o motivo certo, porque as
duas causas pedem atitudes diferentes (sem conta → entrar e reenviar; grande demais pra fila → esperar internet).

### Revisado e considerado OK

RLS de todas as tabelas (cada conta só lê o que é dela; `jornadas` sem update/delete); `validar_jornada`
recalculando a pontuação no servidor com tetos por campo; o gatilho que impede alguém de se promover a
`perfis.admin` pela API (inclusive no INSERT — um perfil não pode nascer admin); `perfil_do_amigo` só devolvendo
dados de amizade **aceita**, e nada de e-mail ou código de amigo; `badge_exibivel` conferindo no progresso se a
insígnia foi conquistada; a chave anônima no `config.js` (é pública por natureza — quem protege é o RLS); a
presença global com `track({})` vazio, que conta sem identificar ninguém; `esc()` no apelido em todas as telas
que mostram gente (ranking, amigos, perfil do amigo) — esse era o outro caminho de XSS entre jogadores e estava
fechado.

### Limites conhecidos e aceitos

- **A pontuação é calculada no navegador** e só conferida no servidor. Inventar uma jornada plausível continua
  possível; mandar uma pontuação qualquer, não. Sem servidor de jogo não tem como fechar, e isso já estava
  escrito no SQL desde o começo.
- **Forjar o fim de uma luta** continua possível pra quem está NA sala: o `de` não é prova, porque o broadcast
  não assina remetente. O alcance, depois da 2ª auditoria, é HP e narração.
  > ⚠ **O que estava escrito aqui estava errado** (corrigido em 30/09/2026): dizia que "o alcance é o de quem já
  > podia editar o próprio `localStorage`" e que "não corrompe save nem executa nada". Corrompia o save **dos
  > outros** — `aoReceberEstado` chamava `consumirRevives`/`consumirItensComuns` direto do pacote, então um
  > `estado` forjado esvaziava a mochila da run de quem recebesse, ou o inventário de CONTA na Sala de Raide.
  > Lição registrada: "o pacote é bem-formado" (o que o `mp-sanear` garante) não é o mesmo que "o pacote é
  > verdadeiro". Saneamento resolve INJEÇÃO, não AUTORIA — e a frase acima confundiu as duas por um dia.
- ~~**`/security-review` não foi rodado** como segunda opinião.~~ ✔ rodado em 30/09/2026 — ver "A segunda
  auditoria de segurança".

---

## A segunda auditoria de segurança (30/09/2026)

Esta é o item (d) que a primeira deixou aberto: **`/security-review` rodado como segunda opinião**. O branch
estava limpo de novo (o comando olha o diff), então o escopo foi o **repositório inteiro**, dividido em quatro
frentes paralelas: SQL/RLS/Storage · pacote da sala · XSS no DOM · auth, upload, cache e geradores. Cada achado
foi reconferido no código antes de entrar aqui — dois candidatos caíram nessa conferência.

**7 achados: 6 graves, 1 médio.** O que mais chama atenção é que **quatro deles estavam em cima de defesa já
existente** — não eram áreas esquecidas, eram áreas protegidas com um buraco fino. É o padrão a levar pra
próxima: o lugar mais perigoso não é o que não tem trava, é o que tem trava e por isso ninguém olha mais.

### 1. `&#39;` passava pelo filtro de endereço de imagem

A primeira auditoria fechou a apóstrofe LITERAL no `urlDeImagem` (o endereço é escrito dentro de
`onerror="…src='AQUI'"`). Mas o valor cai num **atributo**, e o navegador decodifica entidade HTML **antes** de
compilar o `onerror` como JavaScript: `&#39;` chega ao JS como apóstrofe de verdade **sem nunca ter existido na
string que o filtro olhou**. `new URL()` devolve a entidade intacta, host (`cdn.jsdelivr.net`) e esquema
(`https:`) legítimos — passava pelas duas checagens. Bastava entrar na sala e anunciar a própria presença com
`data.sprite` armado: o `src` truncado dava 404, o `onerror` disparava e o `eval` lia a sessão do Supabase do
`localStorage` de **todos os presentes**. Conserto: `& ; %` entraram em `CARACTERE_PROIBIDO_EM_URL` (nenhum dos
12 construtores de `dados.js` usa esses caracteres, então o custo é zero).

**A lição, que vale além deste bug:** um filtro de caractere só é correto em relação ao **contexto** onde o valor
cai. Aqui há dois contextos empilhados (string JS dentro de atributo HTML), e cada camada tem sua própria
decodificação. Filtrar "o caractere perigoso" sem dizer "perigoso em qual camada" é o que deixou o furo.

### 2. `poke_id` cru dentro de um `src`

`perfil-amigo.js` desenhava a sprite das últimas runs de um amigo com `SPR(r.poke_id)` **sem `esc()`**, e
`poke_id` vem de `resumo.registro.ids` — `jsonb` que o cliente envia e que `validar_jornada` não olha. Como
`->>` devolve TEXTO, era string arbitrária indo pra dentro de um atributo. Todos os campos de texto ao redor
estavam escapados; e `conta.js` (`htmlIcone`) **já coagia** o id remoto pra inteiro, com um comentário
descrevendo exatamente este ataque. O call site vizinho é que tinha esquecido.

Conserto **na raiz, não no call site**: a coerção foi pro construtor (`numeroDeSprite` em `dados.js`), então os
12 `SPR*` e todos os ~40 pontos de desenho ficaram cobertos de uma vez — inclusive `fim.js`, que lê o mesmo
`registro.ids`. A faixa aqui é "inteiro", não o `1–1025` do `htmlIcone`: id de FORMA passa de 10000
(`render.spriteFrente` usa `m.formaSprite`), e clampar em 1025 quebraria sprite de forma.

### 3. Reescrever uma amizade e ler o histórico de qualquer conta

A política de UPDATE de `amizades` era `using (auth.uid() = para) with check (status = 'aceita')`. O `using` olha
a linha ANTIGA, o `with check` olha a NOVA — e **nada prendia `de`/`para`**. Quem tivesse um pedido recebido
reescrevia a linha pra "amizade aceita entre `de = <vítima>` e `para = eu`" e repetia trocando o uuid, varrendo a
base com **uma linha só**. Os uuids eram fáceis: `presenca.js` usava `idJogador()` como **chave de presença** do
canal global — o `track({})` vazio era de propósito, mas a *chave* anulava isso.

A vítima não precisava aceitar nada, e como `perfil_do_amigo` é `SECURITY DEFINER` e fura o RLS de
`jornadas`/`progresso` confiando nessa tabela, saía nível, pontuação, gens, shinies e as 5 últimas runs. **A
função estava correta** (exige `'aceita'` nas duas direções, usa `auth.uid()`): o furo era a tabela em que ela
confia. Conserto em `20260930120000`: `using` passou a exigir `status = 'pendente'`, `with check` voltou a exigir
`auth.uid() = para`, e um gatilho `congelar_par_amizade` prende as duas colunas — porque **`with check` não
enxerga `OLD`**, então política sozinha não consegue dizer "essas colunas não mudam". Mesmo padrão que
`proteger_perfis_admin` já usava.

### 4. A penalidade que virava bônus de 70.000×

`validar_jornada` recusa número impossível, e recusava todos — menos o expoente:
`penal := greatest(0.5, power(0.8, continuacoes))`. **`greatest` é piso, nunca teto**, e `continuacoes` vinha do
`resumo` do cliente sem faixa. `power(0.8, -50)` ≈ 70065: o campo que devia TIRAR pontos multiplicava a
pontuação por dezenas de milhares, com todos os outros números dentro do "possível". Um `insert` de console dava
1º lugar geral **para sempre** — `jornadas` não tem política de update nem delete, então nem o dono apaga.

Isso **não** era o limite aceito "a pontuação é calculada no navegador": esse limite é sobre jornada *plausível*
inventada. Aqui o gatilho **aceitava e assinava** um valor impossível, que é exatamente o que ele existe pra
impedir. Conserto: piso 0 no expoente e `least(1, …)` de teto, nos dois lados (`regras.multContinuacao` tinha o
mesmo `0.8 ** n`). O `tests/schema.test.js` cobra a igualdade — e **ele também tinha um bug**: fatiava a função
com `indexOf`, então com uma migration nova ele conferiria a definição VELHA e daria o conserto por feito. Virou
`lastIndexOf`, com âncora no `create or replace` inteiro (o trecho curto reaparece no `execute function` do
`create trigger`, depois do `drop trigger`, o que dava `slice` invertido e corpo vazio) e um `throw` se as
âncoras mudarem. **Teste que valida o estado acumulado de migrations precisa olhar a ÚLTIMA definição.**

### 5. O pacote de rede mandava na mochila alheia

O pior dos sete, e o mais fácil de passar batido, porque não parece código de segurança: `aoReceberEstado`
chamava `consumirRevives(p.batalha)` e `consumirItensComuns(p.batalha)`. Essas funções **apagam item do save**
(`G.S.bag`, `save()`) ou do **inventário permanente de conta** (`gastarItemDeRaide`, na Sala de Raide), e quanto
gastar vinha de `b.itensUsados[meuId()]` — campo do pacote. O único controle era `doAnfitriao`, que aceita pacote
sem `de` de propósito (compatibilidade). Um broadcast com 400 ids esvaziava a mochila da vítima item a item, e
alternando `fim`/`estado` a drenagem recomeçava.

Conserto: **o pacote passou a CONFIRMAR, não a AUTORIZAR.** Existe agora um livro-caixa local (`sala.pedi`),
escrito só pelas minhas próprias ações (`pediItemComum`/`pediRevive`/`pediRaide`), e o desconto é o cruzamento
dos dois — `mp-regras.itensADescontar` (multiconjunto, pra não depender da ordem) e `usosADescontar` (teto, com
piso 0 pra contador negativo não virar crédito). Pacote forjado encontra livro-caixa vazio e não desconta nada.
As duas regras nasceram **puras em `mp-regras.js`, com teste**, porque `mp-resultado.js` importa `ui.js` e não é
importável no Node — a regra do `CLAUDE.md` ("regra nova vai em função pura com teste") é o que tornou este
conserto testável.

**A lição:** `mp-sanear` garante que o pacote é **bem-formado**, não que é **verdadeiro**. Saneamento resolve
injeção, nunca autoria. A frase antiga em "Limites conhecidos" confundia as duas — está corrigida lá.

### 6. `desistir` funcionava em co-op

O comentário no motor dizia "desistir (PvP)", mas o filtro era só `x.tipo === 'desistir'`: a trava de modo
existia **só na UI** (`mp-telas.botoesPvP`). Como o ator de uma ação é o `de` autodeclarado do pacote, um
participante mandava `{ de: "<vítima>", acao: { tipo: "desistir", ref: "A0" } }` — 70 bytes — e o **anfitrião
autoritativo** zerava a equipe da vítima e publicava um `fim` **legítimo**. No Roguelike isso desce por
`mp-resultado.principalCaiu` → `encerrarJornada('desmaiou')`: run acabada, sem nenhuma pista no diagnóstico,
porque a ação foi válida. Conserto: `s.pvp ? … : []` no motor.

**A lição:** regra que só existe na tela não é regra. Vale pro multiplayer o mesmo que já valia pra
`golpesPermitidos` no single player — **o motor tem de conferir também**, porque a tela não é o único caminho até
ele. E ataque que passa pelo anfitrião é pior que pacote forjado: o resultado sai assinado por quem manda, então
nenhum endurecimento no cliente o pega.

### 7. Nome da PokéAPI virando código nos geradores

`gerar-mapas.ps1` e `gerar-megas.ps1` montavam literais de JavaScript concatenando nomes da PokéAPI **sem
escapar** — e esses arquivos (`dados-mapas.js`, `dados-megas.js`) são importados por `dados.js`, ou seja vão pra
todo jogador. O autor conhecia o risco (o `desc` escrito à mão já passava por `-replace "'", "\'"`), mas nada
vindo da rede passava. O caso realista não é nem o hostil: é um `farfetch'd` numa forma nova derrubando o jogo
inteiro com erro de sintaxe — e **`node --check` não roda no Windows**, então o CI seria a única rede. Conserto:
`JsStr` exige `^[a-z0-9-]+$` e **falha o gerador** em vez de emitir, `JsTexto` escapa o rótulo que nós mesmos
montamos. Os `.mjs` de `ferramentas/` não precisaram de nada: todos já usavam `JSON.stringify`.

### Nota operacional: o arquivo que desprotegia ao ser rodado

`supabase/ADMIN-TRIGGERS.sql` tinha o bloco **DESLIGAR ativo** e o de religar comentado. Não é migration (a
integração não aplica), então o banco estava protegido — mas quem abrisse o arquivo pra "gerenciar os gatilhos" e
clicasse em Run desligaria a proteção de `perfis.admin` sem querer, e daí qualquer conta logada viraria admin. Os
blocos foram **invertidos**: rodar o arquivo inteiro sem ler agora é a ação segura.

### Revisado e considerado OK

Pra não reauditar o que já foi olhado: RLS ligada nas 7 tabelas, com `using` **e** `with check` em `saves` e
`progresso`; `jornadas` sem update/delete; `perfis.admin` bloqueado nas duas portas; bucket de imagem privado,
só `insert`, só `authenticated`, caminho preso ao `auth.uid()`; `subirImagensRelato` devolvendo `null` ≠ `[]`;
zero `EXECUTE` dinâmico em todo `supabase/`; `search_path` em todas as 8 funções `SECURITY DEFINER`, nenhuma
aceitando "o id de quem sou"; `auth.users` nunca lida; as 7 portas de `mp-sanear` cobrindo todos os eventos
(inclusive a presença, que é a mais esquecida) com varredura por tipo que passa **nas chaves** também;
`acaoDaRede` limitando `golpe` a índice; `?sala=` validado por `codigoValido`; chaves de cache derivadas só da
PokéAPI; `sw.js` sem `importScripts` dinâmico; e os ids de AdSense sendo constantes de build.

---

## Sprites, animações e microinterações

### Estilo de sprite: Clássico / 3D / Animado (27/09/2026)
Pedido do usuário (junto do backlog de animações), em duas levas: primeiro só o 3D (booleano), depois pediu
também os GIFs animados do Showdown — o que virou um refactor de booleano pra enum de 3 estilos.
A PokéAPI não tem modelo 3D interativo pra jogo — o que existe é `sprites.other.home`, um RENDER 2D do mesmo
modelo 3D usado em Pokémon HOME/jogos modernos (bem mais nítido que o pixel-art `sprites.front_default`), e
`sprites.other.showdown`, os GIFs animados usados no Pokémon Showdown (COM versão de costas de verdade,
diferente do "home"). `dados.SPR_3D`/`SPR_3D_SHINY` e `SPR_ANIM`/`SPR_ANIM_COSTAS`/`SPR_ANIM_SHINY`/
`SPR_ANIM_SHINY_COSTAS` montam pelo id, mesmo padrão do shiny — nunca leem `m.data.sprite`, porque essas imagens
podem não existir pra alguma forma antiga guardada num save velho.
Preferência em `ajustes.ESTILO_SPRITE_KEY` (localStorage `pokerpg-estilo-sprite`, enum `'classico'|'3d'|'animado'`
via `ESTILOS_SPRITE`/`estiloSpriteAtual`/`definirEstiloSprite`), lida em `render.spriteFrente`/`sprCostas` a cada
render — trocar o estilo vale na hora, sem precisar recriar nenhum Pokémon. **3D não tem versão de costas**
("home" só tem frente): `sprCostas` devolve `null` nesse estilo e cai sozinho no MESMO fallback que já existia
pra espécie sem back 2D (frente + CSS `flip`). **Animado tem costas de verdade**, então usa `SPR_ANIM_COSTAS`/
`SPR_ANIM_SHINY_COSTAS` direto. Se a imagem do estilo escolhido não existir de verdade pra algum Pokémon/forma,
`imgMon()` já cai pro sprite 2D clássico no 2º erro de `<img>` (fallback que já existia, não precisou de nada
novo). **Download opcional e À PARTE** do download normal: `offline.baixarImagens3D`/`imagensGuardadas3D` (2
imagens: frente normal e shiny) e `baixarImagensAnimadas`/`imagensGuardadasAnimadas` (4 imagens: frente e costas,
normal e shiny) — mesmo formato de `baixarImagens`, ninguém baixa imagem de estilo que não escolheu.

**Bug relatado pelo usuário (27/09/2026): GIFs animados "estranhamente desproporcionais".** Causa: `.spr` (e as
outras classes que desenham `spriteFrente`/`sprCostas` sem passar por `.spr` — `.me img` da ficha, `.aliado-top
img` do cartão de aliado, `.mp-mon img` do multiplayer) fixam `width`/`height` iguais, o que é inofensivo pro
clássico e pro 3D (sempre quadrados) mas ESTICA o GIF do Showdown: cada Pokémon tem um tamanho de sprite
diferente lá (Wailord bem mais largo que alto, Onix mais alto que largo…), e forçar num quadrado distorce a
imagem. Corrigido com `object-fit:contain` nas quatro regras — encolhe mantendo a proporção, com uma pequena
margem dentro da caixa, em vez de esticar. Não muda nada visualmente pro clássico/3D.

### Sprites de verdade pra Pedra Mega e Cristal Z (27/09/2026)
Pedido do usuário: os três itens de gimmick (`dados.ITEM_PEDRA_MEGA`/`ITEM_CRISTAL_Z`/`ITEM_VINCULO`) são únicos e
genéricos no jogo (uma Pedra Mega serve pra qualquer espécie, um Cristal Z pra qualquer tipo) — `ITEM_SPR(k)`
simples não tem como saber qual arquivo mostrar, então caíam sempre no ícone de caixinha genérico
(`ITEM_SPR_RESERVA`). A PokéAPI TEM sprite de verdade por espécie (pedra) e por tipo (cristal): `PEDRAS_MEGA`/
`CRISTAIS_Z` (`js/dados-item-sprites.js`, GERADO por `ferramentas/gerar-item-sprites.mjs` — Node, roda no
Raspberry Pi, não PowerShell) trazem essas tabelas. `dados.ITEM_SPR_MEGA(especie)`/`ITEM_SPR_Z(tipo)` fazem a
troca; `render.spriteItem(k, m)` é o ponto único que decide qual sprite mostrar pra QUALQUER item, dado quem
seguraria ele (`m`, um Pokémon-like com `.data.speciesName`/`.moves` — `blocoItem` passa o dono de verdade; loja,
mochila e os modais de comprar/vender em `main.js` passam `S.player` como melhor palpite antes de saber quem vai
equipar). `zmove.primeiroTipoZ(M)` acha o tipo do primeiro golpe com Z conquistado (só decide o SPRITE — o golpe
que vira Z de fato na hora H continua escolhido em batalha, por `zDisponiveis`).
**Nem toda espécie tem pedra de verdade**: só 47 das 89 Megas deste jogo são Mega oficial dos jogos de verdade
(+ Kyogre/Groudon, que usam os Orbes da Reversão Primitiva) — o resto (Meganium, Chesnaught, Greninja, Zeraora…)
só existe neste projeto, e a PokéAPI não tem pedra desenhada pra eles (o item existe nos DADOS da API, mas sem
sprite — confirmado um por um, 404 no CDN). Pra esses, `CHAVE_MEGA_GENERICA` = `key-stone`, a Pedra-Chave: item
real dos jogos que ativa QUALQUER Mega Evolução, então nunca fica errado mostrá-la. O gerador casa o nome do
item com a espécie de dois jeitos: pro item OFICIAL, lê o texto em inglês do próprio item na API ("Allows X to
Mega Evolve") — sem depender de adivinhar o padrão do nome (que é irregular: `blastoisinite`, `alakazite`,
`heracronite`… não seguem `especie+"ite"`); pros itens sem esse texto (os ~40 "fan-made" que só existem nesta
extensão da PokéAPI), casa pelo maior PREFIXO comum com o nome da espécie (ex. `meganiumite` → `meganium`) — como
o próprio nome do item já É a espécie com um sufixo trocado, funciona sem ambiguidade nos 89 casos.
**Cristal Z é mais simples**: os 18 tipos têm cristal oficial de verdade (`firium-z`, `waterium-z`…, sufixo
`--held` no arquivo de sprite — nome de arquivo diferente do nome do item, cuidado se algum dia regenerar à mão).
Sem tipo elegível ainda, cai no Anel Z (`z-power-ring`, item real e genérico a todo Z-Move).
**Vínculo de Batalha não tem item nenhum nos jogos** (Battle Bond é habilidade, não item segurado) — ícone
próprio, um SVG embutido de shuriken (tema ninja do Greninja), em vez de fingir que existe um sprite oficial.

### Os 53 itens que apareciam como caixinha (04/10/2026)
Pedido do usuário: "revise todos os itens sem sprites definidos, olhe em outros lugares, sei que alguns tem no
Pokémon Showdown ou outros lugares". Levantamento feito batendo TODA chave de `ITEMS`/`BOLAS`/`ITENS_EVO` contra
o CDN de sprites (161 chaves, script descartável): **53 caíam no `ITEM_SPR_RESERVA`**. Não era um problema só, eram
três, e a correção é uma tabela nova — `SPRITE_DO_ITEM` em `js/dados-item-sprites.js` (GERADO) —, lida por
`ITEM_SPR`: valor COM barra é arquivo nosso, valor sem barra é nome de item na PokéAPI.
1. **Item real com chave em português** (18): os 17 Pratos do Arceus (`prato-chama` → `flame-plate`…) e o Lenço
   de Seda. O sprite sempre existiu; a chave do jogo é que não era o nome do arquivo.
2. **Item inventado deste jogo** (17): os de raide (`cristal-de-ruptura`, `relogio-de-areia`…) e a Mega Potion.
   Não existe sprite pra buscar, então aponta pro item REAL mais parecido (`red-shard`, `x-speed`, `soot-sack`,
   `zygarde-cube`…) — mesmo critério da Pedra-Chave genérica acima: ícone coerente com o nome bate a caixinha.
3. **Item real que a PokéAPI não desenhou** (15, Gen 8/9): Pergaminhos do Kubfu, armaduras do Charcadet, Augurita
   Negra, Bloco de Turfa, Mochi do Recomeço, Cabo de Conexão, Maçãs, Bule Rachado, Braceletes Galarica, Doce de
   Morango, Rédea Espectral. Esses foram **VENDORIZADOS**: o gerador baixa o PNG (do `msikma/pokesprite` via
   jsDelivr quando tem, do Serebii quando não) e grava em `img/itens/`, servido pelo nosso domínio.
**Por que vendorizar em vez de linkar**: o Showdown não serve ícone de item avulso — são todos um SPRITESHEET
único (`itemicons-sheet.png` + um `spritenum` por item), e recortar sheet exige `background-position`, ou seja
trocar as 14 `<img src>` de item do jogo por `<span>` com CSS. O Bulbagarden Archives resolve o endereço certo
pela API mas **devolve 403 na imagem** (bloqueia hotlink). O Serebii serve, mas depender de fansite em tempo de
jogo quebra sem avisar. Com o PNG no repo (136 KB nos 15) o custo é uma linha no `PRECACHE` do `sw.js` (coberta
por `tests/sw.test.js`, teste novo) e o ganho é funcionar **offline** e não ter terceiro no caminho.
O `onerror="${ITEM_ERRO}"` continua em toda `<img>` de item: a caixinha deixou de ser o caso comum, mas segue
sendo a rede de segurança.

### Item de evolução na mochila dobra o encontro (04/10/2026)
Pedido do usuário: "quando um item evolui um pokémon específico, a chance de encontrar ele dobra durante a
exploração". A regra pura é `regras.especiesDobradas(bag)` → conjunto de nomes de espécie, e o dado vem de
`ESPECIE_DO_ITEM_EVO` (`js/dados-evolucao-restante.js`, GERADO): o gerador passou a ler também
`pokemon_evolution.csv` + `items.csv`, cruzando `trigger_item_id` (usar a pedra/maçã) e `held_item_id` (evoluir
segurando) com o `evolves_from_species_id` da evoluída — a espécie que entra na lista é a **de antes**, que é a
que você encontra explorando. 50 itens mapeados; coluna certa é `trigger_item_id`, não `evolution_item_id` (o
primeiro palpite trouxe só as 24 de item segurado e nenhuma pedra, sinal fácil de perceber).
**O peso mora num lugar só** (`mapas.pesoNaRota`, com `MULT_ITEM_EVO = 2`), lido pelo sorteio (`sortearDaRota`) E
pela taxa mostrada (`taxaNaRota`, que `pokedexDaRota` repassa com a marca `dobrado`). Isso não é capricho: os
bugs #74/#75 foram exatamente a tela prometer uma porcentagem que o sorteio não cumpria. A Pokédex da rota mostra
`×2` ao lado da taxa, e a descrição dos itens de evolução ganhou a frase (uma constante `ISCA` nos quatro
templates de `dados.js`, então todos os ~35 itens dizem a mesma coisa).
**Fora de propósito**: o Cabo de Conexão. Ele evolui por TROCA, não nomeia espécie na tabela da PokéAPI (seriam
30+ de uma vez) e se compra na loja — dobraria metade da rota por ₽2.100.

### Mochila: marcador de evolução e divisão que abre (05/10/2026)
Relato de quem joga, três coisas no mesmo pedido: *"o Eletrizador está funcionando para evoluir o Electabuzz?"*,
*"deixe os itens que evoluem um Pokémon com um marcador visível"* e *"a bag quando tem muitos itens fica muito
confusa… ela expande e fica enorme, muito ruim de descer a tela no mobile"*.
**O Eletrizador funcionava.** Conferido contra a PokéAPI: `electabuzz → electivire` é
`{ trigger: 'trade', held_item: 'electirizer' }`, e `evolucao.detalheCumprido` com `gatilho: 'trade'` +
`bag.electirizer > 0` devolve `{ name: 'electivire', consome: 'electirizer' }`. O que faltava era a TELA dizer
isso: item `segurar: true` não tem botão nenhum na mochila (quem dispara é o Cabo de Conexão, ₽3.000), então
parecia defeito. **Bug de comunicação, não de regra** — e o conserto é de texto e marcador, não de motor.
**Marcador**: `regras.quemEvoluiComItem(item, mons)` cruza `ESPECIE_DO_ITEM_EVO` (o MESMO dado gerado do dobro de
encontro, lido pelo outro lado) com o seu lado. Síncrono de propósito: a árvore de evolução de verdade vem da API
e serve pra DECIDIR a evolução; pra marcar uma linha de lista não vale pedir rede. Sem ninguém que use, a marca é
um `💎 Evolução` discreto; com alguém, acende e diz o nome (`.tag-evo.pronto`).
**Divisão que abre**: cada categoria virou `<details>`/`<summary>` NATIVO, com a contagem no cabeçalho — nada de
JS de acordeão. O estado mora em `G.bagAbertas` (tela, não save) porque `render()` refaz o DOM inteiro a cada
ação: sem isso, usar uma Poção fechava a divisão que você acabou de abrir. A primeira divisão (cura) nasce aberta;
mochila VAZIA não inicializa o Set, senão quem abre a mochila antes do primeiro item travaria tudo fechado.
No celular, `ul.bag small` ganhou `-webkit-line-clamp: 2` (o texto inteiro fica no `title`) — a descrição era o
que fazia a lista crescer sem fim, e ela cresceu de propósito quando a loja passou a explicar cada item.
**Não mexi na LOJA**, que tem a mesma forma: lá navegar a prateleira inteira é o objetivo, e ninguém reclamou.

### 🔄 Revezamento: o que fazer com os golpes de "sair de campo" (04/10/2026)
Decisão do usuário entre quatro desenhos apresentados (revezamento, sacrifício, "sair = fim da luta", pós-batalha):
**revezamento**. O problema: num jogo em que VOCÊ é o Pokémon, "trocar" não existe, e U-turn, Volt Switch, Flip
Turn, Teleport e Parting Shot ficavam sem efeito. A saída escolhida reusa duas coisas que já existiam em vez de
inventar um conceito de "quem está na frente": `vol.retirado` (que `estado.emCampo()` já exclui, criado pro Roar) e
`golpe.aoEntrarEmCampo`.
**Como funciona**: `motivo: 'revezamento'` em `batalha.forcarSaida` marca `vol.retirado` + `vol.volta = 1`; no fim
da rodada, DEPOIS do `fimDaRodada` (é ele que apaga o `recemEntrou`, então a ordem importa),
`voltarDoRevezamento()` devolve quem saiu com `vol` NOVO + `recemEntrou`, passando pelas armadilhas do seu lado e
pelas habilidades de entrada. Ou seja: é uma troca de verdade, com o mesmo Pokémon — os degraus de atributo vão
embora (é exatamente pra isso que o Baton Pass existe, e ele já passa os seus pro aliado).
**Exige aliado em pé**: sem ninguém pra cobrir, `forcarSaida` devolve false e o golpe diz "não havia ninguém pra
cobrir o lugar!" — o dano/efeito dele já aconteceu e não é desfeito, como nos jogos. Em sala (`ctx` sem
`forcarSaida`) o golpe avisa que ali não dá.
**Dois ganhos de tabela**: (1) este é o primeiro caminho em que ARMADILHA DO SEU LADO do campo faz algo — antes
Spikes e cia. no seu lado eram inertes por construção; (2) Regenerator e Natural Cure passam a disparar pelo
gatilho DE VERDADE ("ao sair de campo"), além do equivalente adaptado do fim da luta — a mesma
`regras.efeitosAoVencer` serve nos dois pontos.
**Recusas conscientes**: selvagem NÃO sai por revezamento (o U-turn é escolha dele; fazer a luta acabar sem XP
seria castigo pelo que o jogador não fez) — contra treinador continua valendo o caminho antigo, que já manda o
próximo. E `semSaidaForcada` (Suction Cups) passou a travar só `motivo: 'forcada'`: ela segura o arrastão de
outro, não a vontade própria de quem usa U-turn (nem o medo do Wimp Out).

### Animação da barra de HP (27/09/2026)
Pedido do usuário (junto do backlog de animações): a barra saltava direto pro número novo, sem transição. O
`.fill` já tinha `transition: width .45s ease` no CSS — o problema é que `render()` não faz diffing (destrói e
recria o DOM inteiro a cada chamada, ver o comentário no topo de `render.js`), então uma barra NOVA nasce direto
na largura final, sem "de onde" animar. Resolvido com a técnica **FLIP** (First-Last-Invert-Play) em `render.js`:
`hpbar(m, chave)` ganhou um 2º parâmetro opcional — com `chave`, o `.fill` ganha `id="hp-fill-<chave>"` e a classe
`fill-hp`. `capturarLarguraHP()` roda ANTES de `renderSheet()/renderScene()/renderActions()` redesenharem tudo
(guarda a largura atual de cada barra com id); `animarBarrasHP(antes)` roda DEPOIS: força a barra nova a nascer na
largura ANTIGA (sem transição), faz o navegador aplicar isso com `el.offsetWidth` (força reflow), e só então solta
pra largura de verdade COM transição — o olho vê os dois quadros como uma animação contínua. Respeita `REDUCED`
(`ui.js`, `prefers-reduced-motion`): sem animação nenhuma pra quem pediu, igual sempre foi. Chamadas de
`plate(m, chave)` (cena de batalha: `'e'`, `'p'`, `'a'+i`), `cartaoAliado` (`'card-a'+i`) e `renderFicha`
(`'ficha-p'`) já passam a chave certa. **Validado em jsdom** (não dá pra testar em `node:test`, é manipulação de
DOM pura — mesmo padrão do resto de `render.js`): importar o módulo inteiro em jsdom já confirma que a cadeia de
dependências carrega sem erro; as duas funções, expostas temporariamente pra teste e revertidas depois, terminam
na largura correta nos três cenários (largura muda, largura igual — no-op, elemento novo sem entrada anterior).

### Animações de batalha: ataque, dano, cura, status (28/09/2026)
Pedido do usuário ("mais vivo, mais animações"), prioridade 1 de uma leva maior (ver "Layout paisagem"/"Loja de
preparo" — não, essas são de outro dia; a leva desta é celular deitado + isto + microinterações + tela inicial +
FLIP em XP/PP). Intensidade escolhida pelo usuário: **sutil e polido**, não chamativo.
- **Ataque**: `ctx.atacar(m)` — novo gancho OPCIONAL no `ctx` do motor único (`golpe.js`, mesmo espírito de
  `ctx.tremer`, documentado no cabeçalho do arquivo), chamado em `usarGolpe` no EXATO instante em que anuncia
  "X usou Y!" (linha `await ctx.say(...)`). Single player define `CTX.atacar` (`efeitos.js`, importa `atacar` de
  `ui.js`); multiplayer não define nada — `(ctx.atacar || nada)(u)` no motor não quebra. `ui.js` ganhou
  `idDoMon(m)`/`reanimar(id, classe)`, fatorados de `shake()` (que virou uma linha), reusados por `atacar()`. CSS
  `.mon.atacando` (`atacando .35s`): um "pulo" de escala, sem depender de direção (jogador/aliado/inimigo ficam
  em lados diferentes da cena — decidir lunge direcional exigiria saber a posição de cada um, complexidade maior
  pro ganho; um pulo simétrico já comunica "agiu" sem isso).
- **Dano e cura**: SEM gancho novo no motor — reaproveita a técnica FLIP que já existe (`render.js`,
  "Animação da barra de HP" acima). `animarBarrasHP` já compara a largura ANTES/DEPOIS de cada `.fill-hp`;
  agora também olha o SENTIDO da mudança (encolheu = dano, cresceu = cura) e faz `.mon` piscar vermelho
  (`hit-flash`) ou verde (`heal-flash`), só pra `hp-fill-e`/`-p`/`-a<N>` (as barras da CENA — `ficha-p`/`card-a0`
  mostram o MESMO Pokémon noutro lugar, filtradas pra não duplicar a piscada). Isso cobre TODO caminho de cura
  (Restos, fruta, dreno, clima, item, Centro…) de graça, sem precisar caçar os ~15 pontos de `heal()` espalhados
  por `golpe.js`. **Simplificação assumida**: a largura é uma PORCENTAGEM (hp/hp máximo), então um HP MÁXIMO que
  muda no meio da luta (Rare Candy, Dynamax) também mexe na largura sem ninguém ter apanhado ou curado — piscada
  errada rara e sem efeito de jogo, não vale separar os dois casos.
- **Status**: SEM gancho novo — pulso contínuo e sutil em CSS (`@keyframes pulso-status`, `animation:...infinite`)
  nos chips `.st-burn`/`.st-poison`/`.st-paralysis`/`.st-freeze` e `.stg.up`/`.stg.down` (estágio subiu/desceu):
  como a classe já nasce no HTML a cada render enquanto o status durar, "pulsar enquanto durar" não precisa de
  JS nenhum — só a classe continuar presente já mantém a animação (CSS não reinicia animação em elemento que já
  a tinha, só teria efeito NOVO se o elemento nascesse agora, que é exatamente quando o status é aplicado).
  **Sem "pop" no instante exato em que o status é aplicado** (diferente do FLIP de HP, eu precisaria capturar o
  status ANTES do render pra saber que é novo — decidido não fazer por ora: o pulso contínuo + a mensagem no
  log já comunicam o evento, e o ganho do "pop" isolado não parecia valer a complexidade extra).
- `@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}` (já existia,
  linha final do CSS) cobre TODAS essas animações novas de graça — nenhuma precisou de tratamento próprio de
  `REDUCED`.
- **Fora do escopo por ora**: multiplayer não ganhou essas animações (a cena da sala usa outro DOM, `cartao()`
  em `multiplayer.js`, sem os ids `mon-p`/`mon-e`/`mon-a<N>` que `idDoMon`/`hit-flash` dependem) — se pedido,
  precisaria da mesma técnica adaptada pra lá.

### Microinterações gerais: botões e transição de tela (28/09/2026)
Prioridade 2 da mesma leva ("mais vivo"). Duas regras CSS globais, sem tocar JS nenhum:
- **Botões**: `button{transition:filter,border-color,background-color,transform}` + `button:active:not(:disabled)
  {transform:scale(.96)}` na base (`css/estilo.css`, perto do reset). Cobre TUDO de graça porque quase todo
  clicável do jogo É um `<button>` de verdade (o padrão `data-act`) — golpe (`.mv`), carta de Pokémon (`.pick`/
  `.hall-card`), item da mochila, etc. — sem precisar enumerar cada classe.
- **Transição de tela**: `.create,.game{animation:tela-entra .18s ease-out}` (fade + leve deslocamento). Como
  TODA tela do jogo usa `<main class="create ...">` (ou `.game`, só a tela de jogo em si) como contêiner de
  topo — confirmado varrendo `$('#app').innerHTML =` em cada arquivo `tela-*.js`/`criacao.js`/`arena.js`/etc.,
  incluindo o helper `casca()` de `ranking.js`/`perfil-amigo.js` — uma única regra cobre toda navegação.
  **Cuidado que motivou o valor pequeno (4px, 0.18s)**: `.create` é recriado inteiro em MUITAS interações
  dentro da própria tela (ex.: `tela-ajustes.js`, trocar de fonte chama `telaAjustes()` de novo, não só troca
  uma div), então a animação replay a cada clique — não só na troca de tela. Um valor sutil o bastante fica bem
  mesmo repetindo; um valor mais chamativo (cogitado 6px/0.25s) ficaria cansativo nesse caso. `.game` NÃO tem
  esse problema: só é recriado por `buildGame()`, chamado uma vez ao entrar na jornada — turnos e explorações
  usam só `render()`, que atualiza divs internas sem recriar `.game`, então a entrada anima uma vez só.
  Coberto pelo `prefers-reduced-motion` global (já existia) — nenhum tratamento extra precisou.

### Tela inicial mais viva (28/09/2026)
Prioridade 3 da mesma leva. Três toques, todos CSS-only (menos o `<span>` novo do marcador de presença):
- **🟢 marcador de presença** (`js/presenca.js`, feito antes nesta mesma leva): o emoji do ponto vira
  `<span class="dot-viva" aria-hidden="true">` (escondido de leitor de tela — o texto ao lado já diz "X jogando
  agora", repetir "círculo verde" seria ruído) e pulsa com o MESMO `@keyframes pulso-status` já usado nos chips
  de status da batalha (reaproveitado, não duplicado).
  - **Prévia do Pokémon escolhido** (`.pv-art img`, `criacao.renderPreview`): flutua sozinho (`@keyframes
  flutuar`, translateY suave, 3.2s). É o ÚNICO sprite grande e sozinho da tela — um grid inteiro flutuando ao
  mesmo tempo (a grade de iniciais) ficaria ocupado demais, então NÃO entrou lá.
- **Grade de iniciais** (`.pick`, os cartões de espécie): levanta um pouco no hover (`transform:translateY(-3px)`),
  além da borda que já mudava de cor. **Simplificação aceita**: como `.pick` também é um `<button>` e já ganhou
  o `:active{scale(.96)}` global (microinterações, acima), hover+pressionar ao mesmo tempo mostra só UM dos dois
  transforms (o de maior especificidade CSS, `.pick:hover`) em vez dos dois combinados — efeito colateral
  pequeno, não vale compor os dois valores de `transform` só por causa disso.

### FLIP em XP e PP (28/09/2026)
Prioridade 4 (a última) da mesma leva, fechando o ciclo "mais vivo". `render.js`:
- **XP**: `barraXp(M, GR, chave)` ganhou o MESMO 3º parâmetro opcional que `hpbar` já tinha — com `chave`, o
  `.fill` ganha `id="xp-fill-<chave>"` e a classe `fill-xp`. `capturarLarguraHP`/`animarBarrasHP` viraram
  `capturarLargurasBarras`/`animarBarras` (renomeadas: já não são só de HP) e passam a consultar
  `.fill-hp[id],.fill-xp[id]` juntas — a MESMA técnica FLIP, uma função só. O piscar vermelho/verde (hit/heal)
  continua exclusivo de `.fill-hp` (`if (!el.classList.contains('fill-hp')) continue`): dano/cura não fazem
  sentido pra XP. Chaves: `'ficha-p'` (jogador) e `'card-a'+i` (aliado) — as MESMAS já usadas pela barra de HP
  correspondente (sem colisão de id: prefixos `hp-fill-`/`xp-fill-` diferentes).
- **PP não é barra, é texto** ("PP 5/10" nos botões de golpe) — FLIP de largura não se aplica. Tratamento
  PARALELO, não literal: `capturarTextosPP`/`animarPP` comparam `textContent` antes/depois (mesma ideia do FLIP,
  ANTES/DEPOIS do render, só que em texto) e piscam a classe `.pp-mudou` (CSS: escala + cor por um instante) só
  quando o texto muda. Só o `.pp` do BOTÃO de golpe (`renderActions`, `id="pp-<índice>"`) ganhou id — é o único
  que decrementa DURANTE a batalha; o da ficha (dentro do `<details>` de cada golpe) ficou de fora por não ter
  tanto valor piscar toda vez que o painel reabre.
- Ambos cobertos pelo `prefers-reduced-motion` global — nenhum tratamento extra precisou, igual o resto da leva.


---

## Som: cries e música procedural (30/09/2026)
Item do backlog ("Som no jogo"). Decisão de arquitetura tomada com o usuário antes de escrever qualquer código:
Strudel/TidalCycles (a inspiração original do pedido) ficaram de fora — são bibliotecas de live coding, e o
projeto é JS puro sem build nem dependência; carregar uma delas por CDN funcionaria, mas ainda seria uma
dependência de verdade (biblioteca grande, precisaria entrar no service worker pra funcionar offline). Em vez
disso: `js/som.js`, um compositor pequeno escrito do zero com a Web Audio API, na MESMA camada de `ajustes.js`
(só importa `util.js`/`dados.js` — importável de qualquer lugar acima no grafo).

**Desligado por padrão** (`SOM_KEY='pokerpg-som'`, `somLigado()`), como as outras preferências de `ajustes.js`.
`⚙ Ajustes → Som` (seção C, antes de "Jogar offline" — as seções D/E/F foram reletradas) tem um checkbox só;
ligar não pediu confirmação nem aviso: é reversível na hora. As demais seções (D Jogar offline, E Presença, F
Cookies) só mudaram de letra.

**Cries**: `dados.CRY(id)` monta a URL pelo id, no MESMO padrão de `SPR`/`SPR_SHINY` — espelhado no jsDelivr
(`cdn.jsdelivr.net/gh/PokeAPI/cries@main/...`), repositório IRMÃO do de sprites, já coberto pelo `cachePrimeiro`
genérico do `sw.js` (a lista `EXTERNOS` casa por HOST, não por caminho — nenhuma linha nova precisou entrar lá).
`tocarCry(id)` usa `new Audio(url).play().catch(()=>{})`: falha de rede ou autoplay bloqueado é silêncio, não erro
— é decoração, não crítico como as imagens.

**Música**: sem arquivo nenhum, sempre GERADA, de dois ingredientes que se cruzam:
- **`CONTEXTOS`** (que tela) dá andamento, agitação e timbre: `telas`/`menu`/`explorar`/`batalha`/`chefe`.
- **`TEMAS`** (que rota) dá a tonalidade — raiz, escala e a progressão de 4 acordes. As chaves são **os biomas de
  `cenario.climaDaRota`**, a MESMA derivação que já pinta o céu e o chão da batalha a partir do TEXTO da rota.
  Reusar aquilo é o que faz "uma música por rota" valer pras 99 rotas sem tabela nova pra manter: rota com
  "caverna" no nome já nasce com som de caverna. Os 12 biomas cobrem as 99 rotas de hoje (`tests/som.test.js`).

Escalas: pentatônica maior/menor e menor harmônica — soam "certas" com nota quase aleatória, o que dispensa um
gerador de melodia mais esperto. O agendamento segue o padrão clássico de "olhar à frente" (agendar no relógio do
`AudioContext`, não confiar no `setTimeout` por nota — ele atrasa sob carga): `agendador()` roda a cada 25 ms e
agenda todo passo de 16 que cair dentro da janela de 100 ms à frente.

**Vitória** é uma fanfarra curta (arpejo maior ascendente, uma vez só, sem loop) — `tocarStinger()`, sem passar
pelo agendador.

**Onde troca de música**: nos pontos que já eram o choque único de cada transição (nenhuma tela precisou saber de
música sozinha) — `criacao.showCreate` (menu), início da jornada e `main` no `case 'zone'` (explorar, com a rota
nova), `batalha.iniciar` (batalha/chefe + `tocarCry` do inimigo — é o único momento de grito: o jogo não tem
captura de Pokémon selvagem, é o TREINADOR que tenta capturar VOCÊ), `batalha.endBattle` (volta pra explorar),
`fim.telaFim` (fanfarra na vitória, silêncio nos outros motivos) e **um ponto único em `main.aoClicar`** que dá a
faixa `telas` pra toda tela de menu — todas são alcançadas por um `data-act` da lista `TELAS_NAV`, então bastou
uma linha em vez de mexer em 12 telas. Essa linha lê a condição de batalha À MÃO em vez de chamar
`travadoPelaBatalha()`: aquela função TOASTA quando barra, e o `case` do switch a chama de novo — o jogador veria
o aviso duas vezes. `main.abrirJornada` religa a trilha certa ao retomar um save.

### A segunda leva (30/09/2026): o que quem jogou reclamou
Cinco queixas do primeiro dia, todas atendidas em `som.js`:
1. **"Os sons estão com delay"** (o grito principalmente). A causa era `new Audio(url).play()`: o arquivo era
   BUSCADO na hora do grito. Agora o cry é baixado, **decodificado uma vez e guardado** e tocado por
   `createBufferSource` — instantâneo. Quem aquece é **`precarregarCry`, chamado por `pokemon.makeMon`**: todo
   Pokémon do jogo nasce ali, bem antes de entrar em campo, então na hora da luta o áudio já está pronto. O
   service worker já guardava o arquivo (o host está em `EXTERNOS`), então isso custa rede só na primeira vez.

   ⚠️ **O primeiro conserto disto virou um bug pior, e foi pra produção**: o mapa guardava o BUFFER e era marcado
   com `null` antes do fetch, pra não buscar duas vezes. Só que `tocarCry` lia esse `null` como "ainda não
   chegou", apenas re-aquecia e **não tocava** — ou seja, na PRIMEIRA aparição de cada espécie o grito nunca saía,
   que é justamente o caso comum. O jogador relatou como "os cries pararam de tocar". A correção é guardar a
   **promessa** do buffer, não o buffer: quem pede o grito se pendura nela e toca quando ela resolve, esteja o
   áudio pronto ou a caminho (com um corte de 3 s, pra grito que demorou na rede não sair fora de hora).
   Lição de teste, registrada porque se repetiu: **o teste manual que eu fiz exercitou só o caminho QUENTE** (eu
   esperei o áudio chegar antes de mandar tocar), e o caminho frio — o do jogador — nunca foi testado.
   `tests/som.test.js` cobre agora o frio, e foi conferido que ele REPROVA a versão com bug.
2. **"Se eu saio do navegador o som continua"** — incômodo real. `visibilitychange`: aba escondida para o
   agendador e dá `ctx.suspend()`; ao voltar, `resume()` + `retomar()` remonta a faixa do `pedido` guardado.
3. **"Precisa ter menos agudos"** — duas coisas somadas: um **passa-baixa de 2 kHz** na saída de tudo (onda
   quadrada e dente-de-serra jogavam harmônico agudo direto no alto-falante) e a melodia rebaixada: antes era
   `raiz + escala + 24` com raiz 60/62 (chegava perto de 2 kHz, a 7ª oitava); agora o teto é `+12` e as raízes
   moram entre 48 e 57 (Dó2–Lá2), o que põe o topo em ~830 Hz. Nota acima de MIDI 74 ainda sai com 55% do volume.
   `tests/som.test.js` trava esse teto — é fácil desfazer sem perceber ao mexer numa raiz.
4. **"Música para cada rota de acordo com o tema"** — a tabela `TEMAS` acima, via `cenario.climaDaRota`.
5. **"Um som pra tela inicial e as outras que não sejam o jogo em si"** — o contexto `telas` e a linha única em
   `main.aoClicar`.

**Ficou de fora, por escolha**: volume ajustável (só liga/desliga — o pedido era esse) e qualquer coisa que
dependesse de arquivo de áudio publicado (tudo é sintetizado). `tests/referencias.test.js`: `AudioContext` entrou
em `GLOBAIS_MAIUSCULAS` (mesma lista que já tinha `Audio`).

### A terceira leva (30/09/2026): melodia escrita à mão e o editor
Queixa: *"não estou gostando das músicas, tem algum jeito de eu dar um toque humano nela? Quero interferir e
testar, mas não estou perto do Raspberry Pi."* Duas coisas, e a primeira é a causa de fundo:

**1. A melodia era SORTEADA nota a nota.** Dentro de uma pentatônica nenhuma nota soa errada, então o resultado
era *inofensivo* — e sem rumo: faltava o motivo que se repete, que é o que faz a gente reconhecer uma música.
Agora cada tema tem uma **frase escrita à mão** (`melodia`), numa notação de um token por semicolcheia:
número = grau da escala, `.` = silêncio, `-` = segura a nota anterior. O sorteio virou só tempero (a oitava
ocasional) — altura e ritmo são sempre os escritos. Tema sem `melodia` ainda cai no gerador antigo.
⚠️ A variação de oitava é pra **baixo** (`+0` em vez de `+12`): a primeira versão pulava pra `+24` e teria
desfeito exatamente a correção de agudo da leva anterior. `tests/som.test.js` trava o teto e o formato da frase.

**2. O editor: `musica.html`.** Página de autoria, publicada junto com o site pra funcionar **de qualquer
aparelho** (o pedido era justamente poder mexer longe do Pi). Seleciona tema e contexto, edita a frase, ajusta
raiz/escala/onda/progressão/andamento e o corte de agudo e o volume, ouve na hora, e sai com **o bloco de código
pronto pra colar em `TEMAS`** ou com um **link que carrega exatamente aqueles ajustes** (é assim que o resultado
volta pra cá). Decisões que valem registro:
- **Toca pelo motor de verdade** (`som.js` exporta `tocarPreview`/`ajustarSaida`, e `montarFaixa` aceita um tema
  como OBJETO). Um editor com sintetizador próprio soaria diferente do jogo em uma semana.
- **`tocarPreview` dá `resume()`**: o editor cria o `AudioContext` ao mexer nos controles de saída, e ele nasce
  `suspended` — sem isso o botão Tocar agendava tudo e não saía som.
- **Fora do jogo e fora do buscador**: não está em `PAGINAS` (então `gerar-paginas.mjs` não a toca e ela não
  entra no `sitemap.xml`), não está no `PRECACHE`, não é linkada de lugar nenhum e leva `noindex,nofollow` —
  importante porque a revisão do AdSense está em curso e página fina indexada conta contra.
- O link usa `encodeURIComponent`, **não base64**: `btoa` estoura com acento (o nome "menor harmônica" já
  bastava), e em texto dá pra ler o link e ver o que ele carrega.

**Sobre testar isto sem navegador**: jsdom **não executa `<script type="module">`** — a primeira tentativa
mediu zero e parecia que a página estava morta. O jeito que funciona é extrair o corpo do módulo e importá-lo
com o DOM do jsdom nos globais; e `window.AudioContext` precisa ser posto no objeto `window` do jsdom, não só em
`globalThis` (o código checa `window.AudioContext`, e essa mesma distração já tinha dado falso negativo antes).

### A quarta leva (30/09/2026): transição, tema de batalha e os efeitos curtos
Queixa: *"o problema é relacionado à transição de uma pra outra, tem que ser algo mais claro e ao mesmo tempo
suave, tipo uma transição de um lugar para o outro; também é importante ter uma música marcante durante a
batalha, uma música de derrota, um som de level up, um som de compra de item. Quando selecionar o pokemon na tela
inicial soltar o cry do pokemon. Algo mais fluido e natural e mais imersivo."* Cinco coisas, todas em `som.js`:

**1. A transição.** Um nó de ganho novo, `musica`, entre as notas da trilha e o `master` — é ele que sobe e
desce. `comFade(montar)`: a faixa atual desce em 0,35 s, há um **respiro de 0,2 s de silêncio** e a nova entra
subindo em 0,7 s. O respiro é o que atende o "claro" do pedido — crossfade puro, com as duas se sobrepondo,
passa despercebido justamente por ser contínuo. *Não* é crossfade de verdade (as duas tocando juntas) porque
isso pediria dois agendadores e duas `faixa`s; por 0,2 s de sobreposição não compensa. `trocaId` cancela a
entrada de uma troca que outra atropelou — andar rápido entre rotas dispara várias, e sem isso duas faixas
começariam juntas. Os **efeitos curtos entram no `master`, não no `musica`**: um level up no meio de uma
transição não pode ser engolido pelo fade.

**2. A música de batalha.** O contexto ganhou `melodiaFixa`, e ela **vence a melodia do tema**: música de luta
só é marcante se for a MESMA toda vez. A rota continua entrando pela tonalidade (raiz, escala e progressão do
bioma), então a batalha na caverna e a na praia continuam soando diferentes — muda a cor, não a frase. O editor
(`musica.html`) é a exceção: `tocarPreview` marca o tema com `preview`, e aí a frase do TEMA manda, que é o que
se está ajustando lá.

**3. Os efeitos curtos.** `SFX` é uma tabela de `[atraso, midi, duração]` escrita à mão, tocada por `tocarSfx`
sem passar pelo agendador: `vitoria` (o antigo `tocarStinger`), `derrota` (desce e se arrasta), `nivel` (três
degraus subindo, em `progressao` — seu e dos aliados) e `compra` (duas notas agudas, no `case 'buy'`).
`tocarMusica` reconhece qualquer nome que exista em `SFX`, então `fim.telaFim` chama `tocarMusica('derrota')` do
mesmo jeito que já chamava a vitória. Derrota toca em `desmaiou` e `capturado`; encerrar a jornada por vontade
própria continua em silêncio.

**4. O grito na tela inicial.** `criacao.previewSearch`, logo depois de a espécie resolver. O clique no card é o
gesto que os navegadores exigem, mas o `AudioContext` pode ter nascido `suspended` antes disso (a trilha do menu
já o criou), então `tocarCry` passou a dar `resume()` — sem isso o grito seria agendado num relógio parado.

**Ficou de fora**: volume por categoria (música x efeitos) — o nó `musica` já deixaria isso a uma linha, mas o
ajuste continua sendo um liga/desliga só, como combinado.

### A quinta leva (30/09/2026): som de impacto por tipo, piscada colorida e desligar as animações
Pedido: *"precisa ter um som de dano dos ataques ou efeitos, tipo golpes de fogo quando acertam fazem um som de
labareda, o golpe de vento parece uma lufada de ar e assim por diante, isso nos 2 pokemons, isso acredito que
implica no timing das batalhas também (…) impacto colorido nos sprites e o som, então ter a opção de desabilitar
as animações de combate junto com a desabilitação do som seria uma opção viável."*

**Um gancho, não três.** O motor já tinha `ctx.tremer(m)` — chamado nos cinco pontos em que alguém perde HP por
golpe, e chamado igual pros dois lados (você, aliado, inimigo), porque o motor é único. Ele passou a receber o
TIPO do golpe (`ctx.tremer(m, tipo)`) e o `CTX` do single player faz as duas coisas de uma vez: `ui.shake` (a
animação) e `som.tocarImpacto` (o som). Nada de percorrer a árvore de golpes atrás de "onde toco o som de fogo":
quem sabe que houve dano já era esse ponto.

**O som: dez famílias pra dezoito tipos.** `som.IMPACTOS`, uma linha por família, com os tipos dela listados
dentro — `FAMILIA_DO_TIPO` é *derivado* daí, então não existe segunda lista pra manter em sincronia. Duas peças
por família, e o que define o caráter é a **varredura**, não a frequência parada: `ruido` é ruído branco por um
passa-banda que escorrega de uma frequência a outra (descendo e largo = labareda; subindo = lufada; agudo e
estreito = estalo; grave = pancada), `nota` é um oscilador deslizando, pro lado tonal (o ping do gelo, a
badalada do metal, o lamento do fantasma). Nenhum arquivo de áudio, como o resto do módulo.

O detalhe que quase passou: **tudo sai pelo passa-baixa de 2 kHz do `master`**. O estalo do Elétrico nasceu em
2,3 kHz, o filtro o engoliria e a família perderia exatamente o que ela existe pra ter. Roteá-lo por fora do
filtro custaria uma cadeia de saída nova — mais barato baixar os números e ficar com uma chain só. É o que
`tests/som.test.js` trava agora, junto com "todo tipo tem família" (tipo novo cairia na pancada genérica em
silêncio) e "nenhuma família lista um tipo que não existe" (erro de digitação vira família morta).

**A piscada colorida reusou o que já existia.** `hit-flash` (a piscada de dano, deduzida do sentido em que a
barra de HP mudou) trocou o `#ff4d4d` cravado por `var(--cor-impacto, #ff4d4d)`, e `ui.shake` põe a var com a
cor do tipo (`dados.TC`, as mesmas dos selos). A ordem importa e não dava pra escolher: `render()` remonta a
cena inteira, então uma var posta ANTES do `up(ctx)` iria pro lixo junto com o elemento — por isso `shake`
**reinicia** a piscada depois, já com a cor certa. Dano sem tipo (confusão, o esforço do próprio golpe) fica no
vermelho padrão, que é o fallback da própria var.

**O liga/desliga virou um conceito só, não um segundo.** `ui.REDUCED` (uma const lida uma vez, do
`prefers-reduced-motion`) foi substituída por `ui.semAnimacao()`, que junta a mídia do sistema com
`ajustes.animacoesLigadas()`. Função, não const: o checkbox tem de valer na hora, e uma const lida no
carregamento só valeria depois de um F5. Todos os cinco pontos que consultavam `REDUCED` passaram a chamar a
função — e um deles é o `say`, o que **atende o "implica no timing" de graça**: sem animação pra ver, a pausa
entre as mensagens do combate cai de 420 ms pra 80 ms e a luta anda mais rápido. O caminho contrário — deixar a
batalha mais LENTA pra esperar a animação — não foi preciso: os 420 ms do `say` já cobrem os 0,35 s da piscada e
o meio segundo do som mais longo, e o som não precisa terminar antes da próxima linha de texto.

**Ficou de fora:**
- **Som nos efeitos que não são golpe** (veneno e queimadura no fim do turno, recuo, armadilha de entrada). Eles
  nunca passaram por `ctx.tremer` — nem hoje tremem —, então dar som a eles é um gancho novo em cada ponto, não
  um parâmetro num que já existe. Entra quando alguém reclamar que o veneno é silencioso.
- **Som de impacto no multiplayer.** O `ctx` do `mp-motor` não define `tremer` (não tem DOM), e a sala narra o
  turno por linhas já prontas — o caminho seria tocar por `cls === 'hit'` na `narrar`, sem saber o tipo. Som
  genérico pra todo golpe é pior que nenhum; fica pra quando o evento do motor levar o tipo junto.
- **Animação por tipo** (chama subindo no Fogo, jato d'água): a piscada colorida cobre o pedido com uma var de
  CSS; sprite de partícula por tipo é arte nova, não código.

### 🎵 O editor de músicas DENTRO do jogo (07/10/2026)
Pedido: *"quero colocar a opção de editar as músicas também para o admin, do mesmo jeito"* — do mesmo jeito que o
🗺 Editor de rotas, ou seja: tela no jogo, rascunho no navegador, **publicação pela nuvem** e 📋 copiar pro repo.
`musica.html` já editava, mas não é admin, não entra na barra de telas e **não publica** — era o que faltava.

- **As tabelas saíram pra `js/dados-musica.js`** (puro, sem imports, mesmo papel de `dados-rotas.js`). Motivo de
  grafo: `conteudo.js` é o CHÃO (puro, testado no Node) e precisa mutar `TEMAS`/`CONTEXTOS` no lugar — importar o
  motor de áudio dentro dele seria o grafo ao contrário, e arrastaria `cenario.js` pra dentro do teste do pacote.
  `som.js` **reexporta** tudo, então `musica.html` e `tests/som.test.js` não mudaram uma linha.
- **Um publicador só.** `conteudo_publicado` tem **uma linha por canal**: se a tela de música montasse o próprio
  pacote, publicar a trilha apagaria as 180 missões de rota (e vice-versa) **sem erro nenhum aparecer**. Então
  `gerarPacote(rotas, musica)` passou a receber as duas metades e a tela de música **chama**
  `tela-editor-rotas.publicar`. Dependência de uma tela na outra é feia; dois pacotes competindo pela mesma linha
  é pior.
- **`musicaEditada()` manda TODAS as faixas, não só as editadas.** `aplicarMusica` volta pro de fábrica o que o
  pacote não traz (é o que permite desfazer uma edição publicada) — mandar só o rascunho faria o usuário editar o
  `gelo` hoje e perder o `mar` que publicou na semana passada.
- **O que vem da nuvem não passa por teste.** `tests/som.test.js` cobra o teto de agudo e o compasso de 16 passos
  nas tabelas do repositório; tema publicado só tem `conteudo.validarMusica`. Ela lê as MESMAS constantes
  (`RAIZ`, `MIDI_MAIS_AGUDO`, `maisAgudo`) — número repetido à mão seria o editor aprovando o que a publicação
  recusa. A tela valida pela mesma função, com a edição sozinha dentro, pra o erro aparecer no 💾 e não no 📤.
- **`onda` e `melodiaFixa` ausentes são SIGNIFICADO** ("herda do contexto", "sem frase própria"), então o aplicar é
  `tema || fabrica` e não `{ ...fabrica, ...tema }`: com o spread, a chave de fábrica sobreviveria e não haveria
  como voltar a herdar. A chave morta é apagada antes de escrever.
- **A trilha das telas não toca aqui**: `main.js` pede `tocarMusica('telas')` em toda tela de menu, e no editor
  quem manda na trilha é o ▶ da própria tela.
- **Ficou de fora**: o 🎲 sortear frase (está em `musica.html`, que continua existindo pra compor de qualquer
  aparelho) e editar o nome dos biomas ou criar bioma novo — bioma sai de `cenario.CLIMAS`, lido pela cena da
  batalha, não é dado de música. Chave desconhecida no pacote é **recusa**, não "ignora": tema que nunca toca é
  pior que um erro.

### 📦 Fases 2 e 3: a rota, as missões globais, os itens e as badges (07/10/2026)
Fecham o pedido de 06/10 ("controle completo de criação e edição do máximo de coisas do app"). O que passou a ser
dado publicável: **a lista de rotas de cada Gen** (pool com peso, níveis, nome, descrição, bioma, criar e excluir),
**as missões globais**, o **preço de cada item** e as **badges** — texto, prêmio e, desde a mesma tarde, **badge NOVA**.

- **Por que a lista INTEIRA de rotas por Gen, e não um remendo por rota.** Criar, excluir e reordenar são a mesma
  operação ("a lista é outra"), e a ORDEM é a corrente do mapa (o `antes` de cada missão de Alfa, o `libera`, a
  rota final). Um remendo por rota precisaria de um `depois:` e de um `excluir: true` — três mecanismos pra fazer
  o que uma lista já faz. O preço: um pacote montado de uma versão velha do editor REVERTE o mapa daquela Gen. O
  editor sempre monta a lista a partir das tabelas AO VIVO, que é o que torna o preço aceitável (o mesmo acordo da
  música).
- **O que o pacote NÃO pode fazer com um mapa**, e cada trava tem um defeito real atrás: esvaziar uma Gen · tirar
  o **Santuário** (é ele que garante a Pokédex completa) · deixar a Gen sem rota **`final`** (é vencer os
  lendários dela que fecha a Gen — sem isso a jornada não TERMINA, e isso não daria erro, daria um jogo sem fim) ·
  ter **duas** finais (`rotaFinalDaGen` pega a primeira e a outra nunca fecharia nada) · repetir um id de rota
  **entre Gens** (`S.zona` guarda só o id, e `MISSOES` aponta por id) · pool vazio · peso 0 (nunca aparece) ·
  pôr um chefe de raide de forma normal fora do Santuário (a lista é `dados.SO_NO_SANTUARIO`, exportada pra não
  virar segunda cópia da regra).
- **`tema` entrou na lista de campos de propósito.** Nenhuma rota gerada tem esse campo, mas `cenario.climaDaRota`
  já o lê ANTES de adivinhar o bioma pelo texto da rota. É o que permite uma rota CRIADA escolher a própria cena
  (e, com ela, a música) em vez de depender de ter a palavra certa no nome.
- **A ordem de aplicação é regra**: `mapas` → `alfas` → missões. `alfas` é ajuste POR CIMA da rota, então trocar a
  lista depois dele jogaria a troca de Alfa no lixo; as missões apontam pra rota por id.
- **Validar contra as rotas DEPOIS do pacote, não as de fábrica.** Uma missão (ou um Alfa) pode apontar pra uma
  rota que o próprio pacote está criando. Validar contra a tabela de hoje recusaria o pacote coerente — e o pior:
  recusaria só na primeira vez, porque no boot seguinte a rota já existiria e o MESMO pacote passaria.
- **`podeAplicarAgora` ficou GROSSO de propósito pro mapa**: se o pacote traz a Gen da jornada e a lista é
  diferente da de agora, espera a jornada seguinte. Dava pra ser fino (só se a rota atual mudou, só se o pool
  encolheu), mas a run pendura cinco coisas na lista — registro de Pokédex por rota, missão de rota, caça shiny
  com espécie alvo, rota esgotada e `S.zona` — e errar uma trava a jornada de alguém. Gen diferente aplica na hora.
- **O offline**: `alvosDaGen` já derivava de `GENS`, então `baixarGen` passou a baixar o que o pacote pede sem uma
  linha de mudança — a armadilha "isso está no `baixarGen`?" não se repetiu aqui. O que faltava era a MARCA:
  `VERSAO_DOWNLOAD` só muda com deploy, que é exatamente o que o pacote existe pra evitar. Então
  `offline.marcaDaGen` leva uma **impressão do conteúdo da Gen** (os ids que o download traz): pool editado =
  marca nova = a tela volta a dizer "vale baixar de novo", sozinha.
- **A camada de FÁBRICA das rotas é `dados-rotas.MAPAS`**, aplicada por `dados.js` igual a `ALFAS` (e com
  `semChefeDeRaide`/`ALFAS` por cima dela). Sem isso, mapa editado viveria só na nuvem e uma instalação nova
  nasceria com o mapa velho — o "📋 Copiar o arquivo" existe exatamente pra isso.
- **Fase 3, onde a linha foi traçada**: o EFEITO de um item é código (`ITEMS.potion.heal` é lido por
  `itens.usarItem`), então o pacote mexe em preço, nome e descrição, e item novo continua sendo commit.
  **`price: 0` é o botão de desligar um item**: `render.js` só põe na loja o que tem preço, e `precoVenda` passa a
  dar nada por ele — não precisou de flag nova.
- **E onde a linha SE MOVEU, no mesmo dia.** A medida de uma badge estava do lado do código pelo mesmo argumento
  (`mede(ctx)` é uma função, e função não cabe num pacote da nuvem). O relato foi direto: *"o editor de conteúdo
  não me permite criar novas badges, quero ter essa possibilidade, crie um template com várias possibilidades
  para eu poder usar criatividade"*. A resposta não foi publicar código — foi notar que as 58 `mede` de fábrica
  são quase todas **a mesma função**: ler um número do `ctx` e comparar com um alvo. Então virou DADO:
  **`badges.MEDIDAS`** é a lista fechada do que o `contextoBadges` conta (38 entradas: os totais da caçada, as 18
  por tipo, a Pokédex, os laços, os ovos, as jornadas por modo, as gimmicks e o dano), e badge nova traz
  `medida: { campo, alvo, especie? }`, resolvida por `medirPorDado`. `badgesDaConta` lê `b.mede || medirPorDado(b.medida)`.
  O que ficou do outro lado da linha é **medida nova**: regra composta (as duas do Rayquaza juntas) ou coisa que o
  `ctx` não conta ainda continua sendo um campo no `contextoBadges` + uma linha em `MEDIDAS`.
- **`campo` é caminho com ponto, e por isso as 18 por tipo saem de graça.** `abates.tipoAlvo.fire` é lido por um
  `reduce` de 1 linha, o mesmo que serve pra `abates.total` e pra `conhecidas` — e `abates.especie` ganhou um
  `especie: true` na tabela pra que o caminho termine no nome ("derrote 500 Rattata"). Caminho desconhecido vale
  **0**, nunca estoura: a tela de conquistas é onde a carreira inteira aparece, e a validação do pacote é quem
  impede que uma medida inventada chegue lá. `tests/badges.test.js` confere que TODA entrada de `MEDIDAS` existe
  de verdade no `ctx` — rótulo sem campo atrás seria uma badge impossível em silêncio.
- **`badges` é a única chave do pacote com as DUAS semânticas**: id de fábrica é remendo (nome/desc/prêmio, e a
  medida dele continua sendo a função); id novo é a linha INTEIRA. E toda aplicação **tira primeiro** as badges
  de pacote anterior antes de pôr as do novo — badge despublicada tem de sair da tela, não ficar no ar até o F5.
- **O ícone da badge passou a ser escapado** (`tela-conquistas`, `conta`, `perfil-amigo`): era emoji de tabela
  nossa e ia cru pro HTML; com badge vinda da nuvem ele é texto de fora. Duas camadas, como sempre: a validação
  recusa `< > & " ' \` \\` no ícone **e** as três telas chamam `esc()`.
- **Prêmio com item que não existe passou a ser recusado** (vale pras missões de rota também): `S.bag[id]` guardaria
  uma chave que nenhuma tela desenha, e o jogador receberia "nada" sem erro nenhum.
- **Condição de missão com chave desconhecida é recusada.** `regras.progressoCondicao` cai no `[0, 1]` dela, o que
  deixa a missão **impossível em silêncio** — o pior defeito possível aqui. A lista de chaves válidas é a dela.
- **Duas semânticas no mesmo pacote, e confundi-las é bug**: lista inteira (mapas por Gen, missões globais, música)
  onde ausente = fábrica; remendo por chave (alfas, itens, badges) onde só o que vem muda. `missoesRota` é a
  exceção histórica (ausente = NENHUMA), mantida pra não quebrar pacote já publicado.
- **"Missões de conta" era um rótulo mentiroso, e o próprio usuário pegou**: *"tem certeza que as missões de conta
  são para a conta toda? Ou são por Run?"*. São por RUN — `regras.progressoCondicao(cond, S)` mede no save da
  JORNADA (`S.wins`, `S.money`, `S.registro`), então elas zeram a cada jornada nova. O que mede a conta inteira
  são as badges. A tela, o `main.js` e este documento passaram a dizer **missões globais** ("globais" = valem em
  qualquer mapa, que é a oposição real contra as missões de ROTA). O nome da chave do pacote (`missoesGlobais`) já
  estava certo desde o começo — era só a UI que mentia.
- **Ficou de fora**: **rotas secretas** (fase 4 — é mecânica nova: condição no save, na tela de explorar e no
  progresso, não "mover dado pra nuvem"); criar ESPÉCIE ou região; e a validação de "inicial de região no pool",
  porque o editor só oferece candidatas já limpas (`candidatasDaGen`) e a lista viria de `mapas.js`, que roda
  `tirarIniciais` no import e mexeria no estado de quem só queria validar um pacote.

---

## Sprites da cena: o retângulo escuro e o tamanho de verdade (30/09/2026)
Dois defeitos no mesmo print de celular: um fundo escuro arredondado atrás do Pokémon do jogador, e *"os pokémons
oponentes parecem estar muito maior que o necessário, e ambos estão muito pixelados, acho que pela proximidade"*.

**O retângulo era colisão de nome de classe.** A ficha usava `<div class="me">` e a cena da luta usa
`<div class="side me">` (a sala, `<div class="mp-fila me">`) — o seletor `.me img`, escrito para a ficha, pegava
o sprite em campo e lhe dava `background:var(--panel2)` e `border-radius`. Renomeado para **`.ficha-me`**, que é
o lado com um uso só; renomear a cena mexeria em dois arquivos e numa media query. Lição: classe de duas letras
com significado genérico (`me`, `foe`) só serve **composta** (`.side.me`).

**O tamanho**: `.spr` tinha `object-fit:contain`, que ESTICA a imagem até encher a caixa de 128 px (92 no
celular). Pixel art ampliada 1,6× tem pixel de tamanho irregular — é essa a "pixelação por proximidade". E como
todo mundo enchia a mesma caixa, **a proporção entre espécies sumia**: o Showdown desenha o Meowth bem menor que
um Onix, e a cena apagava isso (o "oponente maior que o necessário"). A troca é de uma palavra:
**`object-fit:scale-down`** = `contain` que nunca amplia, ou seja, imagem menor que a caixa sai no tamanho de
verdade dela (1:1, nítida). Com `object-position:bottom` junto, senão o sprite a que sobra espaço flutuaria no meio
da caixa em vez de pisar no chão. A caixa continua valendo pra quem é MAIOR que ela: o sprite 3D (512 px) e os
GIFs grandes seguem sendo reduzidos pra caber.

---

## Troca de tipo, Endeavor no chefe e a leva de itens (30/09/2026)
Pedido: *"ajuste o move Soak, endeavor para os bosses e adicione itens como Heavy Duty Boots, Air Ballon entre
outros"*. Três frentes independentes.

### Soak: o motivo de `regras.tiposDe` existir
Soak não estava implementado. O problema não era o golpe, era **onde o tipo morava**: 6 lugares liam
`m.data.types` direto, e `m.data` **vem do cache e é compartilhado por toda a espécie** (armadilha já registrada
no CLAUDE.md). Escrever o tipo novo ali contaminaria todo Pokémon daquela espécie e ainda iria junto no save.
Então o tipo trocado mora em **`vol.tipos`** e nasceu **`regras.tiposDe(m)`** como fonte única, usada por quem
decide dano, STAB, imunidade, status, clima e terreno. Ficaram de fora, de propósito, os leitores de
**identidade** da espécie (petisco em `amizade.js`, condição de evolução em `evolucao.js`, a ficha em
`render.js`): quem levou Soak não mudou de espécie.
Entraram 4 golpes: `soak` e `magic-powder` (`viraTipo`) e `forests-curse`/`trick-or-treat` (`ganhaTipo`). Falha
quando não mudaria nada e **em quem terastalizou** (o Tera manda na defesa). Some no fim da batalha junto do `vol`.
Efeito colateral de graça: Soak num Voador tira a imunidade a Terra **e** o põe no chão pro terreno — porque
`noChao` passou a ler da mesma fonte.

### Endeavor contra o chefe: era um atalho que anulava a luta
`danoIgualHp` fazia `t.hp = u.hp` **direto**. Contra o chefe da semana, que tem o HP multiplicado
(`boss.prepararChefe`), bastava estar quase morto pra derrubar quase tudo de uma vez — por cima da couraça de
energia, das reduções de `danoNoChefe` e das fases, que nem chegavam a ser consultadas. Agora o buraco que o
golpe abriria vira **dano comum** e passa pelo mesmo caminho de todo mundo (`danoNoChefe` + `aposDanoNoChefe`).
Contra chefe continua sendo muito dano de uma vez; fora do chefe **nada mudou**.

### Itens: 6 novos, 17 frutas de aperto e 6 de dupla função
Reaproveitando ganchos que já existiam onde dava (`resisteDoItem` ganhou a efetividade como parâmetro; a Lente
de Mira entrou no mesmo degrau de crítico do Focus Energy e do Super Luck).
**A Pedra do Rei foi cortada da leva, e depois voltou de outra forma.** Na primeira tentativa eu criei
`kings-rock` em `ITENS_SEGURADOS` sem notar que o id já era item de EVOLUÇÃO (Poliwhirl/Slowpoke). `ITENS_EVO` é
aplicado a `ITEMS` DEPOIS, então o item da loja virava o de evolução e o efeito de recuo ficava morto — e nenhum
teste reclamou, porque eles olhavam a TABELA e não o `ITEMS` final. Cortei o item e reforcei o teste.

### Item de dupla função (`dados.duplo`)
O usuário apontou o obvio que eu tinha perdido: nos jogos esses itens **são os dois** — a Pedra do Rei evolui
Poliwhirl E dá 10% de recuo na mão. O erro não era ter querido o efeito, era ter **duplicado o id em duas
tabelas** em vez de dar duas funções ao mesmo item. A forma certa:
- **`dados.duplo(name, efeito, quem)`** cria um item com as duas marcas: `segurar` (evolui, é gasto) e
  `segurado` (equipável). Um id só, em `ITENS_EVO`; o efeito de luta mora em `segurados.js` na mesma chave.
- **`IDS_EVO_EM_BATALHA`** é derivada (`ITENS_EVO` filtrado por `segurado`), não escrita à mão: marcar um item
  novo como duplo já o inclui, e o teste cobra um gancho e uma descrição que explique o efeito de segurar.
- **A ordem de `CATEGORIAS_ITEM` mudou**: `evolucao` passou na frente de `segurado`, senão o item duplo (que tem
  as duas marcas) migrava de 💎 Evolução pra 🎒 Para segurar e desaparecia de onde quem procura evolução olha.
  Isso não o esconde pra equipar — o seletor de "Segurar" (`render.js`) filtra por `segurado`, não por categoria.
- **A evolução passou a aceitar o item NA MÃO.** `evolucao.detalheCumprido` lê `ctx.bag`, e equipar tira da
  mochila — então, sem isso, equipar a Pedra do Rei travava a evolução do Poliwhirl sem dizer por quê (e nos
  jogos é justamente SEGURANDO que esses itens evoluem). `progressao.contexto` agora inclui o item da mão na
  `bag` que entrega, e `pagar(o, M)` gasta da mão quando foi de lá que veio.
- **`soEspecie`** nasceu pro Dente/Escama Abissal, que nos jogos só servem ao Clamperl. Ler `seg(m).multStat`
  cru daria o bônus a qualquer um, então `multStatDoItem` faz a checagem e `regras.effStat` passou a chamá-la.

Os 6: Pedra do Rei e Presa Afiada (recuo 10%), Garra Afiada (+1 crítico), Revestimento Metálico (Aço +20%),
Dente e Escama Abissal (At./Def. Especial ×2, só Clamperl). Os demais itens de evolução **não têm** efeito de
batalha nos jogos (pedras, Melhoria, Protetor, Escama de Dragão na era moderna…) e seguem só evoluindo.

Testes em `tests/soak-itens.test.js`, todos pelo motor de verdade. O do Endeavor foi conferido contra a versão
antiga: ele **reprova** o comportamento que estava no ar, que é o que faz dele um teste de regressão de verdade.

### Achar os itens novos explorando (30/09/2026)
Pedido, logo depois: *"as berrys adicionadas, quero se seja possível pegar explorando, outros itens pertinentes
também"*. O problema real era de descoberta: a leva acima entregou 20 frutas e 25 segurados permanentes, e todos
**só existiam na loja**. Quem não tem o hábito de passar na loja — ou quem está numa run sem dinheiro sobrando —
nunca encostava na mecânica. As 17 frutas de aperto por tipo eram o pior caso: são justamente o item que se
entende ACHANDO ("por que eu tenho uma Fruta Yache?") e não lendo uma linha de preço.

**Nada de lista escrita à mão.** `FIND_ITEMS` continua sendo o saco ponderado de sempre (repetição = peso), e as
duas listas novas em `dados.js` são **derivadas** — fruta ou segurado novo na tabela já cai nelas sozinho:
- `FRUTAS_ACHADAS` = tudo que termina em `-berry` em `ITENS_SEGURADOS` + `ITENS_FRUTA_TIPO` (20 itens).
- `SEGURADOS_ACHADOS` = o resto de `ITENS_SEGURADOS` (25 itens permanentes).

A varredura é nessas duas tabelas e **não em `ITEMS`**, de propósito: `ITENS_RAIDE_SEGURADOS` também é
`segurado`, e achar um Núcleo Eternamax no chão tiraria o motivo de enfrentar o chefe da semana. É o que
`tests/segurados.test.js` trava, junto com "as duas listas cobrem a tabela inteira, sem sobra" e "todo item
achável tem efeito em `SEGURADOS`".

**Dois degraus, pelo preço.** Fruta é barata (₽300–1200) e de uso único, então sai em QUALQUER rota — é o mesmo
raciocínio que já tinha posto a `oran-berry` no `FIND_ITEMS`. Segurado permanente é caro e pra sempre, então
entra no degrau que já existia pros itens de evolução: **da 4ª rota em diante**. Um teste guarda a fronteira
(nenhum permanente pode custar menos que a fruta mais cara) — senão o degrau deixa de significar alguma coisa.

**A ORDEM dos ramos do sorteio é comportamento, não estética.** Cada `Math.random()` do encadeado sorteia sobre o
que o anterior deixou passar, então a primeira versão — com a fruta antes do item de evolução — **derrubou a
chance do item de evolução de 19,4% pra 15,8%** sem ninguém pedir. Só apareceu porque eu simulei a distribuição
antes de fechar; o comentário que eu tinha escrito afirmava o contrário ("a chance do item de evolução ficou
intacta") e estava errado. Corrigido pondo o degrau já calibrado primeiro: escama (3%) → evolução → segurado →
fruta → comum. Hoje é ~17% de fruta nas rotas rasas e ~11% nas fundas, com evolução e escama exatamente onde
estavam.

**Também corrigido de passagem**: a mensagem do achado dizia "(item de evolução)" testando `evo || segurar`, e
`segurado` não tinha rótulo nenhum — um Orbe da Vida achado apareceria como item qualquer. Agora existe
"(dá pra segurar)", e o rótulo de evolução vem primeiro porque o item `duplo` (Pedra do Rei e cia.) tem as duas
flags.

**Ficou de fora**: os consumíveis CAROS que a loja vende e ninguém acha (Full Restore, Max Potion, Revive, Max
Ether). Não fazem parte da leva que o pedido cita, e o degrau pra eles seria por PREÇO — uma terceira regra no
mesmo encadeado, que já tem cinco ramos. Entra se for pedido.

### ⚡ Itens rápidos, com hotkey (30/09/2026)
O relato **#68** pediu *"um botão para subir ou descer os itens"* na mochila, igual ao que existe pros golpes. O
usuário trocou o pedido na hora: **"no lugar de botões de subir/descer, quero configurar uma Hotkey para itens
rápidos, onde você pode escolher no máximo 2 itens que vão ficar perto dos botões principais da tela"**. A troca
é melhor pelo motivo que o pedido original já dizia sem dizer: o incômodo não era a ORDEM da lista, era **abrir a
mochila e caçar a Poção a cada turno**. Reordenar encurta a caçada; um atalho fixo elimina.

**Como é**: na mochila (explorando), cada item ganha um botão **⚡**. Marcado, ele aparece como cartão na barra de
ações — junto de *Explorar/Centro/Loja* fora da luta e de *Mochila/Fugir* dentro dela — e responde às teclas
**1** e **2**. São no máximo 2 (`regras.MAX_RAPIDOS`), e a marca vive em **`S.rapidos`**, na jornada: os itens são
da run.

**Decisões**:
- **`regras.alternarRapido` é a regra, e é pura** (testada em `tests/regras.test.js`): marcar de novo desmarca, e
  lista cheia devolve **`null`** em vez de trocar o item mais antigo. Trocar sozinho seria "o jogo mexeu na minha
  escolha"; `itens.marcarRapido` mostra um toast pedindo pra tirar um antes.
- **A tecla clica no BOTÃO** (`$('[data-rapido="1"]').click()`), não chama a ação. Assim tecla e dedo passam pelo
  mesmo caminho — inclusive o `disabled` de quando o jogo está ocupado, que de outro jeito eu teria de repetir no
  handler de teclado. Não vale com modal aberto nem com foco num campo de texto (ali o "1" é do campo).
- **Item que não serve no momento continua na barra**, habilitado. `useItem` já responde "esse item só funciona
  durante uma batalha" / "não dá pra evoluir no meio de uma batalha", e o `turn()` não gasta o turno quando o item
  falha (`if (!(await useItem(...))) return`). Filtrar por contexto exigiria repetir em `render.js` a lista de
  flags que o `useItem` já conhece — duas fontes da mesma verdade, pra ganhar um botão cinza.
- **Item que acabou sai da barra e a marca fica.** `rapidosAtivos()` filtra por `bag[k] > 0`: comprou outra Poção,
  o atalho volta sozinho. Desmarcar por ter acabado o estoque faria o jogador reconfigurar a cada compra.
- **Só 2, e não N configuráveis**: é o que o pedido diz, e é o que caber em duas teclas garante. Subir o teto é
  mexer em `MAX_RAPIDOS` e em mais nada.

---

## Anúncios (AdSense) e privacidade

### A raiz do site deixou de ser o jogo (11/10/2026)
O AdSense reprovou o site por **"Conteúdo de baixo valor"**. Medida a causa: a raiz do domínio — a URL cadastrada
na conta — entregava **5 palavras** de HTML, porque era o jogo (`<div id="app">` montada em JS). As onze páginas
estáticas feitas em 29/09 existiam, mas nenhuma era alcançável a partir do HTML da home (o rodapé que as linka é
injetado por `main.js`, não escrito no arquivo).

O jogo passou a morar em **`jogar.html`** e `index.html` virou **a apresentação**: ~890 palavras escritas pra quem
nunca viu o jogo, com links pros capítulos do guia. Ela é gerada pelo mesmo `ferramentas/gerar-paginas.mjs` das
outras — a fôrma ganhou três parâmetros (`arquivo`, `canonical`, `semSufixo`) em vez de um segundo gerador.

Três decisões que valem lembrar ao mexer nisso:
- **O convite de sala não mudou de formato.** `multiplayer.js` monta `URL_SITE/?sala=XXXX` e isso cai na raiz,
  que agora é a apresentação. Em vez de mudar o link (e quebrar todo convite já mandado em conversa), a home
  desvia: um `location.replace` na primeira linha do `<head>`, antes do CSS e do AdSense.
- **`HOME` não entra em `PAGINAS`** — ela não é item de rodapé e o arquivo dela não segue `<slug>.html`. Quem
  varre "as páginas" usa `[HOME, ...PAGINAS]`, inclusive o teste.
- **O que o service worker serve mudou de dono**: o fallback de navegação offline e o clique na notificação de
  lembrete apontavam pra `./`, que era o jogo e virou texto. Os dois agora vão pra `./jogar.html`.

`tests/paginas.test.js` guarda um **piso de 400 palavras** na home e a existência do desvio. Post-mortem completo,
com a tabela do que foi medido em cada página, no topo de `docs/adsense.md`.

### Anúncios (Google AdSense) e Política de Privacidade (27/09/2026)
Pedido do usuário: monetizar o site com ads. **Decidido não perseguir a Play Store** (avaliei a complexidade —
TWA/Bubblewrap é barato tecnicamente, mas conta pessoal exige teste fechado com 12 testadores por 14 dias
corridos antes de publicar, e o risco de marca do Pokémon fica bem mais visível virando app publicado — o
usuário optou por focar só no site). `js/ads.js` é a estrutura pronta, **desligada por padrão**: mesmo gate do
Supabase (`config.ADSENSE_CLIENT_ID`, marcador = nada roda). Quando a conta existir: preencher o client id +
`AD_SLOT_INICIO` (`criacao.js`) com o id da unidade de anúncio.
**O jogo NUNCA carrega o script do Google antes do consentimento** (exigência da política de consentimento da UE
— GDPR): `ads.iniciarAds()` (chamado no boot, `main.js`) só mostra um banner fixo (`.cookie-banner`, não é modal,
não trava o jogo) se `adsConfigurado()` e ainda não houver escolha salva (`pokerpg-consentimento-ads`); só
`aceitar` chama `carregarScript()`. Escolha mudável depois em `⚙ Ajustes` (`htmlAds()`, só aparece com conta
configurada). `blocoAds(unitId)`/`ativarSlots()` desenham e ativam um slot — sempre vazio sem config ou sem
consentimento, nunca um `<ins>` "morto" esperando.
**Tela 🔒 Privacidade** (`js/tela-privacidade.js`, nova entrada em `navegacao.TELAS`) é pré-requisito de
aprovação do AdSense — texto explica o que cada serviço (localStorage, Supabase, PokéAPI, AdSense) coleta, sem
juridiquês. Escrita ANTES de qualquer anúncio existir de verdade, porque é isso que a revisão do Google confere.
`ads.js`/`tela-privacidade.js` entraram no PRECACHE do `sw.js` (regra de sempre: arquivo novo em `js/` = entra lá).


---

## Desenho original da Mega (antes de implementar)

### 4b. Mega Evolução (desenho original)
1.000 golpes finais **sendo a espécie que megaevolui de fato** (Charizard, não Charmander). **Uma missão por Mega**: com X e Y, a tela de Conquistas tem um botão "contar para a X", trocável a qualquer momento, e o que foi acumulado numa não migra pra outra. Desbloqueada, a Pedra **ocupa a vaga de item segurado**. 1× por batalha. As ~30 habilidades que as Megas concedem entram JUNTO, senão metade das Megas nasce inerte.



---

# Detalhe que saiu do CLAUDE.md na faxina de 29/09/2026

O CLAUDE.md foi de ~50k pra ~6k tokens. As ARMADILHAS viraram uma linha cada lá; o detalhe de cada arquivo e de
cada mecânica está preservado aqui, palavra por palavra, como estava antes. Consulte ao mexer na área.

## Tabela de arquivos, completa (versão anterior)

## Estrutura

| Arquivo | Papel |
|---|---|
| `index.html` | Esqueleto: header (`#topr` + `#conta-chip`), `#app`, aviso de `file://`, carrega `js/main.js`, registra `sw.js`. |
| `sw.js` | Service worker do modo offline (ver "Modo offline"). |
| `README.md` | Página do projeto (o que tem + próximos passos). **Atualizar a cada funcionalidade nova.** |
| `css/estilo.css` | Todo o CSS. |
| `img/` | `logo.png` (topo), `favicon-32.png`, `icone-192.png` (favicon / atalho no celular). |
| `js/main.js` | Ponto de entrada: listeners delegados (`data-act`/`data-v`) e `boot()` (carrega save ou abre criação). |
| `js/estado.js` | `G` = estado mutável compartilhado (`S` save, `B` batalha, `PV` prévia, `mode`, `busy`, `panel`), `zone()`, `nm()`, `save()`. |
| `js/util.js` | `rand`/`pick`/`clamp`/`sleep`/`fmt`/`esc`/`lastSeg`/`store`. Sem DOM. |
| `js/dados.js` | Tabelas fixas: tipos (`CHART`, `TYPE_PT`, `TC`), `NATURES`, `ITEMS`, `ZONES` (= rotas de `dados-mapas.js`), `FLAVOR`, `MISSOES`, `DIFICULDADES`… Sem DOM. `ITEM_SPR(n)` monta a URL do sprite do item; vários itens de Gen 8/9 (Coroa Galárica, Armadura Auspiciosa, Pote Rachado…) **não existem** no repositório de sprites da PokéAPI, então toda `<img>` de item usa `onerror="${ITEM_ERRO}"` e cai no `ITEM_SPR_RESERVA` (SVG embutido de caixinha). Antes a figura quebrada era só escondida e ficava um buraco — parecia bug de tela. |
| **Rede instável** | `api.getJSON` tenta 3× com pausa (400ms, 800ms) em falha de REDE e em 429; 404/500 não repetem. `apiErr(e)` escreve pro JOGADOR: `file://` → instrução de servidor; `navigator.onLine === false` → sem internet; 429 → "pediu calma"; com `code` → erro do servidor; sem `code` → conexão instável. Todas as mensagens de falta de dado apontam pra **⚙ Ajustes → Jogar offline** (offline.js). Relato real que motivou isso: celular em 5G oscilando mostrava "Failed to fetch" e a antiga mensagem falava de abrir o jogo dentro de um chat. |
| `js/tutorial.js` / `js/tela-tutorial.js` | **❓ Tutorial** (tour guiado + demonstração, ver "Próximos passos combinados" pra decisão completa). `tutorial.js` puro (`tests/tutorial.test.js`): passos (`TUT_PASSOS`), dados de mentirinha (Pichu/Caterpie/Treinador Theo) e a lógica de golpe/compra/captura — `resultadoCaptura`/o resumo de Runs leem `dados.DIFICULDADES` direto, nunca duplicam o texto. `tela-tutorial.js` desenha em `G.tut` (nunca `G.S`); `telaTutorial()` chama `nuvem.salvarTutorialVisto()` (idempotente) assim que abre. Aberto sozinho no `boot()` de main.js só na primeiríssima visita (sem save); sempre disponível de novo em `navegacao.TELAS` (`❓ Tutorial`). |
| `js/tela-taxas.js` | **📈 Taxas e probabilidades** (ver a seção própria no fim deste arquivo). Tela de referência com 21 seções do que o jogo sorteia. **Nenhum número é escrito no arquivo**: importa a constante que o sorteio usa (`regras`, `mundo`, `ovos`, `mapas`, `mega`, `zmove`, `evolucao`, `esconderijo`, `dados`) e, quando dá, chama a própria função (`chanceDeGrupo`, `chanceItemDoTreinador`, `chancePorBalanco`, `valorCaptura`, `passosParaChocar`). Pesos (`EQUIPE_TREINADOR`, `ITENS_DE_SELVAGEM`) viram porcentagem na hora. Filtra `DIFICULDADES` por `!d.admin`. Reusa `table.ranking`; CSS próprio só do índice (`.taxas-indice`) e da seção. |
| `js/navegacao.js` / `js/ajustes.js` / `js/tela-ajustes.js` | **Navegação e ajustes.** `TELAS` é a ÚNICA lista de telas: `barraTelas(atual)` usa nas telas e `render()` usa no `#topr` (o menu ☰ do celular) — tela nova entra lá e aparece nos dois. `barraTelas(atual)` monta a MESMA barra no topo de toda tela fora do jogo (criação, carreira, saves, ranking, mp, conta, ajustes, relatos): `← Voltar` (`rotuloVoltar()`: pro jogo se há `G.S`, senão pro início) + atalhos pras outras (`TELAS`). Tela nova = incluir `barraTelas('id')` e pôr a entrada em `TELAS`. `Esc` clica no botão de voltar (main.js keydown, fora de explore/battle/create e sem modal aberto). `🏠 Início` com jornada aberta não perde nada: `iniciarJornada` guarda a atual (saves.js) antes de trocar. Fonte: `ajustes.js` (`FONTES`, `aplicarFonte` troca as variáveis CSS `--display`/`--body` e injeta o link do Google Fonts; escolha em `pokerpg-fonte`), aplicada no boot de main.js; tela em `tela-ajustes.js` com cada opção escrita na própria fonte. `tests/ajustes.test.js`. |
| `js/offline.js` | **Baixar um mapa pra jogar offline.** `alvosDaGen(gen)` = todo id do mapa (pool + Alfas + lendários; puro, `tests/offline.test.js`), `quantoFalta`/`jaBaixado` usam `api.pokemonEmCache`, `baixarGen(gen, aoAndar, sinal)` busca em lotes de 6: `loadPokemon` (cai no localStorage), os golpes do learnset até o nível 60 (`loadMove`, deduplicados num Set) e os sprites — pra sprite basta um `fetch(..., {mode:'no-cors'})`, que o service worker guarda no cache EXTERNOS. UI em `tela-ajustes.js` (`htmlOffline`/`baixarMapaOffline`, clique `baixar-gen`). `baixarTudo`/`quantoFaltaTudo`/`totalDoJogo` fazem o mesmo pros 9 mapas de uma vez (botão "⬇⬇ Baixar o jogo inteiro"), o que só passou a ser possível com o cache no IndexedDB (ver `js/api.js`): no localStorage isso estourava a cota e falhava calado. |
| **Clima** | `regras.CLIMAS` (sol/chuva/areia/granizo/neve) + `CLIMA_TURNOS` (5). Estado no **campo da batalha**, compartilhado pelos dois lados: single player `G.B.campo` (exposto como `CTX.campo`, getter em efeitos.js), multiplayer `estado.campo` (mp-motor). `climaDe(campo)` só devolve o clima com `turnos > 0`. Entra em: `calcDamage(u,t,move,clima)` (`multClima`), `effStat(m,stat,crit,atacando,clima)` (`multStatClima`: habilidade + `CLIMAS.defesaDe` por tipo), `chanceAcerto(move,u,t,clima)` (`PRECISAO_CLIMA` + `escondeNoClima`), `golpe.fimDeTurno` (dano de areia/granizo por `danoClima`, `curaClima`, `danoClimaProprio`, `curaStatusClima`) e `aplicarStatus` (`semStatusClima` = Leaf Guard). `mudarClima(clima, ctx, quem)` liga (golpe com `especiais.clima` ou habilidade `climaAoEntrar` em `intimidar`/1º turno do MP) e `passarClima(campo, ctx)` gasta um turno no fim da rodada (batalha.js e mp-motor). **Ao mexer em velocidade, lembrar do clima**: a ordem do turno usa `effStat(..., clima)` nos dois motores. `tests/clima.test.js`. |
| **Lado do campo** | `campo.lados = { jogador, inimigo }` (MP: `A`/`B`), criado sob demanda por `golpe.ladoDoCampo(ctx, m)` — o `ctx` diz o lado com `ctx.ladoDe(m)` (efeitos.CTX no single player; `ladoDe(s, m.ref)` no mp-motor). Forma em `regras.LADO_VAZIO()`: telas `reflect`/`luz`/`veu`, `salvaguarda`, `neblina`, `vento` (turnos) e armadilhas `pedras`/`espinhos`/`toxinas`. Lidos por `multTelas` (em `calcDamage`, 6º parâmetro = lado de QUEM DEFENDE), `temSalvaguarda` (em `aplicarStatus`, que agora recebe `fonte` — status próprio, tipo Rest, passa), `temNeblina` (em `mudarEstagios`), `multVento` (na ordem do turno dos dois motores) e `aplicarArmadilhas` (chamada em `win()` quando o treinador/lendário manda o próximo; se ele cai só com a armadilha, `win()` se chama de novo). `passarLados` no fim da rodada. Golpes em `especiais.js` (`lado`, `soNoGelo`, `armadilha`). **Do lado do jogador ninguém troca de Pokémon**, então armadilha ali é inerte — o golpe avisa isso em vez de fingir (`ctx.trocaDePokemon`). Cuidado com o nome: `espetos` é o Elmo Rochoso (item), `espinhos` é o Spikes (campo). `tests/lado-campo.test.js`. |
| **Terrenos** | `regras.TERRENOS` (eletrico/grama/psiquico/fada) + `TERRENO_TURNOS` (5), no MESMO objeto `campo` do clima (`campo.terreno`/`campo.terrenoTurnos`). **Regra de ouro: só afeta quem está no chão** — `noChao(m)` (não é Voador e não tem Levitate) é checado em `multTerreno`, `terrenoBloqueiaStatus`, `multStatTerreno`, na cura do Campo de Grama e no bloqueio de prioridade do Campo Psíquico. Entra em `calcDamage(u,t,move,clima,terreno)`, `effStat(..., clima, terreno)`, `aplicarStatus` e `golpe.fimDeTurno`. `mudarTerreno`/`passarTerreno` espelham os do clima (golpes com `especiais.terreno`, habilidades `terrenoAoEntrar`). `tests/terrenos.test.js`. |
| **Celular (batalha)** | `render()` liga `body.em-batalha`; o resto é CSS no bloco "celular" (`@media(max-width:880px)`): só a `.scene.battle` é `position:sticky;top:0` (teto de 38vh, com rolagem própria), sprites e golpes compactos, e TODO o resto da página (ações, registro, painéis) rola normalmente por baixo. Fora da batalha, só `#actions` é sticky. **Já existiram abas** ⚔ Luta / 💬 Registro / 📋 Painéis (`abaMobile`, `ABAS_MOB`, classes `body.mob-*`) que escolhiam o que ocupava o meio da tela: **removidas a pedido de quem joga** — cada aba escondia dois terços da tela (ver a ficha de um aliado exigia perder a batalha de vista), e a barra ainda comia uma faixa justo no aparelho mais apertado. Antes disso elas já tinham dado outro bug: o conteúdo nascia abaixo da dobra e os botões pareciam mortos. **Não reintroduzir "esconder painel por aba"**: o problema que elas resolviam ("não vejo o Pokémon enquanto escolho o golpe") está resolvido pela cena presa no topo, sem esconder nada.

**Celular DEITADO (28/09/2026)**: o bloco "celular" acima foi pensado pra RETRATO — cena presa no TOPO, resto rola embaixo — e em paisagem (tela larga e baixa) isso sobraria pouquíssima altura pro resto. Gatilho por `@media(orientation:landscape) and (max-height:500px)` (altura, não largura: um celular deitado pode passar de 880px de largura e continuar precisando do mesmo tratamento; telas realmente altas — tablet/desktop landscape — ficam de fora). Na batalha, a cena vira uma COLUNA fixa à ESQUERDA (`grid-template-columns:minmax(180px,36%) 1fr`, sticky, altura quase inteira da tela) e tudo mais (golpes, painéis, log) numa coluna à direita que rola. **`.stage{display:contents}`** é o truque que torna isso possível: `#scene` mora DENTRO de `.stage`, que é IRMÃO das zonas esq/dir (não pai) — sem "abrir" o `.stage` pro grid do `.game`, `#scene` não teria como virar uma coluna própria (mesma técnica já usada em `.menu-links` no topo do celular). `order:-2`/`order:-1` em `#actions`/`.zona[centro]` colocam os botões de golpe ANTES dos painéis da esquerda/direita na coluna 2 (senão a ordem do DOM enterraria os golpes embaixo da ficha/mochila). Fora da batalha, o mesmo gatilho de altura também entra na condição do bloco "celular" normal (`@media(max-width:880px),(orientation:landscape) and (max-height:560px)`) — sem isso, as 3 colunas do desktop (mais de 1100px de largura mínima) ficavam cortadas num celular deitado mais largo que 880px.<br><br>**Conserto (02/10/2026 — "tenho que descer pra ver a batalha")**: a cena NÃO é mais coluna do grid, é **`position:fixed`** à esquerda, com o `.game` em **uma coluna só** e `padding-left:calc(var(--cena) + 16px)` reservando o espaço. Motivo: como irmã das zonas, `#scene` entrava na **auto-colocação** do grid DEPOIS dos itens da coluna 2 (`#actions` com `order:-2`, `.zona[centro]` com `order:-1`, zona esq), e o cursor de posicionamento do grid **nunca anda pra trás** (CSS Grid §8.5: coluna definida menor que a do cursor ⇒ pula pra linha seguinte) — a cena caía na **4ª linha**, abaixo de tudo, e `position:sticky` não salva porque sticky só anda DENTRO da própria área de grid. Fixa, ela não participa do dimensionamento de linha nem do fluxo: está sempre na lateral, com ou sem rolagem. Ajustes que vieram no mesmo pedido: golpes mais baixos e **sempre 2×2** (`.moves{grid-template-columns:1fr 1fr}` explícito aqui — o `@media(max-width:420px)` que faz 1 coluna não pega em paisagem, mas o `.mv` alto empurrava o resto pra fora da tela), gatilho de altura de 500 → **560px** (celular de 540px de altura deitado ficava fora dos dois blocos) e `.brand{visibility:hidden}` na luta (a logo era a única coisa que ficava ATRÁS do cartão fixo). |
| **Batalha no save** | Recarregar a página apagava `G.B` — dava pra fugir de treinador/Alfa/lendário e de uma derrota no Roguelike com F5. `estado.save()` grava `S.batalha = ganchosSave.serializarBatalha(G.B)` (batalha.js; `caidos` é Set e volta vazio) e `main.abrirJornada` restaura com `restaurarBatalha` — reapontando `B.enemy` pra `trainer.equipe[atual]`, senão viram dois objetos e o dano vai só pra um. |
| **Segredo do brilho** | `regras.bonusShiny(S)`/`multShiny(S)`: jogador shiny (1/4096, sorteado no `makeMon` da criação como pra qualquer Pokémon) ganha **XP e dinheiro em dobro** (`win()` em batalha.js: xp, dinheiro, prêmio de treinador e de Alfa) e **Centro Pokémon de graça** (`estado.centroPokemon`). **É segredo**: não entra no README nem nos patch notes — quem tirar um shiny descobre jogando. |
| **🎯 Caça Shiny** | Modo ligado só na criação (`G.cacaShiny` → `S.cacaShiny`; `S.caca = { rota: speciesName }`). `mapas.js`: `rotaLiberaCaca(z, saber)` exige TODA espécie não-mítica/não-lendária da rota revelada (`REVELA_DERROTADOS`), `progressoCaca` mostra o quanto falta, `cacaDaRota(S, z)` diz quem está sendo caçado; `batalha.sortearOponente` força essa espécie (respeitando o cache no offline). UI em `render.blocoCaca`, clique `data-act="caca"`. `tests/caca-shiny.test.js`. **✅ CORRIGIDO (28/09/2026) — bug real relatado pelo usuário: "a rota nunca libera a opção de escolher quem caçar".** Reproduzido o mecanismo inteiro com jsdom (rota revelada, caça ligada, forçando o ramo de encontro selvagem): o motor de "travar a espécie" (`especieForcada`/`sortearOponente`) sempre funcionou certo. O bug real estava em `cacaveisDaRota`: excluía `mitico` da exigência de revelar ("derrotar 10 Mew não é razoável"), mas **não excluía `lendario`** — mesma razão, mesmo esquecimento. Só importa na prática pro **Santuário** (11ª rota, `posVitoria`): é a ÚNICA rota cujo `pool` mistura lendários (rotas 1–10 guardam os lendários em `z.lendarios`, fora do sorteio selvagem) — exigir 10 derrotas de um Mewtwo com peso ~0,2% no pool nunca fecha de verdade, então a caça no Santuário travava pra sempre num "quase lá". Corrigido: `cacaveisDaRota` agora filtra `!p.mitico && !p.lendario`; `render.blocoCaca` (a lista de espécies OFERECIDAS pra escolher, linha separada que tinha o mesmo filtro incompleto) ganhou a mesma exclusão, pra não oferecer um alvo praticamente impossível de manter em cena. `tests/caca-shiny.test.js` ("lendário no pool... também fica de fora"). |
| **Repelentes** | `ITENS_REPELENTE` (dados.js: `repel` seletivo 30 passos, `max-repel` total 40) → `S.repelente = { tipo, passos, especie? }`, usados por `itens.usarRepelente`. Em mapas.js: `repelenteAtivo`, `semSelvagens(S, z)`, `especieForcada(S, z)` (repelente na frente da Caça Shiny) e `gastarRepelente(S)` (um passo por exploração). `mundo.explore` troca SÓ o ramo do encontro selvagem por ambientação — o sorteio de treinador/item/dinheiro é o mesmo de sempre (pedido explícito do usuário, vale também pra Caça Shiny). |
| `js/segurados.js` | **Itens segurados** (puro, `tests/segurados.test.js`). `M.item` = id em ITEMS; `SEGURADOS` = tabela de ganchos (mesma ideia de habilidades.js): `multDano` (+`soFisico`/`soEspecial`/`soSuperEfetivo`), `multStat`, `semStatus`, `recuoPorGolpe`, `drenaDano`, `espinhos`, `aguentaCheio`, `curaFimTurno`(+`soTipo`/`danoFimTurno`), `curaEm`, `curaStatus`, `gastaNoUso`, `statusFimTurno` (Orbe de Fogo/Tóxico, ver abaixo). Lidos em `regras.effStat`/`calcDamage` (`multDanoDoItem`) e em `golpe.js` (durante o golpe: Faixa de Foco, Sino-Concha, Orbe da Vida, Elmo Rochoso, `comerFruta` depois do dano; no fim do turno: `fimDeTurnoDoItem` + `statusDoItem` + `comerFruta`). Equipar/tirar em `itens.js` (`equiparItem`/`tirarItem`), botão na ficha (`blocoItem` em render.js, `data-act="tirar-item"` com `'p'` ou índice do aliado). Item de dados em `dados.ITENS_SEGURADOS` (`segurado: true`). **MP copia `item` desde 28/09/2026** (`mp-motor.fotoDoMon`) — ver "Itens no multiplayer" abaixo. **✅ FEITO (28/09/2026) — Orbe de Fogo / Orbe Tóxico** (pedido do usuário: "Flame Orb e outros itens desse estilo"): se auto-infligem queimadura/veneno GRAVE a cada fim de turno sem status nenhum — `segurados.statusDoItem(m)` devolve o status de verdade (`'toxic'` vira `'poison'` pra `aplicarStatus`; golpe.js soma `vol.toxico = 1` na mesma chamada que já faz isso pro golpe Toxic), chamado logo depois do bloco de Restos/Lodo Negro em `golpe.fimDeTurno`. Reaproveita `aplicarStatus` de propósito (não uma versão simplificada): cobre imunidade de tipo (Fogo não queima, Venenoso/Aço não envenena) e Safeguard/terreno de graça, sem duplicar nenhuma regra. **Dupla canônica dos jogos**: sinergiza com Guts/Flare Boost/Toxic Boost/Quick Feet/Marvel Scale, todas já implementadas — "punição" que vira vantagem pra quem monta em cima disso. Outros itens "desse estilo" (Quick Claw, itens Choice, Iron Ball, Eviolite…) ficaram de fora desta leva — cada um pede mecânica nova (RNG na ordem do turno, travar escolha de golpe, saber se a espécie ainda evolui…), não só um gancho a mais na tabela.

**✅ FEITO (28/09/2026) — os 4 itens que ficaram de fora da leva anterior**, cada um com a mecânica nova que pedia:
- **Garra Rápida** (`quickClaw`): 20% de chance por turno de agir primeiro DENTRO da própria prioridade (não fura quem tem prioridade maior). `regras.ativouQuickClaw(m, sorte)` (`CHANCE_QUICK_CLAW = 0.2`) é sorteada UMA vez por Pokémon ao montar a lista de ações (`batalha.js` e `mp-motor.js`, no mesmo `.push`/`.map` que já monta `{prio, vel}`) e vira um campo `rapido` a mais na ação; `regras.ordenarAcoes` ganhou um critério de desempate NOVO entre prioridade e velocidade — `rapido` primeiro, e se os dois lados tiverem a Garra (os dois ativaram), a velocidade ainda decide entre eles. `tests/regras.test.js`.
- **Faixa/Óculos/Lenço Escolha** (`choice`, + `multStat` que já existia pro bônus): trava no PRIMEIRO golpe de verdade usado. `golpe.usarGolpe` seta `u.vol.escolha = g.name` logo depois de "X usou Y!" (Struggle nunca trava — é golpe de emergência) — o NOME é do golpe BASE, capturado ANTES de `executar()` transformar Weather Ball/Tera Blast/Water Shuriken por tipo, então a trava sempre compara contra o nome estável. **A trava é só de UI, não do motor**: os três lugares que desenham os botões de golpe (`render.js`, `arena.js`, `multiplayer.js`) desabilitam todo golpe que não é o travado (e mostram "🔒 Travado em X"), com um cuidado extra — se o golpe travado ficar sem PP, Struggle aparece igual (senão a trava deixaria sem NENHUM botão clicável); o motor em si confia na UI e nunca re-valida o `g` recebido, o MESMO padrão de confiança que já valia pro PP (golpe com 0 PP também só é travado do lado de fora). **Aliados** (`golpeDoAliado`, regras.js): ganhou um 6º parâmetro `travado` — se o aliado já está travado, a IA de `ordem` nem escolhe (senão a trava se desfaria sozinha, turno a turno); `parado`/`fora` continuam valendo mais que a trava. **Destrava ao reviver**: `mp-motor.reviverCompanheiro`/`reviverNoEvento` já davam `m.vol = freshVol()` (destrava de graça); o Revive do single player (`itens.js`) NÃO reseta `vol` nenhum historicamente — só apaguei `vol.escolha` especificamente ali, sem mexer no resto do `vol` (fora do escopo deste pedido). `tests/regras.test.js` (`golpeDoAliado` travado) e `tests/habilidades.test.js` (o motor via `usarGolpe`).
- **Bola de Ferro**: só Velocidade -50% (`multStat`). **Simplificação assumida**: nos jogos de verdade também torna o portador "no chão" (perde imunidade a golpe de Terra, mesmo voador ou com Levitate) — ficou de fora porque mexeria na imunidade de tipo do motor único (`typeEff`/`ht.imuneTipo` em `golpe.js`, usada em TODO golpe do jogo), risco maior que o ganho pro uso mais comum do item (Trick Room).
- **Eviolite** (`eviolite`): Defesa/Def. Especial ×1.5, só se a ESPÉCIE ainda evolui. Puro problema de dado: saber "ainda evolui" em batalha (`regras.effStat`, síncrona) sem buscar a árvore de evolução da PokéAPI no meio do turno (~550 requisições encadeadas só pra montar isso uma vez). Resolvido do MESMO jeito que as flags de golpe: `ferramentas/gerar-evolucao-restante.mjs` lê `pokemon_species.csv` do repositório-fonte da PokéAPI (`evolves_from_species_id`) numa passada só — uma espécie "ainda evolui" se ALGUMA OUTRA aponta pra ela nesse campo — e gera `js/dados-evolucao-restante.js` (`AINDA_EVOLUI`, 457 espécies). `segurados.multEviolite(m, stat)` é um gancho À PARTE de `multStat` (não dá pra usar o genérico: o multiplicador depende da espécie seguradora, não é fixo por item), chamado direto em `regras.effStat`. Não inclui formas regionais/variedades (o CSV é por espécie — a mesma chave que Pokédex/caça/registro já usam); uma forma regional herda a resposta da espécie base. `tests/regras.test.js`. |
| **XP depois do nível 100 → pontuação** (04/10/2026) | `regras.xpExcedente(exp, growth)` = `exp - growth[100]`, e `PESOS_PONTOS.xpExtra = 0.003`. **Derivado, nunca um contador novo no save**: `exp` jamais para de crescer (o que para no 100 é o laço de subir de nível em `progressao.gainExp`), então a conta é exata, vale retroativamente pra quem já estava no teto e não precisa migrar save nenhum. O peso saiu da curva: ~30 mil de XP separam o 99 do 100 na curva média, × 0,003 ≈ 89 pontos — quase os 100 de um nível, sem passar na frente de quem jogou a run inteira. **A pontuação é do servidor**: migration `20261004120000` repete o peso e recusa `xpExtra` com nível < 100 ou acima de 100 milhões (conferido em `bigint` ANTES do cálculo em `int`, senão um número absurdo viraria erro de banco em vez de recusa). `tests/schema.test.js` compara os dois lados sozinho — ele itera `PESOS_PONTOS`. A linha "XP além do nível 100" na tela de fim só aparece pra quem tem (`LINHAS` ganhou um filtro opcional). |
| `js/auto.js` / `js/notificacoes.js` / `js/acordado.js` | **🤖 Auto-explorar (só admin)** e as **notificações do navegador**. `auto.js` é um laço que só chama o que a UI já chama (`mundo.explore`, `batalha.turn`, `mundo.curarNoCentro`) — caminho paralelo seria um segundo jogo pra manter; o golpe sai de `batalha.melhorGolpe` (a mesma escolha do inimigo, no degrau `ESPERTEZA.chefe`), a parada sai de `regras.motivoDeParar` e a estatística de `regras.resumoDeAbates` (as duas puras, testadas). O estado da caçada mora em **`G.auto`** porque `render.js` desenha o painel e não pode importar `auto.js` (via única no grafo). O objetivo é um de QUATRO (pedido do usuário, 3ª leva): espécie, **nível do seu Pokémon** (`nivelAlvo`, conferido por `motivoDeParar` e só ENTRE batalhas — parar no meio da luta deixaria a batalha pendurada), **nenhum** (rodar até sair shiny) ou **shiny de uma espécie fixa** (`especieRepel`): mesmo laço de shiny, mas `itens.garantirRepelenteAuto` compra e mantém o Repelente Seletivo nela — a escolha já foi feita na tela, então ele PULA o `ask` e a exigência de "já encontrada" do uso manual (mesmo bypass que o resto do auto-explorar já faz ao oferecer o pool inteiro). Sem dinheiro pra repor o repelente, o laço para com `semDinheiro`, mesma régua do `semPP` — outro recurso finito que pode acabar no meio da caçada. A frase do objetivo sai de `regras.objetivoAuto`, não duplicada na tela. **Para ANTES de atacar o alvo** (quem caça quer decidir o que fazer com ele), foge abaixo de 25% do HP e passa no Centro abaixo de 45% de HP **ou quando `regras.precisaReporPP` acusa PP no fim** (nenhum golpe com mais de 1 PP, ou menos de 25% do PP total — o gatilho era "sobrou um golpe com PP" e era eager demais: três golpes zerados e um cheio ainda dão 20 turnos — repor ANTES do Struggle, que machuca quem usa, foi pedido explícito; vale pros aliados, já que o Centro cura a equipe toda, e se não der pra pagar o laço para com motivo `semPP`): um laço automático que perde a run de quem o ligou é defeito, não risco aceitável. **A mochila vem antes do caixa** (3º pedido do usuário, "gasta muito indo sempre no Centro"): a conta do Centro é `custoCentroEquipe`, que cobra `custoCentro(nível)` de CADA um que esteja com 1 HP ou 1 PP faltando (`precisaCurar`) — com dois aliados Nv. 40 a passada sai por ~₽1.950, e boa parte é topar quem estava em 98%. Então `curarComAMochila` percorre a equipe inteira (não só você: cada um que sai do `precisaCurar` sai da conta) e gasta o item escolhido por **`regras.itemEmVezDoCentro`** (puro, testado), que exige duas coisas do item: **resolver o buraco** (Poção que não fecha o HP que falta não entra — usar duas e ainda pagar o Centro é o pior dos dois mundos; pra PP e status basta servir) e **custar menos do que o Centro cobraria por aquele Pokémon** (`precoVenda` × `custoCentro`), senão queimar uma Hyper Potion pra economizar ₽125 no Nv. 5 é o mesmo desperdício ao contrário. Entre os que passam, o mais barato; item achado explorando vale 0 e ganha sempre. Quem GASTA é o `itens.useItem` da mochila, com o alvo já decidido pelo parâmetro `quem` (o laço não ganhou caminho próprio de usar item — seria um segundo jogo pra manter), e o Centro só é chamado se `precisaDescansar()` ainda responder sim DEPOIS da mochila. `notificacoes.js`: permissão só dentro de clique, `reg.showNotification` antes de `new Notification` (Android recusa o construtor) e **toast sempre**, porque sem permissão/sem suporte o aviso não pode sumir. `navigator.serviceWorker.ready` é consultado só com `controller` — sem service worker ele fica pendente pra sempre. `acordado.js` é o que deixa a caçada seguir com o jogo em SEGUNDO PLANO (pedido do usuário): o Chrome/Android aplica *intensive throttling* (1 timer por minuto) depois de 5 min em background e a isenção documentada é a aba estar tocando áudio — daí o tom de 30 Hz a ganho 0,003, inaudível mas não silencioso. O Wake Lock ali resolve outra coisa (tela não apagar com a página VISÍVEL) e é repedido a cada `visibilitychange`, porque o navegador o solta ao esconder. iPhone fica de fora: o Safari suspende a aba ao trocar de app, com ou sem áudio. Efeito colateral necessário em `ui.say`: com `document.hidden` ela não espera nada — 420 ms de pausa por linha viram 1 s em background e travariam o laço. |
| `js/dados-patchnotes.js` / `js/tela-patchnotes.js` / `js/novidades.js` | **Notas de atualização** (tela 📜 Novidades). `PATCH_NOTES` é escrito À MÃO, mais novo primeiro: `{ versao, data (AAAA-MM-DD), titulo, piada, secoes: [{ nome: 'Novidades'\|'Correções'\|'Equilíbrio', itens: [texto] }] }` — formato garantido por `tests/patchnotes.test.js` (versões únicas, ordem decrescente, itens com mais de 20 letras). Texto PRA JOGADOR: nada de nome de arquivo/função, e cada versão leva uma piada (a piada é o easter egg do rodapé da entrada — tom de 'nota de bugfix absurda', sempre com bicho da franquia dentro). A seção 'Segurança' também vale. **Toda leva de mudanças deve virar uma versão nova aqui.** COMPILADO 2x: 96 entradas → 71 (29/09/2026) → 43 etapas por tema (03/10/2026), renumeradas em sequência 0.1 … 4.3; o script de uso único não ficou no repo, a próxima fusão se faz do mesmo jeito. As respostas dos relatos no Supabase citam o número da etapa, então **recompilar obriga a reescrever as notas** (ferramentas/relatos-admin.mjs --resolver). `novidades.js` guarda só o "já li" (`pokerpg-patch-visto`) porque navegacao.js e a tela se importam. |
| `js/evolucao.js` | **Evoluções especiais** (puro, `tests/evolucao.test.js`). `detalheCumprido(d, M, ctx)`/`evolucoesPossiveis(node, M, ctx)` avaliam os detalhes da PokéAPI (`api.slimEvo`, cache `evo2:`, raiz com `v: 2`; árvore de save antigo é rebuscada em `arvoreDe`). Gatilhos: `level-up`, `use-item`, `trade` (Cabo de Conexão), `pos-batalha`. Condições cobertas: nível, item, item na mochila (`held_item` → `consome`), golpe/tipo de golpe, `min_happiness`/`min_affection` (vínculo `M.felicidade`, começa em 70, aliado 120, +5/+3/+2 por nível e +1 por vitória), hora real (`periodoDoDia`, dusk = 17h), espécie/tipo na equipe, Ataque×Defesa, **gênero** (`d.gender`, 1 = fêmea, 2 = macho, conferido contra `M.genero` — ver "Gênero (02/10/2026)"). **Não suportado** (e por isso ignorado): local, chuva, de cabeça pra baixo, beleza e `level-up` SEM condição nenhuma (na API é o campo magnético de Magnezone/Probopass/Vikavolt — evoluiria em qualquer nível; eles têm Pedra do Trovão). `EVO_ALTERNATIVAS` dá regra equivalente aos 19 casos que o jogo não tem (contadores `M.vol.criticos`, `M.vol.danoSofrido` em golpe.js; `M.recuoTotal`; `M.passos` em mundo.js; `registro.derrotados`; dinheiro). Fluxo: `progressao.checkEvolution(M, extra)` (nível e pós-batalha) e `evoluirComItem(id)` (item/Cabo, chamado por `itens.useItem`). Itens em `dados.ITENS_EVO` (fundidos em `ITEMS`): `evo` (usar), `troca` (Cabo), `segurar` (fica na mochila e é gasto ao evoluir). **Shedinja** (`casulo()` em progressao.js): ao escolher `ninjask`, se há vaga em `S.aliados` o Shedinja é criado e entra como aliado; equipe cheia = `ask` de qual dos dois o próprio Pokémon vira. |
| `js/saves.js` / `js/tela-saves.js` | **Jornadas salvas**: a atual continua em `SAVE_KEY`; as outras em andamento ficam em `pokerpg-saves-guardados-v1` (`{id: S}`, até `MAX_GUARDADAS` = 12). `excluir(id)` lembra o id em `pokerpg-saves-excluidos-v1` pra apagar da nuvem na próxima sincronização (offline) e não ressuscitar. Na nuvem, `saves` tem chave `(user_id, jornada_id)` — uma linha por jornada (o `schema.sql` migra a chave antiga). `nuvem.js sincronizarSaves` executa `reconciliarSaves` (puro, `tests/saves.test.js`): mesma jornada = vale a mais nova; terminada/excluída = apaga; desconhecida vinda da nuvem = `ganchos.oferecerSave` → 'continuar' (a atual vai pras guardadas) / 'guardar' / 'excluir'. **Nada é descartado sem o jogador escolher.** Com o schema antigo (erro 42P10 no upsert), cai pro modo uma-jornada-por-conta e só a atual sobe. Tela: `telaSaves()`; cliques `saves`/`save-guardar`/`save-continuar`/`save-excluir` em main.js (`guardarAtual`, `continuarGuardada`). "Novo jogo" oferece guardar ou encerrar. |
| `js/mapas.js` / `js/dados-mapas.js` | Mapas por Gen (ver "Mundo e progressão"). `dados-mapas.js` é gerado por `ferramentas/gerar-mapas.ps1`. **Iniciais fora das rotas**: `tirarIniciais(GENS)` roda UMA vez ao carregar o módulo e tira dos pools os 27 iniciais das 9 regiões e as evoluções deles (`ehInicialDeRegiao(id)`: cada trio ocupa ids seguidos a partir do primeiro, 1-9, 152-160, …). Pikachu e Eevee ficam — são a região marcada `nasRotas: true` em `REGIOES_INICIAIS` (dados.js). Alfa que era inicial vira o bicho mais raro do pool, no mesmo nível; rota que fica com menos de `MIN_POOL` (5) empresta das rotas vizinhas do mesmo mapa (`completarPool`, 2ª passada — na 1ª todas as rotas já foram limpas, senão uma vizinha suja emprestaria justo o inicial recém-tirado). O gerador aplica a MESMA regra (`EhInicial` em gerar-mapas.ps1), então dados regerados já nascem limpos. `especiesDaGen(gen)` = todas as espécies do mapa sem repetir, sem mítico e **sem o Santuário**, usada pelos treinadores. **Santuário (11ª rota de cada mapa, `posVitoria: true`)**: pool com TODA a Gen — espécies comuns, iniciais, lendários, míticos e as 53 formas regionais —, peso pela taxa de captura, gerado junto com o resto em `gerar-mapas.ps1`. É o que garante completude: qualquer espécie que ficasse de fora das 10 rotas cai ali. `regras.zonaLiberada(z, nivel, S)` ganhou o 3º parâmetro por causa dele: rota `posVitoria` ignora nível e exige `S.gensVencidas.includes(z.gen)`; **sem `S` fica trancada** (padrão seguro — todos os chamadores passam `G.S`). `tirarIniciais` e `especiesDaGen` PULAM rotas `posVitoria` — se um dia alguém varrer rotas pra filtrar conteúdo, tem de pular também, senão o Santuário deixa de cumprir o papel. **Formas regionais**: na PokéAPI são variedades de `pokemon` com id > 10000, não espécies; a entrada do pool é `{ id: 10100, n: 'raichu', f: 'raichu-alola' }` — `n` continua sendo a ESPÉCIE (chave do registro/Pokédex/caça, que o jogo inteiro já usa) e `f` só o nome mostrado (`pokedexDaRota` devolve `nome: f || n`). Formas de Tauros de Paldea ficaram de fora: o nome delas não termina em `-paldea`. **Roguelike + Santuário**: vencer os lendários grava `S.genVencida` NA HORA (não no fim da run) e pergunta se encerra em vitória ou segue no Santuário (`S.aposVitoria`, botão `encerrar-vitoria` nas ações). Quem segue e morre lá termina em derrota **sem perder a Gen**: `encerrarJornada` injeta `genVencida` do save e `gensLiberadasRoguelike` aceita `j.genVencida` mesmo com `motivo !== 'venceu'`. **Lendário selvagem no Santuário** aceita petisco (é o que torna o desbloqueio por amizade possível), mas `ganhoAmizade(..., lendario)` divide o ganho por `DIVISOR_AMIZADE_LENDARIO` (4, piso 1) — `batalha.startBattle` marca `E.lendario` pelo `l`/`m` da entrada do pool. |
| `js/regras.js` | **Fórmulas puras** (testadas): `calcStats`, `calcDamage`, `effStat`, `typeEff`, `chanceAcerto`, `consegueFugir`, `jogadorAgePrimeiro`, `danoResidual`, `imuneAoStatus`, `xpPorVitoria`, `ganhoDeEVs`… |
| `js/api.js` | PokéAPI com cache: memória (`memo`) + **IndexedDB** (`pokerpg-cache`/`dados`), com `localStorage` `pk:*` só de reserva (navegador sem IndexedDB) e migração automática do que já estava lá. `iniciarCache()` roda antes do boot (main.js), monta o índice `chavesGuardadas` (é o que `pokemonEmCache`/`idsEmCache`/`itensNoCache` leem, sem ir ao banco) e pede `navigator.storage.persist()`. `espacoUsado()` = `storage.estimate`, mostrado em ⚙ Ajustes. Saiu do localStorage porque os ~5 MB dele não cabiam o jogo inteiro e o `store.set` falhava calado. `buildLearnset`/`slimPokemon`/`slimMove` continuam puras (testadas). |
| `js/ui.js` | `$`, `REDUCED`, log (`log`/`say`/`logRaw`), modal `ask`, `shake`. |
| `js/render.js` | `render()` (re-render total: conteúdo dos painéis, cena e ações), `buildGame()`, `badge`, `spriteFrente`. |
| `js/layout.js` | Modelo puro do layout dos painéis (zonas, larguras, alturas, recolhidos). Testado. |
| `js/paineis.js` | Painéis na página: esqueleto, aplicar layout, arrastar, ▲▼⇄▾, divisórias, restaurar. |
| `js/pokemon.js` | `makeMon(data, level, opt)` — instância jogável (jogador e selvagem). |
| `js/efeitos.js` | `changeStats`, `inflict`, `healFull` — efeitos com narração, usados pela batalha e pelos itens. |
| `js/batalha.js` | `turn(action)` (único ponto de entrada da UI), `useMove`, `startBattle`/`startTrainerBattle`, bola do treinador, vitória/derrota/captura, `endBattle`. **Equipe de treinador não é só da rota**: `sortearDoTreinador(z)` tira `CHANCE_FORA_DA_ROTA` (50%) de cada membro de `mapas.especiesDaGen(z.gen)` — qualquer espécie do mapa, sempre no NÍVEL da rota — e o resto do pool da rota, que mantém a cara do lugar (o treinador andou até ali; a rota diz o nível, não quem ele criou). Vale pra todo treinador de rota. Offline, filtra pelo que está guardado. |
| `js/progressao.js` | `gainExp`, aprender golpe, evolução por nível. **O que a evolução entrega**: `regras.golpesDaEvolucao(antes, depois, nivel)` = golpes que a forma NOVA aprende **no nível 0** (é assim que a PokéAPI marca "aprende ao evoluir") e a antiga não aprendia. **Nível 1 não entra**: é a lista do que a espécie saberia se nascesse agora (o Exeggutor tem 17 golpes lá), e incluí-la reescrevia o moveset inteiro numa evolução só — bug relatado em jogo + o golpe do nível atual — antes só olhávamos o nível exato, e o golpe assinatura (King's Shield do Aegislash) se perdia pra sempre em qualquer evolução acima do nível 1. `habilidades.habilidadeDaEvolucao(velhas, novas, atual)` mantém o SLOT (oculta continua oculta; antes era índice cru na lista inteira, que misturava oculta com normal quando a forma nova tinha outro número de habilidades) e o registro avisa quando o nome muda. **Evolução pendente**: falha de rede em `arvoreDe`/`evolve` marca `M.evoPendente` (a ficha mostra ⏳) e `verificarEvolucoesPendentes()` tenta de novo ao explorar e depois de vencer — sem isso o nível subia e a evolução sumia sem ninguém ver. |
| `js/pokedex-conta.js` / `js/tela-pokedex.js` | **Pokédex da conta** (puro + tela; `tests/pokedex-conta.test.js`). `pokedexDaConta(jornadas, registroAtual)` junta `registro.vistos/derrotados/amigos/ids` de toda a carreira + a run atual e devolve `{ porId, porNome, conhecidas }`; o `estado` de cada espécie é amigo > derrotado > visto. Registro antigo sem `ids` conta no total por nome, mas não entra no mapa por id (não dá pra desenhar sprite sem id). `ondeAparece(id)` responde "onde eu acho esse?" varrendo os mapas gerados — rotas com a taxa de encontro, Santuário, Alfa e luta final — **sem rede**, então funciona offline. A tela mostra as 1025 espécies (`loading="lazy"` nas imagens: sem isso o navegador baixaria mil sprites de uma vez) e a ficha detalhada vem de `api.loadPokemon`/`loadAbility` no clique, com mensagem própria quando está offline e a espécie não foi baixada. **✨ Pokédex shiny (11/10/2026)**: pedido do usuário, feito como MODO da mesma tela (`soShiny`, variável de módulo — não vai pro save) e não como tela nova: seria a mesma grade, a mesma ficha e a mesma navegação duplicadas pra trocar o critério de "conhecido" e o endereço do sprite (`SPR_SHINY`). Acende por **`temShiny`**, que lê os DOIS campos — `shinies` (encontro, novo) e `shiniesAmigos` (recrutado, que já existia) —, porque carreira anterior à mudança só guardou o segundo: `shinies` não estava na lista branca de `regras.estatisticasDaJornada` e morria no fim da jornada. Entrou na lista branca junto com a tela, e a própria tela avisa o jogador desse buraco histórico em vez de deixá-lo achar que perdeu registro. |
| `js/progresso-conta.js` | **Progresso permanente da conta** (puro; `tests/progresso-conta.test.js`). Regra única: **nunca encolhe**. Antes, desbloqueios e contadores eram DERIVADOS das jornadas da carreira — apagar uma jornada apagava a conquista que ela liberou (risco apontado pelo próprio jogador). Agora há um registro próprio: `especies` (desbloqueada, com data e razão; a data nunca é sobrescrita) e `porJornada` (abates + espécie/nível/dificuldade, pela chave do ID da jornada). **`porJornada` em vez de um total único** porque é o que faz a fusão entre aparelhos e com a nuvem ser correta: mesma jornada = mesma chave, nada conta em dobro, e jornada que só um lado viu entra sem conflito. `bancar()` é idempotente pelo ID, então pode rodar a cada abertura de tela. Acesso em `carreira.js` (`atualizarProgresso`, `desbloqueadasDaConta`, `abatesDaConta`, `mesclarProgressoLocal`), sincronização em `nuvem.js` (tabela `progresso`, uma linha por conta, `try/catch` pra não quebrar quem não rodou a migração) e SQL em `supabase/migrations/`. **Local primeiro**: grava no aparelho na hora (funciona offline) e junta com a nuvem depois. A retroatividade continua: `especiesDesbloqueadas` é a UNIÃO do gravado com o que a regra de hoje reconhece no histórico, então regra nova (como "shiny recrutado desbloqueia") vale pro passado. |
| `js/conquistas.js` / `js/tela-conquistas.js` | **Conquistas da conta** (puro + tela; `tests/conquistas.test.js`). As gimmicks não se desbloqueiam dentro de uma run: somam a CARREIRA. `registrarAbate(S, {porMim, tiposDoAlvo, minhaEspecie, golpe, modo})` é chamado em `batalha.win()` e grava em `S.registro.abates`: `tipoAlvo` (Tera, 200 por tipo) · `especie` (Mega, 1000) · `golpe`/`elemento` (Z-Move, 250/500) · `total` (marcos 1k/10k/100k/1M). **Quem leva o crédito**: a ESPÉCIE conta sempre que a equipe vence (aliado incluído — decisão do usuário, que voltou atrás do "só o seu golpe"); TIPO e GOLPE só quando `porMim`. Sem golpe (veneno/armadilha/recuo) a espécie conta e o golpe não. O modo `easy` não acumula nada. Gigantamax (nível 50 em 25 jornadas) sai de `runsDeNivel` sobre o histórico — não precisou de contador novo. `progressoConquistas(jornadas, registroAtual)` junta carreira + run em andamento. **Contador só acumula depois de publicado**: por isso foi ao ar sozinho, antes de qualquer tela ou mecânica de gimmick. |
| `js/itens.js` | `addItem`, `useItem`. **Itens de golpe** (`dados.ITENS_GOLPE`, `it.ensina`): `ensinarGolpe(id)` pergunta em QUEM (você ou qualquer aliado vivo) e qual golpe, e chama `progressao.aprender(M, ref, true)` — o `true` força VOCÊ a escolher o que o aliado esquece, em vez da escolha automática do level-up (você pagou pelo item). **Aliado aprendendo sozinho** (`escolher = false`): `CHANCE_ALIADO_RECUSA` (50%) de simplesmente não querer o golpe; querendo, troca um golpe **sorteado**, não o de menor poder — pedido do usuário, pra o aliado ter jeito próprio em vez de moveset ótimo e previsível. O item só é gasto se `aprender` devolver `true` (desistir na hora de esquecer não gasta). O que cada um oferece sai de `regras.golpesParaEnsinar(tipo, M)` (puro, testado): `'relembrar'` = `learnset.list` até o nível atual (Escama do Coração, ₽5.000, também aparece em 3% dos itens achados explorando — `mundo.CHANCE_ESCAMA`); `'pokedex'` = `learnset.extras` (Disco Técnico, só loja). `null` = sem cache ou cache antigo sem `extras` → avisa pra conectar, NUNCA diz "não aprende nada". Preço do Disco por `regras.precoItem(id, S)`: `PRECO_DISCO + AUMENTO_DISCO * S.discosUsados` (8k +4k por Disco USADO, não comprado) — a loja (`render`) e o `case 'buy'` (main.js) leem os dois dessa função, nunca de `ITEMS[id].price` direto. |
| `js/amizade.js` | `oferecer` (petisco em batalha), recrutar aliado, `despedir`. |
| `js/fim.js` | `encerrarJornada(motivo)` (resumo → carreira → apaga save aqui e na nuvem), `montarResumo`, tela de fim, `telaCarreira`. |
| `js/roguelike.js` | Desbloqueios do Roguelike entre runs (puro, testado). |
| `js/carreira.js` | Carreira = lista de jornadas terminadas (`pokerpg-carreira-v1`; migra o `pokerpg-recordes-v1` antigo). `calcularCarreira`, `mesclarJornadas`, `melhorDaEspecie`. Puro + `store`, testado. |
| `js/config.js` | `SUPABASE_URL` / `SUPABASE_ANON_KEY` (marcadores = jogo só local). |
| `js/nuvem.js` | Supabase sob demanda: login (Google / link por e-mail), `sincronizar()` (carreira + save em andamento), envio do save com espera, `ganchos` que o main.js liga. `idJogador()` (id da conta, ou de visitante persistido) e `sb()` (o cliente) exportados pra `multiplayer.js` e `presenca.js` não duplicarem/abrirem uma 2ª conexão. |
| `js/presenca.js` | **Marcador "jogando agora"** (tela inicial): canal Realtime global (`pokerpg-presenca-global`, diferente do canal por SALA de `multiplayer.js`), `track({})` vazio — nunca identifica quem, só quanto. Junto, o contador HISTÓRICO admin-only de visitantes sem conta (`registrarVisitanteAnonimo`/`contagemAnonimos`, tabela `visitantes_anonimos`). Interruptor em ⚙ Ajustes (`presencaLigada`/`definirPresenca`), divulgado na tela 🔒 Privacidade — não é telemetria silenciosa. Sem Supabase configurado, tudo aqui é no-op. |
| `js/golpe.js` | **Motor único do golpe** (single player e multiplayer): usarGolpe, mudarEstagios, aplicarStatus, fimDeTurno, com `ctx` de narração. |
| `js/habilidades.js` | Tabela de habilidades (ganchos) + `hab(m)`, `IMPL`. **Só o que está nessa tabela tem efeito de verdade** (hoje 251 de 314 habilidades reais da PokéAPI — a contagem antiga de "307" vinha de uma auditoria velha; a certa é filtrar `abilities.csv` por `is_main_series`, e a contagem real de implementadas é sempre `IMPL.size`, testada em `tests/habilidades.test.js`. `docs/auditoria-batalha.md` ficou desatualizado depois da 2ª leva e não reflete nem o total nem o implementado — não usar como fonte). O resto joga normal, sem o efeito, e a ficha mostra "(sem efeito ainda)". **Mudança de Postura** (`postura`, Aegislash) é a primeira troca de FORMA: `golpe.trocarPostura(m, paraLamina, ctx)` espelha os atributos base (Ataque ↔ Defesa, At.Esp. ↔ Def.Esp.) — as duas formas do Aegislash são os mesmos números trocados de lado, então não precisa buscar a outra forma na rede no meio do turno. **Sempre copiar `m.data` antes** (`{ ...m.data, base }`): esse objeto vem do cache e é compartilhado por todo Aegislash que aparecer. Golpe de dano → Lâmina (antes de calcular o dano); King's Shield → Escudo (`especiais.voltaPostura`). `tests/postura.test.js`. |
| **Barreiras que punem contato** | `especiais.puneContato` (`{ estagio: [attr, n] }` / `{ dano: fração }` / `{ status }`): King's Shield tira 2 de Ataque, Obstruct 2 de Defesa, Spiky Shield machuca 1/8, Baneful Bunker envenena, Silk Trap tira Velocidade, Burning Bulwark queima. A barreira guarda o efeito em `u.vol.punicao` ao ser levantada; quem ataca leva a punição no ponto em que o golpe é bloqueado, **só se for golpe físico** (a mesma regra de contato de Static/Elmo Rochoso). `fimDaRodada` limpa junto com `protegido`. Antes eram todos `protege: true` puro — um Protect com outro nome. |
| `js/especiais.js` | `GOLPES_ESPECIAIS` + `especial(g)`: golpes cujo efeito não cabe no `meta` da PokéAPI. Comportamentos (lidos em `golpe.js`/`regras.js`): `protege`, `aguentaTurno`, `foco`, `descanso`, `autoDesmaio`, `ohko`, `soDormindo`, `toxico`, `semente`, `carga`(+`invulneravel`), `recarga`, `furia`, `poder` (fórmula em `regras.poderEspecial`), `danoIgualHp`. Sem imports. Estado volátil novo em `m.vol`: `protegido`/`aguenta` (1 rodada — limpos por `fimDaRodada(m)`, que substitui o antigo `vol.flinch = false` em `batalha.js` e `mp-motor.js`), `protSeguidas`, `foco`, `toxico` (n/16 por turno), `semente` (ref de quem plantou, via `ctx.refDe`/`ctx.monPorRef`), `carregando` (o golpe), `invul`, `recarga`, `furia {golpe, turnos}`. Pokémon travado (carga/fúria): `usarGolpe` ignora o golpe escolhido e usa `golpeTravado(m)`. Algo que impede de agir (sono, congelado, paralisia, recuo, confusão) chama `interromper(u)` e a carga/fúria se perde. Hyper Beam só recarrega se o golpe conectou (`executar` devolve `'acertou'`). `tests/especiais.test.js`. A auditoria completa (o que ainda falta) está em `docs/auditoria-batalha.md`, gerada da PokéAPI. |
| `js/relatos.js` | Tela de bugs e sugestões + `contextoTecnico()`. |
| `js/mp-motor.js` | Motor puro da batalha multiplayer (lados A/B com N Pokémon). Testado. |
| `js/multiplayer.js` | Salas co-op por código (Realtime), anfitrião autoritativo, telas da sala. |
| `js/ranking.js` | Tela do ranking global (geral / por espécie). |
| `js/conta.js` | Tela de conta e o botão 👤 no topo (`#conta-chip`). |
| `js/missoes.js` | `verificarMissoes()` — anuncia missões novas e entrega prêmio das concluídas. |
| `js/mundo.js` | `explore()`, `desafiarChefe()`. |
| `js/criacao.js` | Tela de criação: passo 1 dificuldade, passo 2 iniciais por região (ou busca livre em modo `especiesLivres`), prévia, `startGame`, `fullRandomizer`. |

Grafo de imports sem ciclos: `util`/`dados`/`layout` → `regras`/`api` → `estado` → `ui` → `paineis` → `render` → `efeitos`/`progressao`/`pokemon` → `itens`/`amizade`/`missoes`/`fim`/`criacao` → `batalha` → `mundo` → `main` (`batalha` importa `encerrarJornada` de `fim`, então `fim` nunca pode importar `batalha`). Manter sem ciclos.


## Mecânicas, mundo, carreira, painéis, roguelike, ranking, multiplayer, motor do golpe (versão anterior)

## Mecânicas (Etapa 3)

- **Dificuldade** (`S.dificuldade`, tabela `DIFICULDADES` em `dados.js`, lida via `dificuldadeDe(S)` — save antigo sem o campo conta como `easy`). Escolhida no **passo 1 da tela inicial** (`G.dif`, `renderDificuldade`). **O código lê as flags de cada modo, nunca compara o nome**: `semCaptura`, `fimDeJogo`, `centroGratis`, `descontoPorVitoria`, `nivelLivre`, `escolhaLivre`, `fimNaGen` (vencer os lendários encerra a run — Roguelike). O passo 2 é o mapa (Gen, `G.gen`, `renderGens` em criacao.js).
  - `easy` Fácil: nunca capturado, Centro grátis, escolhe tudo.
  - `medium` Médio: igual ao Fácil, mas Centro pago com −10% por vitória desde a última visita (`S.vitoriasDesdeCentro`, zera ao usar o Centro ou desmaiar; 10 vitórias = grátis).
  - `hard` Difícil: capturado → foge depois sem a mochila, metade do dinheiro, zona aleatória; nível inicial 5.
  - `hardcore` Hardcore: capturado → fim de jogo, save apagado (`telaFim`); nível 5 + natureza/habilidade sorteadas.
  - `randomizer` Full Randomizer: sorteia até a espécie (o passo 2 vira um botão só); captura/Centro = Difícil.
- **Treinadores caçadores** (`startTrainerBattle` em `batalha.js`, 10% das explorações): equipe de 1–3 Pokémon da zona, 2–4 bolas (`bolaPorNivel`). Com seu HP ≤ metade, 60% de chance por turno de gastar a vez lançando bola (sai antes de qualquer golpe). Captura = fórmula real da Gen 3/4 (`valorCaptura`/`balancosDaCaptura`) com a `captureRate` da SUA espécie (`loadSpecies`, cache `sp2:`). XP ×1,5; dinheiro só no prêmio final (`premioTreinador`). Dá pra fugir (você é selvagem). Desmaiar contra treinador = derrota comum (Centro), não captura.
- **Shiny**: 1/4096 (`ehShiny`) em todo `makeMon` — você, selvagem, treinador, qualquer modo. Sprite montado pelo id (`SPR_SHINY`/`SPR_SHINY_COSTAS`, não fica no cache da API), com `onerror` caindo no normal. Sobrevive à evolução.
- **Centro Pokémon**: `centroPokemon()` (estado.js) é o ÚNICO lugar que decide se precisa e quanto custa — cada Pokémon da equipe que precisa de cura paga `custoCentro(nível)` = ₽50 + ₽15/nível, com as regras do modo por cima. Desmaiar continua curando de graça (com a perda de metade do dinheiro).
- **Amizade / aliados (3.2)** (`amizade.js`): na Mochila, em batalha contra **selvagem**, ofereça um petisco (`ITEMS` com `afinidade`: 6 petiscos que cobrem os 18 tipos uma vez cada). Tipo que gosta: +20–35; errado: 0–5 (`ganhoAmizade`). Só aceita se `nivel ≤ seu nível + 5`. Em 100, vira aliado (`S.aliados`, máx. `MAX_ALIADOS` = 2; cheio → escolhe quem despedir). Aliado tem `growth` próprio, ganha o mesmo XP/EVs que você (Exp. Share), aprende golpes sozinho (troca o de menor poder), ainda **não evolui**.
- **Batalha com vários do mesmo lado**: `ladoJogador()` = você + aliados. Todos agem no turno (`ordenarAcoes`: prioridade → velocidade → sorteio); aliado usa `melhorGolpe` (poder × eficácia × STAB); o inimigo mira um aleatório em pé do seu lado; a bola do treinador mira só você. Você desmaiar = derrota mesmo com aliado em pé. **Nunca assumir "só 1 do meu lado"** — é a base do multiplayer.
- **Registro** (`registrar(S, lista, especie)` → `S.registro.derrotados/amigos/evolucoes`): lido pelas missões, e pelo Roguelike no futuro.
- **Aliado evolui** como você (pergunta antes; árvore buscada na 1ª vez e guardada em `A.evo`, `null` = não evolui) e **itens valem pra equipe**: `itemTemEfeito` decide quem se beneficia; com mais de um alvo, "Usar em quem?". Desmaiado nunca recebe item (Potion não revive).

## Mundo e progressão (Etapa 2)

- **Mapas por Gen** (`js/mapas.js`, puro, `tests/mapas.test.js`; dados em `js/dados-mapas.js`, **GERADO** por `ferramentas/gerar-mapas.ps1` a partir da PokéAPI — não editar à mão: mudar nomes/temas/faixas no script e rodar de novo; o script precisa ficar salvo com BOM, senão o PowerShell 5 estraga os acentos). 9 Gens × 10 rotas, faixas de nível iguais em todo mapa (2–6 … 52–62). `ZONES` (dados.js) = todas as rotas de todos os mapas, cada uma com `gen`. `pool = [{ id, n: speciesName, p: peso, m?: mítico }]` — sorteio ponderado `sortearDaRota` (taxa = peso/total; peso vem da taxa de captura; mítico ≈ 0,4% nas rotas 8 e 9). Rotas 1–9 têm `chefe` (Alfa); a 10ª tem `final: true` + `lendarios` (os da Gen com total ≥ 500; o último = principal). Kanto mantém os ids antigos (`rota1`…`caverna`) por causa de saves e missões; a Fenda Dimensional saiu (save que estava nela cai na 1ª rota).
  - Estado: `S.gen` (sem campo = 1, `genDe`), `S.gensVencidas`, `S.nivelInicioGen`, `S.escolhendoGen`. **Sempre ler rota por `zone()`/`rotasAtuais()` (estado.js)**, nunca `ZONES` direto na jornada: elas aplicam `rotaNaJornada` (níveis escalados por `escalaNivel` quando você entrou no mapa já forte — fora do Roguelike, depois de fechar uma Gen; a 1ª rota fica sempre aberta).
  - Lendários: `startLendarios(z)` (batalha.js) usa o fluxo de treinador (`trainer.lendarios`, `bolas: 0`, `B.chefe` = rota pra bloquear petisco) com `sequenciaLendaria` (até 3 + o principal, que vem com `statsDeChefe`); `rotulo` mostra "X lendário". Vencer → `vencerGen()`: marca `S.chefes[rota]` + `S.gensVencidas`; modo com flag `fimNaGen` (Roguelike) → `encerrarJornada('venceu', { genVencida })`; senão `S.escolhendoGen = true` + `telaEscolherGen()` (fim.js), clique `proxima-gen` (main.js) → `entrarNaGen`. `abrirJornada` volta pra essa tela se o save estiver com `escolhendoGen`.
  - Roguelike: mapas liberados na criação = `gensLiberadasRoguelike(carreira)` (Gen 1 + a seguinte da maior Gen vencida em run Roguelike). Outros modos escolhem qualquer mapa; Full Randomizer sorteia. Pontuação: `gens` × 2000 (PESOS_PONTOS + `validar_jornada` no schema.sql; teste confere). Limite de Alfas no SQL = rotas com Alfa + finais (90).
  - Pokédex da rota (render.js `pokedexRota`): `pokedexDaRota(z, conhecimento())` — "?" nunca enfrentou, silhueta (CSS `filter`) já enfrentou, colorido + `textoTaxa` com `REVELA_DERROTADOS` (10) derrotados. `conhecimento()` soma `vistos`/`derrotados` da carreira inteira + a jornada atual; a parte da carreira é recalculada só quando `versaoCarreira()` muda (carreira.js incrementa em `salvarCarreira`).
  - Missões com `gen` (trilha de Alfas de Kanto + `lenda`) só aparecem no mapa daquela Gen (`situacaoMissoes`). Multiplayer co-op usa as rotas do mapa da run do anfitrião; a luta dos lendários não existe no co-op.
- **Zonas por nível**: `libera` = nível mínimo (`zonaLiberada`). Chip trancado com 🔒; o clique também checa (main.js, só rotas do mapa atual). A rota inicial e o destino depois de capturado respeitam isso.
- **Alfas (chefes)**: `ZONES[i].chefe = { id, nome, nivel }`, sempre acima do teto da zona (teste garante). Botão "⚔ Desafiar" na cena da zona → `startBossBattle`: IVs 31, `statsDeChefe` (HP ×2, resto ×1,3 — `MULT_CHEFE`). Não aceita petisco, dá pra fugir. 1ª vitória: `premioChefe(nível)` + 1 Rare Candy e marca `S.chefes[zona]`; revanche só dá XP.
- **Missões**: `MISSOES` (dados.js), cada uma com `libera` (condição pra aparecer; sem ela, visível desde o início), `objetivo` e `premio`. Condições: `derrotar`+`qtd`, `vitorias`, `amigos`, `nivel`, `chefe`, `treinadores`, `missao` — avaliadas por `progressoCondicao`/`situacaoMissoes` (regras.js, testadas). `verificarMissoes()` (missoes.js) anuncia missão nova 🔓 (`S.missoesVistas`), entrega prêmio 📜 (`S.missoesFeitas`) e é chamada no `finally` de todo turno, depois de explorar e depois de usar item. Ficha mostra as ativas com barra de progresso e quantas seguem escondidas. Teste de dados garante que toda missão aponta pra zona/missão/item que existe.

- **Missões de dinheiro**: `{ dinheiro }` = ter ₽X de uma vez (cai se gastar); `{ gasto }` = total em `S.gasto` (loja + Centro, somado em main.js). Também `{ evolucoes }`. Contagem de "derrotar" segue a facilidade de achar (comum da 1ª rota = 10, raro = 1–3).

## Fim de jornada, carreira e conta

- **Só iniciais na criação**: `REGIOES_INICIAIS` (9 regiões × 3 + Especiais Pikachu/Eevee) em TODOS os modos — Sortear e Full Randomizer também. Flag por modo `especiesLivres` (hoje false em todos, decisão do usuário "a princípio, pode mudar"): true volta a busca livre só naquele modo.
- **Fim de jornada** (`fim.js`, `encerrarJornada(motivo)`): capturado no Hardcore (`'capturado'`), desmaio sem Revive (`'desmaiou'`) ou "Novo jogo" (`'encerrou'` — o botão agora ENCERRA a jornada, não só apaga). Monta o resumo (`montarResumo`: `estatisticasDaJornada` + `pontuacao` × `multPontos`, com `id` da jornada e cópia do registro por espécie), adiciona na **carreira** (`pokerpg-carreira-v1`, lista de TODAS as jornadas terminadas — sobrevive entre jornadas) e apaga o save (aqui e na nuvem). Tela de fim compara com o melhor daquela espécie. `telaCarreira()` (📊, na tela inicial e no topo do jogo fora de batalha) calcula tudo da lista: favorito (espécie mais jogada), máximos (nível, dinheiro de uma vez, missões, vitórias, Alfas), totais, Pokédex (amigos = "capturados" / 1025, faltam, vistos; sprite pelo `registro.ids`), shinies (vistos / amigos / jornadas sendo shiny) e melhor por espécie. Inclui a jornada atual como "em andamento".
- **Conta / nuvem** (Supabase — a Vercel só hospeda; setup em `supabase/COMO-CONFIGURAR.md`, banco em `supabase/migrations/` com RLS): login com Google ou link por e-mail. `sincronizar()` junta a carreira local com a da conta por `id` (`mesclarJornadas`: sobe só jornada de visitante ou da própria conta, nunca de outra conta que logou no mesmo navegador) e reconcilia a jornada em andamento (tabela `saves`, **uma por conta**): mesma jornada → vale a mais nova (`S.salvoEm`); jornadas diferentes → pergunta qual manter; jornada que já terminou em outro aparelho → descartada aqui. Envio do save: `ganchosSave.aoSalvar` → `agendarEnvioSave` (espera 5 s) + na hora ao esconder/fechar a aba. Sem config, tudo é no-op.
- `S.id` (jornada), `S.salvoEm`, `S.maxDinheiro`, `registro.vistos/shinies/shiniesAmigos/ids` foram adicionados pra isso; save antigo ganha `id` ao abrir.
- **Revive / desmaios**: `desmaiosLivres` por modo (Fácil null = ilimitado; Médio+ = 3). `S.desmaios` conta; do 4º em diante cada desmaio gasta um `revive` da mochila, sem ele = Game Over. Revive também reanima aliado desmaiado (½ HP) — único item que `itemTemEfeito` aceita em desmaiado.
- **Tempo de jogo**: `S.tempoMs`, somado em cada `save()` (`marcarTempo`), ignorando pausas > 5 min; o boot zera `S.ultimoTick`.
- **Ordens dos aliados** (`ORDENS`, `A.ordem`, `golpeDoAliado`): livre (mais eficaz) · fraco ("pegar leve", pra não derrubar quem você quer de amigo) · status · parado (em campo, sem agir) · fora (descansando: fora da batalha, não é alvo, sem XP — `emCampo()`). Troca pelo `<select data-ordem>` na ficha, a qualquer hora. Ficha completa do aliado num `<details data-aliado>` (aberto guardado em `G.abertos`).

## Painéis modulares

- Tela do jogo = coluna esq · centro (**cena fixa** → zona de painéis → ações fixas) · coluna dir. Painéis: `ficha`, `missoes`, `aliados`, `mochila`, `log`. **Um layout pro jogo inteiro** (decisão do usuário), salvo em `pokerpg-layout-v1`.
- Modelo puro em `layout.js` (testado em `tests/layout.test.js`): `normalizarLayout` garante cada painel exatamente uma vez mesmo com save velho/quebrado; `moverPainel`/`deslocar`/`trocarZona`/`alternarRecolhido`/`definirLargura`/`definirAltura` nunca mutam.
- DOM em `paineis.js`: `htmlJogo()` (esqueleto), `aplicarLayout()` (MOVE os nós entre zonas — conteúdo e scroll do log vão junto), `tituloPainel(id, html)`, `iniciarPaineis()` (listeners uma vez só: arrastar pelo cabeçalho com marcador, ▲▼⇄▾, divisórias de largura com pointer capture, "↺ Layout"). Altura = `resize: vertical` nativo + ResizeObserver que só grava quando `style.height` mudou.
- `render.js` escreve só o CONTEÚDO de cada painel em `#p-<id>` (`renderFicha/Missoes/Aliados/Mochila`); o `#log` mora dentro do painel `log`. Painel novo: adicionar em `PAINEIS` + `LAYOUT_PADRAO` (layout.js), `TITULOS` (paineis.js) e um `render<X>()`.
- Celular (≤ 880px): uma coluna, cena primeiro, sem arrastar/redimensionar — reordena pelos botões.

## Roguelike (modo principal)

- **Permadeath** (flag `permadeath`, pedido do usuário): desmaiou = `encerrarJornada('desmaiou')` na hora em `lose()` (nem Revive salva); aliado que desmaia é removido de `S.aliados` em `anunciarQuedas` (Centro não traz de volta). Vale no co-op também.
- `DIFICULDADES.roguelike` (primeiro da lista, `G.dif` padrão): flag `desbloqueios` — a criação oferece `INICIAIS` + `desbloqueadas(carreira)` (`permitidos()` em criacao.js, usado na grade, no Sortear e na checagem do `previewSearch`). Captura = fim da run (`fimDeJogo`), 3 desmaios livres, Centro pago com desconto por vitória, nível 5, natureza/habilidade livres, pontos ×1,5.
- `roguelike.js` (puro, `tests/roguelike.test.js`): `progressoRoguelike(jornadas)` soma `registro.derrotados/amigos/evolucoes` **só das jornadas com `dificuldade === 'roguelike'`** (decisão: não dá pra farmar no Fácil) e aplica `DESBLOQUEIO` (dados.js): 10 derrotas · 5 amizades · evoluir 5× pra forma do meio / 10× pra forma final. Iniciais ficam fora (já liberados). Vale pra PRÓXIMA run: só jornadas terminadas contam.
- Forma do meio/final: `evolve()` anota `registro.formas[especie] = 'meio' | 'final'` (final = nó sem `to` na árvore de evolução). `registro.ids` dá o id pra buscar o Pokémon e o sprite.
- Telas: seção "🔓 Desbloqueados" + "Quase lá" na criação (Roguelike), "Desbloqueado pra próxima jornada" na tela de fim (`novosDesbloqueios(antes, depois)`), seção Roguelike na Carreira.

## Ranking global

- `ranking.js` (tela, `G.mode = 'ranking'`) → `buscarRanking(especie|null)` / `especiesRanqueadas()` (nuvem.js) → funções SQL `ranking(p_especie, p_limite)` e `especies_ranqueadas()` (SECURITY DEFINER, devolvem só apelido + números + `eu`). Funciona sem login (só leitura).
- **Pontuação é do servidor**: gatilho `validar_jornada` (schema.sql) recalcula `pontuacao` do resumo e recusa número impossível (nível > 100, Alfas > 7, missões > 36…). **Pesos, multiplicadores e limites do SQL precisam acompanhar `PESOS_PONTOS`, `DIFICULDADES[].multPontos`, nº de Alfas e `MISSOES.length`** — `tests/schema.test.js` falha se divergirem. Modo novo → acrescentar no `case` do SQL.
- Jornada recusada (erro `P0001`) fica marcada `recusada` na carreira local e não é reenviada; as outras sobem uma a uma (uma recusa não trava a sincronização).
- Mudou o schema.sql → usuário precisa rodar de novo no SQL Editor (idempotente).

## Multiplayer (co-op e PvP)

- Decisão do usuário: **os dois formatos**, **sala por código** (4 caracteres, sem lista pública). Até `MAX_JOGADORES` = 6. Funciona sem login (id de visitante em `pokerpg-visitante`), só precisa do Supabase configurado (Realtime).
- Config da sala (anfitrião, broadcast `lobby`): `modo` 'coop'|'pvp', `porJogador` 1–3 (principal + aliados em pé e não "Descansar"; `slot` 0 = principal, k = `S.aliados[k-1]`), `balancear` (padrão **ligado**, pedido do usuário). PvP: cada jogador escolhe `time` A/B (presença). Balancear: co-op → `balancearCoop` (todos no nível do principal do anfitrião = "chamar alguém pra sua run"); PvP → `balancearPvP` (nível médio + HP × (maior/menor) pro time menor). Desligado: níveis reais; co-op com inimigos no nível do mais forte (Alfa +5).
- Escolha é **por Pokémon** (`minhaVez` = próximo Pokémon meu sem ação no turno; `sala.escolhidos` zera a cada turno). Resultado volta por `"dono:slot"` com **fração** de HP (o nível pode ter sido balanceado). PvP é amistoso: só `S.pvp {vitorias, derrotas}`; `desistir` (motor) tira o time inteiro; ninguém foge (`estado.pvp`).
- **Entrada na sala** (`entrada` em multiplayer.js, escolhida no menu): `'run'` (Pokémon da jornada atual, com aliados), `'convidado'` (`makeMon` Nv. 5 de `especiesConvidado()` = iniciais + desbloqueados do Roguelike; foto com `convidado: true`; resultado NÃO mexe em save nenhum, nem PvP conta) ou `'hall'` (ver abaixo). Sem run: convidado ou Hall; anfitrião sem run só abre PvP (coop continua exigindo run do anfitrião, dono da zona). Convidado sem balancear: nível do anfitrião (co-op) / média dos outros (PvP).
- **✅ CORRIGIDO (29/09/2026) — Hall da Fama no multiplayer: o bug era um `ReferenceError` mudo.**
  Relato real, repetido SEIS vezes pelo usuário: "pra iniciar uma run multiplayer ainda preciso escolher um
  Pokémon inicial de nível baixo; onde eu escolho os do meu Hall da Fama?". **A causa raiz não era falta de
  recurso** — a ☄ Sala de Raide já fazia isso desde 28/09. Era um bug: `htmlRaideSelecao` usava **`SPR_SHINY`
  sem importar** em multiplayer.js. Como a chamada está dentro de um ternário
  (`${e.shiny ? SPR_SHINY(e.id) : SPR(e.id)}`), só estourava pra quem tivesse **um shiny no Hall** — que é o caso
  dele. E o estrago era invisível: `renderSala` escreve `#mp-topo` e DEPOIS `#mp-acoes`, então o cabeçalho já
  trocava pra "Sala de Raide" e o `#mp-acoes` ficava com o **HTML VELHO do Co-op**. A tela contava duas histórias
  ao mesmo tempo (foi assim que o print do usuário denunciou: cartão de membro com "⏳ escolhendo…", que só existe
  no modo raide, ao lado de "3 (com aliados)"/"Balancear níveis", que só existem fora dele). Reproduzido em jsdom
  antes e depois: HEAD dá `ReferenceError: SPR_SHINY is not defined`, a versão corrigida desenha o Hall inteiro.
  Três consertos, além do import:
  - **`renderSala` virou um try/catch** (`desenharSala` faz o trabalho): erro ao desenhar agora aparece NA TELA e
    no console, em vez de deixar meia tela velha. Mesma lição já anotada pro `gimmicksNaLoja` (carreira.js):
    falha silenciosa em render vira diagnóstico errado e semanas de relato perdido.
  - **`tests/referencias.test.js` ganhou um segundo teste** que pega essa classe de bug: nome que COMEÇA COM
    MAIÚSCULA e está COLADO no `(`, varrendo o arquivo inteiro. O teste antigo só olhava a chamada colada no
    `${`, então não via `SPR_SHINY` no meio do ternário. Tentei generalizar o teste antigo pra varrer a
    interpolação inteira e **não deu**: prosa em português dentro do HTML ("Termine (ou encerre)", "Desafiar o
    Alfa (") vira falso positivo. A regra de maiúscula+colado separa os dois casos com ZERO exceção no código de
    hoje (toda a família `SPR`/`SPR_SHINY`/`ITEM_SPR`/`TYPE_PT` é assim; prosa sempre tem espaço antes do `(`).
  - **`resumoCfg`** (cabeçalho da sala) só sabia "PvP ou não", então anunciava a Sala de Raide como
    "Co-op · ... · Rota 1" — rota que ela nem usa. Agora conhece os três modos.
  **Recurso novo junto (o pedido original):** `entradaTipo` = `'run' | 'convidado' | 'hall'`, **por jogador** e
  independente do `modo` da sala — dá pra entrar em co-op OU PvP com até `MAX_TIME_HALL` (3) Pokémon do Hall, no
  nível real. `entradaEfetiva()` é o ÚNICO ponto que decide (a Sala de Raide não é um quarto tipo: ela força
  `'hall'` pra todo mundo). Dois ajudantes derivados evitam espalhar a regra: `semMochila()` (convidado ou Hall
  FORA da raide = sem itens/Revive/gimmick) e `usaRun()` (a luta só mexe na jornada quando entrei com ela) —
  substituíram os `sala.convidado || ...` espalhados por `aplicarPvP`, `aplicarCoop`, itens/Revive de evento,
  gimmicks e Centro na sala. Dentro da raide o Hall CONTINUA com a mochila da conta (é o ponto dela), por isso
  `hallEmprestado()` distingue os dois.
  **A escolha aparece nos DOIS lugares**, e isso foi o que faltou na primeira tentativa de consertar: só no menu
  (antes de criar/entrar) não resolvia, porque quem já estava na sala não tinha como chegar nela — era
  literalmente a pergunta do usuário ("onde eu escolho?"). Agora `htmlEntradaNaSala()` repete a escolha no lobby
  (co-op e PvP, some na raide), com `escolherEntradaNaSala`/`escolherConvidadoNaSala` remontando os Pokémon e
  reavisando os outros pela presença. `htmlHallPicker` (extraído de `htmlRaideSelecao`) é a MESMA tela nos dois
  lugares, e `hallSelAtual()`/`podeMexerNoHall()` fazem `raideSelecionarHall`/`raideEquiparHall`/
  `raideComprar*` atenderem menu (`hallEscolha`) e sala (`sala.hallSel`) sem duplicar nada.
- **Ganhos voltam só no nível real** (pedido do usuário): `nivelarMon` guarda `nivelReal`; `naNivelReal(m)` vai no `final` de cada Pokémon. Co-op: XP, EVs, dinheiro, item (35% por jogador, `FIND_ITEMS`), vitória e prêmio de Alfa só entram na run se o principal lutou no nível real (aliado idem pro XP dele). Balanceado com nível ajustado = diversão (HP e permadeath continuam valendo).
- **Roguelike no co-op**: principal desmaiado = `encerrarJornada('desmaiou')` (sai da sala antes); aliado desmaiado = removido de `S.aliados` (do maior slot pro menor). Fora do Roguelike, desmaio no co-op volta com 1 HP.
- **Sala resistente a rede ruim** (relato real: escolhas não chegavam e o turno só saía no prazo de 45 s; alt-tab derrubava a sala). `enviar()` confere o retorno do `send` ('ok' | 'timed out' | 'error') e tenta de novo; o anfitrião republica o estado a cada `PULSO_MS` enquanto espera escolhas (`ligarPulso`); evento `sincronizar` + botão 🔄 pedem o estado atual; `CHANNEL_ERROR`/`TIMED_OUT`/`CLOSED` **não** fecham mais a sala (reinscreve até 5×, `sala.conexao`); anfitrião sumido da presença só encerra a sala depois de `ESPERA_ANFITRIAO_MS`. Tudo registra em `diario`/`anotar()` (console `[mp]` + `barraConexao()` na tela). `centroMP()` cura a equipe sem sair da sala.
- `mp-motor.js` (PURO, `tests/mp-motor.test.js`): dois lados A/B com N Pokémon, `fotoDoMon` (cópia enxuta pra rede), `resolverTurnoMP(estado, ações)` (async) → estado novo + eventos em texto (sem HTML — quem exibe escapa), `acaoDaIA`. O golpe em si vem do motor único `golpe.js` (a duplicação antiga com o single player foi eliminada).
- `multiplayer.js`: canal `pokerpg-sala-<código>` (presence = membros com a foto do Pokémon; broadcast `estado`/`acao`/`fim`/`lobby`). **Anfitrião é a autoridade**: gera inimigos (1 selvagem por jogador, ou o Alfa com HP × nº de jogadores), junta as escolhas (só o dono escolhe pelo próprio Pokémon), prazo de 45 s com golpe automático, roda o motor e publica. Cada cliente aplica o `fim` na PRÓPRIA jornada (HP/PP, XP via `gainExp`, EVs, dinheiro, registro, Alfa); desmaio no co-op = volta com 1 HP, não conta desmaio. Anfitrião saiu = sala acaba.
- `render()` só desenha em `G.mode` 'explore'/'battle' — gainExp roda na tela da sala e chama render().

## Ícone e amigos

- **Ícone** `{ id 1–1025, shiny }`: `perfis.icone_id/icone_shiny` (conta) ou `pokerpg-icone` (sem conta; sobe no 1º login). `meuIcone()` (nuvem.js), `htmlIcone(ic, cls)` (conta.js, cai no sprite normal se o shiny faltar). Aparece no chip do topo, ranking (`ranking()` devolve `icone_*`), presença da sala, amigos e convites.
- **Amigos**: `perfis.codigo_amigo` (6 caracteres, gerado no banco) + tabela `amizades` (de→para, pendente/aceita, par único, RLS). `pedir_amizade(código)` (se o outro já pediu, aceita na hora) e `meus_amigos()` (SECURITY DEFINER: só apelido + ícone do outro). Aceitar = update pelo `para`; recusar/cancelar/remover = delete. Lista em `nuvem.amigos` (carregada no sync).
- **Convite pra sala**: cada conta logada ouve `pokerpg-convites-<uid>`; `convidarAmigo(id, {codigo, modo})` manda broadcast no canal do amigo; quem recebe só mostra se o remetente está em `nuvem.amigos` como aceito → `toast` (ui.js) com "Entrar" (`mp-aceitar-convite`).
- `sincronizar()` lê as colunas novas com fallback (`42703`) pra quem ainda não rodou o schema.sql novo.

## Topo (menu ☰) e login

- Header: `#top-dinheiro` (sempre visível) + `#menu-burger` + `nav#menu-links` (`#topr` + `#conta-chip`). No computador `.menu-links` é `display:contents` (tudo em linha); ≤ 720px vira painel aberto pelo ☰ (`iniciarMenu`/`fecharMenu` em ui.js: fecha ao tocar num botão, fora, ou Esc). **Telas fora do jogo limpam o topo com `limparTopo()`**, nunca `#topr.innerHTML = ''` direto (o dinheiro ficaria velho).
- Login: botão `.btn-login` no topo; tela de conta com "Continuar com Google" no padrão visual do Google (`G_LOGO`) + link por e-mail.

## Motor único do golpe e habilidades

- **`golpe.js` é o ÚNICO lugar que resolve um golpe** (`usarGolpe`), estágios (`mudarEstagios`, com `fonte` = quem causou), status (`aplicarStatus`) e fim de turno (`fimDeTurno`: Shed Skin → queimadura/veneno → Speed Boost). Single player e multiplayer usam o mesmo: a diferença é o `ctx` de narração — single player `CTX` em efeitos.js (nome HTML, golpe colorido, `say` com pausa, `render`, `shake`); multiplayer em `resolverTurnoMP` (texto puro, coleta eventos). **Por isso `resolverTurnoMP` é async.** Nunca reimplementar golpe em outro arquivo.
- `habilidades.js`: `HABILIDADES` = tabela de ganchos (documentados no topo do arquivo) → `hab(m)`; `IMPL` = as que têm efeito (ficha mostra "✓ ativa"). Contas (stab, técnico, crítico, pinch, resiste, filtro, multiscale, multStat/comStatus, precisão) em `regras.js` (`calcDamage`, `effStat`, `chanceAcerto`, `imuneAoStatusMon`); o resto (absorção, imunidade de tipo, Wonder Guard, Sturdy, contato, secundários, recuo) em `golpe.js`. Habilidade nova com gancho que já existe = uma linha; gancho novo = código no motor + teste em `tests/habilidades.test.js` (que também falha se aparecer gancho desconhecido na tabela).

## Bugs e sugestões

- `relatos.js` (tela, `G.mode = 'relatos'`) → `enviarRelato` (nuvem.js) → tabela `relatos` (schema.sql: insert pra anon/authenticated, select só dos próprios). Sem config/offline/falha → fila `pokerpg-relatos-fila`, enviada no `iniciarNuvem` e no `online`. Bug pode anexar `contextoTecnico()` (sem dados pessoais; o jogador vê o JSON antes). Quem mantém lê no Table Editor — ou por `ferramentas/relatos-admin.mjs` (só no Raspberry Pi, `node ferramentas/relatos-admin.mjs`): puxa tudo com a **service role key** local (`ferramentas/.relatos-admin.env`, git-ignorado, nunca colar em chat — ver `relatos-admin.env.example`), baixa os prints do bucket privado `relatos-imagens` e monta `relatos-baixados/RESUMO.md`. Puxa só `status = 'novo'` e marca como `lido` (flags `--manter`/`--todos` mudam isso). **Rotina semanal** (`ferramentas/rotina-relatos.py`, cron do Pi): terça 14h o Claude lê os relatos abertos (`novo`/`lido`) e publica o relatório, com alternativas por item, como issue no repositório PRIVADO `JonasSprocatti/pokerpg-relatos` — o GitHub manda por e-mail, e responder o e-mail vira comentário. Um comentário do dono em até 8 h é a autorização: o Claude implementa os aprovados, fecha com `--resolver`/`--arquivar`, commita, dá push e comenta o resumo. Sem resposta, a issue fecha e os relatos voltam na terça seguinte. Não é e-mail direto porque o Gmail exige senha de app e a conta não deixou criar; o `gh` já está logado no Pi. Depende de "Include your own updates" ligado nas notificações do GitHub (a issue sai da própria conta).

### Próximos passos combinados (em ordem sugerida)
- **Evoluções especiais** (pedido do usuário): hoje `loadEvo` só guarda `trigger` e `min_level` — pedras/itens (use-item), troca (Cabo de Conexão no single player; troca real no multiplayer), amizade, dia/noite, golpe conhecido, zona. A PokéAPI traz tudo em `evolution_details`.
- **Batalha completa** (continua): habilidades → clima → terrenos → itens segurados → golpes especiais/IA → Mega, Z-Moves, Dynamax/Gigantamax, Tera. Desbloqueia uma **espécie** pra próxima run ao derrotar ou fazer amizade com 5–10 dela; evoluir 5× pra forma do meio desbloqueia a do meio, 10× pra forma final desbloqueia a final. Exige progresso persistente entre runs.
- **Etapa 4 — Supabase/multiplayer**: ranking de todos os jogadores (melhor pontuação geral por espécie) e batalha com Pokémon de vários jogadores do mesmo lado (a batalha já é N-do-meu-lado).
- Ideias soltas ainda não pedidas: mais missões (por tipo elemental, por zona), recompensa de Alfa diferente por zona, rank/título de explorador.
- **Pedido pelo usuário (27/09/2026), pra depois**: ~~sprites 3D/animados com download opcional~~ ✔ FEITO
  (`dados.SPR_3D`/`SPR_ANIM`, `ajustes.estiloSpriteAtual`, `offline.baixarImagens3D`/`baixarImagensAnimadas`);
  ~~animação na barra de HP ao tomar dano/curar~~ ✔ FEITO (ver "Animação da barra de HP" abaixo); ~~animação de
  ataque, cura e dano de status na cena de batalha~~ ✔ FEITO (28/09/2026, ver "Animações de batalha" abaixo).
- **Backlog (pedido do usuário, 28/09/2026): som no jogo.** Pesquisado: a PokéAPI TEM os **cries** (grito curto de
  cada espécie) no mesmo repositório de sprites já usado (`PokeAPI/sprites`, pasta `cries/`, `.ogg` por id —
  `pokemon.cries.latest`/`legacy` na resposta de `/pokemon/{id}`), então dá pra tocar com a MESMA técnica de
  espelhamento por jsdelivr já usada pras imagens (`dados.espelhar`). **Música de jogo (tema de batalha, de
  rota, vitória) a PokéAPI NÃO tem** — ela é só dados + sprites/cries, nunca teve trilha sonora. Pra ter música
  precisaria de outra fonte, e aí vira uma decisão de risco (trilha original dos jogos = direito autoral mais
  exposto que sprite/dado; trilha própria/livre de direitos = mais seguro, mas exige compor ou buscar external).
  Ainda sem desenho: pelo menos precisa decidir se entra som ligado por padrão (com ajuste de volume/mudo em
  ⚙ Ajustes, mesmo espírito do `presencaLigada`/`REDUCED`) e quais eventos tocam cry (encontro selvagem? seu
  Pokémon entrando em campo? os dois?).
- ✅ FEITO (28/09/2026) — **Modo tutorial**: pedido em 27/09/2026 como "onboarding por funcionalidade" (destacar
  elemento novo na hora em que desbloqueia); quando o usuário voltou a pedir em 28/09/2026 mudou de forma —
  virou um **tour guiado único** combinando explicação com uma **demonstração jogável** (abrir a loja, comprar
  item, lutar, correr risco de ser capturado por um treinador) e um resumo curto das Runs, em vez de vários
  tutoriais pontuais por funcionalidade. Perguntado ao usuário (`AskUserQuestion`) e fechado: abre sozinho **só
  na primeiríssima vez** que o jogo é aberto neste aparelho (sem save nenhum ainda — decidido no `boot()` de
  main.js, antes de `showCreate()`) + fica sempre disponível pra rever num botão `❓ Tutorial` (entrou em
  `navegacao.TELAS`, então aparece de graça na barra de qualquer tela fora do jogo E no menu ☰ dentro do jogo,
  igual qualquer outra tela da lista); é uma **demonstração à parte, com um Pokémon de mentirinha** (um Pichu
  fixo, sprite por id — `dados.SPR`, sem precisar da PokéAPI, porque o tour precisa abrir mesmo na primeiríssima
  visita, antes de qualquer cache) — nunca toca `G.S` nem o save de verdade, todo o estado vive em `G.tut`;
  "já visto" **sincroniza com a conta** (`perfis.tutorial_visto`, `supabase/migrations/20260928130000_tutorial_visto.sql`,
  mesmo padrão de `badge_exibida`), com o navegador como reserva sem conta (`nuvem.tutorialVistoLocal`/
  `salvarTutorialVisto`, idempotente — nunca reenvia depois do primeiro "visto"). **É pulável em qualquer
  passo** (botão "Pular tutorial", filosofia de não travar — mesmo espírito do banner de cookies do `ads.js`) e
  **"Continuar" nunca fica bloqueado**: mesmo os passos interativos (batalha, loja, captura) deixam avançar sem
  ter batido/comprado/revelado nada — forçar uma ação específica pra sair de uma tela é exatamente o tipo de
  trava que o resto do jogo evita. `js/tutorial.js` (puro, sem DOM, `tests/tutorial.test.js`) guarda os dados de
  mentirinha (Pichu Nv. 8, Caterpie selvagem, Treinador Theo) e a lógica de passo/golpe/compra; **o texto de cada
  passo lê dado real em vez de duplicar**: o resumo de Runs e a tabela "o que acontece se eu for capturado" vêm
  direto de `dados.DIFICULDADES` (`d.desc`, `d.semCaptura`, `d.fimDeJogo`) — mudou a regra ali, o tutorial muda
  sozinho, sem re-escrever texto solto. `js/tela-tutorial.js` desenha (reaproveita classes existentes: `.hp`/
  `.bar`/`.fill` pra HP, `.item-btn`/`spriteItem` pra loja, `.difs`/`.abil` pra os cards de dificuldade — quase
  nenhum CSS novo precisou).
- **Pedido pelo usuário (28/09/2026), pra depois:**
  1. ✅ FEITO — **Layout pro celular em modo paisagem (horizontal)**: ver "Celular DEITADO" na tabela de arquivos
     acima (a cena vira coluna lateral, não fica mais presa no topo).
  2. ✅ FEITO — **Marcador de jogadores online no momento** e **estimativa de quantos jogam sem conta**:
     `js/presenca.js` (ver tabela de arquivos acima). O canal de presença global mostra "🟢 X jogando agora" na
     tela inicial pra QUALQUER jogador; o contador histórico de visitantes sem conta é ADMIN-ONLY (pedido
     explícito do usuário: "essa estatística deve aparecer só pra mim admin") — aparece ao lado do marcador
     ao vivo, só pra quem tem `perfis.admin`. Schema em
     `supabase/migrations/20260928120000_visitantes_anonimos.sql` (tabela `visitantes_anonimos` + duas RPCs
     SECURITY DEFINER: `registrar_visitante_anonimo` grava, `contagem_visitantes_anonimos` só devolve o total
     pra admin). Divulgado na tela 🔒 Privacidade (passo 3) e com interruptor em ⚙ Ajustes — decisão própria
     (não pedida explicitamente, mas coerente com "não pode virar telemetria silenciosa" já anotado aqui):
     desligar tira o jogador do canal de presença E do registro de visitante, sem afetar o resto do jogo.
- **Arceus como chefe de raide** (pedido do usuário, 28/09/2026) — **✅ FEITO em 01/10/2026**, junto com
  **Regigigas** (pedido na mesma conversa: líder dos Regis). Decisão: **entram na rotação**, no FIM da lista
  (`% 14` virou `% 16`). A ordem do array É o calendário — entrar no meio trocaria o chefe da semana de quem já
  está jogando, então chefe novo sempre vai no fim. **Arceus** reusa `pontoFraco` como os Pratos (os 17, sorteados, troca
  a cada 2 ações) + couraça + Julgamento carregado: a mecânica de "o tipo que fere muda" já existia, não valia um
  gancho novo pra Multitype — só a flag `sorteia` e o efeito `{pratos}` da animação (pedido do usuário no mesmo dia:
  "é o Deus Pokémon, a luta tem que ser fantástica"). A animação é um anel com a cor de cada tipo girando em volta
  do sprite (`ui.trocarPratos` + `@keyframes pratos-anel`), que encolhe e deixa o Prato sorteado pulsando; respeita
  `semAnimacao()` e se remove sozinha do DOM. **Regigigas** não ganhou mecânica nenhuma: `habilidade: 'slow-start'` (já
  na tabela do motor) faz o colosso começar com metade do Ataque e da Velocidade e acordar nos 5 primeiros
  turnos, e as fases somam Ataque em cima disso. Golpes escolhidos entre os que já estavam em `TIPO_DO_GOLPE`
  (só `thunder-punch` entrou novo) — de quebra, nenhum deles é de Fogo/Água/Psíquico/Gelo/Voador/Dragão, então
  só a descrição do `prisma-de-luz` mudou (Arceus tem ponto fraco). Com 16 chefes o rodízio de itens novos
  deixou de ser 1 pra 1: os dois primeiros da lista saem duas vezes na volta.

## Modo offline, convenções, testes e Supabase (versão anterior)

## Modo offline

- `sw.js` (service worker, registrado no `index.html`): arquivos do jogo em **rede primeiro** (online pega sempre a versão nova, sem trocar versão a cada deploy; offline cai no cache), PokéAPI/sprites/esm.sh/fontes em **cache primeiro**, Supabase nunca em cache. **Todo arquivo novo em `js/` entra em `PRECACHE`** — `tests/sw.test.js` falha se esquecer.
- Offline (`offline()` em util.js): `sortearOponente` só sorteia Pokémon já em cache (`pokemonEmCache`/`idsEmCache` em api.js); sem nenhum, `erroOffline` com mensagem clara em vez do erro da PokéAPI. Alfa idem.
- Nuvem offline: envio do save fica pendente; `online` → `sincronizar()` (sobe jornadas terminadas + save; save da nuvem de jornada que já terminou é apagado ali). Se o jogo abriu offline, `iniciarNuvem` tenta de novo no `online` (listeners de rede registrados uma vez só). Selo "📴 offline" no topo (`#conta-chip`), com ou sem conta.
- **O download (`baixarGen`) precisa trazer TUDO o que uma jornada pede, não só os Pokémon.** Já faltou duas vezes, e nos dois casos o jogo dizia "mapa baixado" e falhava no avião: (1) **curva de XP e árvore de evolução** (`loadSpecies`/`loadGrowth`/`loadEvo`) — `criacao.iniciarJornada` pede as três ANTES de montar o save, então sem elas nem dava pra começar uma jornada offline, e `checkEvolution` morria a cada nível; (2) **sprites que falhavam calado** (`fetch(url).catch(() => {})`), que davam ícone de imagem quebrada em uns Pokémon e não em outros. Ao acrescentar qualquer busca nova num fluxo de jogo, perguntar: **isso está no `baixarGen`?**
- **`VERSAO_DOWNLOAD` (offline.js)**: quando a lista do que o download traz cresce, subir esse número. `jaBaixado` exige a marca `baixado-v<N>:gen<G>` (gravada só quando o download termina SEM falha) além dos Pokémon em cache, então quem baixou na versão antiga volta a aparecer como incompleto — `precisaRebaixar(gen)` é essa pendência, separada de "faltam N Pokémon" pra tela não mentir na contagem.
- **`try` largo demais vira diagnóstico errado.** `previewSearch` (criacao.js) envolvia busca de rede E montagem da prévia num `try` só, reportando tudo como `apiErr`. Uma função que faltava (`opcaoShiny`, chamada e nunca escrita) virou "A conexão falhou ao buscar um dado da PokéAPI" — e o jogador passou horas limpando cache e trocando de rede. Hoje são dois `try` com mensagens diferentes. Regra: **só o que fala com a rede pode reportar erro de rede**; o resto mostra o erro de verdade.
- **Função chamada dentro de template literal só quebra quando a tela é desenhada** — `node --check` não pega, e teste de função pura também não, porque a UI nunca roda nos testes. `tests/referencias.test.js` varre `${nome(` em todos os `js/*.js` e exige que `nome` exista ou seja importado.
- **As imagens vêm do `cdn.jsdelivr.net`** (espelho do repositório de sprites da PokéAPI), não do `raw.githubusercontent.com` — diagnosticado num aparelho real: `pokeapi.co` respondia e TODA imagem dava `net::ERR_FAILED`, porque esse domínio é bloqueado em muitas redes. `espelhar(url)` (dados.js) traduz o endereço antigo, e é obrigatório em qualquer lugar que desenhe `m.data.sprite`/`back`/`art`: a própria PokéAPI devolve URLs do raw.githubusercontent dentro dos dados, e o que já está guardado no aparelho (ou no save) continua com o endereço velho.
- **Quem guarda as IMAGENS é o service worker**, não o `api.js`. Sem sw controlando a página (primeira visita, ou logo após Ctrl+Shift+R) o download termina "com sucesso" e nenhuma imagem fica guardada — `semServiceWorker()` (offline.js) detecta e a tela de Ajustes manda recarregar antes de baixar.
- **`navigator.onLine` mente.** Ele só diz que existe interface de rede, não que ela chega a algum lugar (wifi de metrô, portal cativo, 4G ruim = "online"). Por isso `cached()` (api.js) **cai no registro guardado quando o `loader()` falha**, e não só quando `semRede()`. Antes ele descartava um registro bom (por faltar campo novo do `valido`) e morria no fetch: dava "A conexão falhou ao buscar um dado da PokéAPI" e não dava pra começar jornada nenhuma, com o mapa inteiro baixado. Qualquer código novo que decida algo por `offline()`/`onLine` precisa ter um caminho de "tentei e falhou" também.
- **Busca que não é essencial não pode derrubar o fluxo.** `criacao.iniciarJornada` pega a árvore de evolução em `try/catch` e deixa `evo` como `undefined` (≠ `null`, que significa "não evolui"): `progressao.arvoreDe` busca depois e `checkEvolution` marca `evoPendente`. Regra geral: antes de dar `await` numa busca de rede num caminho crítico, perguntar se o jogo precisa DAQUILO agora.
- `apiErr(e)` diz qual dado faltou (`e.url` marcada em `getJSON` → `dadoQueFaltou`). Erro de rede genérico não deixa ninguém consertar nada.
- `cachePrimeiro` (sw.js) usa `match(req, { ignoreVary: true })`: o mesmo sprite é pedido por `fetch()` (download) e por `<img src>` (tela), e o servidor responde com `Vary: Authorization,Accept-Encoding` — comparar cabeçalho aí só serve pra dizer "não tenho" com o arquivo guardado do lado.

## Convenções

- **Nunca gravar arquivo com BOM.** `Set-Content`/`Out-File -Encoding utf8` no Windows PowerShell 5.1 escreve UTF-8 **com BOM**, e isso já quebrou o deploy do banco: o Supabase recusou o `config.toml` com `toml: invalid character at start of key: U+00EF 'ï'` — o BOM lido como caractere. Em .sql, .toml, .json e .yml o BOM é veneno. Para gravar sem: `[System.IO.File]::WriteAllText($caminho, $texto, (New-Object System.Text.UTF8Encoding $false))`. As ferramentas de edição do Claude Code já gravam sem BOM; o risco está nos scripts de `ferramentas/` e em qualquer arquivo escrito via PowerShell.
- **Toda funcionalidade nova atualiza o `README.md`** (o que o jogo tem + a lista de próximos passos/já feito) — pedido explícito do usuário, vale sempre.
- Regra nova (conta, fórmula, probabilidade) vai em `regras.js` como função pura, com teste; o módulo de narração só chama e escreve a mensagem.
- Tudo que só `regras.js`/`dados.js`/`util.js`/`api.js` importa precisa continuar sem DOM (importável no Node).
- `esc()` em todo texto vindo de fora (apelido, dados da API) dentro de template string.
- Estado compartilhado sempre via `G.*` (nunca `let` exportado).
- Fontes: `--display` (Fredoka) para títulos e números, `--body` (Atkinson Hyperlegible) para texto. A Pixelify Sans saiu (confundia 2/5/8); não voltar a usar fonte pixelada em número.
- **Campo de formulário já nasce vestido (29/09/2026).** `input`/`select`/`textarea` têm uma regra BASE no topo do `estilo.css` (fundo `--panel2`, borda `--line`, raio 10, padding) — não precisa estilizar campo novo à mão. Antes cada tela estilizava o seu, e esquecer uma fazia o navegador desenhar o **padrão dele (fundo branco)**; como a linha `button,input,select{color:inherit}` já dava texto claro, o resultado era texto claro em fundo branco — ilegível, e uma faixa branca no meio do layout escuro (relato do usuário: Equipar item, busca da criação, chat da sala, código da sala, apelido). A base usa **`:where()`** de propósito: ele não soma especificidade, então a regra pesa (0,0,1) e é PISO, não teto — as ~13 regras por classe que já existiam (`.search input`, `.qtd-ctl input`…) continuam ganhando. Escrever `:not()` solto ali pesaria (0,3,1) e quebraria justamente os campos que já estavam certos. `select option` também é estilizado (a lista que abre no celular herdava o texto claro e sumia no branco); caixa de marcar, rádio e `type=file` ficam de fora (desenho nativo).
- Logo e ícones: `img/logo.png` (topo e README, fundo transparente), `img/favicon-32.png` e `img/icone-192.png` (quadrados, gerados do logo com margem transparente — o original é 373×309). Estão no PRECACHE do sw.js.

## Testes

`tests/*.test.js` com `node:test` — rodar com `node --test` **sem caminho**. CI em `.github/workflows/testes.yml` roda a cada push/PR (aba Actions do GitHub).

**`tests/docs-numeros.test.js` trava os números DESTE arquivo e do README contra o código** (29/09/2026). Motivo: um levantamento do backlog achou 6 afirmações erradas de uma vez — "~30 badges" quando são 53, "96 formas, 93 espécies" de Mega quando são 95/89 (contradizendo o "89 Megas" escrito algumas linhas abaixo), e coisas dadas como pendentes que já estavam prontas. O usuário planeja em cima destes textos; número velho aqui custa tempo de verdade. São três testes: dois com frases-âncora (badges, Megas, habilidades, flags de golpe, `AINDA_EVOLUI`, itens de raide, nº de chefes e o `% N` do calendário) e um genérico que varre **toda** ocorrência de `` `CONSTANTE` = N `` nos dois .md e compara com o valor exportado de verdade — esse pega de graça o que ninguém lembrou de travar à mão. Ele entende as formas que a prosa usa (`1.000` com ponto de milhar, `20%` para um `0.2` no código), então escrever normal não dá alarme falso. **Mudou o número no código → atualize a frase no .md**; se a FRASE foi reescrita, o teste diz qual âncora não achou nada, de propósito, pra não passar batido.

## Supabase: schema sobe sozinho (integração nativa)

> ⚠️ **Ficou mudo por dias por causa de um campo mal preenchido (24/09/2026).** Duas migrations de teste foram
> commitadas no `main` e nenhuma chegou no banco, sem nenhum erro no painel. Causa: o **working directory** estava
> como `/supabase`. Esse campo pede o diretório que **CONTÉM** a pasta `supabase/` — aqui ela está na raiz, então
> o valor certo é **`/`**. Com `/supabase`, ele procurava `/supabase/supabase/migrations` e não achava nada.
> O `supabase/config.toml` também precisa declarar o Postgres do projeto (`select version()` → 17 aqui).
>
> **Como verificar que uma migration chegou** (não confie no painel): consulte a tabela pelo cliente do jogo com
> `select('*').limit(1)` **e uma tabela inexistente de controle**. `select('*', { count: 'exact', head: true })`
> devolve `error` nulo mesmo pra tabela que não existe — esse detalhe fez um diagnóstico dar "tudo OK" e escondeu
> o problema por uma rodada inteira.

O banco é atualizado pela **integração do GitHub no painel do Supabase** (Settings → Integrations → GitHub): repositório conectado, *working directory* **`/`** (a raiz — o campo pede o diretório que CONTÉM a pasta `supabase/`, e não ela mesma), *Deploy to production* ligado na branch `main`. Nada de secret no GitHub — a conexão é do lado do Supabase.

Por isso o schema vive em **`supabase/migrations/`**, no formato do Supabase CLI:

- **Mudança nova = ARQUIVO NOVO**, nunca editar uma migration já aplicada: o Supabase guarda quais já rodaram e não roda de novo.
- **Nome no padrão do CLI**: `<AAAAMMDDHHMMSS>_nome.sql` (ex. `20261001093000_mega.sql`). A integração ordena por esse carimbo; nome fora do padrão ela ignora.
- `20260923120000_base.sql` é o schema inteiro como estava quando adotamos migrations — idempotente, então aplicar num banco que já tem tudo não muda nada.
- **Uma vez só, à mão: `supabase/LIGAR-MIGRATIONS.sql`.** Projeto criado direto pelo SQL Editor (o nosso) não tem a tabela de controle `supabase_migrations.schema_migrations`, e a integração falha com `relation "supabase_migrations.schema_migrations" does not exist` — ela precisa da tabela pra saber o que aplicar, mas não a cria sozinha. Rodar esse arquivo no SQL Editor resolve de vez; depois é só merge no `main`.
- `tests/schema.test.js` lê a pasta inteira (soma das migrations) pra conferir que os pesos de pontuação do SQL batem com os de `regras.js`. **Mudou a fórmula num lado, muda no outro**, senão o servidor recusa jornadas legítimas.
- Nada destrutivo aqui: `drop`/`alter` que possa perder dado de jogador vai num arquivo rodado à mão, porque este fluxo roda sozinho.

## Sucker Punch, badges de parceiros, Insígnia Alpha, clima das rotas (versão anterior)

- **Sucker Punch** (`soSeAlvoAtaca` em `especiais.js`): `vol.golpeEscolhido` é preenchido por `batalha.turn`/`mp-motor` antes de resolver o turno e apagado em `fimDaRodada`;
  falha se o alvo escolheu status, não escolheu golpe (item/fuga) ou já agiu (`primeiro` falso).
- **Badges de parceiros** (`badges.js`, grupo `Parceiros`): `casa-cheia` (venceu com `equipeCheia && esconderijoCheio`, 2+30 parceiros),
  `lobo-solitario` (venceu com `amigos === 0`) e `cemiterio` (`ALVO_PERDIDOS` = 15 aliados PERDIDOS de vez numa MESMA run). Medem uma jornada, nunca a
  soma; ignoram `easy`; as duas de vitória usam `venceu(j)`. Dados novos no resumo da jornada (`fim.montarResumo`: `casaCheia`, `aliadosPerdidos`) e no
  `progresso-conta.bancar` (senão somem — o resumo é lista branca). `S.aliadosPerdidos` sobe em `batalha.anunciarQuedas` e no co-op (`multiplayer`), SÓ em modo
  `permadeath`: nos outros o aliado só desmaia e volta, então "perder" = cair de vez (na prática, Roguelike). Jornadas antigas não têm os campos (contam 0).
- **Insígnia Alpha** (`js/alpha.js`, testada em `tests/alpha.test.js`): sem tabela nem contador — é a data de criação da conta
  (`perfis.criado_em` → `nuvem.criadoEm`, lida em `sincronizar`) antes de `ALPHA_ATE`. `htmlCartaoAlpha` na tela Conta e `htmlInsigniaAlpha({compacto})`
  no chip do topo (`conta.js`); ids do SVG únicos por desenho (`seq`). **Depois de anunciar o Beta, NÃO mexer em `ALPHA_ATE`** (é o que faz a insígnia valer).
  Não aparece no ranking/salas: esses dados de OUTROS jogadores não trazem `criado_em`.
- **Clima das rotas é OPCIONAL por jornada**: `S.climaRotas` (escolhido na criação, caixa `#pv-clima`, `G.climaRotas`), ou forçado por
  `DIFICULDADES[x].climaRotasFixo` (Roguelike e Hardcore: caixa marcada e travada). Sempre perguntar via **`regras.climaDasRotasAtivo(S)`**
  (cobre save antigo sem o campo) — `batalha.iniciar` e `multiplayer` (co-op, run do anfitrião) só passam a rota a `novoCampo` se ativo.
  **Mega do inimigo**: `mega.inimigoMegaLiberada(E)` = nível ≥ `NIVEL_MEGA_INIMIGO` (40), checado em `batalha.megaDoInimigo` SEM marcar
  `megaInimigoUsada` (o Tera do inimigo, que só usa `inimigoPodeMega`, segue livre em qualquer nível). O 40 é o NÍVEL do Pokémon inimigo.
- **Clima/terreno padrão de rota**: `regras.CLIMA_DA_ROTA` (id da rota → `{clima}` ou `{terreno}`; testado contra `dados-mapas.js`
  em `tests/clima-rota.test.js`; Santuário e luta final ficam de fora) e `novoCampo(rotaId)`, usado por `batalha.iniciar`
  (`G.S.zone`) e `mp-motor.novaBatalhaMP` (`opcoes.zona`, só co-op; PvP = campo limpo). O campo ganhou `climaFixo`/`terrenoFixo`
  (o contador não anda — não usar `Infinity`, que vira `null` no JSON do save) e `padrao {clima, terreno}`. `golpe.mudarClima`/
  `mudarTerreno` desligam o fixo (troca dura 5 turnos; repetir o mesmo da rota é no-op); `passarClima`/`passarTerreno`, ao
  esgotar, RESTAURAM o padrão da rota. **Weather Ball**: `regras.golpeDoClima(g, clima)` devolve uma CÓPIA com tipo/poder do
  tempo — usada em `golpe.executar` (o PP já foi gasto no original) e nos botões (`render.js`, `multiplayer.js`). **Castform**
  (`forecast` → `formaDoClima`): `golpe.ajustarForma` troca `m.data` por uma CÓPIA (tipos + sprite pelos ids 10013/14/15) ao
  entrar, no começo de todo `usarGolpe` (usuário e alvo) e no fim do turno; `desfazerForma` roda em `endBattle`. Cherrim
  (Flower Gift) só tem o bônus de atributo, sem troca de sprite.

## Lição cara: `node --check` (versão anterior)

- **Duração da run**: `regras.MULT_XP = 0.6` (escolha do usuário). É UM número — se ficar arrastado, suba.
- **Decidido com o usuário (28/09/2026)**: confirmado que o inimigo TAMBÉM deveria gigantamaxar (só treinador) —
  ao investigar pra implementar, achei que **já existia** (`batalha.gmaxDoInimigo`/`dynamax.inimigoPodeGmax`,
  testado em `tests/gimmicks-coop-inimigo.test.js`): esta nota de "em aberto" tinha ficado esquecida no CLAUDE.md
  depois que o recurso foi construído. Nada a fazer aqui. Painel de manutenção **continua** (jogo ainda em ajuste
  ativo, modo beta da Raide ligado); teto de aliados **continua em 2** (o Esconderijo já resolve "guardar mais
  parceiros" sem mexer em quantos agem por turno — subir o teto mudaria o balanceamento da batalha, não só
  armazenamento).

### ⚠️ Lição cara (25/09/2026): `node --check` não roda nesta máquina
`S?.escondidos ||= []` — optional chaining como alvo de atribuição é **erro de sintaxe**. Derrubou o jogo inteiro
(tela branca) porque o módulo não parseava e levou junto `render.js`, `itens.js` e `amizade.js`. Um `node --check`
pegaria em um segundo. Enquanto não houver Node aqui: **arquivo novo ou reescrito é o maior risco do projeto**, e
o CI é a única rede de verdade. Avisar "não rodei os testes" não basta quando o erro não falha um teste — ele
impede o jogo de abrir.

## Decidido com o usuário, ainda NÃO implementado

Ordem acordada: **1 ✅ contadores + telas** · **2 ✅ cada Gen é uma jornada** · **3 ✅ badges com vantagem** · **4 ✅ Mega** · **5 ✅ Tera** · **6 ✅ Z-Move** · **7 ✅ Dynamax** · **8 habilidades restantes**. A reforma das jornadas (2) vem ANTES das vantagens (3) porque reescreve a criação e o fim de jornada, que é exatamente onde as vantagens se penduram.


## Anti-grind e outras decisões (versão anterior)

### ✅ FEITO — Anti-grind: rota esgotada (só no Roguelike)
(Estava listado aqui como "ainda NÃO implementado" até 29/09/2026, quando conferi rodando: já estava pronto havia
tempo. Mesmo tipo de nota esquecida que o Gigantamax do inimigo — ver o item de 28/09 em "Decidido com o usuário".)

`regras.rotaEsgotada(z, nivel, dificuldade)` (pura, `tests/regras.test.js`): quando o seu nível passa do limite da
rota, ela deixa de dar caçada — nada de farmar em rota fraca. Você continua **entrando e vendo a Pokédex dela**
(quem vive ali, taxas, Alfa); o que some é só o encontro. **Só no Roguelike** (compara a dificuldade direto).
O limite é `limiteDaRota(z)` = `max(z.max * FATOR_ESGOTADA, z.max + MARGEM_ESGOTADA)` — o **dobro do teto** (2), mas
com um piso de **+15 níveis**: sem essa margem, a 1ª rota (teto 6) esgotaria no nível 13, cedo demais pra quem
ainda está montando a equipe. Só muda rotas de teto abaixo de 15; do meio do mapa pra frente o dobro é que manda.
Lido em `mundo.explore` (bloqueia o encontro) e em `render.js` (o botão vira "✔ Rota esgotada" e a rota explica o
porquê, em vez de simplesmente não acontecer nada — falha muda vira relato de bug).

### Outras decisões
- **XP por Gen fica canônico** (Paldea dá ~20% mais XP por ponto de força que Kanto): é dado da franquia, não erro nosso.
- **Formas de Hisui ficam no Santuário de Galar** (Gen 8, como a PokéAPI classifica), não em Sinnoh.
- **Paradoxo de Paldea** já aparecem sozinhos na Área Zero e na Borda da Grande Cratera, além do Santuário — não precisou de nada.


---

## Travas, IA e troca de Pokémon (desenho de 29/09/2026)

Pedido do usuário: resolver os golpes que travam (Taunt/Encore/Disable), melhorar a IA dos inimigos pra usar isso, e
achar uma solução pras habilidades, golpes e itens que dependem de TROCAR de Pokémon. Feito em 3 etapas, cada uma um
commit com teste. Decisões fechadas com o usuário (via pergunta):

- **Regenerator / Natural Cure** → agem **ao vencer a luta** (Regenerator recupera 1/3 do HP, Natural Cure tira o
  status). É o equivalente de "sair de campo" pra quem joga sozinho.
- **Roar / Whirlwind / Dragon Tail / Red Card** → contra selvagem, **encerra a luta**; contra treinador, **chama um
  aleatório da equipe** (o atual sai sem contar como derrotado, sem XP dele); **contra o jogador, quem levou o golpe
  SAI da luta e ela segue sem ele** (aliados continuam; se estava sozinho, a luta acaba como uma fuga, sem penalidade).
- **Wimp Out / Emergency Exit / Eject Button** → só nos **inimigos e aliados**. Nos Pokémon principais do jogador
  continuam sem efeito (uma habilidade sorteada no Hardcore não pode te tirar da luta contra a vontade).
- Ordem: 1. travas · 2. IA · 3. trocas.

### Etapa 1 — travas (FEITA)
- **`regras.motivoBloqueio(m, g)` é a única fonte** do que um Pokémon pode escolher: Choice, Colete de Assalto, Taunt,
  Encore, Disable, Torment e PP. `golpesPermitidos(m)` filtra; lista vazia = Struggle. Antes a trava do Choice estava
  COPIADA em 4 lugares (render.js, arena.js, multiplayer.js e golpeDoAliado) e o motor confiava cegamente na tela;
  com mais quatro travas isso viraria 16 cópias, e a IA não teria de onde ler o que o ALVO pode fazer. Agora as 3
  telas, os aliados (`golpeDoAliado` recebe a lista já filtrada), a IA (`escolhaIA` idem) e o motor perguntam à
  mesma função. O bônus: **Gorilla Tactics** deixa de ser bloqueada pelo problema das "3 telas" (ainda não feita).
- **O motor confere também** (`golpe.usarGolpe`, no ponto onde ficava o cheque solto do Colete de Assalto),
  porque a ordem do turno importa: o inimigo mais rápido que te provoca DEPOIS de você escolher um golpe de status
  faz o seu golpe falhar (sem gastar PP). No **Encore** a escolha é TROCADA pelo golpe repetido (Gen 5+), e isso vale
  também na ordem do turno (`batalha.turn` e `mp-motor` aplicam `golpeForcado` antes de calcular a prioridade).
  Carga/fúria em andamento (`golpeTravado`) e Struggle ficam de fora.
- **Estado em `m.vol`** (só dados simples: vai no save e pela rede): `ultimo` (último golpe usado, novo — nada
  guardava isso), `provocado` (turnos), `encore {golpe, turnos}`, `desativado {golpe, turnos}`, `tormento`.
  Prazos: Taunt 3, Encore 3, Disable 4, **+1 se o alvo já agiu neste turno** (o turno em que foi aplicado já passou).
  Contam em `golpe.fimDeTurno` via `regras.passarTravas`, que devolve o que acabou pra narrar. Torment dura a batalha.
- **Falhas** (`regras.falhaDaTrava`): chefe de evento é imune (como a status); já estar sob o efeito; Encore/Disable
  sem golpe pra repetir; Encore num golpe sem PP; Encore de Encore/Mimic/Transform/Sketch/Mirror Move/Me First/Struggle.
  **Encore suspende sozinho se o golpe repetido ficar sem PP** (`motivoBloqueio`) — senão o Pokémon ficaria sem golpe.
- **Habilidades**: gancho novo `imuneTrava` (lista de travas que não pegam). Oblivious → `['provocar']`; **Aroma Veil**
  (nova, 209 de 314) → as quatro. Testado em `tests/habilidades.test.js` (o teste do gancho valida contra `TRAVAS`).
- UI: `regras.resumoTravas(m)` devolve as linhas "😤 Provocado por 2 turno(s)…" que as três telas mostram; o botão
  bloqueado explica o motivo no `title`. O Colete de Assalto agora apaga os botões de status (antes o clique passava
  e só o motor recusava).
- Testes: `tests/travas.test.js` (18) — inclui os casos que SÓ o motor pega. Conferido por mutação: desligar a
  conferência do motor, o `golpeForcado` ou o filtro da IA faz testes falharem.
- **Fora do escopo por ora**: Heal Block, Imprison, Throat Chop, Magic Bounce refletindo Taunt, Mental Herb, e
  mostrar o "provocado/encore" do INIMIGO na placa dele (hoje só aparece narrado no log).

### Etapa 2 — IA com nota por golpe (FEITA)
Antes: `escolhaIA` era "maior dano ou sorteio"; `melhorGolpe` dava nota 0,1 a QUALQUER golpe de status, então o inimigo
só usava Toxic, Reflect ou Swords Dance por sorteio; `esperteza` (0,5 / 0,75 / 0,9) só decidia "acerta o maior dano ou
sorteia". Agora `regras.escolhaIA(moves, tiposA, tiposAlvo, esperteza, sorte, contexto)` ganhou o parâmetro opcional
`contexto = { u, alvo, campo, ladoU, ladoAlvo }`; com ele, cada golpe recebe uma nota (`notaDoGolpe`) e "pensar" é
escolher a maior. **Sem contexto, ou no degrau `simples`, o comportamento é exatamente o antigo** (os testes antigos
seguem valendo sem mexer).
- **A escala**: ≈ "% do HP do alvo que o golpe vale". Dano = `min(1, dano/HP do alvo) × 100 × precisão`; status é
  posto na mesma régua (dormir 55, paralisar 40 (+15 se o alvo é mais rápido), queimar 40 (+15 se o alvo bate físico),
  veneno 30…). Assim dá pra comparar "atacar" com "paralisar" com "se curar" numa conta só.
- **Dano esperado**: `calcDamage` ganhou o 7º parâmetro `esperado` (sem crítico, rolagem no meio, 92,5%). Sem isso
  um crítico ou uma rolagem baixa mudaria a escolha de um turno pro outro.
- **Três degraus** (`nivelDaIA(esperteza)`): `simples` = selvagem; `basico` = treinador (dano + status que pega + cura;
  o resto vale `IGNORADO`); `completo` = Alfa, lendário e chefe (buffs/debuffs, telas, clima, terreno, Taunt/Encore/
  Disable, proteção, Leech Seed, Toxic, Rest…). A esperteza continua sendo a **chance de pensar**; quando "se distrai" o
  inimigo sorteia, mas só entre os golpes razoáveis (nota > −50): nunca um golpe imune ou uma tela repetida.
- **Regras que a IA respeita**: imunidade de tipo/habilidade (Levitate, Volt Absorb, Soundproof…), status só em quem
  não tem status e não é imune (e sem Safeguard), cura só com HP ≤ 65%, buff só até +2 e só com folga de HP, Ataque só
  pra quem tem golpe físico, tela/clima/terreno que já está ativo vale −100, proteção nunca duas seguidas, Explosion
  só se derruba, golpe de 2 turnos ×0,6, golpe que derruba ganha +40 (+30 se tem prioridade), Taunt só vale contra
  quem tem golpe de status (e menos se ele acabou de bater), Encore só contra quem acabou de usar buff/golpe fraco.
- **`esp.armadilha` vale −100**: do lado do jogador ninguém troca de Pokémon, então Stealth Rock/Spikes não pegam
  ninguém — a IA sabe. Se um dia existir troca voluntária, é só tirar essa linha.
- Empate de nota: sorteia entre os empatados (senão o inimigo seria sempre o primeiro golpe da lista).
- **Chamadores**: `batalha.chooseEnemyMove` (single player) e `mp-motor.acaoDaIA` (sala), sempre sobre
  `golpesPermitidos` (etapa 1). Aliados NÃO usam isso: continuam no `melhorGolpe`/`ordem` que o jogador escolhe.
- Testes: `tests/ia.test.js` (21). Conferido por mutação (status voltando a valer 0,1, imunidade ignorada, buff sem
  teto, treinador enxergando tudo). Simulei 60 lutas completas IA×IA no motor da sala com esperteza de chefe: 0 erros
  e o uso saiu coerente. Isso achou um erro de desenho: o Taunt valia 12 pontos até contra quem só tem golpe de dano.
- **Fora do escopo**: o inimigo não prevê o golpe do jogador (escolhe sem saber), não avalia recuo/HP próprio ao bater,
  não conta golpes de vários acertos, e o alvo é sempre o primeiro do seu lado em pé.

### Etapa 3 — trocas (FEITA, só no single player)
Cada dependência de troca foi ligada ao evento equivalente que já existia. **A primitiva é `ctx.forcarSaida(m, {motivo})`**,
implementada em `batalha.forcarSaida`; o motor (`golpe.js`, via `sairDeCampo`) só PEDE, porque quem tem a batalha é que
sabe o que "sair" quer dizer. Sem o método no ctx (multiplayer) o golpe falha com aviso.
- **Selvagem**: foge, a luta acaba (`B.saidaForcada = 'inimigo'`), sem XP nem dinheiro. **Treinador**: manda outro
  (`regras.proximoDoTreinador`: Roar & cia. SORTEIAM; Wimp Out manda o próximo da fila); o que saiu ganha `vol.retirado`
  e NÃO conta como derrotado — volta depois se ainda estiver de pé. **Alfa, lendários, chefe da semana**: falha.
- **Seu lado**: quem levou o golpe ganha `vol.retirado` e some de `emCampo()`; a luta segue com os outros. Se era o
  último em campo, `B.saidaForcada = 'jogador'` e acaba como fuga. Você (principal) arrastado com aliados vivos vê só
  o botão **⏭ Assistir o turno** (`turn({type:'passar'})`); se eles caírem, a luta termina (`turn()` confere no fim).
  **Wimp Out/Emergency Exit NÃO tiram o seu principal** (decisão do usuário: uma habilidade sorteada não pode te expulsar).
- **`vol.retirado` vive no `vol`**, que `iniciar()` e `endBattle()` zeram: não vaza pro save nem contamina a próxima luta.
- **Decisões de desenho que valem lembrar**: (1) NUNCA chamar `endBattle()` de dentro de um golpe — `turn()` continua
  usando `B` depois; por isso só se MARCA `B.saidaForcada` e o loop para. (2) O inimigo pode ser trocado no meio do turno,
  então `E` virou `let` e é relido de `B.enemy` a cada ação; a ação pendente de quem saiu é pulada (`vol.retirado`) —
  sem isso o Pokémon que saiu bateria no que acabou de entrar. (3) `win()` deixou de fazer `T.atual++`: o próximo é o
  primeiro de pé (`proximoDoTreinador`), senão um Roar deixaria um Pokémon vivo para trás e a fila reencontraria os mortos.
  As bolinhas da equipe (render.js) passaram a contar só `hp > 0`.
- **Regenerator / Natural Cure** agem ao **vencer a luta** (`batalha.habilidadesAoVencer`, chamada quando cai o ÚLTIMO
  da fila, antes de `vencerGen`/`vencerEvento`), em todo o seu lado de pé — inclusive quem foi arrastado. Regenerator
  1/3 do HP (`regras.efeitosAoVencer`, sem passar do máximo).
- **Cartão Vermelho** (`red-card`, ₽3.000, gancho `cartaoVermelho` em segurados.js): quem acerta o portador sai; o
  cartão se gasta. **Eject Button/Eject Pack NÃO foram feitos**: com a saída voluntária vetada no seu principal só
  serviriam a aliados. **Shed Tail** também não (não existe Substitute).
- **Mean Look / Block / Spider Web** (`prende`): `vol.preso` bloqueia o "Fugir" (single e sala); Fantasma é imune.
- **Baton Pass** (`passaBonus`): os estágios (e o Focus Energy) vão para o primeiro aliado em campo e quem usou volta a
  zero; sem aliado, falha. Como você nunca troca, a semântica é "transferir", não "sair e passar".
- **Slow Start** (`inicioLento: 5`, lê `vol.turnosEmCampo`, contado em `fimDeTurno`) e **Stakeout** (`emboscada: 2`, lê
  `vol.recemEntrou`, posto quando o treinador manda outro e limpo em `fimDaRodada`). Stakeout só dobra contra o
  inimigo que ACABOU de entrar — você nunca "entra".
- **Habilidades novas** (209 → 215): regenerator, natural-cure, wimp-out, emergency-exit, slow-start, stakeout.
- **Testes**: `tests/saida.test.js` (13; o ctx é um espião que prova QUANDO o motor pede a saída) + conferência por
  mutação. `batalha.js` não é testável em `node:test` (depende de DOM): foi validada em jsdom com um harness descartável —
  a saída de campo em todos os casos, `turn()` inteiro com o `render()` real (Roar trocando o inimigo no meio do turno,
  você fora e os aliados lutando, luta sem ninguém em campo, vitória com Regenerator) e a quebra proposital da proteção
  `retirado` (o Pokémon que saiu passa a bater no novo: HP 63 em vez de 100).
- **Fora do escopo**: multiplayer (Roar & cia., Regenerator, Wimp Out não valem lá), Eject Button, Shed Tail, Dancer, e a
  IA do inimigo ainda não USA Roar/Mean Look de propósito (vale `IGNORADO` em `notaDoGolpe`).

Também nasceu do trabalho desta etapa: um terceiro teste em `tests/referencias.test.js` — todo ajudante que OUTRO módulo
exporta e que este arquivo chama tem de estar importado. O `nm()` esquecido no render.js (dentro de um `esc(...)`) seria
o segundo `ReferenceError` mudo da semana, depois do `SPR_SHINY` da Sala de Raide.

---

## Itens de raide: "serve contra quem?" (29/09/2026)

Pedido do usuário: descrever o que os itens de raide fazem e para quais bosses servem. O achado que motivou o desenho:
**o prêmio dos chefes é um rodízio (`evento.ev()`), não temático** — o Groudon dá Prisma de Luz (só serve contra chefe com
ponto fraco; ele não tem), o Calyrex dá Célula Zygarde (só serve contra a regeneração do Zygarde), o Rayquaza dá Escama
Abissal (ele não ataca com Água). Olhando o item ninguém sabe se ele presta pra luta de hoje.
- **A fonte é o código.** `js/itens-raide.js` responde "serve contra quem?" lendo `boss.CHEFES` (ponto fraco, regeneração,
  golpe carregado) e `evento.EVENTOS` (os 4 golpes de cada chefe). Como o evento guarda golpes só como NOMES e a resposta
  tem de sair sem rede, `TIPO_DO_GOLPE` mapeia cada golpe de chefe ao tipo; o teste falha se um chefe novo usar golpe fora
  da tabela. Regra de cada item em `SERVE`: "todos" (Ruptura, Interrupção, Escudo, Espelho, Relógio, Fragmento e os
  passivos), por tipo de golpe (Cinza=Fogo, Escama Abissal=Água, Escama do Céu=Voador/Dragão, Cristal Psíquico, Cristal
  Gélido), ponto fraco (Prisma) ou regeneração (Célula).
- **A descrição do item (dados.js) leva o resultado**: `… Um por luta. Serve contra: A, B e C.` É a fonte única mostrada
  na dica dos botões (Arena e sala), na mochila da run e na tabela da ajuda. O texto é ESTÁTICO (dados.js não pode importar
  evento.js: ciclo), mas `tests/itens-raide.test.js` confere descrição × derivado para os 17 itens — mecânica nova de
  chefe que mude a resposta faz o CI acusar o texto velho. Verificado dando um ponto fraco ao Groudon em memória: a lista
  derivada muda e a descrição passaria a mentir.
- **Ajuda dos chefes** (`ajuda-chefes.js` → `htmlItensDeRaide`): duas tabelas (consumíveis e segurados de prêmio) com
  item, o que faz, contra quem serve e quem dá de prêmio (lido de `recompensa` dos chefes).
- **Caixa do chefe** (`linhaItensDoChefe`, Arena e run): separa os itens de raide que VOCÊ tem em "servem" e "não servem
  contra ele". Em co-op/sala a caixa do chefe é outra tela e não ganhou a linha.
- **Erro achado no caminho**: a descrição do Espelho Reverso dizia "inverte a tabela de tipos a seu favor". O motor
  (`boss.danoNoChefe`) aplica a MESMA inversão do Mundo Reverso ao dano que você dá (net ×1/ef): contra quem resiste vira
  super efetivo, mas contra quem é fraco vira resistido. A descrição agora avisa que atrapalha, e um teste prova a
  afirmação no motor. Imunidades (ef 0) não mudam. Contra o Giratina, que já alterna o próprio Mundo Reverso, o item é
  a mesma inversão (não soma).
- **Fragmento Tera** só faz sentido onde há Tera (run, ou sala co-op com run); a Arena e a Sala de Raide não têm gimmicks.
- **Fora do escopo**: esconder/desabilitar o botão do item que não serve no chefe atual (hoje o botão aparece e o motor
  recusa com o motivo; o jogador agora sabe antes pela caixa do chefe), e a linha nova na caixa do chefe do co-op.

---

## Narração do turno na sala (29/09/2026)

Pedido do usuário logo depois de destravar a Raide: "está muito automático a aplicação dos danos, é interessante
mostrar exatamente quem está atacando, pra ter uma noção das ações".
- **O problema**: `resolverTurnoMP` resolve o turno INTEIRO e devolve os eventos como texto; `aoReceberEstado` fazia
  `for (const e of p.eventos) logRaw(...)` — tudo no mesmo instante. No single player nada disso acontece porque
  `ui.say` espera entre as mensagens e `ctx.atacar` anima quem bate. Pior com três Swampert do Hall da Fama: o
  registro dizia "Swampert usou Earthquake!" três vezes e não dava pra saber de quem era qual.
- **Duas partes.** (1) O motor passou a dizer QUEM agiu: `let atuando` + `porConta(ref, fn)` em volta de cada
  `usarGolpe`, do golpe extra do chefe, do item comum e do `fimDeTurno`; `say` põe isso em cada evento (`{txt, cls,
  ref}`). (2) A sala revela as linhas com `PAUSA_NARRACAO` (260 ms) e destaca o cartão de quem age.
- **Quem age é ESTADO, não classe solta**: `sala.atuandoRef`, lido por `cartao()` (que ganhou `data-ref`). A sala se
  redesenha sozinha a cada pulso do anfitrião e a cada troca de presença — com a classe só no DOM, o destaque sumia
  no meio da narração. Verificado forçando um redesenho no meio: o destaque se mantém.
- **`renderSala()` vem ANTES de `narrar()`**: narrar mexe nos cartões que o render acabou de montar. Os botões de
  golpe aparecem na hora, então dá pra escolher enquanto o registro corre atrás (o prazo de 45 s continua valendo).
- **`sala.narrando` é um crachá**: se outra narração começar (ou a sala fechar), a anterior para na hora — senão duas
  narrações escreveriam no registro ao mesmo tempo. Pulso republica com `eventos: []`, então não re-narra.
- **`REDUCED`** (`prefers-reduced-motion`) recebe tudo de uma vez, como antes.
- **Nomes repetidos**: `mp-motor.numerarRepetidos` (puro) numera só os iguais — "Swampert 1/2/3". Fica em mp-motor
  pra ser testável; `montarLado` chama no fim.
- **Limite honesto**: o HP dos cartões já é o do FIM do turno. A foto que chega do anfitrião não tem os passos
  intermediários, então não dá pra animar a barra baixando a cada golpe como no single player — a narração mostra a
  ORDEM e o AUTOR, não o HP caindo aos poucos. Para mudar isso o motor teria de mandar o HP de cada passo.
- **Fora do escopo**: animação de ataque/dano nos cartões da sala (o `hit-flash`/FLIP do single player depende dos
  ids `mon-p`/`mon-e`, que a sala não usa), e a linha "servem/não servem" da caixa do chefe no co-op.
- Testes: `numerarRepetidos` e "todo evento tem autor" em `tests/mp-motor.test.js` (com mutação nos dois). A narração
  em si (DOM) foi verificada em jsdom: 10 linhas saindo em ~5,6 s, destaque passando por A2 → A1 → A0 → chefe, nada
  aceso no fim e o destaque sobrevivendo a um redesenho no meio.

---

## A revisão do multiplayer (29/09/2026)

Pedido do usuário: *"revisar e refazer todo o multiplayer, está muito ruim o design atual, quero uma otimização e
uma evolução no multiplayer, que seja fácil, prático, bom e bonito"*. Era o item "revisão e refatoração completa do
multiplayer" do backlog. Feito em quatro levas, cada uma commitada e testada em separado.

### O ponto de partida (o que estava errado, medido)
`multiplayer.js` tinha **1190 linhas** com menu, rede, autoridade do anfitrião, aplicação no save e todo o HTML
juntos. **Nenhum teste** o cobria — inclusive `aplicarCoop`, que grava XP/HP/dinheiro no save. O lobby era uma pilha
de seções com `<select>` nativos; a escolha do Pokémon existia em **dois lugares** (menu e lobby, com quatro funções
quase iguais); a luta eram cartões de 64 px **sem status nem estágios** (dava pra passar a luta envenenado sem ver);
o prazo do turno era um número em texto. Na rede, o anfitrião publicava a **batalha inteira a cada 4 s** e a cada
escolha de qualquer jogador, e cada pacote recebido reescrevia `#mp-topo` e `#mp-acoes` por completo.

### Como ficou dividido
| Arquivo | Papel | DOM | Rede |
|---|---|---|---|
| `mp-regras.js` | decisões puras: entrada, quem falta, mochila, "por que não dá pra começar" | não | não |
| `mp-rede.js` | canal, envio com fila, pulso, presença, diagnóstico | não | sim |
| `mp-cartao.js` | cartão, placa e a CENA (a Arena importa daqui) | sim | não |
| `mp-resultado.js` | aplicar o fim da luta no save e descontar a mochila | pouco | não |
| `mp-telas.js` | todo o HTML | sim | não |
| `multiplayer.js` | orquestração: entrar/sair, autoridade do anfitrião, ações do `data-act` | — | — |

Três decisões de arquitetura que sustentam isso:
- **A sala mora em `G.sala`**, não num `let sala` de módulo — é a regra do projeto ("estado compartilhado sempre via
  `G.*`") e é o que deixa mp-telas/mp-resultado enxergarem a sala sem importar o orquestrador.
- **A rede nunca importa a tela**: `mp-rede.ligarRender(fn)` recebe o `renderSala` no boot da sala e a rede só chama
  `redesenhar()`. Sem isso haveria ciclo.
- **As telas nunca importam as ações**: quem despacha `data-act` é o `main.js`. Por isso `mp-telas` pode ser o penúltimo
  da cadeia (`mp-regras → mp-rede → mp-cartao → mp-telas → multiplayer`), verificado por `tests/imports.test.js`.

### O que mudou pra quem joga
- **Menu**: duas portas (criar / entrar com código). A escolha do Pokémon **saiu daqui** — acontece no lobby, onde já
  se vê o modo e quem chegou. Morreram `escolherEntrada`, `escolherConvidado` e o `hallEscolha` do menu.
- **Convite**: `📋 código` e `🔗 convite` (link `?sala=XXXX`, montado a partir de `URL_SITE`). O `main.js` lê o
  parâmetro no boot, limpa a barra de endereço com `replaceState` e entra **depois de `iniciarNuvem()`** (antes disso
  não há canal pra abrir). Sem `navigator.clipboard` (http, permissão negada), mostra o texto pra copiar na mão.
- **Espectador** (`entradaTipo: 'espectador'`): `minhasFotos()` devolve `[]`, então a pessoa não entra em lado nenhum;
  `semMochila()` já a cobria de graça; `todosProntos`/`motivoParaNaoComecar` a ignoram de propósito — senão um
  espectador segurava a sala inteira.
- **"Pronto" em todos os modos** (era só da Raide) e **o botão de começar diz por que está apagado**
  (`motivoParaNaoComecar`, puro e testado): quem falta escolher, qual time está vazio, falta de run pro co-op.
- **Config em botões-cartão** e **visível pra quem não é anfitrião** (travada). Antes ele não via configuração nenhuma.
- **Cena de batalha**: `.scene.battle` + `.mon`/`.spr`/`.plate` reaproveitados do single player, em FILAS (até 6×3 não
  caberia no layout de duas colunas de lá) e encolhendo sozinho (`apertada`/`lotada`). Trouxe de graça o que faltava:
  **tipos, status e estágios** na placa (`chipsFor`/`badgesDeTipo` viraram exports de `render.js`).
- **Turno**: barra de prazo (só `style.width`, atualizada pelo relógio — nunca re-render), fichas ✓/⏳ por jogador e
  `📜 turnos anteriores` (`sala.historico`, últimos `MAX_HISTORICO` = 5, só na memória).

### Otimização de rede e render
- **`ping`**: broadcast novo e magro (`turno`, `acoesFeitas`, `prazo`) nas batidas do pulso e a cada escolha. O estado
  completo sai em turno novo, ao sincronizar e a cada `ESTADO_CHEIO_MS` (15 s) como rede de segurança.
  **Compatível com versão antiga**: um cliente que não conhece `ping` ignora o evento e continua se acertando pelo
  estado completo periódico — por isso o pulso leve virou um evento NOVO em vez de um `estado` mais magro (mandar
  `estado` sem `batalha` faria o cliente velho gravar `undefined`).
- **Render por região** (`pintado.topo`/`pintado.acoes`): se o HTML montado é igual ao que está lá, o DOM não é tocado.
- **`renderSala` virou transação**: monta as duas partes e só então escreve. Antes, um erro no meio deixava
  `#mp-topo` novo com `#mp-acoes` velho (o bug do `SPR_SHINY`); o `try/catch` só reportava.
- **`enviar()` com fila**: uma mensagem por vez, pra seis jogadores agindo juntos não virarem rajada.

### O que ficou de fora (de propósito)
- **Troca de Pokémon entre jogadores** — o usuário não a marcou nesta leva; segue no backlog.
- **Roar & cia. em sala**: `ctx.forcarSaida` continua só no single player. Mexeria no `mp-motor`, que está estável e
  testado, e a refatoração era de arquitetura/telas — misturar as duas coisas na mesma leva seria diagnóstico ruim
  depois. Os itens de "Travas, IA e troca de Pokémon" continuam valendo.
- **Animar o HP baixando durante a narração**: continua impossível pelo mesmo motivo de sempre (a foto que chega é o
  fim do turno). A cena nova não muda isso.
- **jsdom não virou teste do CI**: o projeto não tem `node_modules` nem build. O smoke mora em
  `ferramentas/smoke-multiplayer.mjs` e se explica sozinho quando falta o jsdom.

### Como conferir
`node --test` (653 casos, incluindo `tests/mp-regras.test.js` e `tests/imports.test.js`) e o smoke:
`JSDOM=/caminho/node_modules/jsdom/lib/api.js node ferramentas/smoke-multiplayer.mjs`. O teste de verdade continua
sendo duas abas com `python3 -m http.server 3000`.

---

## 🗺 Missões por rota e o editor de rotas (01/10/2026)

Fechou o item **"Missões próprias de cada mapa"** do `docs/backlog.md`. Veio em duas conversas: primeiro um
documento de proposta (`docs/missoes-por-rota.md`, que continua valendo como registro do levantamento e da
revisão), depois o pedido que mudou o desenho — *"acho que o ideal é você criar um sistema onde eu possa escolher
os pokemons da Gen que estão na rota, consiga criar a missão, a recompensa dela por itens e o nome da missão"*,
com a mesma coisa pros Alfas e **uma análise de curva de stats** da rota.

### O que havia antes, e os dois defeitos

36 missões numa tabela à mão em `dados.js`. A revisão achou dois defeitos de verdade:

1. **`scyther` nascia pronta**: `libera` e `objetivo` eram a MESMA condição (`derrotar: 'scyther', qtd: 1`), então
   no turno em que o primeiro caía a missão aparecia e concluía no mesmo laço do `verificarMissoes` — ₽3.000 por
   uma missão que nunca existiu. E estava rotulada como "Safari", onde não há Scyther no pool nenhum.
2. **25 das 36 só eram alcançáveis em Kanto**: as 15 de espécie não tinham `gen`, então em Johto o `libera` nunca
   era cumprido e elas ficavam escondidas pra sempre, inflando o contador de "escondidas" sem caminho nenhum pra
   revelar. Pior nas formas regionais, onde `speciesName` repete (`rattata` de Alola acordava a missão de Kanto).

Os dois agora são cobrados por teste (`tests/dados.test.js`: `libera ≠ objetivo`, e espécie de `alvos` tem de
estar no POOL da rota). Também: a trilha de Alfas cobria 6 dos 9 (faltavam Usina, Ilhas Espuma e Estrada Vitória,
o trecho mais longo da jornada) e a 5ª liberava por `nivel: 20` em vez da rota anterior, anunciando fora de hora.

### A forma: duas camadas de mapa

`dados-mapas.js` é **gerado da PokéAPI** e não deve guardar escolha de desenho. `dados-rotas.js` é **gerado pelo
editor dentro do jogo** e guarda só o desenho: as 180 missões (uma de espécie e uma de Alfa em cada uma das 10
rotas × 9 Gens; o Santuário não tem, é pós-vitória) e os Alfas trocados (`ALFAS`, hoje vazio).

As duas se juntam em **`dados.js`**, que passou a ser o único arquivo que importa `dados-mapas.js` e a exportar
`GENS`. `mapas.js` e `pokedex-conta.js` leem `GENS` **de lá**. Isso foi deliberado: aplicar a troca de Alfa em
`mapas.js` pareceria mais natural (é o módulo do mapa), mas `dados.js` constrói `ZONES` do mesmo array, e a troca
valeria na tela de explorar e não na batalha — ou pior, o contrário, dependendo da ordem de import. Um dono só.

### A condição `alvos`

Única regra nova no motor (`regras.progressoCondicao`): `alvos: [[especie, qtd]…]`. Várias espécies **somam** e
**cada uma tem o próprio teto** — 20 Plusle e 0 Minun dá 8/16, não 16/16, senão a missão de duas espécies viraria
a de uma só com o dobro da conta. `qualquer: 1` é o que o `libera` usa: ver UM dos dois já revela a missão (exigir
os dois a esconderia por azar na ordem do sorteio da rota). O editor **sempre** emite `alvos`, mesmo com uma
espécie só — um caminho de código, não dois. `derrotar` continua existindo para as missões globais.

### O editor (`js/editor-rotas.js` + `js/tela-editor-rotas.js`)

Tela de admin (`navegacao.TELAS` com `admin: true`; `telasVisiveis()` é o único ponto que decide, lido pela barra
e pelo menu ☰ — senão o atalho apareceria num e não no outro, e a própria tela confere `ehAdmin()` de novo).

**A análise de curva** responde ao pedido "ver se está desequilibrada ou justa". O Alfa de cada rota foi sorteado
pelo gerador de mapas sem olhar o pool, então há rota em que ele é um paredão e rota em que é mais fraco que o
capim. A tela mostra, por rota: BST de cada espécie com barra, **mediana** (não média — um Dratini de peso 2 no
pool puxaria a média sozinho), **mediana ponderada pelo peso de aparição** (o que o jogador realmente encontra, e
é contra ela que o Alfa é julgado), espalhamento `max/mediana` com veredito `parelha`/`variada`/`desigual` e quem
está puxando a ponta. Para o Alfa: razão contra a ponderada, veredito `fraco`/`justo-fraco`/`justo`/`duro`/`muro`
(faixa justa 1.15×–1.5×, já contando que `statsDeChefe` dá HP ×2 e +30% no resto) e a **faixa-alvo de BST** pra
procurar candidato — mais "BST 395 contra uma rota de mediana 310" do que "Cloyster nível 24", que não dá pra
julgar. `🔍 Sugerir Alfa` varre a Gen e lista as espécies que caem na faixa, do centro dela pra fora.

**Como a edição chega no jogador** (decisão do usuário entre as três opções apresentadas): rascunho no
`localStorage` + botão `📋 Copiar o arquivo`, que devolve o conteúdo de `dados-rotas.js` pra colar no repositório.
Tabela no Supabase foi recusada: missão é conteúdo estático, buscar isso no boot é rede num caminho hoje
instantâneo, e missão quebrada iria ao ar sem passar pelos testes. O preço combinado é um commit por leva.

**Detalhes que custaram uma linha cada, mas são bug silencioso se faltarem:**
- O `<select>` do Alfa garante a opção do Alfa ATUAL mesmo que `especiesDaGen` não o traga (hoje traz todos os 81,
  conferido). Sem isso, o select mostraria a primeira opção como selecionada e "Guardar o Alfa" trocaria o Pokémon
  da rota sem ninguém pedir.
- `carregarBsts` vai de 8 em 8, não num `Promise.all` de 150: o "Sugerir Alfa" varre a Gen inteira.
- O redesenho assíncrono só acontece se o editor ainda estiver na tela (procura `#ed-saida`), senão quem saiu no
  meio de um carregamento teria o editor desenhado por cima da tela nova.
- `gerarArquivo` é testado **carregando o resultado de volta como módulo** (`import('data:text/javascript,…')`):
  é um arquivo reescrito a cada edição, e um `import` que estoura leva todo o grafo do jogo.

### Balanceamento e o SQL

`PESOS_PONTOS.missoes` continua **120**. O teto do `validar_jornada` subiu de 36 pra **197**
(`supabase/migrations/20261001120000_limite_de_missoes.sql`) — e é 197, não 37, porque `S.missoesFeitas` acumula
quando a jornada segue pro mapa seguinte com o mesmo Pokémon: numa run que atravessa as 9 Gens, todas as 180 são
alcançáveis. O teto é anti-fraude, não balanceamento.

### Ficou de fora desta leva (pedido na mesma conversa)

**Criar e excluir rotas** e **rotas secretas** (abertas por Pokémon capturado/usado, golpe aprendido etc.). A
primeira é CRUD sobre a lista que `mapas.js`, o Santuário, a Pokédex, a caça shiny, o download offline e o
desbloqueio do Roguelike todos leem; a segunda é mecânica nova (condição no save, na tela de explorar e no
progresso), não editor. Escolha do usuário: o editor de missões/Alfas/curva primeiro.

## ⏩ Forjar jornada no painel de testes (02/10/2026)

**O pedido**: "tem como eu como mestre reviver os meus saves que eu perdi pra conseguir continuar analisando
bugs?" — jornadas boas tinham acabado em Game Over.

**Reviver é impossível, e isso é por desenho.** `fim.encerrarJornada` faz `store.del(SAVE_KEY)` e
`apagarSaveNuvem(resumo.id)`; a carreira guarda só o que `montarResumo` monta (estatística, sprite, pontuação) —
nada de mochila, golpes, IVs, rota, `meta.growth`. Não existe lixeira, nem histórico, nem coluna de save morto.
Conferido no banco antes de escrever código: a tabela `saves` não tinha nenhuma linha da conta do usuário (as 12
que o SQL Editor mostrou eram de outras contas — **o SQL Editor roda como `postgres` e passa por cima do RLS**,
a política `save: tudo no próprio` está correta e com a chave anônima ninguém alcança save alheio).

**Então o substituto**: `dev.forjarJornada(nivel)` + botão ⏩ na seção 🧪 de ⚙ Ajustes. Põe o nível escolhido
(`NIVEIS_FORJA` = 20/50/80/100), ₽50.000 e 5 de cada item na mochila **da run em andamento**.

- **Mexe só em `G.S`**, nunca no progresso permanente — é a exceção do painel: não há o que 🧹 limpar depois, a
  jornada forjada termina como qualquer outra e aí sim conta na carreira.
- **Nível direto** (`exp = meta.growth[nivel]` + `regras.recalc`), **golpes** = os 4 últimos do learnset até o
  nível (`api.buildLearnset` já devolve `list` ordenada). Subir por `gainExp` seria o caminho "de verdade", mas são
  ~45 níveis de `say()` (420 ms cada) e um modal "esquecer qual golpe?" por nível: 40 perguntas não testam nada.
- **A evolução, sim, vai pelo caminho de verdade**: `while (await checkEvolution(P))` — uma pergunta por estágio,
  porque é justamente o comportamento que se quer ver ao forjar um nível alto.
- **Itens de raide ficam de fora** (`ITEMS[k].raide`): a mochila deles vira **inventário da conta** no fim da
  jornada (`fim.js` → `darItensDeRaide`), e forja não pode inflar conta permanente.
- Barrado em batalha e sem jornada aberta (o botão nasce `disabled`, e `forjarJornada` confere de novo — regra que
  só existe na tela não é regra).

**Sem teste automatizado**: `dev.js` não importa no Node (cadeia `render.js` → `ui.js` → `matchMedia`), e o que o
forjar acrescenta é um `filter`+`slice` sobre lista já testada mais chamadas a `recalc`/`checkEvolution`, que têm
teste próprio. Não está no README nem nos patch notes de propósito: o painel 🧪 inteiro é invisível pra quem joga.

## 🏋 Itens de treino: zerar EVs, maximizar um IV e trocar de habilidade (04/10/2026)

Pedido do usuário: *"um item para resetar os EVs, tem que ser muito caro e não pode ser possível pegar ele nas
rotas, acho que 250 mil; e o mesmo para um item para maximizar um IV aleatório — o jogador não escolhe, um dos
IVs aleatoriamente é maximizado, mas ele não pode maximizar novamente um que já está em 31"*.

Em seguida, no mesmo dia: *"também um item para mudar a habilidade do pokemon"*.

**Como ficou** (`dados.ITENS_TREINO`): três itens de `price: 250000`, marcados com **uma só** propriedade,
`treino: 'evs'` / `'iv'` / `'habilidade'`. Itens reais da franquia, com o papel que têm lá: o **Fresh Start
Mochi** (Gen 9) zera EVs, a **Bottle Cap** (Treino Intenso, Gen 7) sobe um IV ao máximo e a **Ability Capsule**
troca de habilidade. O mochi não tem sprite no repositório da PokéAPI e cai no ícone de caixinha
(`ITEM_SPR_RESERVA`), como meia dúzia de itens de Gen 8/9 já fazem.

**Decisões**:
- **Uma propriedade com três valores, não três propriedades.** Cada marca nova de item custa uma negação na
  lista de filtros que já existe (a mochila de batalha em `render.js` tem seis) e uma linha em
  `CATEGORIAS_ITEM`/`itemTemEfeito`. Com `treino` guardando os três, cada ponto desses leva **um** `!it.treino` —
  e a Cápsula, que chegou depois, não custou nenhuma linha nesses pontos: entrou pronta na categoria ✨ Especiais,
  fora da mochila de batalha e já recusada dentro da luta. O preço disso é o `SEM_EFEITO` de `itens.js`, que é
  indexado pela MARCA do item: resolvido com `const tipo = it.treino || Object.keys(SEM_EFEITO).find(...)` — as
  chaves `evs`/`iv`/`habilidade` são valores de `treino`, não marcas, e o comentário no arquivo avisa.
- **A regra "não pode maximizar o que já está em 31" é a MESMA conta que decide se o item é usável.**
  `regras.ivsParaMaximizar(m)` devolve a lista de atributos abaixo de 31; `itemTemEfeito` pergunta se ela tem
  alguém e `itens.js` sorteia DELA (`pick`). Duas contas separadas deixariam a loja vender uma tampa de ₽250.000
  pra quem já tem os 6 IVs em 31 — e seria a mesma classe de bug do `golpesPermitidos` (regra que a tela aplica e
  o motor não).
- **IV aleatório, não escolhido** (pedido, e também balanceamento): com escolha, ₽1,5 milhão compraria um Pokémon
  perfeito; sorteado, cada tampa é uma aposta e os últimos IVs custam de verdade. O sorteio é `util.pick` sobre a
  lista filtrada, então ele nunca "perde" uma tampa num 31.
- **`M.ivs` é reescrito por CÓPIA** (`{ ...M.ivs, [s]: 31 }`), nunca em cima. A badge "Potencial máximo" passa
  `pokemon.IVS_MAX` — um objeto **congelado e compartilhado** — pra todo Pokémon criado; escrever nele estouraria
  (ou, sem `strict`, mudaria o IV de todos). Hoje esse caso nem chega aqui (6× 31 = lista vazia = item não
  usável), mas o `Object.freeze` existe justamente pra não depender dessa coincidência.
- **O piso de 1 HP depois de zerar EVs.** `regras.recalc` desce o HP ATUAL junto com o máximo e clampa em **0** —
  252 EVs de HP no nível 100 valem 63 pontos, então usar o mochi com 1 de HP deixaria o Pokémon **desmaiado fora
  de batalha**, estado que nada na tela de exploração sabe tratar. `Math.max(1, M.hp)` logo depois do `recalc`,
  com teste cobrindo que o `recalc` sozinho chega a 0.
- **Bloqueados em batalha**: mexem no HP máximo no meio do turno. Entram na lista de exclusão da mochila de
  batalha (não aparecem lá) **e** recusam em `useItem` — a tela esconde, o caminho confere.
- **Não se acham explorando**: basta não entrar em `FIND_ITEMS` nem em `ITENS_EVO_ACHADOS`. O 🗺 Editor de rotas
  (só admin) continua listando todos os `ITEMS` no seletor de prêmio da rota; não vale uma trava, é escolha manual
  de quem edita o jogo.

### A Cápsula de Habilidade (04/10/2026)
Mesma prateleira, mas com **três diferenças de desenho** em relação à tampa:

- **Aqui o jogador ESCOLHE.** Um IV 31 é melhor que um IV 7 sem discussão, então sortear é a trava de preço; uma
  habilidade é troca LATERAL (Blaze × Solar Power depende do que você está montando), e nesse caso sortear seria
  só perder ₽250.000 sem saber no que. `habilidadesParaTrocar` devolve as outras habilidades da espécie —
  **inclusive a oculta**, que nos jogos é outro item (o Ability Patch). Um item só: dois seria uma distinção que
  este jogo não faz em lugar nenhum, já que a criação também oferece a oculta junto das normais.
- **O modal mostra `IMPL`.** São 251 habilidades com efeito de verdade em 314 reais, e trocar por uma das outras
  97 sem aviso seria pagar um quarto de milhão por "será ajustado em atualizações futuras". As três informações
  do modal (nome, descrição da PokéAPI e "✓ ativa em batalha") são as MESMAS que `criacao.js` mostra na escolha
  original — é a mesma escolha, feita no meio da run. A descrição é buscada com `loadAbility` **antes** de abrir o
  modal, senão a primeira vez seria às cegas (`syncGet` devolve só o que já está em memória).
- **A escolha vem ANTES de debitar a mochila.** O caminho comum de `useItem` faz `S.bag[id]--` e só então entra no
  encadeado de efeitos — cancelar um modal aberto depois disso comeria o item. Então a pergunta sobe pra junto do
  "usar em quem?", que já estava do lado certo, em vez de devolver o item à mochila no cancelamento (restaurar
  estado é sempre a versão errada de nunca ter mexido nele).

Não precisa de `recalc`: habilidade não entra em `calcStats` (o efeito dela é gancho de batalha, lido ao vivo). E
`habilidadeDaEvolucao` continua valendo sem mudança nenhuma — ela decide por **slot** (oculta → oculta, 1ª normal
→ 1ª normal), então evoluir depois de usar a cápsula preserva a troca.

**Ficou de fora**: o requisito de **nível 100** que o Treino Intenso tem nos jogos (não foi pedido, e aqui a run
acaba muito antes de 100 na maioria dos modos) e a **Gold Bottle Cap** (maximiza todos de uma vez) — ela é
exatamente o que o "aleatório" deste pedido existe pra evitar.

### A loja no celular não dizia o que os itens fazem (04/10/2026)
Mesmo pedido, terceira parte: *"quero que a loja no mobile seja melhor, não tem uma descrição clara dos itens na
loja"*. A causa era pequena e específica: o cartão da loja (`render.js`, `G.panel === 'shop'`) punha `it.desc` só
no **`title`** da `<button>` — tooltip de passar o mouse, que **não existe no celular**. A mochila, do lado, já
mostrava a descrição num `<small>` dentro da linha desde sempre; a loja era a única tela de item que escondia.

**Conserto**: um `<small class="item-desc">` dentro do botão (o `title` fica, pro desktop), `.item-btn img` passa
de `grid-row:span 2` pra **`1/-1`** (senão a terceira linha cai na coluna do ícone) com `align-self:start`, e a
grade da loja ganha `.loja-grid` com coluna mínima de **240px** em vez dos 150px da mochila — com 150px e um
texto de 200 caracteres o cartão virava uma tira vertical. No celular isso dá uma coluna de largura cheia.

## ⚔ Saga, fase 1 fechada: identidade de JRPG, 8 perícias e Brecha/Ruína (05/10/2026)

Pedido do usuário: *"Quero que o modo saga seja totalmente inspirado nos RPG's japoneses, de Final Fantasy,
quero que invista e me traga um protótipo muito bom, está muito cru e ainda se parece muito com o jogo inicial
que estamos fazendo, seja criativo, procure referências da internet."*

O diagnóstico dele estava certo e é específico: a Saga tinha MECÂNICA nova (ofício, ameaça, grupo inimigo,
comandar companheiro) e **nenhuma CARA nova**. Mesma cena, mesma grade de quatro golpes, mesmas palavras. Num
jogo de texto, metade de "ser outro gênero" é o vocabulário e o ritmo da tela — e os dois eram do jogo base.

Isto fecha a **fase 1** do `docs/plano-saga.md` (o que faltava: as 8 perícias e o Brecha/Ruína).

### As referências, e por que cada uma entrou ou ficou de fora

Pesquisadas na internet pra este trabalho, não de memória:

| Referência | O que faz lá | O que virou aqui |
|---|---|---|
| **Octopath Traveler** — *Break & Shield Points* | cada inimigo tem N escudos e fraquezas; acertar a fraqueza tira 1, zerar derruba o inimigo (perde a ação, fica fraco a tudo, toma o dobro) | **a forma inteira de Brecha/Ruína**: Guarda = Shield Points, Brecha = o escudo que cai, Ruína = o Break |
| **Final Fantasy VII Remake** — *stagger* | a barra de pressão fica VISÍVEL na placa do inimigo; o "staggered" é a janela pra despejar tudo | a **Guarda desenhada na cena**, abaixo do HP, em escudos contáveis (◆◈◇) |
| **Persona** — *1 More* no crítico | crítico vale tanto quanto a fraqueza | **crítico também abre 1 Brecha** — sem isso o Guerreiro não participaria da abertura |
| **Final Fantasy** (I–X), *menu de comandos* | janela azul de moldura dupla com Lutar / Magia / Item / Fugir (desenho da Kazuko Shibuya) | a **janela de comandos** da Saga: ⚔ Atacar · ✨ Perícia · 🎒 Mochila · 🏃 Fugir |
| **Final Fantasy X** — *CTB*, janela de ordem de turno | a fila de quem age, usada pra planejar | a **fila da rodada** no topo da cena (já existia; ganhou a Ruína e passou a valer com 2 lutadores) |
| **Final Fantasy VII** — *Limit Break* | enche apanhando, estoura uma vez | **ficou de fora**: as 4 gimmicks (Mega/Z/Tera/Dynamax) já são "uma por batalha, não gasta o turno". Seria um segundo ultimate competindo com o primeiro (ver "Ultimate: não construir", `docs/plano-saga.md`) |
| **Bravely Default** — *Brave / Default* | adiantar até 4 turnos tomando dívida, ou guardar | **ficou de fora, e é a decisão mais importante aqui** — ver abaixo |
| **Sea of Stars / Chained Echoes** — timing e combo | apertar no tempo certo reforça o golpe | **ficou de fora**: é mecânica de reflexo num jogo de TEXTO que se joga com leitura, e quebraria no celular e pra quem usa teclado |

**Por que Brecha/Ruína e não Brave/Default.** As duas eram candidatas boas, e a escolha foi por onde elas
TOCAM o código. Brave/Default (e o CTB do FFX) mexem na **economia do turno**: quantas ações cada um tem, e em
que ordem. Aqui o turno é o do Pokémon — prioridade, Quick Claw, velocidade efetiva com clima e terreno — e ele é
lido por **dois motores** (`regras.ordenarAcoes`, usado por `batalha.js` e por `mp-motor.js`). Trocar isso
significaria um segundo sistema de turno convivendo com o primeiro, ou mudar o multiplayer e os cinco outros
modos por causa de um. Brecha/Ruína mexe na **resolução do golpe**, onde já havia o gancho exato de que ela
precisa (`eficacia`, o super efetivo) — e é, além disso, a mecânica que responde ao problema de desenho que a
Saga tinha: **dar motivo pra montar a comitiva por TIPO** em vez de por barra de dano. Virou a decisão nova de
jogo que o modo não tinha.

### Brecha e Ruína (`regras.js`, puro e testado)

- **Guarda** por inimigo: **3** selvagem, **6** Alfa/lendário, **10** chefe da semana (`regras.GUARDA`). Vive em
  `m.vol.guardaMax`/`m.vol.guarda` — `vol` é apagado em todo início e fim de batalha, então **nada vai pro save**.
- **Quem abre**: super efetivo 1, crítico 1, status vindo de fora ½, Marca ½, 🔮 Selo Arcano +2.
- **Ruiu**: `vol.ruina = RUINA_TURNOS` (2), os degraus **positivos** dele vão a zero, e todo dano nele é ×1,5.
  Quando acaba, a **Guarda volta cheia** (como em Octopath: quebrou, aproveitou, o escudo volta).
- **`RUINA_TURNOS` = 2 tem motivo.** A Ruína é marcada NO MEIO de uma rodada, pelo golpe que fecha a Guarda, e
  a contagem cai no fim da rodada. Com 1, derrubar a Guarda com o último a agir não custava **nada** ao inimigo
  (ele já tinha agido). Com 2 ele perde o resto da rodada e a seguinte inteira, que é o "perde o próximo turno"
  do desenho. É o número de afinar se a luta comum ficar fácil demais.

**Onde encosta no motor**: quatro pontos em `golpe.js`, todos pedindo a quem sabe, nunca decidindo. O motor chama
`ctx.abrirBrecha?.(alvo, n)` — **o mesmo padrão do `ctx.forcarSaida`** (o motor PEDE, `batalha.js` faz e narra) —
e lê `regras.multSaga(u, t)` uma vez no dano, que junta Ruína, Muralha e Marca num multiplicador só. O
multiplayer não passa o gancho, então na sala nada disso acontece; e fora da Saga `vol.guardaMax` nunca é
posto, então `multSaga` devolve 1 e o dano é **exatamente o de antes**. Nenhum outro modo muda de comportamento.

### As 8 perícias (`js/pericias.js`, puro e sem imports)

| Ofício | Perícia | O que faz | Recarga |
|---|---|---|---|
| 🛡 Guardião | **Brado de Ferro** | ameaça ×3 por 2 turnos, +1 Def | 3 |
| 🛡 Guardião | **Muralha** | a comitiva toma metade do dano nesta rodada | 5 |
| 💚 Curandeiro | **Bálsamo** | cura ⅓ do HP máximo de quem está mais ferido; a ameaça sobe | 2 |
| 💚 Curandeiro | **Purificar** | tira status, confusão e paixão da comitiva | 4 |
| 🔮 Arcano | **Selo Arcano** | próximo golpe: +2 Brechas e nenhuma resistência o reduz | 3 |
| ⚔ Guerreiro | **Estocada** | próximo golpe não erra e sai crítico | 3 |
| 🕯 Encantador | **Marca** | o alvo em foco toma +25% por 2 turnos, e já perde ½ Brecha | 4 |
| 🎻 Bardo | **Canção de Guerra** | +1 Atk e +1 Vel na comitiva toda | 4 |

**Recarga em turnos, não mana** (decisão do plano, confirmada ao construir): mana é uma segunda barra pra
administrar — e pra encher fora da luta, o que exigiria pousada ou item —, e a Saga já administra HP, PP, itens e
amizade. Recarga é zero UI nova além do número no botão, e a decisão continua sendo "agora ou guardo?".

**Perícia é a AÇÃO da rodada, como um golpe.** Entra em `acoes` no `turn()` com `prio: 0` e a velocidade de quem
usa, e o resto da rodada corre normal. A alternativa (perícia de graça, antes de tudo, como um item) daria quatro
ações por rodada a uma comitiva de quatro e tornaria toda luta trivial.

**Nenhuma reimplementa golpe.** Cada uma chama o que já existia: `efeitos.changeStats` (que é
`golpe.mudarEstagios`), a limpeza de status por escrita direta no `vol`, a cura igual à dos itens, e
`regras.abrirBrecha`. `golpe.js` continua sendo o único lugar que resolve um golpe.

**Só o ofício MAIOR dá perícia.** O ofício menor existe pra LER o bicho ("Curandeiro-Guardião"); se ele dobrasse
o arsenal, um Miltank com quatro perícias faria a comitiva de quatro virar uma de dois.

**Dá pra comandar a perícia de um companheiro** pela mesma fileira que já comandava o golpe (`B.planos[chave]`
passa a aceitar `{ pericia }` além de `{ idx, alvo }`). Sem isso a mecânica seria quase inútil: o Curandeiro e o
Guardião da sua comitiva quase nunca são **você**, e o Bálsamo é metade da tática do modo.

**A trava é conferida no motor, não só no botão.** `usarPericia` reconfere `periciaPronta` — a recarga pode ter
mudado entre a escolha e o turno (o plano de um companheiro é escrito ANTES da rodada rodar), e regra que só
existe na tela não é regra. Mesmo princípio de `golpesPermitidos` e de `golpeDoPlano`.

**Perícia que não teria o que fazer não entra em recarga**: Bálsamo sem ninguém ferido e Purificar sem ninguém
maculado avisam e deixam a rodada seguir. Gastar 2 a 4 turnos de recarga num clique que não fez nada é o tipo de
punição que ensina a pessoa a não usar o botão.

### A cara: janela de comandos, moldura e vocabulário

- **`G.panel = 'comandos'`** é o painel padrão do turno na Saga (`batalha.painelInicial`), e ⚔ Atacar / ✨ Perícia
  são submenus dele. O custo é **um toque a mais pra atacar** — aceito porque é onde ✨ Perícia passa a existir
  como irmã de ⚔ Atacar em vez de um botão perdido embaixo dos golpes, e porque **no celular a janela 2×2 é mais
  BAIXA que a grade de quatro golpes com descrição**. Ela vive em `#actions`, abaixo da cena presa no topo:
  **não esconde nada** (ver a armadilha "não reintroduzir esconder painel por aba" no `CLAUDE.md`).
- **Moldura dupla** (`border: 3px double`) na cena e na janela, azul-noite, `--display` no comando e no nome da
  perícia, `--body` no texto do efeito. **Nenhuma animação nova**: moldura não precisa piscar pra ter cara, e
  `prefers-reduced-motion` já é global.
- **Vocabulário**: "Rodada N" em vez de "Turno N", "Escolha o comando" em vez de "Escolha sua ação", "comitiva",
  "ofício", "perícia", "invoca". Perícia é sempre PT-BR e golpe segue em inglês ("Protect") — é a regra que deixa
  "Muralha" legível ao lado de Reflect sem ser a tradução dele.
- **A fila da rodada** passou a valer com **2** lutadores (era 3), ganhou 💥 e o fim da fila pra quem está em
  Ruína, e **no celular deitado deixou de sumir**: agora encolhe pros ícones. Esconder o elemento que mais ensina
  o turno era pior que encolher.
- **A flag é `jrpg`**, nova em `DIFICULDADES.saga`, separada de `ameaca` e `grupos` de propósito: aquelas duas
  são regras (quem é o alvo, quantos inimigos) e podem valer sozinhas um dia; esta é "o modo se apresenta como
  JRPG". Lida pela FLAG, nunca pelo nome do modo.

### O bug que esta leva achou: comandar companheiro nunca funcionou

A fileira de comandar (entregue em 03/10/2026) desenhava certo — nome, ofício, ✓ de quem já tinha plano — e **o
clique não fazia nada**. `render.js` emitia `data-act="comandar"` e `data-act="comandar-auto"`, e **nenhum dos
dois existia no `switch` do `main.js`**; a função `escolherGolpe`, escrita justamente pra separar "plano de
companheiro" de "minha ação", estava definida e **nunca era chamada** (`case 'move'` ia direto no `turn`).
Ou seja: a funcionalidade inteira estava ligada só de um lado.

É a mesma família do `SPR_SHINY` e do `gimmicksNaLoja` — erro que só aparece pra quem joga, nunca num teste —, só
que num eixo que nenhum teste cobre hoje: **`tests/referencias.test.js` confere função chamada em template
literal, `tests/imports.test.js` confere import nomeado, e ninguém confere `data-act` emitido × `case` tratado.**
Um teste desses é tentador e ficou de fora por ora: o `switch` do `main.js` tem ~150 casos, vários `data-act` são
montados por concatenação (`'ed-' + x`) e outros são tratados por `closest('[data-painel-acao]')` fora do switch,
então a varredura ingênua daria falso positivo demais pra confiar. Está anotado em `docs/backlog.md`.

### Conferido com jsdom

Comitiva de 4 (Alakazam Arcano, Aggron Guardião, Miltank Curandeira, Togekiss Bardo) contra grupo de 3, turnos
reais: a janela de comandos abriu com os quatro botões e a fileira da comitiva com o emoji de cada ofício; a cena
desenhou 3 sprites e 3 placas inimigas, 4 do seu lado, a fila na ordem de velocidade e `🛡 ◆◆◆ 3 de 3` em cada
inimigo; "Rodada 1 · Escolha o comando". O painel de perícia mostrou **1** pro Arcano e **2** pro Aggron. Num
turno só: o plano de Brado do Aggron rodou (recarga marcada, `provocou ×3`, Def +1) e o Selo Arcano ficou
guardado; na rodada seguinte o Psychic selado fechou a Guarda do Machop — *"A guarda de Zubat trinca. (2 de 3)"*,
*"💥 A guarda de Machop se parte — Machop RUIU!"* —, a placa virou `💥 RUIU`, a fila jogou ele pro fim com 💥, e
ele perdeu **duas** rodadas (*"está em Ruína e não consegue agir"*). O Bálsamo da Miltank mirou sozinho o mais
ferido (36 → 76 de 120) e a ameaça dela subiu. Perícia de outro ofício foi recusada sem gastar recarga. Nenhum
render estourou.

### O que ficou de fora de propósito

- **Limit Break** e **Brave/Default** (acima).
- **Seleção manual de alvo aliado**: "o mais ferido" e "a comitiva toda" cobrem as 8 perícias de hoje. Continua
  sendo decisão fechada do plano.
- **Marca escolhendo o alvo**: ela cai em quem está **em foco** na cena, que é o alvo que você já escolhe com um
  toque. Um segundo seletor de alvo só pra uma perícia seria UI nova pra um caso.
- **Ameaça e Brecha no `mp-motor`**: não existe Saga em sala. As funções são as mesmas quando chegar a hora.
- **O mundo da Saga** (trilhas, NPCs Pokémon, facções com reputação): era a fase 3 do plano. **O capítulo 1 foi
  entregue em 13/10/2026** — ver "⚔ Saga, o mundo andável" abaixo. O modo continua `admin: true` até haver mais
  capítulos.

## ⚔ Saga, o mundo andável: capítulo 1, o Vale do Orvalho (13/10/2026)

Pedido do usuário: *"quero inovar, quero criar um mundo de RPG com missões, NPCs, diálogos realistas, missões
secretas, itens, habilidades únicas, um mapa onde eu realmente possa andar"*, com o combate continuando por
turnos. É a fase 3 do `docs/plano-saga.md`, com UMA mudança de rumo em relação ao que estava desenhado: o plano
previa **trilhas em grafo de nós** (estilo Slay the Spire) e o pedido foi um mapa **onde se anda**. Virou grade de
casas com câmera.

**Os quatro arquivos, e por que quatro**: `dados-saga.js` (conteúdo, sem imports) · `saga-mundo.js` (regras
puras, testadas) · `saga-cena.js` (só HTML) · `tela-saga.js` (ações). A cena e as ações estão separadas por causa
do grafo de imports: quem desenha o mapa é o `render.js`, que fica ABAIXO de `batalha.js`; quem começa luta
precisa ficar ACIMA. Um arquivo só fecharia um ciclo.

- **O mundo é uma CAMADA sobre as rotas, não um mundo paralelo.** Cada mapa aponta pra uma rota da Gen da jornada
  pelo índice (`rota: 0`); o mato alto chama `startBattle` daquela rota, o Alfa das ruínas é o `startBossBattle`
  dela. É a decisão que paga todas as outras: níveis escalados, pool, Pokédex da rota, grupo inimigo, modo
  offline (`baixarGen` já cobre — **nenhuma busca nova**) e as 9 Gens funcionam sem uma linha. O preço é que **a
  história nunca cita a espécie de um inimigo** (quem é o Alfa depende da Gen): o texto diz "o Alfa", e o mapa
  mostra o sprite do Alfa daquela Gen. NPC tem espécie fixa porque NPC é só imagem.
- **Mapa escrito em texto** (`grade`: linhas do mesmo tamanho; cada caractere é um tile de `TILES` ou a chave de
  um objeto em `objs`). Legível no diff e editável sem ferramenta. O risco é o de todo conteúdo escrito à mão —
  erro que não estoura, só estraga — e por isso `tests/saga-mundo.test.js` cobra geografia: linhas iguais,
  caractere conhecido, porta com volta, **todo objeto alcançável a pé** e **ninguém encurralado ao chegar por uma
  porta**. Esse último pegou um erro de verdade no primeiro mapa (a NPC da clareira estava na frente da porta).
- **Objeto com VARIANTES**: uma casa pode ter uma lista, e vale a primeira cujo `se` fecha. É o que faz o Alfa
  virar o Coração da Fonte e depois o leito vazio, e a fenda das ruínas deixar de bloquear com a lamparina — sem
  código por caso.
- **Esbarrar é interagir.** Andar contra NPC, baú, placa ou inimigo é o "botão A". Tocar numa casa anda até lá
  por busca em largura (`caminho`), e se o destino bloqueia, o último passo é o esbarrão — no celular, tocar no
  NPC é falar com ele. Zero botão de ação.
- **Diálogo como dado**, na caixa que já existia (`ui.ask`, com retrato): `falas` escolhe por onde a conversa
  começa (primeira entrada cujo `se` vale), cada nó tem `fala`, `faz`, `opcoes` ou `vai`. **Condição** (`vale`) e
  **efeito** (`aplicar`) são puros; o que não é dado puro — mochila, cura, loja, viagem — volta como `pedidos` pra
  `tela-saga` executar. Toda fala vai pro log, pra reler.
- **Missão secreta = missão que o diário não mostra até começar.** O gatilho da do capítulo é falar com o mesmo
  NPC três vezes (`se.falas`), e o caminho é uma **árvore falsa** (tile `t`: desenha como árvore, deixa passar).
  Quem acha a clareira por conta própria entra na missão já na 2ª etapa — por isso o texto dela serve aos dois.
- **Consequência é dado, não sistema**: uma flag fecha um começo de conversa pra sempre (vender o minério ao
  Sableye faz a ferreira recusar o Coração — o final da Forja some), a reputação negativa muda como te recebem, e
  o 3º final só abre com a missão secreta OU sendo Fantasma/Sombrio/Veneno (`se.tipo`: quem você é conta).
- **Dons** (`DONS`, em `m.dons` do SEU Pokémon): os dois de batalha entram em `regras.multSaga`, que o motor já
  lia uma vez no dano (Brasa: ×1,2 em inimigo em Ruína · Casca: ×0,9 no que você recebe); os dois de mapa são
  lidos em `saga-mundo` (Passo de Sombra corta o encontro pela metade · Faro faz a árvore falsa cintilar).
- **Luta que o mapa começou**: `tela-saga` anota `S.saga.luta = { flag }` e `batalha.endBattle(venceu)` — a porta
  única do fim de luta — chama `saga-mundo.fimDaLuta`. Vai no save, então F5 no meio não ganha nem perde a marca.
- **Enquanto anda não chama `render()`**: repinta só a grade (`pintarMapa`) e o render inteiro sai no fim, se algo
  além de andar aconteceu. A cada `PASSOS_POR_EXPLORACAO` casas conta um "passo" de ovo, de evolução por passos e
  de repelente — o mesmo que um clique em Explorar faz.
- **Depois do capítulo**: o guarda abre o Passo do Norte e a jornada segue pela **lista de rotas de sempre**
  (`S.saga.fora`), com um botão de volta ao Vale. É o que impede o capítulo 1 de encolher o jogo: as rotas 4 a
  10 e os lendários continuam alcançáveis enquanto não têm mapa.

**Simplificado de propósito**: inimigo à vista não anda nem reaparece (o mato alto é o grind) · a reputação muda
conversa e final, mas **não** muda preço do mercador nem recruta · Juramentos (fase 2) seguem não construídos ·
o capítulo cobre as rotas 1 a 3. **Sem navegador no Pi**: conferido por `tests/saga-smoke.test.js` (mapa
desenhado, andar, conversa até o fim, baú, pousada, o Passo e a volta), não por olho — a aparência do mapa
(`css/estilo.css`, bloco "⚔ Saga — o mundo andável") precisa de uma olhada em tela de verdade.

**Como escrever o capítulo 2**: mapas e NPCs em `dados-saga.js` (os testes dizem o que faltar); `rota` com índice
novo pede subir o teto no teste; condição ou efeito que ainda não existe = uma linha em `vale`/`aplicar` + teste.

## ⚔ Saga vira jogo de mapa: pixel art, tela própria, capítulos 2–3 e o 🌍 Editor de mundo (13/10/2026, à tarde)

Segunda leva do mesmo dia, em cima da seção acima ("o mundo andável"). O pedido, em quatro mensagens: *sprites
no padrão do Pokémon*, *uma Engine pra eu mesmo criar mapas e missões pelo navegador, tipo RPG Maker*, *uma
história de 10 capítulos*, e depois — vendo o trabalho andar — *layout diferente dos outros modos, bem de jogo,
com animação de parado e de movimento*, *humanos que não são a melhor coisa pros Pokémon (caçadores, crianças
que os pegam pra lutar), mas também humanos que protegem*, *várias opções de sprite pra mesma coisa* e *a mesma
proporção dos sprites 2D da PokéAPI*.

**O que da seção de cima deixou de valer**: a grade de emoji com câmera de 11×9 (`VISAO`, `.saga-mapa`, `.casa`)
foi substituída inteira; o mapa único do capítulo 1 usava as rotas 1–3 e hoje usa só a 1ª; os dons deixaram de
ser dois `if` em `multSaga`. O resto (objeto com variantes, esbarrar é interagir, diálogo como dado, luta que o
mapa começou, missão secreta) continua como está escrito lá.

### A arte: por que LPC, e o que foi descartado

- **Tiles idênticos aos dos jogos só existem arrancados do cartucho.** São material protegido, sem licença de uso;
  não entram no repositório — e o site tem AdSense, que já reprovou uma vez. O repositório de sprites da PokéAPI
  (que o jogo já usa pros Pokémon) diz no próprio arquivo de licença que as imagens são da The Pokémon Company, e
  não tem tile de mapa nenhum.
- **Vistos e descartados**: *Kenney Tiny Town/Dungeon/Ski/Battle/Farm* (CC0, lindos, mas 16×16 — um humano teria
  um terço da altura de um Pokémon do nosso sprite de 96 px; foi o que a mensagem "mesma proporção" decidiu) ·
  *Tuxemon tileset* (CC-BY-SA, o mais "cara de Pokémon", mas é uma folha só de exterior e a página tem uma
  disputa de autoria não resolvida) · *Ninja Adventure* (CC0, enorme, mas 16×16 e o pacote completo só sai pelo
  itch.io) · um conjunto "Zelda-like" CC0 (a página não diz se a arte é original, e traz um personagem que
  lembra demais um personagem conhecido).
- **Escolhido: Liberated Pixel Cup.** Tiles 32×32 e personagens de 64 px — o MESMO grão de pixel dos sprites da
  PokéAPI, então mapa e Pokémon são desenhados na mesma escala inteira (`--u`: 1 no celular, 2 em tela larga).
  CC-BY-SA 3.0 (os de Sharm e Redshrike também OGA-BY): crédito obrigatório, em `img/saga/CREDITOS.txt`, no
  README e no rodapé do 📖 Diário. O atlas é obra derivada e sai sob a mesma licença; o código, não.
- **Humanos vestidos** saem do *Universal LPC Spritesheet Character Generator*: corpo + cabeça + roupa + cabelo
  + capuz + bota, camadas de 576×256 coladas e TINGIDAS no gerador (roupa vem branca e multiplica; cabelo vem
  ruivo e é recolorido pela luz do pixel). É o jeito barato de ter caçador, patrulheira, menino, menina, velho e
  lenhador a partir das mesmas peças. **Os moldes de corpo sem roupa da base nunca viram NPC.**
- **`ferramentas/gerar-atlas-saga.mjs`** baixa as fontes, recorta, monta e escreve `img/saga/atlas.png`,
  `gente.png`, `CREDITOS.txt` e `js/dados-saga-arte.js`. Precisou de um **PNG sem dependência**
  (`ferramentas/png.mjs`, ~100 linhas: o Pi não tem PIL e o projeto não tem dependência nenhuma).
- **O que o LPC não tem e foi desenhado no gerador** (arte nossa, original): flores, mato alto, placa de
  madeira, lápide e o breu das cavernas.

### O mapa guarda terreno; a figura sai dos vizinhos

- **Borda automática** (`saga-arte.js`, puro e SEM imports — o gerador importa dali a ordem das 47 figuras sem
  depender do arquivo que ele mesmo gera): toda folha de terreno do LPC tem o mesmo desenho (bloco 3×3 + quatro
  cantos internos), e as 47 combinações saem de recortar e colar QUARTOS de tile no gerador. Em jogo é uma
  consulta numa tabela de 256 posições. É o que deixa o editor ter um pincel de "caminho" em vez de uma paleta
  de 47 pedaços — e o que mantém o mapa legível como texto.
- **Três campos por tile**: `fundo` (opaco; sem ele vale o do chão do mapa, então a mesma árvore fica na grama
  num mapa e na pedra noutro), `arte` (camadas) e `prop` (enfeite grande). **Tema** (`mapa.tema`) e `mapa.pele`
  trocam esses campos por tile: é como "várias opções pra mesma coisa" entrou sem inventar tile novo.
- **Enfeite grande não tem "tamanho" pro motor.** Árvore e casa são sprites com o pé numa casa; o que bloqueia é
  sempre o tile, casa por casa (a casa de 3×3 é o `c` da porta + oito `h`). Considerado e descartado: guardar a
  pegada no enfeite e calcular ocupação por mapa — o mapa em texto deixaria de dizer a verdade sobre onde se anda.

### A tela de jogo

- **Chão num `<canvas>` pintado uma vez; coisas e personagens como elementos**, com `z-index` pela linha (quem
  está mais embaixo passa na frente). Canvas pro chão porque um mapa de 34×22 são 748 casas com até três
  camadas; elementos pras coisas porque é o `z-index` que dá "andar atrás da copa" de graça.
- **Andar não redesenha nada**: troca `--ex/--ey` (você) e `--cx/--cy` (câmera) e a transição do CSS desliza.
  O `render()` inteiro só sai quando algo além de andar acontece.
- **O seu vulto**: você aparece duas vezes — a de verdade, que passa atrás das coisas, e uma cópia translúcida
  por cima de tudo, na mesma posição. Em campo aberto as duas coincidem; atrás de uma árvore, o vulto é o que
  deixa ver onde você está. (Copa do LPC cobre três casas pra cima: sem isso, duas fileiras de cada borda
  ficariam cegas.)
- **Gavetas por CSS, não por código**: a classe `mundo` em `.game` esconde os painéis de sempre e `data-gaveta`
  mostra um deles como folha lateral. Os painéis não foram reescritos. Em `.game` e não no `body` porque `.game`
  só existe na tela do jogo — a classe some sozinha ao sair. A armadilha "não reintroduzir esconder painel por
  aba" é das abas que escondiam dois terços da tela DE BATALHA; aqui o mapa é o jogo, e foi pedido assim.
- **Animação**: parado respira, andando dá um pulinho por casa, gente parada balança de leve, bando ronda como
  silhueta do Pokémon mais comum da rota, o Alfa é maior e brilha; clarão antes da luta, escurecer ao trocar de
  mapa, letreiro com o nome do lugar. Tudo some com `ui.semAnimacao()`; os efeitos de tela têm opacidade 0 de
  base, senão sem animação um clarão cobriria a tela pra sempre.
- **Ficou de fora**: Pokédex da rota e aviso de repelente na tela do mapa (não há "embaixo do mapa" na tela
  cheia) · NPC que anda · água animada · a tela de BATALHA da Saga continua a de antes.

### O conteúdo: capítulos 1 a 3 e o roteiro dos 10

- **Um capítulo = uma rota da Gen.** É o que faz dez capítulos caberem numa jornada (o 10º é a rota dos
  lendários). O capítulo 1 foi redesenhado na escala nova e encolheu das rotas 1–3 pra só a 1ª.
- **Humanos como o quarto lado** (pedido do usuário), nenhum só vilão: o Nico arma laço porque "quem tem um
  forte come todo dia"; o Tomé caça porque a praga levou o gado; a Lã, a Flaaffy da Bia, QUER lutar — quem quer
  parar é a humana; o Campeão não quer ser solto. O terceiro desfecho do capítulo 2 (mostrar a subida dos peixes
  aos caçadores) só existe pra quem acalmou o Alfa com o unguento em vez de derrubá-lo.
- **`sprite: '@alfa'`**: um NPC que É o Alfa da rota (o Alfa ferido, a Fera da arena) sem citar a espécie.
- **Dons viraram dado** (`DONS[id].dano/ruina/defesa/encontro/faro`): dom novo não precisa de código, e o editor
  cria. Os tetos estão em `saga-validar.EFEITOS_DE_DOM` — é o que impede um pacote publicado de dar ×50 de dano.
- **Missão só anda pra frente.** Sem isso, falar de novo com quem dá a etapa 1 devolveria uma missão que já
  estava na 3; com isso, um nó de fala pode aplicar `missao` sem ter de proteger a si mesmo.

### 🌍 O Editor de mundo

- **Mesmo desenho dos outros editores**: rascunho no navegador, o MESMO pacote e o MESMO publicador
  (`tela-editor-rotas.publicar`), e o arquivo de fábrica pra colar (`js/dados-saga-mundo.js` — por isso o
  conteúdo saiu de `dados-saga.js`, que ficou só com tiles e temas).
- **O pacote ganhou `saga`**, semântica de lista inteira: mapa, personagem e missão se citam por id, e meio mundo
  de um pacote com meio de outro é exatamente a porta pro nada. Aplica na hora, mesmo com jornada aberta: o save
  guarda só ids, e `estadoSaga` recomeça no início se o mapa em que você estava sumiu.
- **Um validador, três leitores** (`saga-validar.js`): o teste da fábrica, a aba ⚠ do editor e
  `conteudo.validarSaga`. É a regra "guarda de tabela nova = guarda igual na validação do pacote", só que por
  construção: não há segunda cópia pra ficar velha.
- **Um tratador de campo pra tela inteira**: cada `<input>` carrega o CAMINHO do que edita
  (`data-ed='["NPCS","anciao","nome"]'`). Condição e efeito são listas de regras com um "+ acrescentar…", não
  JSON na mão. Nada do editor passa pelo `data-act` do `main.js`.
- **▶ Testar é o motor do jogo com outro `ctx`** — o desenho do `golpe.js`: o motor só PEDE (lutar, mochila,
  cura, loja) e quem atende decide. No teste a luta vira "venceu ou perdeu?", não há encontro aleatório, e nada
  encosta em save. Dá pra andar num mapa recém-pintado sem jornada e sem rede.
- **O defeito que o teste de fumaça achou antes de alguém abrir a tela**: trocar de aba gravava um "rascunho"
  igual ao que estava no ar. Rascunho é o que o 📤 Publicar manda — então ele ficaria velho calado e seria ELE, e
  não o mundo publicado depois, que uma publicação por outra tela levaria. Hoje só grava o que mexeu no mundo, e
  sem rascunho vai o que está no ar (`sagaParaPublicar`).
- **Ficou de fora**: renomear id (de mapa, personagem, missão) com as referências junto · importar tileset pelo
  navegador (a figura nova entra pelo gerador) · camada livre de enfeite por cima do terreno · desfazer fora do
  mapa (o ↩ só cobre pintura e objeto).

**Conferido sem navegador** — e isto é um limite, não um detalhe: os mapas foram OLHADOS em PNG
(`ferramentas/desenhar-mapa.mjs`, que usa a mesma escolha de figura do jogo), e as três telas rodam em teste de
fumaça com DOM de mentira. O que NINGUÉM viu ainda é o CSS em tela de verdade: a tela cheia, o HUD, as gavetas,
o deslize da câmera e o layout do editor.

## 👀 O primeiro olhar de verdade na Saga, e os 🧪 testadores (13/10/2026, à noite)

**Navegador no Pi.** O usuário instalou `chromium-headless-shell` (apt; ~800 MB com as 170 bibliotecas — o disco
foi de 1,4 GB a 615 MB livres) e nasceu `ferramentas/olhar.mjs`: sobe o navegador sem janela, fala o protocolo do
DevTools pelo WebSocket do Node 22 (zero dependência), roda JS na página, aperta tecla, clica e fotografa.
Considerado e descartado: Playwright (faltavam 9 das 16 bibliotecas, e pediria sudo do mesmo jeito), limitar a
memória por cgroup (o usuário só tem `cpu` e `pids` delegados) — ficou `choom -n 1000`, que faz o kernel matar o
navegador antes da sessão. Na prática: 20 s por roteiro, memória folgada.

**O que a primeira foto mostrou** (nada disto um teste com DOM de mentira pegaria):
- **Tela quase toda preta.** A câmera era calculada dentro do `render()`, antes de a barra do topo receber os
  botões; a área do mapa media altura 0 e a câmera ia pro pé do mapa. E o tratador de `resize` repintava o chão
  mas esquecia de reposicionar. Virou um `ResizeObserver` na tela do mundo E na barra do topo.
- **Pokémon flutuando** um palmo acima da própria sombra: o desenho não encosta na base do quadro de 96 px.
  O deslocamento foi de −60 pra −46 (medido olhando), e o balão de missão desceu junto.
- **A barra do topo comia 190 px no computador** (duas fileiras de atalhos): na tela de jogo ela fica compacta em
  qualquer largura, com os atalhos no ☰ — `body:has(.game.mundo)`, porque a barra mora fora de `.game`.
- No ▶ Testar do editor o nome saía "Voce selvagem" (`rotulo` não conhece o jogador de mentira): a cena aceita
  quem nomeia.
- **Conferido e certo**: andar e a câmera deslizando, a gaveta por cima do mapa, a caixa de conversa, o zoom 2 no
  computador, o balão "!" do Ancião, a paleta do editor com as miniaturas, o mapa do editor com as letras dos
  objetos, o teste dentro do editor com o vulto atravessando a copa.
- **Não conferido**: batalha começando do mapa (precisa de rede e é lenta no Pi), loja, e a aparência dos emojis
  (o Pi não tem fonte de emoji; na foto viram quadradinhos).

**🧪 Testadores** (pedido do usuário: *"liberar apenas o modo saga para alguns jogadores que eu escolher"*).
- `perfis.beta` + a flag `beta: true` no modo. **`nuvem.podeUsarModo` é o único ponto que decide** — eram três
  cópias de `!x.admin || ehAdmin()` em `criacao.js`, e a quarta nasceria errada.
- **É só a chave do modo.** Testador não vê editor, painel de testes nem o **canal de teste** do conteúdo: joga o
  que está liberado pra todos (ou o de fábrica). Considerado: dar o canal de teste também — descartado por ora
  porque o pacote é UM, e o testador receberia junto rotas, itens e música em teste.
- **No banco**: o gatilho deixa a coluna mudar só quando QUEM PEDE é admin — a mesma pergunta pela API e de
  dentro de `definir_beta` (security definer mantém o `auth.uid()` de quem chamou), sem variável de sessão.
- `beta` é lido numa consulta à parte: junto das outras colunas, a falta da migration derrubaria o perfil
  inteiro, e o admin perderia o próprio acesso até ela chegar.
- **Continua fora dos patch notes**: o teste é "um jogador comum consegue usar?", e testador é escolhido.

## ⚔ Saga: o mapa no celular aproveita a tela (14/10/2026)

Relato do usuário, com print: a faixa da missão cobria o Pokémon ao andar pro norte; em pé sobrava uma faixa preta
embaixo do mapa; deitado, a barra do site + o HUD + a missão comiam um terço da altura.
- **Faixa preta = mapa mais baixo que a tela** (Estrada Velha: 17 linhas × 32 px = 544 px numa tela de ~720). O zoom
  (`saga-cena.zoomDaTela`) deixou de ser só 1 ou 2: se o mapa não enche a tela, sobe o quanto falta, em quartos
  (casa de 32 px cai em pixel CSS inteiro), **com teto 2** — uma sala de 14×8 num celular comprido ficaria
  gigante; a sobra dela é o escuro de fora, como nos jogos. Calculado em `posicionarMundo` (troca de mapa refaz).
- **A câmera desconta o HUD**: `camera(pos, casa, tela, total, folga)` centra você no que SOBRA abaixo da faixa
  e deixa o mapa descer até a beira dela (`folgaDoHud` mede `.hud-missao`/`.hud-local`). Considerado: apagar a
  faixa quando você passa por baixo — mais código e o que está "lá em cima" continuaria escondido.
- **Missão numa linha só** no celular (o texto inteiro está no 📖 Diário, que ela abre).
- **Deitado**: `--saga-topo` vira 0 e a barra do site flutua no canto (só ₽ e ☰, sem logo); o HUD vira UMA fileira
  em grade (comitiva | missão | lugar), e o lugar encosta na barra por `--saga-topo-l` (a largura dela, medida no
  mesmo `ResizeObserver`). Só no mapa e fora da loja (a loja ocupa a tela e ficaria sob a barra); a luta não muda.
- Conferido com `olhar.mjs` em 400×780, 870×390 (com o ☰ aberto) e 1280×800.
- A ✨ que aparece no mapa é o dom **Faro de Quem Espera** marcando uma passagem secreta (tile `falsa`) — já existia.

## ⚔ Saga: o companheiro que vai embora, e as falas reescritas (13/10/2026)

Dois pedidos do usuário logo depois de ver a história inteira: *"o companheiro indo embora, pode colocar, gostei
da ideia"* e *"revise as falas dos personagens, quero algo mais realista e menos enrolado, alguns têm falas
confusas"*.

- **💔 O companheiro que vai embora** (capítulo 9): na entrada do Acampamento do Degelo, cada ordem que você
  feriu (reputação abaixo de zero) chama de volta quem anda com você e é dela. "Ser da ordem" é ter um dos tipos
  que a facção declara (`FACCOES[id].tipos`: Forja = aço/pedra/fogo, Círculo = planta/inseto/fada, Corte =
  sombrio/fantasma/veneno). São duas peças de dado novas: a condição **`aliado: facção`** (há alguém da ordem na
  comitiva) e o efeito **`parte: facção`** (o primeiro da ordem sai de `S.aliados`). É perda de verdade, como a
  bola do treinador; o item que ele segurava volta pra mochila (a ordem chamou o Pokémon, não o equipamento).
  Um chamado por ordem, uma vez só — quem entrar na comitiva depois não é chamado de novo. Sem ninguém daquela
  ordem, o gatilho nem existe. **Não tem confirmação de propósito**: é consequência, não escolha; o que avisa é a
  reputação, que o diário mostra o tempo todo. Quem tem as três ordens em paz (o caminho do final verdadeiro)
  nunca perde ninguém.
- **As falas**: 525 das 533 foram reescritas. A regra nova está em `docs/saga-historia.md` (regra 6): gente fala
  curto e direto — diz o que aconteceu, o que quer e pra onde ir. Saíram os aforismos de fecho de fala ("Pedra
  não negocia. Pedra cai."), as metáforas empilhadas e as charadas; ficaram o jeito de cada um e a informação.
  A média caiu pra 116 letras por fala. **Texto de resposta do jogador, placa, baú e narração de luta não
  mudaram** — o pedido foi sobre as falas; se também estiverem enroladas, é a próxima passada.
- Como foi feito sem quebrar nada: as falas novas moram em três arquivos de troca aplicados por um script que
  acha o nó pelo personagem e recusa texto que perca `{eu}`/`{custo}`. Os testes da história (que conferem o
  CAMINHO, não a letra) passaram sem tocar.

## ⚔ Saga: os capítulos 4 a 10, o fim da história e a 🗺 carta da região (13/10/2026)

Dois pedidos do usuário, no mesmo dia: *"pode seguir com as próximas partes da história também, cap 4 a 10"* e
*"no pin que mostra o nome do local, que seja possível clicar e abrir um mapa mostrando onde você está; onde
você ainda não passou fica bloqueado — dá uma sensação de mistério, tipo ver uma região em que não entrou, mas
tem como, através de uma missão específica"*.

**O mundo de fábrica agora cobre a Gen inteira**: 10 capítulos, **36 mapas**, **100 personagens**, **31 missões**
(9 secretas), 29 dons, 14 itens-chave e **quatro finais**. O roteiro (`docs/saga-historia.md`) foi seguido; o
que mudou ao virar jogo está anotado lá, capítulo por capítulo.

**O capítulo 1 virou tutorial (14/10/2026)**, a pedido do usuário. Considerado: uma tela de dicas à parte, ou o
❓ Tutorial geral (`tutorial.js`) — descartados porque a Saga já tem o que precisa (fala, gatilho, luta no
mapa, missão) e a regra 6 do roteiro pede fala direta, o que serve bem pra instrução. Ficou assim, só DADO:
o **Pichu** foi pra perto da chegada e ensina os controles; o **Cabo Lairon** dá *A lição do Cabo* (Guarda,
Ruína, luta de treino com o bando `treino` na praça, depois Perícia e petisco + 2 Mel Silvestre); um gatilho na
entrada do bosque avisa do mato alto. De fora, de propósito: a passagem secreta (é a secreta do capítulo, não
lição) e Recuar (só aparece com comitiva). O **roteiro completo** sai do conteúdo para
`docs/saga-roteiro.md` (`ferramentas/gerar-roteiro-saga.mjs`; `tests/saga-roteiro.test.js` reclama se o mundo
mudar e o arquivo não).

### A história (o que cada capítulo virou)
- **4 · O Charco dos Esquecidos** — a Corte do Abismo conta o lado dela. O livro-caixa da Forja (lascas de Coração
  vendidas aos humanos) tem **três destinos, com três personagens diferentes na mesa ao mesmo tempo**: a Regente
  (ler em praça), a Dona Chaveira (levar à Brasa) e a Dama Véu (queimar). Secreta: a palafita do sineiro, atrás
  de uma árvore falsa — *ele ouviu os Antigos onze anos antes de todo mundo*.
- **5 · Ferro-Fundo** — cidade dentro da montanha, metade em greve. O piquete só deixa descer quem ouviu **os dois
  lados** (o mesmo desenho do guarda de Pedralume, só que a condição são duas marcas). Secreta: o humano que
  forja as peças finas e nunca perguntou pra onde iam — com a ponta de lança do capítulo 2 ele a reconhece.
- **6 · O Bosque que Anda** — as árvores foram embora e deixaram **covas** (tile novo). Secreta: o Vô Carvalho
  não anda; a licença dele é a PRIMEIRA entrada da conversa da Mãe Meganium, pra valer antes ou depois da
  decisão do bosque (senão a missão ficava sem saída pra quem decidisse primeiro).
- **7 · A Ponte Partida** — o vão do meio é uma placa que bloqueia enquanto NENHUMA de duas marcas existe
  (`sem: [a, b]`): fecha vencendo o Alfa do rio **ou** deixando a árvore do capítulo 6 se deitar. O Tomé chega
  como você o deixou no capítulo 2 (três começos de conversa). Secreta: o Nico, atrás de uma parede falsa.
- **8 · O Deserto de Sal** — a parede dos Primeiros Laços só se lê depois do Alfa. Secreta: o **nó de pano**,
  num nicho cercado de breu cuja única entrada é a parede falsa (`%`, tile novo; o teste confere a geometria).
- **9 · O Degelo** — "a reputação vira gente": cada ordem com reputação ≥ 0 manda quem conversa; abaixo de zero,
  manda **cobrar** (uma luta no lugar da tenda). Vencer os cobradores não traz o personagem de volta — a segunda
  variante do objeto também tem condição. O **conselho pleno** não precisou de condição nova: o Tio do Poço tem
  três começos de conversa com `repAbaixo`, um por ordem, e só o padrão (nenhuma abaixo de zero) liga a marca.
  O Carteiro entrega cartas dos capítulos anteriores, que mudam com o que você fez lá.
- **10 · A Nascente** — os Antigos são os lendários da Gen. Vencê-los não encerra nada: eles **escutam**, e a
  conversa que vem depois é que termina a jornada, num de quatro finais. 🌊 A Cheia sempre existe; ⚒ O Cano e
  🌑 A Sombra dependem de quem liderou a subida; 🪢 **O Laço** pede quatro coisas juntas (a Lia do seu lado, o
  sino devolvido, o conselho pleno e o nó de pano) — e a Dama Véu, no Limiar, mostra quais das quatro você trouxe.

### O que entrou no motor
- **Tipo de luta `antigos`** (`saga-validar.TIPOS_DE_INIMIGO`): chama `batalha.startLendarios` com a rota FINAL
  da jornada, achada pelo que ela tem (`lendarios`), não pelo número — rota é coisa editável. Gen sem lendário
  cai no Alfa, pra história não travar. Figura `'@antigo'` = o último lendário da lista, como `'@alfa'`.
- **Efeito `fim: 'nome do final'`**: `aplicar` guarda em `S.saga.final` e devolve um pedido; quem encerra é o
  `ctx.encerrar` (`encerrarJornada('venceu', { final })`), e a tela de fim mostra "Final da Saga: …". Considerado
  e descartado: uma tabela `FINAIS` — seria mais uma tabela no pacote, no editor e no validador, pra guardar um
  nome que já cabe no próprio efeito. O texto do final é diálogo comum.
- **`batalha.vencerGen` não pergunta nada quando a luta veio do mapa** (`S.saga.luta`, lido ANTES do `endBattle`,
  que apaga a anotação): fecha a Gen, grava `S.genVencida` e devolve o jogador ao mapa. Fechar o jogo ali não
  perde a vitória. A luta dos lendários pela lista de rotas (os outros modos) segue igual.
- **Jornada que termina no meio da conversa**: o `finally` do andar não toca mais em mundo nem em save quando
  `G.S` sumiu. No navegador nada estourava (a tela do mapa já não existe); foi o teste de fumaça que mostrou que
  a ordem dependia disso.
- `viajar` (seguir pra lista de rotas) continua existindo, pra mundo menor publicado pelo editor; o de fábrica
  não usa mais — o Vau ganhou um portão de verdade pro capítulo 4. E não manda mais ninguém pro Santuário.

### A arte nova (sem desenhar nada)
`gerar-atlas-saga.mjs` aprendeu duas coisas: **terreno recolorido pela luz** (`cor`) e **terreno só de
preenchimento** (`soEnche`). Com isso a grama do LPC virou **neve, sal e lodo**; a água, **gelo**; a laje de
caverna, **piso de gelo**. Entraram do pacote: água salobra (o brejo), tábuas de ponte, cachoeira e cova.
Árvore e casa "de sal" são as mesmas figuras recoloridas. Três humanos novos saíram das MESMAS camadas noutra
cor (ferreiro, guerreiro, sábia). Temas novos: `charco`, `sal`, `geleira`; `inverno` ganhou chão de neve.
Tiles novos: `b` ponte (entra na família da água pra ela "continuar" por baixo), `u` cova, `%` parede falsa,
`w` cachoeira — esta é TILE com enfeite e não objeto, porque fica no fundo do lago, onde ninguém chega a pé, e
o validador recusa objeto fora de alcance.

### A 🗺 carta da região
- **A posição dos mapas sai das PORTAS** (`saga-mundo.cartaDoCapitulo`): o vizinho vai pro lado da borda mais
  próxima da porta, alinhado pela casa dela; ocupado, tenta a borda seguinte; só então empurra. Considerado e
  descartado: coordenada escrita em cada mapa — mapa novo do editor nasceria sem lugar, e o plano B dela seria
  exatamente este algoritmo. Então ele é o plano A.
- **O mistério é regra, não enfeite**: lugar não visitado é um vulto com "?" e nome "???"; caminho só é traçado
  entre dois lugares visitados; porta só é marcada quando leva a lugar conhecido; e tile `falsa` sai na cor do
  que ele imita (`finge`). Sem isso a carta desenharia a árvore falsa do bosque.
- **Por onde você passou** (`S.saga.vistos`) é marcado em `estadoSaga`, a porta por onde toda leitura do estado
  passa — nenhum jeito de chegar a um mapa precisa lembrar de marcar. Save antigo começa só com o lugar atual.
- **É um SVG de texto** (um `<path>` por cor, casas emendadas em tiras), não canvas: cabe na caixa `ui.ask` sem
  esperar o HTML entrar na página, e é testável no Node. A cor que chega ao atributo é conferida (o ajuste
  `pele` de um mapa pode vir do pacote publicado).

### Como foi conferido
- **`tests/saga-historia.test.js` JOGA os capítulos 4 a 10**: conversa na mesma ordem do motor, abre baú, vence
  luta e confere o que mudou. É o que o validador não vê (ordem). Achou de verdade: os capítulos 2 e 3 não
  tinham loja, e o 3 não tinha onde descansar — o Lasca e o porteiro Kiko passaram a oferecer.
- Um caso soma a reputação de um roteiro de escolhas LENDO os números dos próprios diálogos, pra provar que o
  final verdadeiro é possível (nenhuma ordem abaixo de zero no capítulo 9).
- **No navegador** (`ferramentas/olhar.mjs`): o fim de ponta a ponta — esbarrar nos Antigos, a luta dos quatro
  lendários começada pelo mapa, a conversa, o final e a tela de vitória com o nome dele —, a carta no celular e
  no computador, e um passeio pelos sete biomas novos sem erro no console.

### Ficou de fora, de propósito
- ~~Companheiro que vai embora no capítulo 9~~ — entrou no mesmo dia, a pedido (seção acima).
- **Reputação mexendo em preço** e **NPC que anda**: seguem no backlog.
- **Consertar reputação no capítulo 9**: quem chega lá com uma ordem abaixo de zero não reúne o conselho nesta
  jornada. É o "consequência é porta fechada" do roteiro; o diário mostra a reputação o tempo todo.
- A frase da tela de vitória ("o mapa da Gen seguinte está liberado") é a genérica de quem fecha uma Gen.

## ⚔ Saga: a luta numa tela só, alavanca, deitado/em pé e sprite 2D (13/10/2026)

Quatro pedidos do usuário depois de ver a tela nova: *sprites exclusivamente 2D neste modo*, *os controles do
celular estão estranhos — um joystick seria melhor*, *responsivo na vertical e na horizontal*, e *em combate
tem que ficar descendo e subindo a tela; quero tudo ali, sem rolar*. Foi a primeira leva FEITA OLHANDO
(`ferramentas/olhar.mjs`): cada ajuste abaixo saiu de uma foto, não de um palpite.

- **Medido antes**: no celular (390×844) a página da luta tinha **3.267 px** de altura. Depois: 844 — igual à tela,
  nos comandos e na lista de golpes; 390 com o celular deitado; 800 no computador.
- **A luta é uma grade em `.game`** (classe `luta`): cena, registro e comandos moram em caixas diferentes, e
  `display:contents` nas caixas do meio os transforma em itens da mesma grade. Considerado e descartado:
  `position:fixed` em cada pedaço (como no mapa) — três caixas fixas precisariam saber a altura uma da outra.
- **A cena é um contêiner de tamanho**, e sprites e placas se medem por ela (`cqw`/`cqh`): a mesma regra serve a
  390×460 e a 500×330. O preço apareceu na primeira foto — a cena virou uma tira de 26 px, porque `.game` alinha
  os itens no começo e um contêiner de tamanho não tem altura própria. `align-items:stretch`.
- **A placa virou uma linha e meia** (nome+nível, tipos na mesma linha, HP embaixo, Guarda numa linha fina):
  com a placa inteira, cinco Pokémon em campo empurravam os sprites pra fora da cena. Do SEU lado o tipo saiu
  (está na gaveta da ficha) — o que decide o turno é o tipo do inimigo.
- **A cena deixou de ser grade de 3 linhas** e virou coluna flexível: a fila da rodada caía na linha do lado
  inimigo e ficava atrás de uma placa.
- **Painel de comandos como bloco**: ele é uma coluna flexível que reparte a altura entre os filhos, e numa
  coluna alta (computador) os botões da comitiva viravam ovais de 110 px.
- **Cena grande dobra o sprite** (`@container`): 96 → 192 px, inteiro. Só dá porque na Saga o sprite é sempre 2D;
  nos outros modos o `scale-down` existe por causa do estilo 3D.
- **🕹 Alavanca** no lugar das quatro setas: segurar e arrastar manda uma direção, e o motor anda enquanto ela
  durar. Quatro direções (o mapa é de casas). `passos()` passou a aceitar qualquer iterável, então o andar
  contínuo é UMA caminhada — antes, cada passo de tecla repetida gravava o save. Tecla segurada usa o mesmo
  caminho (sem depender da repetição do teclado, que tem atraso). Conferido segurando de verdade no navegador:
  andou 12 casas e parou ao soltar.
- **`sprites2d`**: flag do modo, lida num ponto só (`render.estiloDoSprite`). Conferido com o ajuste em "3D": o mapa
  e a luta seguem pedindo o sprite clássico.
- **Deitado**: barra do topo mais baixa, botões do mapa em duas fileiras, missão numa linha; na luta, os comandos
  perdem o subtítulo e o registro encolhe pra duas linhas.
- **Ficou de fora**: a luta dos OUTROS modos (o pedido foi sobre este; lá o layout é o que os jogadores
  validaram) · alavanca flutuante (nasce onde o dedo toca — brigaria com o toque-pra-andar do mapa) · NPC que
  anda · a loja ainda é uma página por cima do mapa.

## 📈 Taxas e probabilidades: uma tela com tudo o que o jogo sorteia (06/10/2026)

Pedido do usuário: *"Crie uma tela no site que demonstra as taxas, possibilidades, o que pode acontecer em tudo
no jogo, exemplo, dados dos poke eggs, taxas de aparição de shinies, probabilidade de itens em rotas e em
pokemons e assim por diante, tudo que puder ter explicações objetivas explique em uma página para os usuários"*.

### A decisão que define a tela: nenhum número é escrito nela

Uma tela de taxas escrita à mão é **pior que nenhuma tela de taxas**. O jogador passa a tomar decisão em cima
daquele número ("não vale caçar fruta nesta rota"), e no primeiro ajuste de balanceamento a página vira promessa
quebrada sem ninguém notar — é exatamente o problema que `tests/docs-numeros.test.js` existe pra impedir no
CLAUDE.md, e ali o público é quem mexe no código, não quem joga.

Então `js/tela-taxas.js` **importa a constante que o sorteio usa** e formata. Onde a constante não existia, ela
foi **exportada de onde o sorteio acontece**, nunca copiada:

| O que faltava | Onde nasceu |
|---|---|
| Os degraus do "Explorar" (10 / 58 / 15 / 7 / 10) estavam como `r < 0.10`, `r < 0.68`… soltos nos `if` | `mundo.CHANCES_EXPLORAR` + um `DEGRAU` acumulado privado, que é o que o `if` compara agora. A tabela ficou mais legível que os números mágicos. |
| A chance do item de evolução achado (`0.2` cru, ao lado de três constantes nomeadas) | `mundo.CHANCE_ITEM_EVO` |
| A faixa do dinheiro achado (`rand(20, 80)`) | `mundo.DINHEIRO_ACHADO` |
| Os degraus de crítico (`[1/24, 1/8, 1/2, 1]` dentro do `calcDamage`) | `regras.DEGRAUS_CRITICO`, e o `Math.min(3, …)` passou a ser `DEGRAUS_CRITICO.length - 1` |

O resto (shiny, manada, equipe do treinador, captura, ovos, clima, pontuação, dificuldades, desbloqueios) já
tinha constante exportada e é só leitura. Algumas linhas chamam a **própria função** em vez de citar a fórmula:
`chanceDeGrupo(i, 10)` desenha a curva rota a rota, `chanceItemDoTreinador(10/30/50/70)` mostra a rampa,
`chancePorBalanco(50/100/200)` mostra o que a fórmula de captura dá na prática, `valorCaptura(...)` dá o exemplo
com HP cheio e com 10%, `passosParaChocar(...)` traduz os ciclos de ovo em explorações. Pesos viram porcentagem
na hora (`EQUIPE_TREINADOR`, `ITENS_DE_SELVAGEM`), então mexer num peso reescreve a tela sozinho.

### Forma

21 seções, cada uma `[título, descrição, linhas]` com as linhas em `[o que, o número, como funciona]`, renderizadas
por uma função de 6 linhas em `table.ranking` (classe que já existia — nenhuma tabela nova de CSS). Índice de
atalhos no topo (`.taxas-indice`), porque a página é longa de propósito: ela é referência, não leitura.

### O que ficou de fora, e por quê

- **O que é exclusivo de admin** (⚔ Saga, 🤖 auto-explorar, editor de rotas): a convenção do CLAUDE.md vale aqui
  inteira — a tela é pra quem joga, e anunciar o que ninguém alcança é promessa. Por isso `modos` filtra
  `DIFICULDADES` por `!d.admin`, derivado, e não uma lista de modos à mão que esqueceria de esconder o próximo.
- **O segredo do brilho** (o que um Pokémon shiny ganha além do brilho): a CHANCE é informação e está na tela; o
  prêmio escondido continua se descobrindo jogando. Mesma regra do README e dos patch notes.
- **A espécie de dentro do ovo**: a seção de ovos explica a mecânica inteira e não revela o que a tela do ninho
  esconde de propósito.
- **A taxa de cada espécie, rota por rota**: são ~1.000 linhas e já existem na Pokédex da rota, que mostra a
  porcentagem exata de onde você está. A tela explica a REGRA (peso ÷ soma dos pesos, e o ×2 do item de evolução)
  e aponta pra lá. O último parágrafo da página é esse ponteiro.
- **Página estática no site** (`CAPITULOS_GUIA`): a tela ficou em `navegacao.TELAS` porque os números precisam ser
  LIDOS do código em tempo de execução. Um capítulo do guia valeria por SEO e seria ~15 linhas em
  `ferramentas/conteudo-guia.mjs` reusando as mesmas seções — não foi pedido, não foi feito.

### Como foi conferido

Além da suíte (878 testes), a tela foi **renderizada de verdade no Node** com o `document` de mentira de
`tests/turno-smoke.test.js` (adaptado pra CAPTURAR o `innerHTML` em vez de descartar), e o HTML de 30 KB varrido
por `undefined`, `NaN`, `null` e `[object Object]`. Foi isso que pegou os dois defeitos que só aparecem desenhando:
o `<` cru de `"Nv. < 20"`, que o navegador lê como começo de tag e **come a célula inteira** (virou "Até o Nv. 19"),
e `32,857142857%` numa tabela de leitura (o formatador passou a dar 2 casas só abaixo de 1%, 1 casa até 10% e
inteiro acima). Também apareceu ali que "Magikarp 100 · a maioria 100" era redundante: 5 ciclos cai no piso de
`PASSOS_MIN` igual aos 20 do padrão.

## 💥 Golpe de área e as habilidades que dependiam de haver mais de um (07/10/2026)

Pedido do usuário, na mesma frase: *"arrumar habilidades como Damp e também fazer moves que pegam em área
começarem a pegar, agora que temos mais de um Poké como oponente"*. As duas coisas são o mesmo buraco. O jogo
nasceu com **um** inimigo (`B.enemy`), e tudo que pressupunha dois ou mais ficou pra depois: `target` da PokéAPI
ignorado, e um grupo inteiro de habilidades (Damp, Telepathy, Friend Guard do lado de lá) sem o que fazer. Quando
🐺 grupo e aliados chegaram, a premissa caiu — mas o código que a assumia continuou lá.

### A raiz: o `CTX` do single player ainda enxergava um inimigo só

`efeitos.CTX.aliadosDe`/`oponentesDe` nasceram assim:

```js
aliadosDe:   m => (ladoJogador().includes(m) ? ladoJogador() : [G.B?.enemy])…
oponentesDe: m => (ladoJogador().includes(m) ? [G.B?.enemy] : ladoJogador())…
```

Aquele `[G.B?.enemy]` é a premissa velha escrita por extenso: do lado de lá existe UM. O `mp-motor` já fazia certo
(ele nasceu com lados de N), então o mesmo motor dava respostas diferentes nos dois modos. **Friend Guard,
Battery, Power Spot, Steely Spirit, Plus/Minus, Bad Dreams, Trace, Frisk, Download, Anticipation e Forewarn do
lado inimigo só viam quem estava em foco.** Nada disso aparecia como erro: aparecia como "a habilidade não faz
nada", que é indistinguível de "não foi implementada".

Hoje são `inimigosEmCampo()` e `emCampo()` — e repare que é **em campo**, não `ladoJogador()`: quem está
descansando no banco não dá nem leva bônus de aliado. O teste de quem é de qual lado passou a ser
`G.B?.inimigos?.includes(m)`, porque `ladoJogador()` já não serve de referência quando o outro lado também é uma
lista.

### `alvosDoGolpe`: a lista de alvos sai dos ganchos que já existiam

A tentação era criar uma API nova no `ctx` (`ctx.alvosDe(u, g)`) e implementá-la nos dois motores. Não precisou:
`oponentesDe` e `aliadosDe` **já estão nos dois ctx** e já dizem exatamente o que o golpe de área precisa saber.
A função nova (`golpe.alvosDoGolpe`) é derivação pura em cima deles, e o multiplayer ganhou área de graça.

As duas famílias de `target` ficam em `dados.js` (não em `golpe.js`) porque **quem mais lê a tabela é a IA**, em
`regras.notaDoGolpe` — e `regras` vem antes de `golpe` no grafo de imports:

- `ALVOS_OPONENTES` = `all-opponents` → só o outro lado (Rock Slide, Muddy Water, Hyper Voice).
- `ALVOS_TODOS` = `all-other-pokemon`, `all-pokemon` → o outro lado **e o seu aliado** (Earthquake, Surf, Discharge).

Dois ficaram **de fora de propósito**, e cada um por um motivo diferente:

- **`opponents-field`** (Spikes, Stealth Rock, Toxic Spikes) parece área e não é: aquilo cai no **lado**, não em
  cada Pokémon. Rodar o golpe uma vez por alvo poria **3 camadas de Spikes numa tacada**. Isso chegou a estar na
  primeira versão do `Set` e foi tirado antes de rodar.
- **`random-opponent`** (Outrage, Thrash, Petal Dance) sorteia UM alvo — que é literalmente o que o jogo já faz.
  Entrar na lista transformaria um golpe de alvo único em área.

### Por que `executar` roda N vezes, e o que NÃO pode repetir

`usarGolpe` faz tudo o que é "uma vez por ação" (PP, status de quem usa, travas de escolha, Protean, o texto
"X usou Y!") e só então chama `executar` **uma vez por alvo**. A alternativa — reescrever `executar` pra receber
uma lista — mexeria em 300 linhas do caminho mais quente do jogo pra entregar a mesma coisa.

O preço é que `executar` tem, no fim, blocos que são **do usuário**, e esses não podem contar por alvo. Os alvos
extras recebem `area.respingo` e pulam exatamente quatro:

| efeito | por quê |
|---|---|
| Orbe da Vida (`seg(u).recuoPorGolpe`) | cobra uma vez por golpe, não por alvo |
| recuo (`meta.drain < 0`) | nos jogos o recuo sai do dano total, uma vez |
| cura (`meta.heal`) | idem |
| queda/subida de atributo do próprio usuário (`mudaOUsuario`) | Make It Rain baixaria o At.Esp. 3× |

E dois ficam **de fora da trava, de propósito**: **dreno** (`meta.drain > 0`) e **Moxie/Beast Boost**
(`aoNocautear`). Nos jogos os dois contam **por alvo atingido** — Parabolic Charge cura de cada um, e Moxie sobe
uma vez por queda. A trava não é "efeito do usuário": é "efeito do usuário que vale **uma vez por golpe**".

O laço também para se o usuário morrer no meio (`u.hp <= 0 && i`): Elmo Rochoso ou Orbe da Vida podem derrubar
quem atacou no primeiro alvo, e um morto não continua batendo nos outros dois.

### `MULT_AREA`: área é alcance, não dano grátis

`regras.MULT_AREA = 0.75`, aplicado **só quando o golpe pega mais de um** (`area.varios`) — como nas duplas dos
jogos. Pegando um só (grupo de um, ou o resto já caiu), sai cheio. Mora em `regras.js` porque é fórmula, e foi
pro teste junto com o resto.

### A IA precisava saber, senão o inimigo se explodia sozinho

Esta é a parte que não estava no pedido e sem a qual o pedido vira um bug. Com área ligada, um Golem inimigo com
dois colegas em campo usaria **Earthquake** e levaria o próprio bando junto — a IA escolhe por `notaDoGolpe`, que
só olhava o alvo. Duas linhas:

```js
const outrosAlvos = Math.max(0, (c.oponentes || 1) - 1);
if (ALVOS_OPONENTES.has(g.target) || ALVOS_TODOS.has(g.target)) nota += outrosAlvos * BONUS_AREA;
if (ALVOS_TODOS.has(g.target))                                  nota -= (c.aliados || 0) * PENA_AREA_ALIADO;
```

`BONUS_AREA = 25` e `PENA_AREA_ALIADO = 35`: a pena é **maior** que o bônus de propósito, porque a nota é "% do
HP do alvo que o golpe vale" e o alvo extra já sai ×0,75 — enquanto o aliado atingido é dano no time dele. O
contexto (`c.aliados`/`c.oponentes`) é preenchido em `batalha.melhorGolpe` e em `mp-motor.acaoDaIA`; chamador que
não passe nada cai em `0`/`1` e a conta some, então nada quebra.

### Damp e Telepathy

As duas estavam na lista de "não implementadas" por motivos que **deixaram de valer**. Damp estava no grupo 4
("mexeria em regra compartilhada") — não mexe: com `ctx.aliadosDe` + `ctx.oponentesDe` já corretos, `quemAbafa()`
é uma linha que varre os dois lados. Telepathy estava no grupo 1 ("sem gatilho equivalente") — o gatilho é
exatamente o que acabou de nascer.

- `abafaExplosao` (Damp): barra `esp.autoDesmaio` **depois** do "usou X!" e de gastar o PP (o golpe foi tentado,
  como nos jogos), e cala o `aftermath` de quem cai. As duas metades da habilidade, não só a primeira.
- `imuneGolpeAliado` (Telepathy): lido em `alvosDoGolpe`, filtrando o aliado da lista. Não é imunidade a dano —
  é não estar na lista de alvos, que é o que a habilidade faz de verdade.

`IMPL.size` foi de 249 pra **251**; `tests/docs-numeros.test.js` cobrou a frase no `CLAUDE.md`, no `README.md` e
aqui, e `tests/habilidades.test.js` cobrou os dois ganchos novos na lista de ganchos conhecidos. As duas redes
pegaram na primeira rodada.

### Os relatos #79 e #80 eram a mesma coisa, e o golpe de área ia piorar

O jogador relatou dois números que não fechavam: "Pokémon derrotados" na carreira marcava **7.595** e a insígnia
*Terror das rotas* contava **6.705**; e o dano total da conta estava em 13 mil depois de cinco Gens.

A causa do #80 estava em `batalha.win()`, uma linha abaixo da outra:

```js
for (const F of caidos) registrar(S, 'derrotados', …);   // laço: cada um do grupo
registrarAbate(S, { … tiposDoAlvo: E.data.types … });     // UMA vez, com o principal
```

A carreira contava 3 numa manada de 3; a conquista contava 1. A diferença de 890 é exatamente o acumulado de
quem jogou com grupo desde que grupo existe. Agora `registrarAbate` roda no **mesmo laço**, e o crédito do golpe
final deixou de ser `B.abate` (um campo só, que guardava a **última** queda da luta inteira) e passou a morar no
próprio caído, em `F.quedaPor` — porque um golpe de área derruba mais de um na **mesma ação**, e um campo único
nunca daria conta.

O #79 é mais simples e tem duas metades. A primeira não é defeito: `registrarDano` nasceu em 01/10/2026, seis
dias antes do relato, e `progresso-conta.bancar` é idempotente por id de jornada — jornada já contada não
reprocessa, então as runs anteriores não têm dano gravado e **nunca terão**. É o preço de "o progresso nunca
encolhe". A segunda é defeito e ia piorar muito com área: a conta era `hpAntes - alvoMeu.hp`, do **foco**, então
todo respingo sumiria do contador. Agora é a soma do lado inimigo antes e depois do golpe, o que também captura,
de graça, dano em quem não era o alvo escolhido.

### O que ficou de fora

- **Escolher o alvo de um golpe de área** na interface: não faz sentido, o golpe já pega todos. A cena continua
  mostrando o foco.
- **`random-opponent`** (Outrage) sorteando alvo novo a cada turno da fúria: hoje ele bate em quem foi escolhido.
  É uma mecânica à parte, não é área.
- **Narração agrupada** ("acertou os 3!"): cada alvo narra o seu bloco, como já fazia. Com `PAUSA_NARRACAO` isso
  lê bem; se virar parede de texto numa manada de 3, aí sim vale juntar.

## 🤝 Golpe de companheiro e de apoio (09/10/2026)

A continuação direta do golpe de área: o `target` da PokéAPI também diz quando o golpe mira o **próprio lado**, e
isso estava sendo jogado fora. Os quatro alvos de companheiro (`ally`, `user-and-allies`, `all-allies` e
`user-or-ally`) moravam todos dentro de `SELF_TARGETS`, então o efeito caía em **quem usou** — Helping Hand e
Coaching não faziam nada ("este efeito será ajustado em atualizações futuras"), Heal Bell curava só o próprio
status e Howl subia só o próprio Ataque.

**Dois golpes faziam o CONTRÁRIO do que prometiam**, e esses não eram efeito faltando, eram defeito: `heal-pulse`
e `floral-healing` têm `target: selected-pokemon` e `meta.heal`, e o motor curava `u` — quem usou, nunca o
parceiro ferido. `decorate` (mesmo alvo, `attack+2`/`special-attack+2`) caía no `else` de `mudaOUsuario` e subia
**os atributos do inimigo**. Nos jogos quem usa escolhe o alvo; aqui o alvo é sempre o inimigo em foco.

**Três conceitos, nenhum sistema novo:**

| conceito | onde mora | o que decide |
|---|---|---|
| `dados.ALVOS_ALIADOS` | tabela, ao lado de `ALVOS_OPONENTES`/`ALVOS_TODOS` | quais `target` miram o próprio lado |
| `regras.golpeDeApoio` | função pura, testada | golpe de status de alvo escolhido cujo efeito é BOM pra quem recebe |
| `dest` em `golpe.executar` | uma linha | quem RECEBE o efeito: o próprio, o alvo, ou o companheiro |

`alvosDoGolpe` continua sendo a única porta da lista de alvos, e por isso o grupo selvagem e o treinador com
mais de um em campo ganharam tudo de graça: `ctx.aliadosDe` já responde pelos dois lados. `user-or-ally`
(Acupressure) ficou **fora** de `ALVOS_ALIADOS` de propósito — lá o próprio é alvo válido, e é o que o jogo já
fazia.

**O que virou código novo em `especiais.js`** (o resto funciona pelo caminho comum, porque os atributos já vêm no
`meta`): `ajudaAliado` (Helping Hand), `chamariz` (Follow Me, Rage Powder), `curaStatus` + `cura` +
`sobeEstagios` (Heal Bell, Aromatherapy, Jungle Healing, Lunar Blessing, Purify, Take Heart), `soAliados`
(Coaching, Dragon Cheer — não pegam quem usou, e sem companheiro falham), `soPlusMinus` (Gear Up, Magnetic Flux),
`statAleatorio` (Acupressure), `focoDragao` (Dragon Cheer vale 2 no Dragão) e `semEfeitoReal` (Hold Hands).

**`semEfeitoReal` existe por honestidade de texto.** A regra do projeto é que efeito ainda não construído diz
"será ajustado em atualizações futuras" — mas Hold Hands **não faz nada nos jogos**, e prometer efeito futuro ali
seria mentir. Uma chave, uma mensagem, zero dívida.

**O chamariz (Follow Me) mora no motor, não em `batalha.turn`.** A primeira versão trocava o alvo na linha onde o
inimigo sorteia quem bater — e aquilo valeria só pro single player e só pro lado inimigo. Movido pro topo de
`usarGolpe`, o redirecionamento vale pros dois lados, vale na sala, e todas as travas abaixo dele (Campo
Psíquico, Dazzling, Pressure) já leem o alvo de verdade.

### O que ficou de fora

- **Ordem do turno**: After You, Quash e Instruct mexem na fila de ações, não no alvo. Continuam dizendo que o
  efeito será ajustado — é outro sistema (reordenar `acoes` no meio da rodada).
- **Ally Switch**: trocar de posição com o companheiro não significa nada sem posições em campo.
- **Spotlight**: é o chamariz ao contrário (marca um ALVO pra ser mirado pelos oponentes DELE). Precisaria do
  chamariz lido também na escolha do seu golpe, o que hoje é a tela, não o motor.
- **Escolher QUAL companheiro recebe**: a cena mostra o foco inimigo, não um seletor do próprio lado. Helping Hand
  e Aromatic Mist pegam o primeiro em pé; os de cura, **o mais ferido** — que é a escolha que o jogador faria.
- **`purify` curando o HP de quem usa** (nos jogos é o usuário que recupera, se curou o status do alvo): aqui a
  cura vai pra quem recebeu a limpeza. Desvio consciente, marcado no comentário da tabela.

## 🔤 A segunda leva de fontes (07/10/2026)

O relato #78 ("Pufavo uma fonte mais bonitinha") tinha sido atendido em 06/10 com três opções por GOSTO ao lado
das seis por legibilidade. Perguntado o que mais caberia "para esse estilo de jogo", o usuário pediu mais opções
em vez de trocar o padrão — que continua sendo Fredoka + Atkinson Hyperlegible, porque quem nunca abre ⚙ Ajustes
é a maioria e legibilidade é a aposta certa pra esse caso.

**Critério: categoria ausente, não "mais uma redondinha".** Já havia quatro arredondadas (Fredoka, Nunito,
Quicksand, Baloo 2) e duas geométricas (Comfortaa, Lexend). As três novas são coisas que a lista não tinha:

| id | o que é | categoria que faltava |
|---|---|---|
| `mplus` | M PLUS Rounded 1c | arredondada de **UI de jogo japonês** (traço cheio, não fina como a Quicksand) |
| `grandstander` | Grandstander (título) + Rubik (texto) | **display saltitante** — a única com personalidade no título e sobriedade no corpo |
| `bitter` | Bitter | **serifa**. Não havia nenhuma, e num RPG de texto é a que mais muda a sensação de ler |

**Nenhuma de peso único, e isso não é detalhe.** O CSS usa `--display` em 500/600/700/800 (`.top-r` é `700`,
`.dinheiro b` é `800`). Fonte com um peso só faz o navegador sintetizar o negrito — engrossar o traço na marra —
e numa display gorda isso borra. Foi o que tirou **Lilita One**, **Titan One** e **Varela Round** da lista de
candidatas, todas com um peso só. Os pesos das três escolhidas foram conferidos um a um batendo na API do Google
Fonts (`curl` na URL que `urlDaFonte` monta, conferindo 200 **e** que o CSS devolvido traz `@font-face` de
verdade) — pedir um peso que não existe devolve 200 com o peso mais próximo, calado, então só o status não basta.

**A regra dos dígitos continua sendo o filtro duro.** 2, 5 e 8 inequívocos, e a amostra da tela
(`Pikachu · Nv. 25 · 2 5 8 · ₽1.250`) existe pra isso. É por ela que **nenhuma fonte pixelada volta**, mesmo
sendo a mais "cara de Pokémon" possível: a Pixelify Sans já foi tentada e saiu por confundir dígito. E não dá
pra contornar pondo pixel só no título, porque `--display` é "títulos **e números**" — o HP, o dano e o dinheiro
saem nela.

Custo: nada no jogo (só a fonte escolhida carrega) e três requisições a mais ao abrir ⚙ Ajustes, que carrega
todas pra desenhar cada opção na própria fonte. O `sw.js` já tinha `fonts.googleapis.com` e `fonts.gstatic.com`
em `EXTERNOS`, então o modo offline pegou as três de graça.

## 👾 A fonte pixelada, e o `target` que o cache nunca atualizava (07/10/2026)

Duas coisas no mesmo pedido, e a segunda é um post-mortem de algo que eu mesmo tinha acabado de quebrar.

### O relato: "Rock Slide deveria pegar em todos, mas não tá pegando"

A área tinha entrado horas antes, com teste passando. O teste passava **e estava certo** — ele usava um `ctx`
fabricado e um golpe com `target: 'all-opponents'` escrito à mão. Nunca tocou no caminho pelo qual o `target`
chega de verdade. Reproduzir foi rodar `batalha.turn()` com o `CTX` real: com `target` presente os dois inimigos
apanhavam; tirando o `target`, o segundo ficava intacto. O código estava certo, o **dado** é que não chegava.

O `target` atravessa três camadas antes do motor, e a do meio não tinha guarda nenhuma:

```js
export const loadMove = url => cached('move:' + lastSeg(url), async () => slimMove(await getJSON(url)));
//                                                                      ↑ nenhum `valido`
```

`target` entrou no `slimMove` em **21/09/2026**. `cached` aceita qualquer registro guardado quando `valido` é
nulo — então todo golpe cacheado antes daquele dia voltava **sem `target`, para sempre**, porque nada o
invalidava. É literalmente a armadilha que o `CLAUDE.md` já descrevia ("campo novo num `load*` entra por
`valido`, não por chave nova"), e ela estava escrita *antes* deste bug acontecer. A regra existia; o campo passou
sem ela.

**Por que ninguém viu em 16 dias:** enquanto todo golpe batia num alvo só, `g.target` não era lido por nada que
mudasse o jogo. O dado estava corrompido e era inofensivo. A área não criou o bug — ela foi o primeiro leitor.

### Três camadas, três consertos

| camada | conserto | por quê |
|---|---|---|
| cache (`api.loadMove`) | `valido: v => typeof v?.target === 'string'` | o registro velho é rebuscado na primeira vez online |
| save (`S.player.moves`) | `pokemon.completarAlvosDoSave`, no boot | **o save guarda uma CÓPIA do golpe, não uma referência** — consertar o cache não conserta quem já está dentro de um save |
| download offline | `VERSAO_DOWNLOAD` 5 → 6 | a lista de buscas não cresceu, o CONTEÚDO de uma delas mudou; sem a marca nova, quem baixou antes joga no avião com área quebrada e sem nunca saber |

A camada do save é a que se esquece. `loadMove` conserta o que o jogo **vai** buscar; o golpe que já está no
`S.player.moves` foi copiado uma vez, no dia em que foi aprendido, e ninguém relê. Por isso a migração no boot,
e por isso ela é **não-bloqueante**: é conserto de dado velho, não pode atrasar o jogo abrir nem derrubá-lo se a
rede falhar (a armadilha "busca não essencial não pode derrubar o fluxo"). Sem rede cada busca falha calada e o
golpe segue como estava — o comportamento de antes, não uma regressão.

**Ela mora em `pokemon.js`, não em `progressao.js`,** e por um motivo que só apareceu ao escrever o teste:
`progressao.js` arrasta `ui.js`, que lê `matchMedia` no corpo do módulo e não importa no Node sem DOM de mentira.
`completarAlvosDoSave` é dado + rede, sem DOM — `pokemon.js` já importa `loadMove` e já é importável no Node.
Quando o teste é difícil de escrever, normalmente é o lugar que está errado, não o teste.

### A quarta camada: o dado parou de depender da rede (mesma tarde)

As três camadas acima foram publicadas e o relato voltou **igual**: *"Rock Slide ainda não está pegando os outros
Pokémon do oponente"* — com 2 ou 3 inimigos na cena e só um apanhando. O motor foi reproduzido de novo rodando
`batalha.turn()` de verdade com dois inimigos: com `target`, os dois apanham. O motor está certo. O que não dá
pra garantir é o `target` ter chegado — **os três consertos dependem todos de REDE**: `valido` só rebusca
estando online, `completarAlvosDoSave` é um `fetch` por golpe, e o download offline pede o mapa de novo. Qualquer
um deles falhando calado (rede ruim, PokéAPI lenta, aba aberta desde antes do deploy) devolve o jogador ao
mesmo lugar, e não há nada na tela que diga qual foi.

O erro de desenho estava uma camada acima de todos eles: **"quem este golpe alcança" não é dado vivo.** O alvo
do Rock Slide não muda nunca; tratá-lo como algo a buscar na internet é o que criou três camadas de migração
pra uma informação que cabe numa tabela. Então ela virou tabela:

```js
export const GOLPE_AREA = { "rock-slide": "all-opponents", "earthquake": "all-other-pokemon", … };  // 84 golpes
```

Gerada pelo `ferramentas/gerar-golpe-flags.mjs` que já existia (um `csv('move_targets.csv')` a mais, mesmo
`moves.csv` que ele já baixava pelas flags), guardada no `dados-golpe-flags.js` que já existia, e lida por
`golpe.alvosDoGolpe` e `regras.notaDoGolpe` com **uma linha cada**:

```js
const alvo = g.target || GOLPE_AREA[g.name];
```

Só os 84 golpes de área entram — o resto é "bate num só", que já é o plano B de quem lê. Com isso a área passa a
funcionar com save velho, cache velho, mapa baixado antes e sem rede nenhuma; as três camadas anteriores
continuam valendo (elas consertam o `target` pra TODOS os usos, não só o de área), mas deixaram de ser o que
sustenta a funcionalidade.

**A lição é a do `try` largo e a do `navigator.onLine`, numa terceira forma:** quando o conserto de um dado
estático depende da rede, ele tem a taxa de sucesso da rede — e falha calado. Dado que não muda vira arquivo
versionado junto do código, não migração.

### A caixa dos lendários vazando pra fora da tela (celular)

No mesmo relato, uma foto: texto quebrando palavra por palavra numa tira de ~80px, sprites atravessando a borda
da caixa e o botão **⚔ Enfrentar** no meio deles. Não eram três bugs — era um só, e de CSS.

`.chefe-box` é um grid de três colunas (`sprite · texto · botão`). A caixa dos lendários trocava a primeira por
`auto` e punha lá a fileira inteira de lendários — **até 10 sprites, nenhum deles encolhível**. Uma trilha `auto`
nunca fica menor que o `min-content` do conteúdo, e o `min-content` de um flex `nowrap` é a SOMA dos itens: ~300px
de trilha numa caixa de 400px, sobrando ~80px pro texto e empurrando o botão pra fora. A página inteira ganhava
rolagem lateral — por isso a foto está com o zoom pra trás e a caixa de cima (a do evento) também parece
espremida: ela estava, pelo mesmo motivo de largura.

Dois consertos, ambos de uma linha:

- a fileira de sprites ocupa a **linha inteira** (`grid-column:1/-1`) e tem `flex-wrap:wrap` — ela deixa de
  disputar largura com o texto e pode quebrar em duas fileiras;
- em tela estreita (≤560px) o **botão desce** pra uma linha só dele, como `.insignia` já fazia desde sempre.

E um terceiro, invisível na foto mas real: `.lend-imgs img{width:44px}` vinha **antes** de `.chefe-box
img{width:64px}` no arquivo, com a mesma especificidade — então todos os lendários saíam do tamanho do
principal, e o destaque do último (o lendário-chefe) nunca aparecia. Agora é `.chefe-box .lend-imgs img`.

### A fonte pixelada: o que mudou não foi a fonte

A Pixelify Sans já tinha estado no jogo e **saiu** por confundir 2, 5 e 8 — a regra mais dura da lista de fontes,
num jogo que mostra HP, dano e ₽ o tempo todo. O pedido de trazê-la de volta não vinha com uma fonte melhor;
vinha com a mesma fonte.

O que mudou foi **onde ela entra**. `--display` sempre significou "títulos **e** números" — as duas coisas na
mesma variável, e é isso que tornava impossível ter pixel sem ter pixel no HP. Agora há `--titulo`, lida só por
h1/h2/h3:

```css
--titulo  →  nome de Pokémon, de rota, de tela        (14 regras de h1/h2/h3)
--display →  nível, HP, dano, ₽, botões, código da sala
```

A separação custou **14 `sed`** trocando `var(--display)` por `var(--titulo,var(--display))`. O fallback é o que
deixou as outras doze fontes byte-a-byte idênticas: nenhuma define `--titulo`, então todas caem no `--display` de
sempre e não precisaram saber que a variável existe.

Antes de separar, a verificação que decide tudo: **nenhum h1/h2/h3 do jogo mostra número.** `.pv h2` é o nome na
prévia (o `Nº 0025` está num `<p class="dexno">` acima), `.ficha-me h2` é o apelido (o `nível 25` está num
`<p class="sub">`), `.zone-head h2` é o nome da rota. Os números todos moram em classe própria. Se um único
deles tivesse número dentro, a separação não funcionaria e a resposta teria de ser "não dá".

`aplicarFonte` **remove** a propriedade quando a fonte não tem `titulo`, em vez de só não setá-la: ela fica no
`style` do `<html>` e sobreviveria à troca, deixando título pixelado numa fonte que não pediu nada disso.

A combinação é deliberadamente de três famílias: Pixelify Sans no título, **IBM Plex Mono** nos números (ar de
console, dígitos impecáveis) e **Atkinson Hyperlegible** no texto corrido — a narração da batalha é o que mais se
lê no jogo e não podia virar refém da estética. Duas das três já estavam no projeto.

`tests/ajustes.test.js` tranca a regra pelos dois lados: nenhuma fonte pode ter pixelada em `display` ou `corpo`
(varre uma lista de nomes conhecidos: Pixelify, Press Start, Silkscreen, VT323, Jersey, Micro 5), a Pixelada tem
de manter `titulo` pixelado, e o CSS tem de manter o fallback. Sem esse teste, a regra do projeto some no dia em
que alguém achar que "fica legal".

### O que ficou de fora

- **Press Start 2P**, a fonte de arcade mais reconhecível: largura fixa e enorme, estoura um `h1` de
  `clamp(34px,5.5vw,60px)` com `max-width:14ch`. Peso único também.
- **Avaliar os dígitos olhando**: este ambiente não tem navegador nem PIL (`CLAUDE.md`). A escolha foi feita
  tirando o risco por construção — prender a pixelada onde número não passa — em vez de apostar que os dígitos
  de alguma pixelada seriam bons o bastante. É mais barato garantir que medir.

## 🐉 O chefe de raide que era o mais fácil, e a sala que lutava em silêncio (07/10/2026)

Relato #81, literal: *"Parece que a mecânica de expor fraqueza não é para esse Boss, foi muito fácil a luta.
Lutando contra o mega Rayquaza com 2 Mewtwo e um Cloyster, o Cloyster usou Shell smash e depois Icicle Spear, não
apareceu o aumento de status e nem o dano do próximo golpe dele. Também as animações do Boss parecem estar fracas
e bugadas, achei muito facil"*.

### O que foi DESCARTADO no diagnóstico

A acusação mais concreta era o Shell Smash. Testei a hipótese antes de ler código: montei um Cloyster, um Mega
Rayquaza preparado por `prepararChefe`, e rodei dois turnos de `mp-motor.resolverTurnoMP` (o motor da Sala de
Raide) num script descartável. Shell Smash narrou as cinco linhas certas, `vol.stages` ficou
`{attack:2, special-attack:2, speed:2, defense:-1, special-defense:-1}`, e o Icicle Spear do turno seguinte saiu
com o estágio aplicado e o estágio **sobreviveu** ao turno. A suspeita de que `mudarEstagios` falhasse calado tem
fundamento — ela começa com `if (!(c.stat in m.vol.stages)) continue;`, que é exatamente "não faz nada e não
diz" — mas `fotoDoMon` dá `vol: freshVol()` e `mp-sanear.saneado` preserva objeto, então nunca chega lá vazio.
**Não havia bug de Shell Smash.** O que havia era o jogador vendo o golpe fazer menos diferença do que devia,
porque o chefe caía rápido de qualquer jeito.

### A causa real: `mult` copiado da ficha errada

O Mega Rayquaza é o **único dos 16 chefes sem couraça** (`coura: null`), e isso é de propósito e testado: o
quebra-cabeça dele é a janela do `pontoFraco`, que gira a cada 2 ações. O erro foi o número: `mult: 1.75` tinha
sido copiado do Mega Mewtwo e do Kyurem Negro, que **têm** couraça — e lá `danoNoChefe` multiplica os dois
(`0.5 × 1.75 = 0.875`). Sem couraça o 1,75 ficava solto. Pior: os cinco tipos da janela (Gelo, Pedra, Dragão,
Elétrico, Fada) são justamente as fraquezas naturais de Dragão/Voador, e Gelo é **×4** — então o multiplicador do
chefe empilhava em cima de uma efetividade que já era enorme. Daí "foi muito fácil" com um Cloyster.

Medido em `danoNoChefe(chefe, 100, tipoDaJanela, 2)` nos 16, acertando a janela:

| chefe | leva | | chefe | leva |
|---|---|---|---|---|
| **rayquaza-mega** | **175** | | arceus | 80 |
| mewtwo-mega-y | 87 | | calyrex / terapagos | 50 |
| kyurem-black | 87 | | mediana do elenco | ~45 |

Duas a quatro vezes mais mole que o resto. Os números viraram `mult: 0.9, contra: 0.25` — o **líquido** que os
irmãos dele já tinham, sem inventar mecânica nova.

**O que foi considerado e não feito:** dar couraça a ele (apaga a identidade do chefe e reescreve 3 testes) e
criar um campo `reducao` que valesse sempre pra quem não tem couraça (mecânica nova, código novo e um segundo
jeito de dizer a mesma coisa). Trocar dois números numa tabela que `danoNoChefe` já lê resolve igual.

O guarda é uma **regra**, não o número: `tests/boss.test.js` → *"nenhum chefe leva MAIS que o dano cru fora da
Ruptura"*. É a invariante de desenho que o Rayquaza violava — só a 💥 RUPTURA aumenta dano; couraça e ponto fraco
só reduzem. Varre os 16, então chefe novo com o mesmo engano não passa. (O teste zera `boss.ultimoTipo` entre as
duas medidas: `danoNoChefe` **guarda** o tipo do golpe pro `adapta` do Terapagos, e sem zerar a segunda medida
vinha reduzida e o assert da Ruptura falhava — num código certo.)

### "As animações do Boss parecem estar fracas e bugadas"

Não estavam fracas: **não existiam**. `efeitos.CTX` tem `tremer`, `atacar`, `atualizar` e `pratos`; o ctx do
`mp-motor` tinha só os ganchos puros. O motor já chama tudo como opcional (`(ctx.tremer || nada)(t, g.type)`),
então a sala lutava em silêncio absoluto, com os cartões parados — a única tela do jogo assim. Com um chefe de HP
alto, isso faz a luta parecer travada.

O motor é **puro e roda só no anfitrião**: quem tem tela é cada cliente, que recebe a lista de eventos. Então a
tremida tinha de viajar. A primeira tentativa foi um evento próprio (`{tremer: ref, tipo}`) — e **quebrou 5
testes na hora**, porque `historico`, `arena.js` e os testes todos fazem `e.txt.includes(...)`/`esc(e.txt)` sem
perguntar. Era a lista de eventos ganhando uma segunda forma, e cada consumidor tendo de aprender a filtrar.

A versão que ficou mantém **uma forma só**: `ctx.tremer` guarda `tremendo = {tremer: ref, tipo}` e o próximo
`say` pendura isso na linha que ele cria. Funciona porque no `golpe.js` todo `ctx.tremer` é imediatamente seguido
de um `ctx.say` (é a linha "X perdeu N HP"), e semanticamente fica mais honesto: *esta* linha sacode *aquele*
cartão. Zero mudança em `arena.js`, no histórico e nos testes existentes.

Do lado da tela, `ui.shake` foi partido em dois: `tremerEl(el, tipo)` faz o trabalho num elemento que o chamador
já tem, e `shake(m, tipo)` passou a ser a casca que resolve o sprite por `idDoMon`. A sala não tem sprite com id
— tem cartões `[data-ref]`, os mesmos que `marcarAtuando` já varria —, então `multiplayer.tremerCartao` faz
`querySelectorAll('[data-ref=…]')` com `CSS.escape` e chama `tocarImpacto(tipo)` ao lado. As duas metades já
perguntam sozinhas a `semAnimacao()` e ao ajuste de som.

### O que ficou de fora

- **`atacar` (o pulinho de quem usa o golpe) e `pratos` (o anel do Arceus) na sala.** Seguem só no single player.
  Dariam mais dois eventos pendurados e o ganho é bem menor que o da tremida, que é o que dá peso ao impacto.
- **Animação na Arena.** Ela usa o mesmo `mp-motor`, então a linha do dano já chega com `tremer` — mas a Arena
  reconstrói a cena inteira a cada turno a partir de `arena.log`, não narra linha por linha. Ligar lá é mudar o
  laço de desenho dela, não aproveitar este. O campo está lá quando alguém quiser.
- **Rever o balanço dos outros 15 chefes.** O teste novo diz que nenhum deles viola a invariante; se algum está
  fácil ou difícil demais dentro dela, é afinação, e afinação se faz com relato na mão.

## 🔔 Lembretes por push: chamar de volta quem parou (08/10/2026)

**O pedido** (do usuário, 08/10/2026): "mandar mensagem para lembrete os jogadores que os pokémons estão esperando
eles para terminar uma aventura, também se estiver faltando pouco para fazer uma missão da conta, chamar o jogador
para finalizar a missão" — e, na mensagem seguinte, "entre outras mensagens que podem ser legais do usuário receber,
tipo novos patch notes e etc". O objetivo declarado é retenção: trazer de volta quem abandonou no meio.

**A pergunta que decidiu a arquitetura:** lembrete que só aparece ao ABRIR o jogo não traz ninguém de volta — ele só
é visto por quem já voltou. Então o pedido só se cumpre com **Web Push** (notificação com o jogo fechado), e isso
implica servidor, chave VAPID e cron. O usuário escolheu essa via sabendo dos três passos manuais.

### A decisão central: o servidor não conhece regra de jogo

O caminho óbvio seria a Edge Function varrer `saves` e `progresso` e decidir sozinha quem está perto de uma badge.
Isso significaria reimplementar `badges.js`, `ovos.js` e o calendário de `evento.js` em Deno — **duas verdades sobre
as mesmas regras**, e a cópia que roda no servidor é justamente a que `tests/` (Node, sobre `js/`) nunca vê. É o
mesmo problema que `tests/schema.test.js` existe pra policiar nos pesos de pontuação.

Então inverteu-se: **o cliente escreve o lembrete pronto e o servidor só entrega.**

- `js/lembretes.js` (puro, sem imports, testado) decide **o que dizer e quando**.
- `notificacoes.agendarLembretes` roda a cada sessão (no `then` do `iniciarNuvem`, sem `await`), junta o que as
  regras de verdade respondem (`G.S`, `badgesDaCarreira()`, `evento.fimDaSemana`) e grava em `lembretes`.
- `supabase/functions/lembretes` pega o que está na hora e manda o título e o corpo que já vieram escritos.

O preço, consciente: o lembrete é escrito com o que se sabia na **última sessão**. Como o jogador não está jogando,
nada mudou mesmo — e cada sessão nova reescreve a linha (com `enviado_em: null`, que é o reset).

### Um lembrete por pessoa, não um por motivo

Três notificações no mesmo dia desinstalam o jogo. Por isso os motivos **competem** em `motivoDeVolta` e o mais
atraente leva: **ovo quase chocando > badge a 90% > o parceiro parado na rota**. O chefe da semana é o único que
anda em paralelo, porque não depende de haver jornada aberta. E a função de envio manda **no máximo um push por
jogador por giro** — um `Map` por `user_id` sobre a lista ordenada por `quando`.

Prazos: `HORAS_PARADO` = 10 com jornada aberta, `DIAS_SEM_RUN` = 7 sem ela (aí é convite, não cobrança) e
`FALTA_POUCO` = 0,9 do alvo da badge. Como o `quando` conta **de agora**, quem joga todo dia nunca chega a receber
nada: a linha é reescrita antes de vencer. O prazo de parado começou em 3 dias e virou 10 horas a pedido do usuário
(08/10/2026): 3 dias é quando a pessoa já esqueceu o jogo, e o lembrete existe pra pegar a jornada ainda quente.

**Hora de gente, não hora do prazo (`emHoraBoa`, 08/10/2026 — removida em 09/10/2026):** a primeira versão só deixava
o push saír das 7–9 h e das 15–22 h, empurrando pra frente quem caía fora da janela. A ideia era não incomodar de
madrugada — mas o usuário relatou o efeito colateral: dormiu com três ovos no ninho, os três chocaram de noite, e
não recebeu NENHUM aviso, porque o `quando` do lembrete tinha sido empurrado pra manhã seguinte (e por essa hora o
jogador já tinha aberto o jogo sozinho, sem o push ajudar em nada). A janela protegia de um incômodo que o próprio
usuário disse não querer ser protegido — pedido explícito foi "pode mandar a qualquer momento". `emHoraBoa` e
`JANELAS` foram removidas de `lembretes.js`; o único limite que resta é o **cron, que gira de hora em hora**
(`supabase/LIGAR-LEMBRETES.sql`), e é por isso que o corpo do lembrete do ovo continua sem contagem de minutos.

**O ovo é o único motivo com hora de verdade** (e foi o que motivou a mecânica de relógio, abaixo): ele anda sozinho,
então `motivoDeVolta` devolve `emMs` = `falta × MS_POR_PASSO` e o lembrete é agendado pro minuto em que o ovo fica
pronto, não pro prazo de parado. O corpo dele **não tem contagem**: com a janela empurrando a entrega (e o cron
girando de hora em hora), um "faltam 25 min" escrito na última sessão chegaria horas depois mentindo — então diz
"ele já deve estar pronto, e abre na hora em que você voltar ao jogo", que é a verdade (o choco acontece no cliente).
O número de verdade mora na tela do ovo, onde é recalculado a cada render.

## 🥚 O ovo também choca no relógio (08/10/2026)

**O pedido** (do usuário, na mesma conversa dos lembretes): "para cada minuto offline, o ovo avança em um ponto,
quando estiver prestes a chocar, manda uma mensagem". É a outra metade do mesmo laço de retenção: o lembrete precisa
ter o que anunciar, e um ovo que só anda quando o jogador está jogando nunca dá motivo pra ele voltar.

**Um minuto de relógio (`MS_POR_PASSO`) é um passo, e os dois caminhos SOMAM.** `andarOvos` (exploração) continua igual; `andarNoTempo`
credita os minutos desde o marco. Com o piso e o teto de passos que já existiam (`PASSOS_MIN` e `PASSOS_MAX`), o ovo passa a chocar em 1h40 a 6h40 de
relógio — e antes disso pra quem está explorando.

As três decisões que o desenho precisou tomar, todas com teste:

- **Marco POR OVO (`ovo.em`), não um `S.ovosEm` global.** Ovo posto agora não pode receber crédito pelas três horas
  em que o jogador esteve fora antes de ele existir.
- **`em += n * MS_POR_PASSO`, nunca `em = agora`.** Jogar fora os segundos quebrados a cada crédito faria um ovo
  creditado de 30 em 30 s não andar NUNCA — e `cuidarDosOvos` roda a cada exploração, que é bem mais frequente que
  um minuto.
- **Relógio pra trás é ignorado** (`n <= 0`). Fuso, correção de hora e o relógio adiantado de propósito existem;
  ovo que desanda, não.

**Onde o crédito entra:** `cuidarDosOvos` ganhou `{ explorando }`. Em `main.abrirJornada` ela é chamada com
`explorando: false` — o ovo que ficou pronto com o jogo fechado **nasce ao abrir**, com a narração de sempre, e
abrir o jogo **não** vale uma chance de `CHANCE_OVO` (cinco aberturas seguidas seriam cinco sorteios de ovo novo sem
explorar nada). Na exploração ela roda com os dois caminhos, porque o marco precisa andar também com o jogo aberto:
senão o tempo da sessão inteira sairia de uma vez na próxima abertura.

**A tela diz os dois.** `render.blocoOvos` mostra "faltam 90 passos (1 h e 30 min sem jogar)" e explica que o passo
vem de exploração **e** de minuto — barra subindo sozinha sem explicação parece defeito. A formatação do tempo é a
mesma função do push (`lembretes.emQuantoTempo`), porque dois formatadores diriam números diferentes pro mesmo ovo.
Na 📈 Taxas entrou a linha "Passo pelo relógio", com os limites calculados das constantes, como todas as outras.

### O que ficou de fora

- **Creditar com o jogo ABERTO e parado** (um `setInterval` adiantando a barra na tela). O crédito acontece ao abrir
  a jornada e a cada exploração; com o jogo aberto, explorar é justamente o que o jogador está fazendo. Um timer só
  pra animar a barra é trabalho em troca de nada.
- **Teto de crédito por volta.** Quem volta depois de uma semana choca todos os ovos de uma vez, e está certo: o
  tempo passou de verdade, e `passos` já é travado em `alvo`.

### O que o desenho protege

- **O ovo continua secreto.** `ovoQuaseChocando` devolve só `falta`; `ovo.especie` não é lido. Notificação é tela
  que o jogador não pediu — vazar ali é pior que vazar no jogo. Tem teste.
- **Desligar desinscreve de verdade.** `desligarNotificacoes` chama `cancelarPush()`: só gravar a preferência no
  `localStorage` deixaria o servidor mandando push pra quem desmarcou (o envio é por aparelho inscrito, não pela
  chave local). A ordem é apagar a linha **antes** do `unsubscribe` — ao contrário, uma rede ruim deixaria o
  endereço morto no banco pra sempre.
- **Endereço morto é apagado**, mas só em 404/410. Um 403 é chave VAPID trocada, e o aparelho se reinscreve sozinho
  na próxima vez que o jogo abrir — apagar ali seria desinscrever todo mundo por um erro de configuração.
- **A chave da linha é lista FECHADA no banco** (`check (chave in ('volta','chefe','aviso'))`). A semântica é "um
  lembrete por motivo", não "uma fila": sem a trava, uma conta gravaria dez mil linhas com chave inventada.
- **`publicar_aviso` é a única `security definer`** daqui, porque é a única que escreve na linha de outras pessoas.
  Dupla trava: `perfis.admin` (protegido contra autopromoção desde 20260925090000) e só pra quem já tem push
  inscrito — criar linha pra quem não recebe nada é encher a tabela de lembrete que nunca sai.
- **Só o cron chama a função.** `verify_jwt` sozinho aceita o JWT de qualquer jogador logado; o `Authorization` é
  comparado com a service role key.
- **O `push` do service worker nunca estoura.** Payload estranho cai num `catch` que usa o texto cru — sem isso o
  Chrome mostra o genérico "Este site foi atualizado em segundo plano", que é pior que não avisar. E o clique
  **foca a aba que já existe** em vez de abrir a segunda (dois saves do mesmo jogador vivos lado a lado).

### O que ficou de fora

- **Lembrete de missão de ROTA e de missão global.** O pedido dizia "missão da conta", e as badges são exatamente
  isso (`badges.js` mede a carreira); as missões globais (`MISSOES`) zeram a cada run e medem o save, então "falta
  pouco" nelas chama pra terminar uma coisa que o jogador já vai ver ao abrir o jogo.
- **Escolher no ⚙ Ajustes QUAIS lembretes receber.** Quatro caixinhas pra uma notificação por dia no máximo é mais
  UI que benefício. Se alguém reclamar do chefe da semana, aí vira caixinha.
- **Um "aviso" automático a cada deploy de patch notes.** O aviso global é um botão no 🧰 Editor de conteúdo (📢,
  pré-preenchido com o título da versão mais nova de `PATCH_NOTES`), não um gatilho. Deploy não é notícia: boa
  parte das versões é conserto, e avisar todas acaba com a credibilidade da notificação.
- **iPhone com o jogo no navegador.** O Safari só entrega push pra site adicionado à tela de início. Está dito no
  README, nos patch notes e na própria tela de ⚙ Ajustes.

## 🥚 O choco ganha modal, e o push perde a hora boa (09/10/2026)

**O pedido** (do usuário): foi dormir com três ovos no ninho, os três chocaram de madrugada e não recebeu nenhum
aviso — a janela de "hora boa" (ver seção acima) empurrou o `quando` pra manhã, e por essa hora o jogo já tinha
sido reaberto sozinho. Pedido explícito: "pode mandar a qualquer momento", e o choco em si devia ser "algo mais
interativo" que uma linha de log — uma tela mostrando o Pokémon que nasceu.

**Duas mudanças independentes, mesma conversa:**

1. **`emHoraBoa`/`JANELAS` saíram de `lembretes.js`.** O `quando` de todo lembrete (ovo, badge, parceiro parado,
   chefe) volta a ser só `agora + prazo`, sem empurrar pra 7–9 h/15–22 h. O único limite que resta é o cron, que
   gira de hora em hora (`supabase/LIGAR-LEMBRETES.sql`) — por isso o corpo do lembrete do ovo continua sem
   contagem de minutos ("faltam 25 min" escrito na última sessão ainda chegaria atrasado).
2. **`amizade.chocar` abre um modal** (`ui.ask`, classe `.ovo-nasceu`) com o sprite do filhote (`imgMon`/
   `spriteFrente`, os mesmos de `render.js`) e o nome, depois das linhas de log de sempre (natureza, golpe-ovo,
   herança). Chocar vários ovos de uma vez (comum depois de uma noite fora) mostra um modal por ovo, em sequência
   — é o mesmo padrão de `ask` encadeado que `progressao.checkEvolution` já usa pra evolução.

**Por que não avisar ANTES de abrir o jogo qual Pokémon nasceu:** o choco só acontece no CLIENTE — o relógio só
credita os minutos retroativamente quando `main.abrirJornada` chama `cuidarDosOvos({ explorando: false })`. O
servidor nunca sabe a espécie (e nem deveria: o ovo é segredo, ver acima), então o push continua dizendo só "está
pronto", e é abrir o jogo que revela — a parte "interativa" do pedido mora no modal, não na notificação.

### O que ficou de fora

- **Botão/ajuste pra escolher janela de horário.** O usuário pediu "sem hora boa" de propósito, não "outra janela".
  Se um dia virar reclamação (push de madrugada incomoda), a janela volta como ajuste opt-in, não como padrão.
- **Deep link do push pra uma tela específica.** Só existe UMA tela (o jogo inteiro), e `abrirJornada` já roda
  `cuidarDosOvos` sozinho a cada abertura — não há "tela do ovo" separada pra apontar. O clique do push já abre
  (ou foca) a aba existente (`sw.js:notificationclick`), que é o que importa.

## 🪐 A terceira leva de golpes: chão, aperto e fim de turno (13/10/2026)

O relato vinha junto do bug dos ovos: *"ajuste mais moves, Yawn, Magnetic Rise e Gravity não estão funcionando
por exemplo, me liste todos os moves que ainda faltam"*. Os três caíam no `Mas nada aconteceu...` — e o pedido da
lista é o que fez esta leva ser **escolhida por levantamento**, não por palpite.

### O levantamento, e por que `dados-ref/` existia pra isto

A conta de "quantos golpes faltam" sai de cruzar `dados-ref/golpes.tsv` (a Pokédex-fonte, 💾 gerada, não a API
REST) com duas coisas do código: `especiais.GOLPES_ESPECIAIS` e os `ailment` que `golpe.aplicarStatus` sabe
resolver. Um golpe **funciona** se tem poder (passa pela fórmula de dano), ou mudança de atributo, ou cura, ou um
`ailment` tratado, ou uma linha na tabela de especiais. O resto diz "será ajustado".

Tirando Z-Move, Max/G-Max e os golpes Shadow (nada disso é aprendível aqui), o levantamento deu **121 golpes sem
efeito nenhum**. Esta leva fechou **39 deles** — e as duas armadilhas do levantamento valem registro:

- **`confusion` e `infatuation` NÃO estavam faltando.** `AIL_MSG` (`dados.js`) tem só os 5 status maiores, porque
  é a tabela de "o que escrever quando pega"; confusão e paixão são tratados **antes** dela em `aplicarStatus`,
  por morarem no `vol`. Um levantamento ingênuo marca 15 golpes como quebrados por isso.
- **O dump de `dados-ref/` é de 2020** e tem o metadado **vazio** nos golpes de Gen 8/9 (Victory Dance aparece
  sem `stats`). Na API VIVA eles vêm completos e funcionam. São 8 nomes: `victory-dance`, `shelter` e
  `hard-press` já funcionavam; `power-shift`, `revival-blessing`, `doodle`, `shed-tail` e `chilly-reception` não.

### Os 5 grupos, e o que cada um custou

| grupo | golpes | o que foi preciso construir |
|---|---|---|
| 🪐 chão e flutuação | Gravity, Magnet Rise, Telekinesis, Smack Down, Thousand Arrows | `vol.noSolo` / `vol.voando` + 3 linhas em `regras` |
| 🪢 aperto | Bind, Wrap, Fire Spin, Clamp, Whirlpool, Sand Tomb, Magma Storm, Infestation, Snap Trap, Thunder Cage | **um** `ailment` em `aplicarStatus` |
| ⏳ fim de turno | Yawn, Nightmare, Ingrain, Aqua Ring, Perish Song, Wish | um campo no `vol` cada, resolvido em `fimDeTurno` |
| 📊 estágios e HP | Haze, Psych Up, Belly Drum, Topsy-Turvy, Pain Split, Power Trick, Power/Guard/Heart Swap, Speed Swap, Guard/Power Split | contas puras sobre o que o motor já guardava |
| 💥 dano fixo e poder | Sonic Boom, Dragon Rage, Seismic Toss, Night Shade, Psywave, Super Fang, Nature's Madness, Final Gambit · Return, Frustration, Magnitude, Tri Attack, Splash, Celebrate, Happy Hour, Refresh, Sappy Seed | `regras.danoFixoDe` + 3 fórmulas de poder |

**O aperto foi o melhor negócio da leva:** dez golpes com UMA linha, porque a PokéAPI já os descreve pelo mesmo
`ailment: 'trap'`. Nenhum deles tem entrada em `especiais.js` — e se a API trouxer um décimo primeiro, ele
funciona sozinho. É o oposto de uma lista nossa pra manter.

### A regra que a gravidade quebrava

A gravidade é **o único efeito de campo que marca cada Pokémon**, não só um número do `campo`: enquanto ela vale,
todo mundo em campo precisa sentir o terreno, pisar nos espinhos e levar golpe Terrestre. Duas saídas foram
consideradas:

1. **`campo` por parâmetro** em `noChao(m, campo)` e `eficacia(hu, tipo, alvo, campo)`. Honesto, e **espalhado**:
   `noChao` é chamado em 8 lugares, `eficacia` em 4, e `calcDamage` recebe `clima`/`terreno`/`lado` separados, não
   o campo — a conta não para de crescer.
2. **Marca no `vol` de quem está em campo** (`vol.noSolo`, `vol.gravidade`), posta por `mudarGravidade` e tirada
   por `passarGravidade`. Zero threading: `noChao`, `eficacia` e `motivoBloqueio` continuam lendo só o Pokémon.

Foi a 2. O preço é que `passarGravidade(campo, ctx, mons)` precisa da **lista de quem está em campo** — e ela já
estava na mão nos dois pontos que contam os turnos (`batalha.js` e `mp-motor.js` montam essa lista pro fim de
turno). O `vol.noSolo` guarda a **origem** (`'gravidade'` × `true`): sem isso, a gravidade passando levantaria de
volta quem o Thousand Arrows tinha derrubado de vez.

**Quais golpes a gravidade proíbe não é lista nossa.** A flag `gravity` da PokéAPI (uma das 21 de
`dados-golpe-flags.js`) existe exatamente pra isso, e `regras.motivoBloqueio` a lê — então as 3 telas de golpe, a
IA e o motor respeitam de graça, pelo mesmo caminho do Taunt e do Encore. Flag nova na API = golpe novo proibido,
sem commit.

### O que a IA precisou saber

Golpe sem linha em `notaDoGolpe` vale `IGNORADO`, e aí o inimigo **o usa em cima de um já ativo** — um Hypno
gastaria quatro turnos bocejando. Cada grupo ganhou a sua: a gravidade vale muito contra quem flutua e nada
contra quem já está no chão; Magnet Rise só presta se o alvo tiver golpe Terrestre; Pain Split só se o alvo tem
muito mais HP; Final Gambit só quando o troco derruba. O dano fixo precisava de linha **própria** porque
`calcDamage` não sabe calculá-lo (o poder é 0 ou mentira) — sem ela a IA o tratava como golpe de poder nulo.

### O que ficou de fora, por motivo

- **Copiar/usar golpe alheio** (Mimic, Metronome, Mirror Move, Transform, Sketch, Sleep Talk, Copycat, Assist,
  Nature Power, Me First, Instruct): todos pedem **executar um golpe que não é o escolhido**, e o `ppLeft`/`meta`
  do golpe copiado tem de vir de algum lugar. É um sistema, não uma tabela.
- **Substitute** (e o Shed Tail, que depende dele): uma camada de HP entre o golpe e o Pokémon, lida por todo
  efeito de status, dreno, recuo e contato. O maior item que sobrou.
- **Trocar habilidade** (Role Play, Skill Swap, Gastro Acid, Simple Beam, Entrainment, Worry Seed, Doodle):
  `hab(m)` lê `m.ability`, que **vai no save** — mexer nele pede o mesmo cuidado do `abilityAntes` do Trace, e
  o `endBattle` teria de desfazer sete caminhos novos.
- **Trocar item** (Trick, Switcheroo, Bestow, Corrosive Gas, Recycle, Fling, Natural Gift, Teatime): o inimigo
  **não segura item** hoje, então metade deles não teria o que trocar. Mesma razão do Heavy-Duty Boots.
- **Contra-ataque** (Counter, Mirror Coat, Metal Burst, Bide): precisa guardar **quanto e de que classe** foi o
  último dano recebido neste turno — estado de turno que o motor não tem.
- **Ordem do turno** (Trick Room, After You, Quash) e **proteção de lado** (Wide Guard, Quick Guard, Crafty
  Shield, Mat Block): já estavam no backlog pelo mesmo motivo (reordenar `acoes` / proteger um lado inteiro).
- **Tirar imunidade** (Foresight, Odor Sleuth, Miracle Eye): é o avesso do `vol.noSolo` desta leva e caberia bem,
  mas pede uma marca "ignore a imunidade DESTE tipo neste alvo" em `eficacia` — vale como leva própria.
- **Os que dependem de trocar de Pokémon** (Healing Wish, Lunar Dance, Revival Blessing, Chilly Reception):
  mesma família do Shed Tail e do Eject Button, já documentada em "Travas, IA e troca de Pokémon".
- **Sticky Web e Lucky Chant**: caberiam em `LADO_VAZIO` com pouca coisa, mas a teia só pega **quem entra em
  campo** — e do seu lado ninguém entra, como o `esp.armadilha` já avisa. Ficaram pra quando (se) houver troca.

**Saldo: 121 → 82 golpes sem efeito.** A conta se refaz a qualquer momento cruzando `dados-ref/golpes.tsv` com
`GOLPES_ESPECIAIS` + os `ailment` de `aplicarStatus` — não há lista escrita à mão pra envelhecer.

## 🥚 "Só o primeiro par põe ovo" — e o Riolu que nunca ia pôr (13/10/2026)

> *"Peguei 2 Starly para breedar, logo após coloquei 2 Riolu, mas só vem ovos de Starly, nunca de Riolu."*

**Não era bug de sorteio.** `ovos.acharPar` varre todos contra todos e **sorteia** entre os pares (`pares[
Math.floor(sorte() * pares.length)]`) desde que existe — dois casais válidos dão 50/50. O que foi descartado no
diagnóstico, nesta ordem: o sorteio (lido e testado), a montagem do `grupos` (o `grupos.has(nome)` dedupa certo
porque a checagem é síncrona), e o `MAX_OVOS` (ovo que choca libera a vaga).

**O Riolu é que não cruza.** Ele é **bebê**, e bebê está no grupo-ovo `no-eggs` nos jogos — a espécie só põe ovo
depois de evoluir (vale pra Pichu, Igglybuff, Munchlax, Riolu…). `dados-ref/especies.tsv` responde isso em uma
linha: `riolu … no-eggs`, contra `starly … flying`. `parCompativel` estava **certo**.

**O defeito era de TELA, e é o mesmo de 06/10.** `situacaoDoNinho` devolvia só `pares[0]`: com um casal de Starly
funcionando, a frase era "Starly e Starly se dão bem" e **nada** dizia que os dois Riolu ao lado estavam ali de
enfeite. Quem joga não tem como adivinhar o grupo-ovo de uma espécie. Mecânica sem porta de entrada na tela é
mecânica que não existe — e aqui a tela estava pior que calada: estava **respondendo sobre outro casal**.

O conserto são duas frases, nenhuma mecânica nova:

- **`ovos.semParNoNinho`** (pura, testada): quem não entrou em casal nenhum, com o **motivo** — `nao-cruza`
  (bebê/lendário/mítico), `sem-sexo` (só com Ditto), `sem-par` (tem tudo, mas ninguém combina aqui) e
  `desconhecido` (ficha de espécie fora do cache). Os quatro motivos são frases diferentes de propósito: "não dá"
  e "ainda não sei" não são a mesma informação.
- **"São 2 casais aqui — o ovo sai de um deles, sorteado"**, quando `quantos > 1`. O campo `quantos` já existia e
  ninguém lia.

**Por que não "deixar o bebê cruzar"**: seria inventar regra, não portar. A fidelidade aqui é o que faz o jogador
que conhece os jogos reconhecer o sistema — e quem não conhece agora **aprende pela tela**, que é o lugar certo.

## 🎭 Cópia, Substituto e troca de habilidade — as três famílias caras (13/10/2026)

As três que a leva anterior deixou de fora por serem "sistema, não tabela". O pedido veio no mesmo dia, e o
levantamento continuou sendo o juiz: **82 → 62 golpes sem efeito**, 21 fechados (20 da lista + o Snore, que
nunca esteve nela — ele TINHA efeito e era engolido por uma trava, o que é pior).

### 🎭 Copiar golpe alheio: o problema era de onde vem o OBJETO

Mimic, Metronome, Mirror Move, Copycat, Sleep Talk, Assist, Nature Power, Me First, Instruct e Transform têm um
problema só em comum: **executar um golpe que não é o escolhido**. O que faltava não era a execução — era o
objeto do golpe, com tipo, poder, `meta` e PP. `vol.ultimo` guarda só o NOME.

**A virada**: o objeto nunca precisa de busca nova. *Quem usou um golpe sabe esse golpe, e o moveset dele está em
campo.* `golpeDeNome(nome, donos)` procura o nome nos movesets de quem for candidato, e com isso Mirror Move,
Copycat, Instruct, Mimic e Sketch saem de graça; Metronome e Assist sorteiam no mesmo lugar.

| golpe | de onde vem | candidatos |
|---|---|---|
| Mirror Move, Mimic, Sketch | `t.vol.ultimo` | o alvo |
| Copycat | `campo.ultimo` | todos em campo |
| Instruct | `t.vol.ultimo` | o alvo (e é **ele** quem age) |
| Sleep Talk | sorteio | os seus outros golpes |
| Assist | sorteio | os companheiros |
| Metronome | sorteio | todos em campo |
| Me First | `t.vol.golpeEscolhido` | — (×1,5 de poder) |
| Nature Power | `GOLPE_DO_TERRENO` | — (tabela) |

**`usarCopia` NÃO é uma chamada recursiva de `usarGolpe`**, e isso é a decisão central. O golpe de cópia já
passou por tudo o que decide "consigo agir?" (sono, paralisia, recuo, confusão, travas) e já gastou o próprio PP
— repetir aquele bloco faria o **Sleep Talk falhar na trava de sono que ele existe pra furar**. `usarCopia` é o
MIOLO de `usarGolpe`: anuncia, marca o `ultimo` e chama `executar` por alvo, que é a porta única de todo efeito.
São 12 linhas. O que ela deixa de fora, consciente: golpe de dois turnos **não carrega** (sai na hora) — e é por
isso que Fly, Dig, Solar Beam & cia. estão em `SEM_COPIA` junto dos golpes de cópia.

**`regras.SEM_COPIA` é a trava de recursão e a regra dos jogos ao mesmo tempo.** Metronome sorteando Metronome,
ou dois Mirror Moves se espelhando, não têm fim; e os jogos já excluem a maioria desses de Metronome/Mimic. Uma
lista serve às duas coisas.

**Dois defeitos achados pelos próprios testes:**

- **Copycat copiava a si mesmo.** `usarGolpe` grava `campo.ultimo = g.name` ANTES de `statusEspecial` rodar — e
  o Copycat lia esse campo três linhas depois, dentro do mesmo turno. O conserto não foi mudar a ordem: foi
  **golpe de cópia não entrar na memória da luta** (`if (podeCopiar(g.name))`), que é a regra dos jogos de todo
  jeito e fecha o furo num lugar só.
- **Worry Seed e Simple Beam miravam em quem usou.** O `quem` lia `esp.copiaHabilidade`, que nesses dois é
  `undefined` — caía no `[u]` do fim. `poeHabilidade` entrou na mesma condição de `proAlvo`.

**Nature Power virou TABELA, não busca.** Os 5 golpes (Tri Attack · Thunderbolt · Energy Ball · Moonblast ·
Psychic) têm tipo, poder e precisão que **não mudam desde que existem**, e a alternativa era uma chamada de rede
no meio do turno — justo o que a armadilha "busca não essencial não pode derrubar o fluxo" manda evitar. É a
mesma decisão de `dados-golpe-flags.GOLPE_AREA`.

**Metronome tem um teto consciente**: ele sorteia entre os golpes que **alguém em campo sabe**, não entre os ~900
do jogo. Rolar um id aleatório pediria rede a cada uso (cache miss garantido), poderia cair num Z-Move ou num Max
Move, e quebraria offline. Com 8 a 24 golpes em campo a imprevisibilidade continua de pé, o dado é sempre
correto, e nunca falha. Está marcado com `ponytail:` no código.

**Snore era um bug silencioso, não um efeito faltando.** Ele tem poder 50 e `meta` completo — nunca apareceu no
levantamento. Mas a trava de sono do topo de `usarGolpe` devolvia "está dormindo profundamente" antes de ele
sair, então o golpe era inutilizável e **nada na tela dizia isso**. Uma condição (`soNoSono`) consertou ele e
habilitou o Sleep Talk de uma vez.

### 🪆 Substituto: um ponto só, e um `return`

O medo era que o boneco fosse uma camada que **todo** efeito tivesse de consultar — status, dreno, recuo,
contato, roubo de item, saída forçada. Não é, porque `executar` é a porta única: uma condição no topo dele, com
`return`, já garante tudo de uma vez.

```
golpe de status  → "o substituto bloqueia o golpe"
golpe de dano    → bate no boneco; o excesso ao estourar se PERDE
```

Quem atravessa é quem tem a flag **`authentic`** da PokéAPI (a flag "ignora substituto" — Snore, Heal Bell e os
golpes de troca de habilidade já vêm marcados, sem lista nossa) e quem tem **Infiltrator** (`atravessaTelas`, a
mesma habilidade que fura tela e salvaguarda). O boneco mora em `vol.substituto`, então morre sozinho ao sair de
campo e no fim da batalha — zero migração, zero desfazer.

**Shed Tail saiu junto, de graça**: `{ substituto: 1/2, revezamento: true }`. O `revezamento` já existia e
`usarGolpe` o resolve depois do retorno de `statusEspecial`.

**O teto consciente**: recuo e dreno não contam o dano feito ao boneco (nos jogos contam). É o único efeito de
QUEM ATACA que o `return` engole junto, e replicá-lo custaria repetir o bloco de dano inteiro. Marcado com
`ponytail:`.

### 🧠 Trocar habilidade: quase tudo já existia

Role Play, Skill Swap, Entrainment, Doodle, Simple Beam e Worry Seed escrevem em `m.ability` guardando a antiga
em `m.abilityAntes` — **o mesmo caminho do Trace e do Mummy**, que `golpe.desfazerTrace` (já chamado no
`endBattle`) desfaz. A família custou um ajudante de três linhas.

**Gastro Acid é o único que não troca nada.** Ele liga `vol.semHabilidade`, e `habilidades.hab` lê:

```js
export const hab = m => m?.vol?.semHabilidade ? {} : HABILIDADES[m?.ability] || {};
```

Uma linha, no ponto por onde **toda** leitura de habilidade do jogo passa — então a anulação vale em tudo de uma
vez. Melhor que `m.ability = null` por três razões: morre sozinho ao sair de campo (que é a regra dos jogos),
não encosta no save, e **a ficha continua mostrando qual habilidade o Pokémon tem**, que é a informação certa
pra quem olha.

**`ABILIDADE_TRAVADA` virou `TRAVADAS` (um Set) e ganhou `forecast`.** Stance Change já estava barrada do
Trace/Mummy porque é mecânica do motor (a troca de forma do Aegislash); a do Castform entrou pelo mesmo motivo —
e porque o Transform, que copia a habilidade do alvo, usa a MESMA caixa `formaBase` que o Castform. Copiar
Forecast faria `ajustarForma` reescrever os tipos de um Pokémon transformado no meio da luta.

### 🎭 Transform: três caixas que já estavam prontas

Transform copia tipos, atributos (menos o HP), habilidade, sprite e os 4 golpes com 5 PP. Nada disso mexe em
`m.data` direto — aquele objeto vem do cache e é **compartilhado por toda a espécie**:

| o que copia | onde guarda o original | quem desfaz |
|---|---|---|
| tipos e sprite | `m.formaBase` (a caixa do Castform) | `desfazerForma`, já no `endBattle` |
| atributos | `m.statsAntes` | `desfazerCopia` (novo) |
| moveset | `m.movesAntes` (o mesmo do Mimic) | `desfazerCopia` (novo) |
| habilidade | `m.abilityAntes` (a caixa do Trace) | `desfazerTrace`, já no `endBattle` |

`desfazerCopia` é a única peça nova, e entra na MESMA linha do `endBattle` que já desfazia Mega, Tera, Dynamax,
Forma, Ash-Greninja e Trace. **Sketch é o único de propósito permanente** — é a razão de existir do Smeargle —, e
por isso nem passa por lá: grava no save e pronto.

### O que ficou de fora destas três famílias

- **Magic Coat e Snatch** (refletir/roubar o golpe de status alheio): não são "usar outro golpe", são
  **interceptar o golpe do outro antes de ele resolver**. Precisariam de um gancho na fila de ações, que é o
  mesmo que falta pro After You e pro Instruct de verdade (o nosso faz o alvo repetir, mas fora da ordem).
- **Transform copiando Mega/Tera/Dynamax** do alvo: a cópia leva os atributos JÁ transformados (o que é certo),
  mas não a gimmick em si. Virar um Charizard Mega Y por Transform exigiria rodar `mega.js` num Ditto.
- **Imprison** (proíbe os golpes que VOCÊ também sabe): é da família de `motivoBloqueio` e caberia bem, mas a
  trava precisa ler o moveset do OUTRO lado — e `motivoBloqueio(m, g)` é puro e recebe só um Pokémon.
- **Substituto com Baton Pass / Shed Tail passando o boneco pra quem cobre**: o `revezamento` tira quem usou e
  põe um aliado, e o boneco fica com quem saiu. Transferi-lo exigiria `forcarSaida` devolvendo QUEM entrou.

## 🏁 A cauda longa dos golpes: as 8 famílias que faltavam (13/10/2026)

O pedido foi "faça todos esses" sobre a tabela de famílias que o relatório anterior deixou. **65 → 0**: a
varredura de `dados-ref/golpes.tsv` × `GOLPES_ESPECIAIS` + os `ailment` de `aplicarStatus` hoje só acusa
`victory-dance`, `shelter` e `hard-press`, e esses três são **falso positivo do dump de 2020** (metadado vazio
nos Gen 8/9 que a API viva preenche — eles já funcionavam pelo caminho comum).

**Dois "bloqueios" estavam vencidos**, e esse foi o achado mais útil do levantamento:

- **"o inimigo não segura item"** — venceu quando `batalha.novoOponente` passou a dar item ao selvagem
  (`regras.itemDeSelvagem`, relato #77). Trick, Switcheroo e Corrosive Gas tinham com o que trabalhar desde
  então; a nota do backlog é que estava velha.
- **"o Sticky Web só pega quem entra em campo, e do seu lado ninguém entra"** — meia verdade. Do lado do
  **inimigo** entra sempre (treinador manda o próximo, a fila de lendários), e do seu lado o 🔄 revezamento traz
  o aliado de volta pelas armadilhas. A teia funciona onde importa.

### O padrão que fez 65 golpes caberem

Quase nada aqui é sistema novo. O que resolveu família após família foi sempre a mesma pergunta: **qual é a porta
única por onde isso já passa?**

| família | a porta única | custo |
|---|---|---|
| 👁 tirar imunidade (3) | `regras.eficacia` | 2 linhas — é o avesso do `vol.noSolo` da Gravidade |
| 🚫 Heal Block | `regras.heal` | 1 linha, e cobre as ~25 chamadas de cura do jogo |
| 🔒 Embargo e Magic Room | `segurados.seg` | 1 linha, e desliga os 76 itens segurados |
| 🔗 Imprison e Throat Chop | `regras.motivoBloqueio` | 2 linhas — as 3 telas, a IA e o motor obedecem de graça |
| 🛡 proteção de lado (6) | o `return` de `golpe.executar` | um laço sobre `GUARDAS_DE_LADO` |
| ⚔ contra-ataque (4) | `vol.ultimoDano` escrito no único ponto de dano | 1 escrita + 1 função pura |

**Imprison merece registro**, porque o motivo de ele estar na lista de "caros" era real e a saída foi lateral:
`motivoBloqueio(m, g)` é pura e recebe **um** Pokémon, então não podia ver o moveset do outro lado. A solução não
foi dar o outro lado pra ela — foi **copiar os nomes dos golpes em comum pro `vol` do alvo** na hora do golpe
(`vol.proibidos`). A lista viaja com quem foi selado, a função continua pura, e as 3 telas de golpe passaram a
respeitar o selo sem uma linha nova.

### 🎒 O item que volta na vitória (pedido do usuário, no meio da leva)

> *"moves que derrubam item ou trocam item, ao fim da batalha, se tiver vencido, os itens voltam ao normal"*

A regra ficou **uma**, e é ela que resolve a tensão: **o que era seu volta; o que você ganhou de mão vazia, fica.**

```js
export function desfazerItens(m) {
  if (!m || !('itemAntes' in m)) return null;
  const antes = m.itemAntes; delete m.itemAntes;
  if (antes && m.item !== antes) { m.item = antes; return antes; }   // o seu Restos volta
  return null;                                                       // o espólio do Thief fica
}
```

`'itemAntes' in m` em vez de `??=` **é a parte que importa**: "não tinha item" (`null`) e "ainda não anotei"
(`undefined`) precisam ser estados diferentes, e é essa diferença que mantém o Thief valendo a pena sem deixar
nenhum golpe do inimigo tomar o seu item pra sempre. O espólio de vitória já existia por outro caminho
(`itemCaiComoEspolio`), então não há duplicidade.

Quem mexe no item **anota** (`golpe.anotarItem`), e isso inclui o Knock Off e o Thief que já existiam —
retroativamente consertados pela mesma regra. **Perder ou fugir não devolve**: aí a perda vale, como qualquer
consequência de uma derrota. E `endBattle` ganhou o parâmetro `venceu`, passado pelas duas portas de vitória
(`win` e `vencerGen`).

**Item CONSUMIDO é outra coisa** e não entra: `gastarItem` (fruta comida, Faixa gasta, Erva usada, Fling
arremessado) grava em `vol.itemGasto` — que é de onde o ♻ **Recycle** o traz de volta — e nunca anota `itemAntes`.
Consumo não é roubo.

### ⏱ A peça que destravou cinco golpes de uma vez

After You, Quash, Trick Room, Magic Coat e Snatch estavam juntos no backlog por precisarem "de um gancho na fila
de ações". Eram dois problemas diferentes:

- **Trick Room** não precisava de gancho nenhum: `ordenarAcoes(acoes, sorte, invertido)` ganhou um parâmetro, e
  os dois motores já têm o `campo` na mão quando montam a fila. A sala inverte a **velocidade**, não a ordem toda
  — prioridade, Garra Rápida e Stall continuam valendo por cima, como nos jogos.
- **After You e Quash** precisavam mexer na fila **no meio** da rodada. Aí entrou `ctx.reordenar(m, modo)`, o
  mesmo desenho de `ctx.forcarSaida` e `ctx.abrirBrecha`: o motor só **pede**, quem tem a fila atende. Sem o
  gancho (luta de sala) o golpe diz que ali não dá, em vez de fingir.
- **Magic Coat e Snatch** não eram problema de fila: eram de **momento**. O que faltava era um ponto onde o golpe
  já está decidido e ainda não resolveu — e `executar` é exatamente isso. Duas condições no topo dele.

**E aqui o bug da leva**, que vale mais que a feature: a primeira versão de `batalha.reordenar` guardava
`agora: () => i` apontando pro `i` do `for` declarado **logo abaixo**, fora de escopo. `node --check` passou
(identificador solto é JS válido) **e o teste de unidade passou também** — porque lá o `ctx.reordenar` é
**mockado**: o mock provava o motor pedindo, nunca o jogo atendendo. É a armadilha do `T` do `win()` repetida,
com uma lição nova:

> **Mock de gancho de `ctx` testa metade do contrato.** Gancho novo = um caso em `tests/turno-smoke.test.js`, com
> o ctx de verdade.

O ponteiro virou um **campo** do objeto (`filaDoTurno.i`), atualizado dentro do laço, e o smoke test roda o
`turn()` inteiro com After You na mão.

### As traduções conscientes

Três golpes não têm análogo aqui e foram traduzidos em vez de recusados — cada um para o efeito que ele **tem**
nos jogos, não para a mecânica que ele usa:

| golpe | nos jogos | aqui | por quê |
|---|---|---|---|
| **Ally Switch** | troca de POSIÇÃO com o parceiro | o companheiro passa a receber os golpes mirados em você (`vol.chamariz`) | não há posições em campo, mas o *efeito* é esse — e é o mesmo campo do Follow Me; muda só quem decide |
| **Healing Wish / Lunar Dance** | você desmaia, o substituto que ENTRA vem curado | você desmaia, um companheiro **em campo** fica curado | é a mesma tradução que o Baton Pass já usava |
| **Revival Blessing** | revive alguém do banco | levanta um companheiro **caído em campo** com metade do HP | mesma família; sem ninguém caído, falha e diz |
| **Metronome** | qualquer golpe do jogo | sorteia entre os golpes de quem está em campo | id aleatório pediria rede por uso e quebraria offline (ceiling marcado com `ponytail:`) |

### O que ficou de fora, agora de verdade

A lista de golpes sem efeito acabou. O que sobrou são **tetos conscientes dentro de golpes que funcionam**, todos
marcados no código:

- **Recuo e dreno não contam o dano feito ao Substituto** (nos jogos contam) — o `return` que torna o boneco
  simples engole junto o único efeito de quem ATACA.
- **Golpe de dois turnos copiado sai na hora** em vez de carregar — e por isso Fly, Dig & cia. estão em
  `SEM_COPIA`.
- **Shed Tail não passa o boneco pra quem cobre**: o `revezamento` tira quem usou e põe um aliado, mas
  transferir o substituto exigiria `forcarSaida` devolvendo QUEM entrou.
- **Transform não copia a gimmick do alvo** (Mega/Tera/Dynamax). Leva os atributos já transformados, que é o
  certo; virar um Charizard Mega Y exigiria rodar `mega.js` num Ditto.
- **Fling usa uma tabela de 8 potências** (111 dos nossos 160 itens, agrupados) e `PODER_FLING = 30` pros 49 que
  a PokéAPI não classifica — todos itens nossos, inventados.
- **Natural Gift lê o tipo das 17 frutas de aperto** (`dados.FRUTA_DO_TIPO`, a fonte única) + as 3 de cura. As
  outras frutas dos jogos não existem aqui.

## 📱 Revisão de usabilidade do modo Roguelike: a tela inteira, medida no navegador (14/10/2026)

Pedido do usuário: *"revisão completa do modo Roguelike, analise todo o layout atual e traga melhorias de
usabilidade, foco máximo em qualidade, melhoria visual e usabilidade"*. Depois de um primeiro balanço, uma dica
dele mudou o método: **"faça lutas com 2 e 3 inimigos, a quantidade de informação nas lutas vai sobrecarregar a
tela"** — e sobrecarregava de verdade (ver "Grupo em campo"). Tudo abaixo foi **medido com o `olhar.mjs`**
(`getBoundingClientRect` + foto), nos tamanhos 360×640, 390×844, 844×390 (deitado) e 1280×800.

### O que a medição achou (antes → depois)

| Onde | Antes | Depois |
|---|---|---|
| **Explorar no computador (1280×800)** | botão em `y = 1144`, **350 px abaixo da dobra**; a zona (chips + Pokédex + Alfa) tinha ~800 px | preso na base da tela (`y ≈ 655`) |
| **Golpes na luta, computador** | começavam em `y = 694` (meio golpe à vista): o registro de 236 px ficava entre a cena e eles | `y ≈ 434`: cena → golpes → Mochila/Fugir → registro |
| **Cena da luta no celular (390×844)** | 321 px com `max-height:38vh` + rolagem interna: **a placa do SEU Pokémon era cortada** | 253 px, sem corte (placa ao lado do sprite) |
| **3 inimigos + 2 aliados, celular** | 790 px (cena); no computador, 753 px | 389 px (duas colunas) e 330 px |
| **Loja no computador** | abria no fim da coluna (`y ≈ 1056`): clicar em "Abrir loja" parecia não fazer nada | abre no topo, no lugar da zona |
| **Barra do topo no computador** | ~190 px (3 fileiras de botões) | 62 px: logo · carteira · ☰ |
| **Criação no celular** | 5.316 px | 3.784 px |

### Decisões (e o que foi descartado)

- **O dock de ações é `position:sticky; bottom:0`, nos três tamanhos — não "no topo da coluna".** Considerado
  e descartado: pôr o Explorar acima da zona no computador (posição estável, mas um botão amarelo gigante acima do
  título da rota lê como barra de ferramentas, e o celular precisa do rodapé de qualquer jeito). Um desenho só.
  `:not(.cheia)` deixa a Saga fora (HUD próprio); `:not(.em-batalha)` deixa os golpes de fora (um dock preso em
  cima da cena cobriria a placa).
- **A loja substitui a zona** (`:has(#actions.em-loja)` esconde `#scene` e a zona central) em vez de rolar a
  página até ela. Considerado: rolar com `scrollIntoView` — deixa a zona (800 px) entre o clique e a loja. A compra
  tem toast, então o registro escondido não deixa sem retorno. `case 'panel'` (main.js) volta ao topo ao abrir e
  fechar.
- **Golpes antes do registro, só por `order`** (`body.em-batalha #actions{order:1}`): o DOM e a tabulação ficam
  como estavam, e o celular deitado (que já fazia `order:-2`) ganha pela ordem no arquivo.
- **Sem aba, sem gaveta na luta fora da Saga.** A regra do CLAUDE.md ("não reintroduzir esconder painel por aba")
  continua: ficha, aliados, missões e mochila seguem na página, rolando. Considerado e descartado: levar a tela
  única da Saga (`.game.luta`) pros outros modos no celular — resolveria a altura, mas esconderia os painéis atrás
  de gavetas, que é exatamente o que quem joga recusou.
- **A cena só fica presa se sobra tela pro resto** (`cena-alta`, medido em `render()`): `offsetHeight >
  innerHeight − 240`. Presa com 470 px num celular de 640, ela cobria os golpes que o toque de rolar vinha buscar.
  Só no retrato; no deitado a cena é lateral e **sempre** fixa (a regra devolve `position:fixed`; foi o primeiro
  erro que a foto mostrou — a cena caía em `y = 1422`).

### Grupo em campo (a dica do usuário)

A placa é uma **linha e meia**, não quatro, no mesmo desenho que a luta da Saga já tinha: nome e nível numa linha
(truncar o nome era o pior erro de uma primeira versão — numa manada o nome é *quem é o bicho*), e embaixo a barra
de HP + **uma nuvem de etiquetas** (tipos, status, estágios, item) que quebra sozinha porque `.pl-tipos` e `.chips`
viram `display:contents`. Sem o rótulo "HP" (a barra colorida com os números já diz).

- **`compacta`** (2+ inimigos ou aliado): placas compactas em **qualquer** tamanho — no computador a cena de
  753 px virou 330 px. 1×1 continua com as placas largas.
- **`denso`** (5+ em campo): no celular EM PÉ cada Pokémon é uma **coluna** — inimigos numa fileira (placa em cima,
  sprite embaixo), o seu lado noutra (sprite em cima, placa embaixo). Revisto no mesmo dia: a 1ª versão eram duas
  colunas (inimigos | você) com as placas empilhadas no alto e os sprites em miniatura no pé, e quem joga mandou
  print de 3×2 dizendo "não faz sentido" — não dava pra ligar placa e sprite. `.plates`/`.mons-lado` viram
  `display:contents` e placa e sprite caem na mesma coluna da grade pela ordem (a do array nos dois). Deitado
  continua com duas colunas (inimigos | você): a regra do retrato exclui a tela baixa no próprio `@media`, porque
  o bloco deitado não desfaz `display:grid`/`contents`. No celular deitado a cena `compacta`
  vira duas colunas e a coluna da cena alarga
  (`--cena:min(47vw,430px)`): é a altura que falta ali, a largura sobra.
- **`com-aliados`** no seu lado: os sprites encolhem pra a placa ficar AO LADO deles (embaixo, a cena passava de
  440 px).
- O pedido de alvo ("Em quem usar X?") vira uma linha fina dentro da cena — era um balão de duas linhas que
  empurrava o "Cancelar" pra fora.
- **Armadilha de especificidade:** as regras da cena em grupo ganham de qualquer `.game.luta …` da Saga, então
  todas levam `body.em-batalha` (a classe que só existe fora dela). `tests/css-luta.test.js` cobra isso e o
  `position:fixed` do deitado. `tests/turno-smoke.test.js` cobra o contrato das classes (`compacta`/`denso`/
  `com-aliados`), que só existe no markup.

### O resto

- **Barra do topo:** `body:has(.game)` (era `.game.cheia`, só Saga) — logo · carteira · ☰, em todo tamanho. O ☰ abre
  em **duas colunas** (eram ~20 botões em fila) e ganha um ponto vermelho quando há 📜 Novidades (a barra cheia
  mostrava o selo "novo"; sem ela o aviso sumia).
- **Telas fora do jogo, celular:** os 13 atalhos viram uma **fileira que rola de lado** com máscara nas pontas
  (eram 4–5 linhas antes do título). Considerado: levá-los pro ☰ — `ui.limparTopo` está embaixo no grafo de imports
  e não pode importar `navegacao`; CSS resolve sem tocar no grafo.
- **Rotas no celular:** fileira que rola, com a atual centralizada por `centrarRota` (`render()` recria o DOM, e a
  fileira voltaria pro começo a cada ação — a rolagem que a pessoa deixou é devolvida).
- **Criação:** dificuldades não escolhidas em duas linhas (`-webkit-line-clamp`), mapas em 3 colunas (9 numa linha no
  computador — a Gen 9 ficava sozinha), **Opções da jornada** e **Chefes da semana** em `<details>` (abertos acima
  de 720 px, `larguraLarga()`), e o "Começar" **sticky dentro da prévia**.
- **Mochila:** item em duas linhas (texto em cima, botões embaixo) e volta pra uma linha quando o *painel* é largo —
  `container-type:inline-size` em `#p-mochila`, porque a pergunta é o tamanho do painel (que o jogador arrasta), não o
  da tela.
- **Botões `.btn.big` por tela:** um cheio só. O Desafiar do Alfa/lendários/evento usa a cor da própria caixa,
  vazado.
- **Toque:** `▲ ▼ ⇄ ▾` dos painéis com 38 px em `pointer:coarse` (eram ~22 px).
- **Registro:** esmaecido de 16 px no topo (a primeira linha aparecia cortada pela metade).
- **Fim de jornada:** "Nova jornada" sticky (ficava a ~1000 px do título).

### Ficou de fora, de propósito

- **Descrições de golpe e habilidade em inglês** (vêm da PokéAPI, que não tem PT-BR pra texto de efeito): é a maior
  quebra de qualidade que sobrou numa UI em PT-BR, mas é um projeto de **conteúdo** (~900 habilidades e ~900 golpes
  traduzidos e revisados), não de layout. Fica em `docs/backlog.md`.
- **Atalhos de teclado pros golpes (1–4):** `1` e `2` já são os itens rápidos (`data-rapido`), em batalha. Mexer
  nisso é decisão de quem joga no computador.
- **Sprite pequeno em Pokémon pequeno** (um Caterpie em 30 px): é a escolha documentada do `object-fit:scale-down`
  (nunca ampliar pixel art), não defeito.

### Como se confere de novo

Um roteiro por estado, não por tela: `olhar.mjs` + criar a jornada pela tela de verdade + `startBattle(zona)` de uma
rota **tardia** (`rotasAtuais()[5]`; as três primeiras nunca têm grupo) com `Math.random` fixado pra forçar o
tamanho do grupo (`[0.01, 0.99]` = grupo, máximo) e aliados na equipe. Estados a fotografar: 1×1, 2×0, 3×1, 3×2
**com** status/estágios/item em todos, e o pedido de alvo; em 360×640, 390×844, 844×390 e 1280×800.

## 🍖 Oferecer petisco com um toque (14/10/2026)

Pedido do usuário: *"um botão pra facilitar a captura nos outros modos que não sejam o saga, algo como um botão que
já joga os petiscos que o pokémon gosta que tem na bolsa"*.

**O que mudou na prática.** Fazer amizade era: Mochila → achar a divisão "Fazer amizade" → tocar no petisco → o turno
passa e o painel volta pros golpes → repetir 3–5 vezes. Agora, num selvagem e com petisco na mochila, há um botão
acima de Mochila / Fugir que escolhe o petisco e **repete a oferta, uma por turno**, até ele aceitar.

### Desenho (e o que foi descartado)

- **É `turn({ type: 'oferecer' })` num laço — nada da amizade foi reimplementado.** `batalha.oferecerPetiscos` chama a
  porta única das ações, então herda a narração, o turno inteiro do inimigo, o recrutamento (inclusive o `ask` de
  equipe cheia) e o fim de luta. Considerado e descartado: uma função própria "oferecer N vezes" — duplicaria
  `amizade.oferecer` e as duas divergiriam.
- **Só oferece o que ele GOSTA.** Petisco que ele não liga rende 0–5; gastar o toque, o turno e o petisco com isso é
  o erro que o botão existe pra evitar. Entre vários que agradam vai o de **maior estoque** (todos rendem o mesmo
  20–35; assim nenhum acaba antes dos outros), no empate a ordem do catálogo. A escolha é `regras.planoDoPetisco`.
- **Recusa "forte demais" ANTES de gastar.** `amizade.oferecer` GASTA o petisco e o turno e só depois diz que o alvo
  não confia (`podeFazerAmizade`, nível ≤ o seu +5). Pelo botão isso desperdiçaria um toque inteiro, então o plano
  barra antes e o botão fica desabilitado **dizendo o motivo** ("forte demais (aceita até Nv. 10)" / "nenhum que
  Inseto goste"). Sem petisco nenhum na mochila o botão nem aparece (quem nunca comprou não vê botão que não serve).
- **A repetição tem teto e freio, porque cada oferta é um TURNO** (o inimigo ataca, os aliados agem) e o Roguelike
  não tem segunda chance:
  - `OFERTAS_POR_TOQUE = 5` — é a conta de encher a barra: 100 ÷ 20, o MENOR ganho de um petisco que agrada. Cinco
    ofertas bastam pra qualquer não-lendário; lendário confia ~4× mais devagar e leva mais de um toque.
    `tests/petisco.test.js` prende o teto ao ganho mínimo — se um mudar, o outro tem de mudar.
  - `PISO_HP_OFERTA = 0.5` — com o seu HP na metade ou menos a repetição para e a decisão volta pra você. **A 1ª
    oferta sempre sai** (foi pedida num toque); o piso corta a REPETIÇÃO. Em luta de dois dígitos de nível, a
    metade costuma chegar na 2ª ou 3ª oferta: é o desenho, não defeito — o toque seguinte oferece mais uma.
  - Para também se um aliado cai (aliado que desmaia é perdido no Roguelike), se acabam os petiscos que ele gosta, se
    o alvo muda ou cai, e no **⏹ Parar** (que só levanta uma bandeira lida ENTRE os turnos: a oferta em andamento
    termina). **O motivo vai pro registro** — repetição que corta no meio sem dizer por quê parece botão quebrado.
  - Se `turn` recusar (o petisco não saiu da mochila) o laço sai: sem isso giraria pra sempre.
- **Em luta de grupo, pergunta pra quem** — a mesma escolha de alvo dos golpes, com `G.alvoDe = 'petisco'` no lugar
  do índice do golpe (`case 'alvo'` põe o escolhido em `B.foco`, que é o que `amizade.oferecer` lê). O rótulo diz o
  nome do inimigo em foco.
- **Fica de fora da Saga** (`modoJRPG`), como pedido: lá a comitiva tem caminho próprio. E de treinador, Alfa e chefe
  da semana, como `amizade.oferecer` sempre fez.

### Um buraco achado no caminho

O **chefe da semana não tinha guarda** em `amizade.oferecer`: ele não tem `trainer` nem `chefe` (só `evento`). Com o
piso de Nv. 70 dele, quem passava do 65 passava no `podeFazerAmizade` e podia fazer amizade com ele pela mochila.
Agora `B.evento` é recusado nos três lugares (`oferecer`, a divisão "Fazer amizade" da mochila e o botão), com
caso no smoke.

### Estado e teste

`G.ofertando = { parar, feitas }` é estado de TELA (não vai pro save; zera no `finally`). Cobertura:
`tests/petisco.test.js` (o plano, a escolha por estoque, o teto = conta, a parada) e um caso em
`turno-smoke.test.js` com `Math.random = 0` (ganho mínimo: 3 Méis = 60/100, nada de rede) — consome só o que ele
gosta, para quando acabam, com HP baixo sai UMA oferta, "forte demais" não gasta nada, treinador e chefe da semana
nem rodam.

## 🧪 Primeiro relato de testador da Saga, e o #82 (14/10/2026)

Um testador (conta `beta`) jogou os primeiros capítulos e mandou quatro pontos; o usuário mandou junto um print da
luta 3×2 fora da Saga (ver `denso` em "Grupo em campo", acima).

- **"Uma notificação eterna de missão, no meio da tela; tive que dar zoom out pra clicar onde queria."** É a faixa
  `.hud-missao`, que ficava sempre no topo do mapa e comia o toque de quem andava pro norte. Agora ela aparece
  quando a missão MUDA (chave = id + texto da etapa) e se recolhe em `MS_FAIXA` = 6 s (`saga-cena.faixaDaMissao`).
  O relógio é do MÓDULO, não do DOM — `render()` refaz o HUD a cada ação e reiniciaria a animação. Recolhida, ela
  continua no DOM com `visibility:hidden`: a margem dela é o que empurra a alavanca pro pé da tela. A animação
  apaga; um `setTimeout` em `ligarMundo` garante (sem animação — ⚙ Ajustes ou o sistema — ela ficaria).
  Considerado: um botão ✕ — é mais um alvo de toque no mapa, e o 📖 com a bolinha já é o lugar fixo da missão.
- **"Nada indica que dá pra passar pelas árvores pra outra rota; a trilha de baixo não vai a lugar nenhum."** A
  árvore (`carvalho`, 96×128) cobre 3×3 casas ACIMA do pé, então a copa da borda tampava a casa da porta e, no
  rodapé de Pedralume, o próprio ponto de partida (você nascia escondido). Duas regras genéricas, sem mexer em
  mapa: (1) cada enfeite grande leva `data-cobre` (as casas que ele cobre, saído de `PROPS`) e
  `posicionarMundo` deixa translúcida a copa com você atrás; (2) copa que cobre uma **saída pela borda** é sempre
  meio transparente (`vaza`), e a porta da borda ganha uma seta amarela pra fora (`.saida`, CSS puro — o Pi não
  tem fonte de emoji e o celular de alguém pode não ter também).
- **"Dependendo de onde você clica, fica parado na saída."** Tocar na folhagem acerta o TRONCO (parede), e
  `caminho` devolvia `[]`. Agora parede como destino leva à casa alcançável mais perto (até 3 casas), com a
  porta ganhando o empate — quem toca perto da borda quer sair.
- **"A missão da flor nunca some se você queima a vila."** A Selma some do acampamento quando ele é queimado ou
  esvaziado (`some`), e a missão `erva` ficava pra sempre em andamento. Campo novo de missão: **`falha`**, uma
  condição (`vale`) que, valendo, tira a missão das em andamento e a lista no diário como **perdida**. É derivado
  (nada gravado), conferido por `saga-validar` e editável no 🌍 Editor (aba Missões). Considerado: fechar a missão
  como concluída no efeito do fogo — mentiria no diário ("concluída") e exigiria `missao` aceitar lista.
  `tests/saga-mundo.test.js` prende a condição da missão à da Selma sumir.

**Relato #82 — Intimidate várias vezes em dupla/trio.** `startTrainerBattle` chamava `intimidar(m)` uma vez por
Pokémon enviado, e `intimidar` sem `soInimigo` já roda a entrada de TODOS em campo: com 3 enviados, cada
Intimidate (dos dois lados) disparava 3×. Uma chamada só. (#83, Fling sem gastar o item, já estava resolvido pela
leva de 13/10, com teste em `tests/especiais.test.js`.)
