/* PokéRPG — service worker: deixa o jogo abrir e jogar SEM internet depois do primeiro acesso online.
   - Arquivos do próprio jogo: pré-carregados na instalação (PRECACHE) e servidos "rede primeiro" — online
     sempre pega a versão nova (sem precisar trocar versão a cada deploy); offline cai no cache.
   - PokéAPI (dados), sprites, a biblioteca do Supabase (esm.sh) e fontes: "cache primeiro" — não mudam.
   - Supabase (login/banco) NUNCA passa pelo cache: offline falha e o jogo guarda pra enviar quando voltar.
   Todo arquivo novo em js/ precisa entrar em PRECACHE (tests/sw.test.js confere). */
const CACHE_JOGO = 'pokerpg-jogo-v1';
// v2: o v1 guardou sprites como resposta OPACA (fetch com no-cors), que o Chrome contabiliza inflada na cota do
// site — chegou a reportar 20 GB pra menos de 1 MB de imagem. Trocar o nome faz o activate apagar o cache antigo.
const CACHE_EXTERNO = 'pokerpg-externo-v2';
const PRECACHE = [
  // './' é a apresentação; o JOGO é './jogar.html' (mudou em 11/10/2026). Os dois no precache: quem salvou o
  // atalho na raiz continua achando a página, e quem abre o jogo offline acha o jogo.
  './', './index.html', './jogar.html', './css/estilo.css', './img/logo.png', './img/favicon-32.png', './img/icone-192.png',
  /* Sprites de item que a PokéAPI não desenhou (img/itens/, baixados por ferramentas/gerar-item-sprites.mjs e
     apontados por SPRITE_DO_ITEM). São arquivos NOSSOS, não do CDN de sprites: sem eles aqui, a mochila offline
     volta a mostrar a caixinha de reserva. Arquivo novo na pasta = linha nova aqui (tests/sw.test.js cobra). */
  './img/itens/auspicious-armor.png', './img/itens/black-augurite.png', './img/itens/cracked-pot.png',
  './img/itens/fresh-start-mochi.png', './img/itens/galarica-cuff.png', './img/itens/galarica-wreath.png',
  './img/itens/linking-cord.png', './img/itens/malicious-armor.png', './img/itens/peat-block.png',
  './img/itens/redea-espectral.png', './img/itens/scroll-of-darkness.png', './img/itens/scroll-of-waters.png',
  './img/itens/strawberry-sweet.png', './img/itens/sweet-apple.png', './img/itens/tart-apple.png',
  // páginas estáticas do site (GERADAS por ferramentas/gerar-paginas.mjs). Entram aqui porque o rodapé do jogo
  // linka pra elas: offline, um link que leva a "não foi possível conectar" é pior que link nenhum.
  './sobre.html', './guia.html', './privacidade.html', './termos.html', './contato.html',
  // capítulos do guia: linkados do índice (guia.html), que está acima — pular um deixaria um buraco no meio da leitura offline
  './guia-comecar.html', './guia-batalha.html', './guia-mundo.html', './guia-transformacoes.html', './guia-progresso.html', './guia-multiplayer.html',
  './js/ads.js', './js/consent.js', './js/tela-privacidade.js', './js/texto-privacidade.js', './js/site.js',
  './js/ajuda-chefes.js', './js/itens-raide.js', './js/ajustes.js', './js/alpha.js', './js/arena.js', './js/boss.js', './js/evento.js', './js/hall.js', './js/perfil-amigo.js', './js/perfil-dados.js', './js/amizade.js', './js/api.js', './js/batalha.js', './js/carreira.js', './js/config.js', './js/conta.js',
  './js/criacao.js', './js/dados.js', './js/dados-mapas.js', './js/dados-megas.js', './js/dados-item-sprites.js', './js/dados-golpe-flags.js', './js/dados-evolucao-restante.js', './js/dev.js', './js/mega.js', './js/tera.js', './js/zmove.js', './js/dynamax.js', './js/esconderijo.js', './js/ovos.js', './js/rastreio.js', './js/cenario.js', './js/dados-patchnotes.js', './js/efeitos.js', './js/especiais.js', './js/estado.js', './js/evolucao.js', './js/fim.js', './js/golpe.js', './js/habilidades.js', './js/itens.js',
  './js/layout.js', './js/loja-conta.js', './js/main.js', './js/mapas.js', './js/missoes.js', './js/mp-motor.js', './js/mp-sanear.js', './js/mp-regras.js', './js/mp-rede.js', './js/mp-cartao.js', './js/mp-resultado.js', './js/mp-telas.js', './js/multiplayer.js', './js/mundo.js', './js/navegacao.js', './js/novidades.js', './js/offline.js', './js/nuvem.js', './js/paineis.js', './js/segurados.js', './js/tela-ajustes.js', './js/tela-patchnotes.js', './js/tela-conquistas.js', './js/conquistas.js', './js/tela-pokedex.js', './js/pokedex-conta.js', './js/progresso-conta.js', './js/badges.js',
  './js/pokemon.js', './js/presenca.js', './js/progressao.js', './js/ranking.js', './js/regras.js', './js/relatos.js', './js/imagens-relato.js', './js/render.js', './js/roguelike.js', './js/saves.js', './js/tela-saves.js', './js/ui.js', './js/util.js', './js/som.js',
  './js/tutorial.js', './js/tela-tutorial.js', './js/tela-taxas.js', './js/auto.js', './js/notificacoes.js', './js/lembretes.js', './js/acordado.js',
  './js/dados-rotas.js',
  './js/conteudo.js', './js/conteudo-nuvem.js', './js/editor-rotas.js', './js/tela-editor-rotas.js',
  './js/dados-musica.js', './js/editor-musica.js', './js/tela-editor-musica.js',
  './js/editor-conteudo.js', './js/tela-editor-conteudo.js',
  './js/oficios.js', './js/pericias.js',
  './js/dados-saga.js', './js/dados-saga-mundo.js', './js/dados-saga-arte.js', './js/saga-arte.js', './js/saga-validar.js', './js/editor-saga.js', './js/tela-editor-saga.js', './js/saga-mundo.js', './js/saga-cena.js', './js/tela-saga.js'
];
// origens de terceiros que podem ir pro cache (conteúdo estável)
// cdn.jsdelivr.net é de onde vêm as imagens e os cries (espelho dos repositórios de sprites/cries da PokéAPI — ver dados.js);
// raw.githubusercontent.com fica na lista porque dados antigos guardados no aparelho ainda apontam pra lá
const EXTERNOS = ['pokeapi.co', 'cdn.jsdelivr.net', 'raw.githubusercontent.com', 'esm.sh', 'fonts.googleapis.com', 'fonts.gstatic.com'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE_JOGO).then(c => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys()
    .then(ks => Promise.all(ks.filter(k => ![CACHE_JOGO, CACHE_EXTERNO].includes(k)).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin === location.origin) { e.respondWith(redePrimeiro(req)); return; }
  if (EXTERNOS.some(h => url.hostname === h || url.hostname.endsWith('.' + h))) { e.respondWith(cachePrimeiro(req)); return; }
  // o resto (Supabase etc.) vai direto pra rede
});

async function redePrimeiro(req) {
  const cache = await caches.open(CACHE_JOGO);
  try {
    const resp = await fetch(req);
    if (resp.ok) cache.put(req, resp.clone());
    return resp;
  } catch {
    /* Navegação offline pra um endereço que não está no cache cai no JOGO, não na apresentação: quem está sem
       rede quer jogar, e a home é só texto. (Era './index.html' quando a raiz AINDA era o jogo.) */
    return (await cache.match(req, { ignoreSearch: true })) || (req.mode === 'navigate' ? cache.match('./jogar.html') : Response.error());
  }
}
/* `ignoreVary`: o mesmo sprite é pedido de dois jeitos — o download pra jogar offline (offline.js) usa `fetch()`,
   a tela usa `<img src>` — e o servidor de sprites responde com `Vary: Authorization,Accept-Encoding`. Quando os
   cabeçalhos das duas formas de pedir não batem, a Cache API responde "não tenho" com o arquivo guardado ali do
   lado, e offline isso vira ícone de imagem quebrada. O conteúdo é o mesmo PNG nos dois casos, então comparar
   cabeçalho aqui não protege de nada: ignorar o Vary só faz a entrada guardada servir os dois. */
/* ---- push (lembretes com o jogo FECHADO) ----
   Quem manda é supabase/functions/lembretes, com o título e o corpo já escritos (js/lembretes.js decide o texto;
   o servidor não conhece regra de jogo nenhuma). O `catch` do JSON não é zelo: um payload estranho que estoure
   aqui faz o Chrome mostrar a notificação genérica "Este site foi atualizado em segundo plano", que é pior que
   não avisar. `tag` junta: dois lembretes do mesmo motivo viram um, nunca uma pilha. */
self.addEventListener('push', e => {
  let d = {};
  try { d = e.data?.json() || {}; } catch { d = { titulo: 'PokéRPG', corpo: e.data?.text() || '' }; }
  e.waitUntil(self.registration.showNotification(d.titulo || 'PokéRPG', {
    body: d.corpo || '', tag: d.tag || 'pokerpg-lembrete', icon: './img/icone-192.png', badge: './img/favicon-32.png',
    data: { url: d.url || './jogar.html' }
  }));
});
/* Clicar tem de CAIR no jogo, e numa aba só: se já existe uma aberta, foca ela — abrir a segunda deixaria dois
   saves do mesmo jogador vivos lado a lado. `includeUncontrolled` porque a aba pode ter sido aberta antes deste sw. */
self.addEventListener('notificationclick', e => {
  e.notification.close();
  const url = e.notification.data?.url || './jogar.html';   // o lembrete abre o JOGO, não a apresentação
  e.waitUntil((async () => {
    const abas = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const minha = abas.find(c => new URL(c.url).origin === self.location.origin);
    if (minha) { await minha.focus(); return; }
    await self.clients.openWindow(url);
  })());
});

async function cachePrimeiro(req) {
  const cache = await caches.open(CACHE_EXTERNO);
  const hit = await cache.match(req, { ignoreVary: true });
  if (hit) return hit;
  try {
    const resp = await fetch(req);
    // opaque (sem CORS, ex.: <img>) também serve pra exibir; só não guarda erro
    if (resp.ok || resp.type === 'opaque') cache.put(req, resp.clone());
    return resp;
  } catch {
    return Response.error();
  }
}
