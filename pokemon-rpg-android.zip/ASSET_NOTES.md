# Notas de recursos visuais

O pacote Clover Valley V2 Free foi fornecido pelo usuário e está incluído em
`app/src/main/assets/clover_valley/`. O texto de leitura fornecido junto ao
pacote foi preservado em `CLOVER_VALLEY_README.txt`.

Antes de publicar ou redistribuir o jogo, confira os termos/licença na página
original de download do pacote. O arquivo de leitura incluído não especifica
uma licença completa nem condições de redistribuição.
