# RPG 2D para Android

Projeto inicial jogável de RPG 2D vertical para Android, com exploração, encontros, batalhas por turnos, progressão e salvamento local. O personagem do mapa usa sprites direcionais e animações do pacote Clover Valley V2 Free fornecido pelo usuário.

**Importante:** para evitar problemas de direitos autorais, esta implementação usa criaturas e nomes originais, sem artes, sprites, nomes ou outros recursos oficiais de Pokémon.

## Gerar o APK pelo GitHub (sem computador)
1. Crie um repositório vazio no GitHub pelo navegador do celular.
2. Envie os arquivos desta pasta para o repositório, mantendo a estrutura.
3. Abra **Actions** e habilite workflows, se o GitHub pedir.
4. Aguarde **Build Android APK** concluir.
5. Abra a execução concluída e baixe o artefato `rpg-debug-apk`.
6. Extraia o APK e instale no Android. Talvez seja necessário permitir a instalação pelo navegador/gerenciador de arquivos.

## Desenvolvimento
- Kotlin + Jetpack Compose
- Android SDK 35
- Gradle 8.9
- APK debug, sem assinatura de distribuição

## Recursos visuais
- Sprites de caminhada e repouso nas direções cima, baixo e lado; o sprite lateral é espelhado ao caminhar para a esquerda.
- Arquivos do pacote incluídos em `app/src/main/assets/clover_valley/`.
- Confira `ASSET_NOTES.md` e o arquivo de leitura do pacote antes de publicar/redistribuir.

## Correções desta versão
- Todos os botões direcionais passam pela mesma validação de limites e obstáculos.
- Direção do personagem é salva localmente.
- A animação de caminhada usa os seis quadros do sprite sheet.
- Uma vitória encerra os comandos da batalha para impedir vitórias/XP repetidos.
- Poções são limitadas a três no início, consumidas ao usar e permitem resposta do inimigo.
- Vantagens elementais seguem um ciclo Fogo > Natureza > Água > Fogo.
- Interface em tela imersiva.
