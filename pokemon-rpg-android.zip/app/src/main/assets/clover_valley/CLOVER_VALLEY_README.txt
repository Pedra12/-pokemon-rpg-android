Thank you for downloading the FREE version of the Clover Valley 16x16 Farming RPG Asset Pack!

This free pack includes a limited selection of assets to help you get started on your cozy farming RPG project.

If you enjoy these assets and want to unlock the full set with more animals, buildings, characters, enemies, tilesets, UI elements, and much more please consider supporting by purchasing the full pack.

Your support helps me continue creating and improving these assets!

⭐ If you like this pack, please leave a 5-star rating on the download page. It really means a lot!

Thanks again, and happy game making!

— Josee