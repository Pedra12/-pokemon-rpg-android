package br.com.aventuraelemental

import android.os.Bundle
import android.graphics.BitmapFactory
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlin.random.Random
import kotlinx.coroutines.delay

private val Ink = Color(0xFF172333)
private val Night = Color(0xFF111B2B)
private val Panel = Color(0xFF202F43)
private val Mint = Color(0xFF65E6B4)
private val Gold = Color(0xFFFFD166)
private val Paper = Color(0xFFF1F6F8)
private val Red = Color(0xFFFF7777)

data class Creature(
    val name: String, val element: String, val maxHp: Int,
    val attack: Int, val color: Color, var hp: Int = maxHp, var level: Int = 1
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
        setContent { MaterialTheme { GameScreen() } }
    }
}

@Composable
fun GameScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("save", 0) }
    var screen by remember { mutableStateOf("home") }
    var playerX by remember { mutableIntStateOf(prefs.getInt("x", 4).coerceIn(1, 7)) }
    var playerY by remember { mutableIntStateOf(prefs.getInt("y", 5).coerceIn(1, 8)) }
    var facing by remember { mutableStateOf(prefs.getString("facing", "down") ?: "down") }
    var steps by remember { mutableIntStateOf(prefs.getInt("steps", 0)) }
    var wins by remember { mutableIntStateOf(prefs.getInt("wins", 0)) }
    var message by remember { mutableStateOf("A trilha está quieta. Explore a região!") }
    var turn by remember { mutableIntStateOf(0) }
    var player = remember { Creature("Brasa", "FOGO", 44, 10, Color(0xFFFF855E)) }
    var enemy = remember { Creature("Musguito", "NATUREZA", 36, 8, Color(0xFF7ED6A5)) }
    var playerHp by remember { mutableIntStateOf(prefs.getInt("hp", 44).coerceIn(1, 44)) }
    var potions by remember { mutableIntStateOf(prefs.getInt("potions", 3).coerceIn(0, 99)) }
    var enemyHp by remember { mutableIntStateOf(36) }
    var enemyName by remember { mutableStateOf("Musguito") }
    var enemyElement by remember { mutableStateOf("NATUREZA") }
    var enemyColor by remember { mutableStateOf(Color(0xFF7ED6A5)) }
    var enemyMaxHp by remember { mutableIntStateOf(36) }
    var enemyAttack by remember { mutableIntStateOf(8) }
    var level by remember { mutableIntStateOf(prefs.getInt("level", 1).coerceIn(1, 20)) }
    var xp by remember { mutableIntStateOf(prefs.getInt("xp", 0).coerceAtLeast(0)) }
    var anim by remember { mutableIntStateOf(0) }
    var battleResolved by remember { mutableStateOf(false) }

    fun save() {
        prefs.edit().putInt("x", playerX).putInt("y", playerY).putInt("steps", steps)
            .putInt("wins", wins).putInt("hp", playerHp).putInt("potions", potions)
            .putInt("level", level).putInt("xp", xp).putString("facing", facing).apply()
    }
    fun startBattle() {
        val pool = listOf(
            Triple("Musguito", "NATUREZA", Color(0xFF7ED6A5)),
            Triple("Chispim", "FOGO", Color(0xFFFF855E)),
            Triple("Ondino", "ÁGUA", Color(0xFF69C7FF))
        )
        val pick = pool.random()
        enemyName = pick.first; enemyElement = pick.second; enemyColor = pick.third
        enemyMaxHp = 28 + level * 5; enemyHp = enemyMaxHp; enemyAttack = 5 + level * 2
        turn = 0; battleResolved = false; screen = "battle"
        message = "$enemyName apareceu! Escolha seu movimento."
    }

    fun movePlayer(dx: Int, dy: Int) {
        facing = when {
            dx < 0 -> "left"
            dx > 0 -> "right"
            dy < 0 -> "up"
            else -> "down"
        }
        val nx = playerX + dx
        val ny = playerY + dy
        if (nx !in 0..8 || ny !in 0..9) {
            message = "O limite da região impede você de avançar."
            return
        }
        if ((nx == 4 && ny == 2) || (nx == 4 && ny == 3)) {
            message = "Uma pedra antiga bloqueia o caminho."
            return
        }
        playerX = nx
        playerY = ny
        steps++
        message = listOf("O vento balança as folhas.", "Você ouve algo na grama.", "A trilha continua adiante.").random()
        if (nx in 1..7 && ny in 2..8 && Random.nextInt(100) < 19) startBattle()
        save()
    }

    fun elementMultiplier(attacker: String, defender: String): Double = when (attacker to defender) {
        "FOGO" to "NATUREZA", "NATUREZA" to "ÁGUA", "ÁGUA" to "FOGO" -> 1.5
        "FOGO" to "ÁGUA", "NATUREZA" to "FOGO", "ÁGUA" to "NATUREZA" -> 0.75
        else -> 1.0
    }

    Box(Modifier.fillMaxSize().background(Night)) {
        when (screen) {
            "home" -> Column(
                Modifier.fillMaxSize().padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("AVENTURA", color = Mint, fontSize = 16.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp)
                Text("ELEMENTAL", color = Paper, fontSize = 38.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(12.dp))
                Text("Uma região selvagem espera por você.", color = Color.LightGray, textAlign = TextAlign.Center)
                Spacer(Modifier.height(28.dp))
                CreatureArt(Color(0xFFFF855E), Modifier.size(150.dp))
                Spacer(Modifier.height(28.dp))
                BigButton("CONTINUAR A JORNADA") { screen = "world" }
                Spacer(Modifier.height(10.dp))
                Text("Nível $level  •  $wins vitórias  •  $xp XP", color = Gold)
                Spacer(Modifier.height(18.dp))
                Text("RPG original • Pixel-art • Salvamento local", color = Color.Gray, fontSize = 11.sp)
            }
            "world" -> Column(Modifier.fillMaxSize().padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("VALE DAS FOLHAS", color = Mint, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("Treinador Nv. $level  •  $xp XP", color = Paper, fontSize = 13.sp)
                    }
                    TextButton(onClick = { save(); screen = "home" }) { Text("MENU", color = Gold) }
                }
                Spacer(Modifier.height(10.dp))
                WorldMap(playerX, playerY, facing, steps)
                Spacer(Modifier.height(10.dp))
                Text(message, color = Paper, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp))
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    MoveButton("↑") { movePlayer(0, -1) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    MoveButton("←") { movePlayer(-1, 0) }
                    Spacer(Modifier.width(14.dp))
                    MoveButton("↓") { movePlayer(0, 1) }
                    Spacer(Modifier.width(14.dp))
                    MoveButton("→") { movePlayer(1, 0) }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("PASSOS", "$steps", Modifier.weight(1f))
                    StatCard("VITÓRIAS", "$wins", Modifier.weight(1f))
                    StatCard("VIDA", "$playerHp/44", Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                BigButton("PROCURAR CRIATURA") { startBattle() }
                Text("Dica: mova-se pela grama para encontrar criaturas.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            }
            "battle" -> Column(Modifier.fillMaxSize().padding(18.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("ENCONTRO SELVAGEM", color = Gold, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    Text("Nv. ${level}", color = Paper)
                }
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("$enemyName  Nv.${level}", color = Paper, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(enemyElement, color = Mint, fontSize = 11.sp)
                        HpBar(enemyHp, enemyMaxHp)
                        Text("$enemyHp / $enemyMaxHp PV", color = Color.LightGray, fontSize = 11.sp)
                    }
                    CreatureArt(enemyColor, Modifier.size(130.dp))
                }
                Spacer(Modifier.height(24.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF3A4B61)))
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    CreatureArt(player.color, Modifier.size(120.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Brasa  Nv.$level", color = Paper, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("FOGO", color = Gold, fontSize = 11.sp)
                        HpBar(playerHp, 44)
                        Text("$playerHp / 44 PV", color = Color.LightGray, fontSize = 11.sp)
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text(message, color = Paper, modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp), textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                Text("SEUS MOVIMENTOS", color = Mint, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoveCard("Faísca", "FOGO", Modifier.weight(1f)) {
                        if (screen == "battle" && !battleResolved) {
                            val mult = elementMultiplier("FOGO", enemyElement)
                            val dmg = ((10 + level * 2) * mult).toInt().coerceAtLeast(1)
                            enemyHp = (enemyHp - dmg).coerceAtLeast(0)
                            message = "Brasa usou Faísca! $dmg de dano."
                            anim++
                            if (enemyHp <= 0) {
                                battleResolved = true
                                wins++; xp += 12
                                if (xp >= level * 25) { xp -= level * 25; level++; message = "$enemyName caiu! Você subiu para o nível $level!" }
                                else message = "$enemyName caiu! +12 XP."
                                playerHp = (playerHp + 8).coerceAtMost(44)
                                save()
                            } else {
                                val incoming = (enemyAttack * elementMultiplier(enemyElement, "FOGO")).toInt().coerceAtLeast(1)
                                playerHp = (playerHp - incoming).coerceAtLeast(0)
                                message += " $enemyName revidou com $incoming de dano."
                                if (playerHp <= 0) { playerHp = 22; message += " Brasa descansou e recuperou parte da vida." }
                                save()
                            }
                        }
                    }
                    MoveCard("Investida", "NORMAL", Modifier.weight(1f)) {
                        if (screen == "battle" && !battleResolved) {
                            val dmg = 7 + level * 2
                            enemyHp = (enemyHp - dmg).coerceAtLeast(0)
                            message = "Brasa avançou! $dmg de dano."
                            anim++
                            if (enemyHp <= 0) {
                                battleResolved = true
                                wins++; xp += 10; playerHp = (playerHp + 6).coerceAtMost(44)
                                if (xp >= level * 25) { xp -= level * 25; level++; message = "Vitória! Você subiu para o nível $level!" } else message = "Vitória! +10 XP."
                                save()
                            } else {
                                playerHp = (playerHp - enemyAttack).coerceAtLeast(0)
                                message += " O rival revidou!"
                                if (playerHp <= 0) { playerHp = 22; message += " Brasa recuperou parte da vida." }
                                save()
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = !battleResolved && potions > 0 && playerHp < 44,
                        onClick = {
                            if (!battleResolved && potions > 0 && playerHp < 44) {
                                potions--
                                playerHp = (playerHp + 14).coerceAtMost(44)
                                val incoming = (enemyAttack * elementMultiplier(enemyElement, "FOGO")).toInt().coerceAtLeast(1)
                                playerHp = (playerHp - incoming).coerceAtLeast(0)
                                message = "Brasa usou uma poção. $enemyName revidou causando $incoming de dano."
                                if (playerHp <= 0) { playerHp = 22; message += " Brasa recuperou parte da vida." }
                                save()
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Poção +14 ($potions)", color = Mint) }
                    OutlinedButton(enabled = !battleResolved, onClick = { screen = "world"; message = "Você saiu do encontro."; save() }, modifier = Modifier.weight(1f)) { Text("Fugir", color = Paper) }
                }
                if (battleResolved) {
                    Spacer(Modifier.height(10.dp))
                    BigButton("VOLTAR AO MAPA") { screen = "world"; message = "A trilha continua. Sua equipe está pronta."; save() }
                }
                Spacer(Modifier.height(8.dp))
                Text("Vantagens: Fogo > Natureza, Natureza > Água e Água > Fogo.", color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center)
            }
            else -> Unit
        }
    }
}

@Composable
fun WorldMap(px: Int, py: Int, facing: String, stepCount: Int) {
    val context = LocalContext.current
    var walking by remember { mutableStateOf(false) }
    var walkFrame by remember { mutableIntStateOf(0) }
    LaunchedEffect(stepCount) {
        if (stepCount > 0) {
            walking = true
            repeat(6) { frame ->
                walkFrame = frame
                delay(75)
            }
            walking = false
            walkFrame = 0
        }
    }
    val spriteDirection = if (facing == "left" || facing == "right") "side" else facing
    val spritePath = if (walking) {
        "clover_valley/Character/Boy/Walk/walk_$spriteDirection.png"
    } else {
        "clover_valley/Character/Boy/Idle/idle_$spriteDirection.png"
    }
    val playerSprite = remember(spritePath) {
        runCatching {
            context.assets.open(spritePath).use { BitmapFactory.decodeStream(it).asImageBitmap() }
        }.getOrNull()
    }
    Column(Modifier.fillMaxWidth().background(Color(0xFF233D3A), RoundedCornerShape(18.dp)).border(2.dp, Color(0xFF46675C), RoundedCornerShape(18.dp)).padding(8.dp)) {
        Canvas(Modifier.fillMaxWidth().height(310.dp)) {
            val cols = 9; val rows = 10
            val cw = size.width / cols; val ch = size.height / rows
            for (y in 0 until rows) for (x in 0 until cols) {
                val grass = if ((x * 3 + y * 7) % 5 == 0) Color(0xFF2E5947) else Color(0xFF35684E)
                drawRect(grass, Offset(x * cw, y * ch), Size(cw - 1, ch - 1))
                if ((x + y) % 4 == 0) {
                    drawCircle(Color(0xFF4D8558), radius = cw * 0.07f, center = Offset(x * cw + cw * .3f, y * ch + ch * .6f))
                }
            }
            // caminho de terra
            for (i in 0..9) {
                val x = if (i < 5) 4 else 4 + (i - 5) / 2
                val y = i
                drawRect(Color(0xFFB89A68), Offset(x * cw, y * ch + ch*.25f), Size(cw, ch*.5f))
            }
            // lago
            drawOval(Color(0xFF4BA8CE), Offset(cw * 0.3f, ch * 1.0f), Size(cw * 2.3f, ch * 1.6f))
            // ruína
            drawRect(Color(0xFF9DA5A7), Offset(cw * 3.3f, ch * 1.4f), Size(cw * 1.4f, ch * .6f))
            drawRect(Color(0xFF68777C), Offset(cw * 3.5f, ch * 1.5f), Size(cw * .3f, ch * .3f))
            // personagem com sprite direcional real; fallback caso o arquivo não carregue
            val spriteSize = (minOf(cw, ch) * 1.55f).toInt().coerceAtLeast(1)
            val centerX = ((px + .5f) * cw).toInt()
            val centerY = ((py + .5f) * ch).toInt()
            if (playerSprite != null) {
                if (facing == "left") {
                    scale(-1f, 1f, pivot = Offset(centerX.toFloat(), centerY.toFloat())) {
                        drawImage(
                            image = playerSprite,
                            srcOffset = IntOffset((if (walking) walkFrame else 0) * 64, 0),
                            srcSize = IntSize(64, 64),
                            dstOffset = IntOffset(centerX - spriteSize / 2, centerY - spriteSize / 2),
                            dstSize = IntSize(spriteSize, spriteSize)
                        )
                    }
                } else {
                    drawImage(
                        image = playerSprite,
                        srcOffset = IntOffset((if (walking) walkFrame else 0) * 64, 0),
                        srcSize = IntSize(64, 64),
                        dstOffset = IntOffset(centerX - spriteSize / 2, centerY - spriteSize / 2),
                        dstSize = IntSize(spriteSize, spriteSize)
                    )
                }
            } else {
                drawCircle(Color(0xFFFFD166), radius = cw * .36f, center = Offset(centerX.toFloat(), centerY.toFloat()))
                drawCircle(Color(0xFF172333), radius = cw * .2f, center = Offset(centerX.toFloat(), centerY.toFloat()))
                drawCircle(Color.White, radius = cw * .09f, center = Offset(centerX.toFloat(), centerY.toFloat() - cw*.05f))
            }
        }
        Text("Lago Azul   •   Ruínas Antigas   •   Grama Alta", color = Color(0xFFC5E4D2), fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 5.dp))
    }
}

@Composable
fun CreatureArt(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width; val h = size.height
        // sombra
        drawOval(Color(0x55000000), Offset(w*.18f,h*.78f), Size(w*.64f,h*.12f))
        // corpo e orelhas
        drawCircle(color, radius = w*.31f, center = Offset(w*.5f,h*.53f))
        drawCircle(color, radius = w*.15f, center = Offset(w*.28f,h*.28f))
        drawCircle(color, radius = w*.15f, center = Offset(w*.72f,h*.28f))
        drawCircle(Color(0xFF26364A), radius = w*.045f, center = Offset(w*.4f,h*.48f))
        drawCircle(Color(0xFF26364A), radius = w*.045f, center = Offset(w*.6f,h*.48f))
        drawArc(Color(0xFF26364A), 15f, 150f, false, Offset(w*.4f,h*.53f), Size(w*.2f,h*.13f), style = Stroke(width = w*.025f))
        drawCircle(Color.White, radius = w*.018f, center = Offset(w*.41f,h*.465f))
        drawCircle(Color.White, radius = w*.018f, center = Offset(w*.61f,h*.465f))
        // detalhe brilhante
        drawCircle(Color(0x99FFFFFF), radius = w*.07f, center = Offset(w*.35f,h*.37f))
    }
}

@Composable
fun HpBar(value: Int, max: Int) {
    val fraction = (value.toFloat() / max.coerceAtLeast(1)).coerceIn(0f, 1f)
    Box(Modifier.fillMaxWidth().height(8.dp).background(Color(0xFF4B5664), RoundedCornerShape(8.dp))) {
        Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(if (fraction > .35f) Mint else Red, RoundedCornerShape(8.dp)))
    }
}

@Composable
fun BigButton(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink), shape = RoundedCornerShape(14.dp)) {
        Text(label, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
    }
}
@Composable
fun MoveButton(label: String, onClick: () -> Unit) {
    Box(Modifier.size(58.dp).background(Panel, RoundedCornerShape(16.dp)).border(1.dp, Color(0xFF41546C), RoundedCornerShape(16.dp)).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(label, color = Paper, fontSize = 25.sp, fontWeight = FontWeight.Bold)
    }
}
@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(12.dp)).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Paper, fontSize = 16.sp, fontWeight = FontWeight.Black)
    }
}
@Composable
fun MoveCard(title: String, type: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.height(76.dp).background(Color(0xFF293D52), RoundedCornerShape(14.dp)).border(1.dp, Color(0xFF425D76), RoundedCornerShape(14.dp)).clickable { onClick() }.padding(12.dp), verticalArrangement = Arrangement.Center) {
        Text(title, color = Paper, fontWeight = FontWeight.Black)
        Text(type, color = Mint, fontSize = 10.sp, letterSpacing = 1.sp)
    }
}
